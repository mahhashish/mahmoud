<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>About my little app</title>
</head>
<body>
  <h1>Hello Laravel 4!</h1>
  <p> Welcome to the Awesomeness! </p>
</body>
</html>