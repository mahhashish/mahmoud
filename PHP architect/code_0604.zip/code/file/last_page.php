<html>
<head>
<title>Files & folders - On-line Survey</title>
</head>
<body>

<table border=0><tr><td>
Thank you for your comments
<br/><br/>
</td></tr>
<tr bgcolor=lightblue><td>
your compliementary T-Shirt will be sent out <br/>
to you as soon as we can arrange it
</td></tr>
<tr><td>
<br/><br/>
<A href="signon.php">Return to First page</A>

</td></tr>
</table>