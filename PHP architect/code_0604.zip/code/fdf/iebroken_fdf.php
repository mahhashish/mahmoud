<?php
	$self = $_SERVER['PHP_SELF'];
	$basename = basename($self);
	if (ereg(".pdf$", $basename)){
		header("Content-type: application/pdf");
		header("Content-length: " . filesize($basename));
		readfile($basename);
	}
	else{
		error_log("Possible hack attempt from $_SERVER[REMOTE_ADDR]");
	}
?>
