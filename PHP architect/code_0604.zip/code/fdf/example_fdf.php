<?php
	// This will set up our $_PATH variables,
	// as well as work around a few Microsoft IE bugs,
	// and create an FDF for us
	require 'fdf_input.inc';
	
	// Listing 3:
	// Setting an FDF "button" to submit the fields as "HTML"
	// lets us process FDF submission exactly as we would an
	// HTML FORM using $_POST:
	if (isset($_POST) && count($_POST)){
		$corrects = array('fdf_is' => 'Adobe', 'bug_count' => 3, 'case_sensitive' => 'on');
		$high = count($corrects);
		$score = 0;
		reset($_POST);
		while (list($key, $value) = each($_POST)){
			if (isset($corrects[$key]) && ($corrects[$key] == $value)){
				$score++;
			}
			error_log("setting $key to $value");
			fdf_set_value($outfdf, $key, $value, 1);
		}
		$percent = sprintf("%02.2f", 100 * $score/$high);
		fdf_set_status($outfdf, "Your scored $score/$high for $percent%");
		
		// Hide the 'Grade Me' button, since they already took the Quiz:
		fdf_set_flags($outfdf, "save", FDFSetF, 2);
		
		@mail('php-article-announce-subscribe@phpbootcamp.com', "subscribe $_POST[email]", "subscribe $_POST[email]", "From: $_POST[email]\r\nReply-to: $_POST[email]\r\n");
	}
	
	// Listing 4:
	elseif (isset($_PATH) && count($_PATH)){
		// Pre-populate any presets from the URL
		// Feel free to surf to a URL such as:
		// /example_fdf/fdf_is/Adobe/iebroken8675309/example.pdf
		// to provide yourself a correct answer
		// on the first Quiz question:
		while(list($var, $value) = each($_PATH)){
			fdf_set_value($outfdf, $var, $value, 0);
		}
		// Solely for the sake of example, add some more
		// items to our popup menu dynamically.
		// The original hard-coded in the PDF only
		// has 1, 2, and 3.
		//fdf_set_opt($outfdf, "bug_count", 3, 'IV', 'Four');
		//fdf_set_opt($outfdf, "bug_count", 4, 'V', 'Five');
		//fdf_set_opt($outfdf, "bug_count", 5, 'VI', 'Six');
	}
	
	// Listing 2:
	// Pre-set the 'today' field to today's date:
	fdf_set_value($outfdf, 'today', date('Y-m-d'), 0);
	// Force the "today" field to be read-only:
	fdf_set_flags($outfdf, "today", FDFSetF, 1);
	
	// end of example_fdf
	
	// This will pull in the PDF template and
	// spew out our FDF to the browser
	require 'fdf_output.inc';
?>
