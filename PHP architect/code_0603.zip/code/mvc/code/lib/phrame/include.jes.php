<?php
require_once 'util/Object.php';
require_once 'util/ArrayList.php';
require_once 'util/HashMap.php';
require_once 'util/Stack.php';
require_once 'util/ListIterator.php';
//require_once 'ext/Xml.php';
require_once 'Constants.jes.php';
require_once 'Action.php';
require_once 'ActionController.jes.php';
require_once 'ActionForm.php';
require_once 'ActionForward.php';
require_once 'ActionMapping.php';
//added
require_once 'MappingManager.php';
?>
