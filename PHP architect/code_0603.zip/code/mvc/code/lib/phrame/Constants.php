<?php
//request contant(s)
define(_ACTION, 'action');
define(_VIEW, 'view');
//session constant(s)
define(_CONTROLLER, '_controller');
define(_ERRORS, '_errors');
define(_FORM, '_form');
//mappings constant(s)
define(_ACTION_FORMS, '_actionForms');
define(_ACTION_MAPPINGS, '_actionMappings');
define(_TYPE, '_type');
define(_NAME, '_name');
define(_INPUT, '_input');
define(_VALIDATE, '_validate');
define(_ACTION_FORWARDS, '_actionForwards');
define(_PATH, '_path');
define(_REDIRECT, '_redirect');
//options constant(s)
define(_CACHE, '_cache');
define(_ERROR_REPORTING, '_errorReporting');
define(_ERROR_HANDLER, '_errorHandler');
?>
