<?php $_config_vars = array (
  'site_title' => 'php|architect MVC Links Application',
  'short_site_title' => 'Links',
); return true; ?>