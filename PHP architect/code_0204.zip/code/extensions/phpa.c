/*
  +----------------------------------------------------------------------+
  | PHP Version 5                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2003 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.0 of the PHP license,       |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_0.txt.                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author:                                                              |
  +----------------------------------------------------------------------+
*/

/* $Id: header,v 1.14 2003/09/19 09:02:14 sniper Exp $ */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "php.h"
#include "php_ini.h"
#include "ext/standard/info.h"
#include "php_phpa.h"

/* If you declare any globals in php_phpa.h uncomment this:
ZEND_DECLARE_MODULE_GLOBALS(phpa)
*/

/* True global resources - no need for thread safety here */
static int le_phpa;

/* {{{ phpa_functions[]
 *
 * Every user visible function must have an entry in phpa_functions[].
 */
function_entry phpa_functions[] = {
	PHP_FE(confirm_phpa_compiled,	NULL)		/* For testing, remove later. */
	PHP_FE(phpa_my_true_love_gave_to_me, NULL)
	PHP_FE(phpa_get_gifts_range, NULL)
	PHP_FE(phpa_2d_array, NULL)
	PHP_FE(phpa_emit_ecard, NULL)
	PHP_FE(phpa_iterate_array, NULL)
	{NULL, NULL, NULL}	/* Must be the last line in phpa_functions[] */
};
/* }}} */

/* {{{ phpa_module_entry
 */
zend_module_entry phpa_module_entry = {
#if ZEND_MODULE_API_NO >= 20010901
	STANDARD_MODULE_HEADER,
#endif
	"phpa",
	phpa_functions,
	PHP_MINIT(phpa),
	PHP_MSHUTDOWN(phpa),
	PHP_RINIT(phpa),		/* Replace with NULL if there's nothing to do at request start */
	PHP_RSHUTDOWN(phpa),	/* Replace with NULL if there's nothing to do at request end */
	PHP_MINFO(phpa),
#if ZEND_MODULE_API_NO >= 20010901
	"0.1", /* Replace with version number for your extension */
#endif
	STANDARD_MODULE_PROPERTIES
};
/* }}} */

#ifdef COMPILE_DL_PHPA
ZEND_GET_MODULE(phpa)
#endif

/* {{{ PHP_INI
 */
/* Remove comments and fill if you need to have entries in php.ini
PHP_INI_BEGIN()
    STD_PHP_INI_ENTRY("phpa.global_value",      "42", PHP_INI_ALL, OnUpdateLong, global_value, zend_phpa_globals, phpa_globals)
    STD_PHP_INI_ENTRY("phpa.global_string", "foobar", PHP_INI_ALL, OnUpdateString, global_string, zend_phpa_globals, phpa_globals)
PHP_INI_END()
*/
/* }}} */

/* {{{ php_phpa_init_globals
 */
/* Uncomment this function if you have INI entries
static void php_phpa_init_globals(zend_phpa_globals *phpa_globals)
{
	phpa_globals->global_value = 0;
	phpa_globals->global_string = NULL;
}
*/
/* }}} */

/* {{{ PHP_MINIT_FUNCTION
 */
PHP_MINIT_FUNCTION(phpa)
{
	/* If you have INI entries, uncomment these lines 
	ZEND_INIT_MODULE_GLOBALS(phpa, php_phpa_init_globals, NULL);
	REGISTER_INI_ENTRIES();
	*/
	return SUCCESS;
}
/* }}} */

/* {{{ PHP_MSHUTDOWN_FUNCTION
 */
PHP_MSHUTDOWN_FUNCTION(phpa)
{
	/* uncomment this line if you have INI entries
	UNREGISTER_INI_ENTRIES();
	*/
	return SUCCESS;
}
/* }}} */

/* Remove if there's nothing to do at request start */
/* {{{ PHP_RINIT_FUNCTION
 */
PHP_RINIT_FUNCTION(phpa)
{
	return SUCCESS;
}
/* }}} */

/* Remove if there's nothing to do at request end */
/* {{{ PHP_RSHUTDOWN_FUNCTION
 */
PHP_RSHUTDOWN_FUNCTION(phpa)
{
	return SUCCESS;
}
/* }}} */

/* {{{ PHP_MINFO_FUNCTION
 */
PHP_MINFO_FUNCTION(phpa)
{
	php_info_print_table_start();
	php_info_print_table_header(2, "phpa support", "enabled");
	php_info_print_table_end();

	/* Remove comments if you have entries in php.ini
	DISPLAY_INI_ENTRIES();
	*/
}
/* }}} */


/* Remove the following function when you have succesfully modified config.m4
   so that your module can be compiled into PHP, it exists only for testing
   purposes. */

/* Every user-visible function in PHP should document itself in the source */
/* {{{ proto string confirm_phpa_compiled(string arg)
   Return a string to confirm that the module is compiled in */
PHP_FUNCTION(confirm_phpa_compiled)
{
	char *arg = NULL;
	int arg_len, len;
	char string[256];

	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "s", &arg, &arg_len) == FAILURE) {
		return;
	}

	len = sprintf(string, "Congratulations! You have successfully modified ext/%.78s/config.m4. Module %.78s is now compiled into PHP.", "phpa", arg);
	RETURN_STRINGL(string, len, 1);
}
/* }}} */
/* The previous line is meant for vim and emacs, so it can correctly fold and 
   unfold functions in source code. See the corresponding marks just before 
   function definition, where the functions purpose is also documented. Please 
   follow this convention for the convenience of others editing your code.
*/

static char *twelve_days_items[12] = {
	"a partridge in a pear tree",
	"two turtle doves",
	"three french hens",
	"four calling birds",
	"five gold rings",
	"six geese a-laying",
	"seven swans a-swimming",
	"eight maids a-milking",
	"nine ladies dancing",
	"ten lords a-leaping",
	"eleven pipers piping",
	"twelve drummers drumming"
};

/* {{{ proto string phpa_my_true_love_gave_to_me(int nthday)
   Returns a description of what my true love gave to me on the nthday of christmas */
PHP_FUNCTION(phpa_my_true_love_gave_to_me)
{
	long nthday;

	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC,
		   	"l", &nthday) == FAILURE) {
		return;
	}

	if (nthday < 1 || nthday > 12) {
		RETURN_FALSE;
	}

	RETURN_STRING(twelve_days_items[nthday-1], 1);
}
/* }}} */

/* {{{ proto array phpa_get_gifts_range(int nstart, int nend)
   Returns a description of what my true love gave to me on the days from nstart to nend of christmas, inclusive */
PHP_FUNCTION(phpa_get_gifts_range)
{
	long nstart, nend;
	int i;

	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC,
		   	"ll", &nstart, &nend) == FAILURE) {
		return;
	}

	if (nstart < 1 || nstart > 12 || nend < 1 || nend > 12) {
		RETURN_FALSE;
	}

	array_init(return_value);

	for (i = nstart; i <= nend; i++) {
		add_index_string(return_value, i, twelve_days_items[i-1], 1);
	}
}
/* }}} */

static const char *names[3][2] = {
	{ "Rasmus", "Lerdorf" },
	{ "Zeev",	"Suraski" },
	{ "Andi",	"Gutmans" }
};

/* {{{ proto array phpa_2d_array()
   Returns a 2d array of names */
PHP_FUNCTION(phpa_2d_array)
{
	int i, j;
	zval *tmparray;

	array_init(return_value);
	
	for (i = 0; i < 3; i++) {
		MAKE_STD_ZVAL(tmparray);
		array_init(tmparray);
		for (j = 0; j < 2; j++) {
			add_index_string(tmparray, j, names[i][j], 1);
		}
		add_next_index_zval(return_value, tmparray);
	}
}
/* }}} */

/* {{{ proto void phpa_emit_ecard(array fields)
   Emits a personalized e-card greeting */
PHP_FUNCTION(phpa_emit_ecard)
{
	zval *array;
	zval **name = NULL, **age = NULL;

	if (FAILURE == zend_parse_parameters(ZEND_NUM_ARGS()
			TSRMLS_CC, "a", &array)) {
		return;
	}

	if (SUCCESS == zend_hash_find(Z_ARRVAL_P(array), "name", sizeof("name"),
			(void**)&name)) {
		convert_to_string_ex(name);
		zend_printf("Hello '%s' ", Z_STRVAL_PP(name));
	}

	if (SUCCESS == zend_hash_find(Z_ARRVAL_P(array), "age", sizeof("age"),
			(void**)&age)) {
		convert_to_long_ex(age);
		zend_printf("Happy %dth birthday!", Z_LVAL_PP(age));
	} else {
		zend_printf("Happy birthday!");
	}
	
}
/* }}} */

/* {{{ proto void phpa_iterate_array(array array)
   For each element of the array, print the key and value */
PHP_FUNCTION(phpa_iterate_array)
{
	zval *array;
	char *strindex;
	int strindexlen;
	long intindex;
	zval **item;
	HashPosition pos;

	if (FAILURE == zend_parse_parameters(ZEND_NUM_ARGS()
			TSRMLS_CC, "a", &array)) {
		return;
	}

	zend_hash_internal_pointer_reset_ex(Z_ARRVAL_P(array), &pos);

	while(SUCCESS == zend_hash_get_current_data_ex(Z_ARRVAL_P(array), (void**)&item, &pos)) {

		switch (zend_hash_get_current_key_ex(Z_ARRVAL_P(array), &strindex, &strindexlen, &intindex, 0, &pos)) {
			case HASH_KEY_IS_STRING:
				/* binary safe */
				zend_printf("string(%d): ", strindexlen);
				PHPWRITE(strindex, strindexlen);
				break;
				
			case HASH_KEY_IS_LONG:
				zend_printf("long: %d ", intindex);
				break;
		}

		zend_printf(" => ");

		convert_to_string_ex(item);

		PHPWRITE(Z_STRVAL_PP(item), Z_STRLEN_PP(item));

		zend_printf("\n");
			
		/* don't forget to do this, otherwise you'll end up in an infinite loop */
		zend_hash_move_forward_ex(Z_ARRVAL_P(array), &pos);
	}

}
/* }}} */


/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
