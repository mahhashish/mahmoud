/*
  +----------------------------------------------------------------------+
  | PHP Version 5                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2003 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.0 of the PHP license,       |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_0.txt.                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author:                                                              |
  +----------------------------------------------------------------------+
*/

/* $Id: header,v 1.14 2003/09/19 09:02:14 sniper Exp $ */

#ifndef PHP_PHPA_H
#define PHP_PHPA_H

extern zend_module_entry phpa_module_entry;
#define phpext_phpa_ptr &phpa_module_entry

#ifdef PHP_WIN32
#define PHP_PHPA_API __declspec(dllexport)
#else
#define PHP_PHPA_API
#endif

#ifdef ZTS
#include "TSRM.h"
#endif

PHP_MINIT_FUNCTION(phpa);
PHP_MSHUTDOWN_FUNCTION(phpa);
PHP_RINIT_FUNCTION(phpa);
PHP_RSHUTDOWN_FUNCTION(phpa);
PHP_MINFO_FUNCTION(phpa);

PHP_FUNCTION(confirm_phpa_compiled);	/* For testing, remove later. */
PHP_FUNCTION(phpa_my_true_love_gave_to_me);
PHP_FUNCTION(phpa_get_gifts_range);
PHP_FUNCTION(phpa_2d_array);
PHP_FUNCTION(phpa_emit_ecard);
PHP_FUNCTION(phpa_iterate_array);

/* 
  	Declare any global variables you may need between the BEGIN
	and END macros here:     

ZEND_BEGIN_MODULE_GLOBALS(phpa)
	long  global_value;
	char *global_string;
ZEND_END_MODULE_GLOBALS(phpa)
*/

/* In every utility function you add that needs to use variables 
   in php_phpa_globals, call TSRM_FETCH(); after declaring other 
   variables used by that function, or better yet, pass in TSRMLS_CC
   after the last function argument and declare your utility function
   with TSRMLS_DC after the last declared argument.  Always refer to
   the globals in your function as PHPA_G(variable).  You are 
   encouraged to rename these macros something shorter, see
   examples in any other php module directory.
*/

#ifdef ZTS
#define PHPA_G(v) TSRMG(phpa_globals_id, zend_phpa_globals *, v)
#else
#define PHPA_G(v) (phpa_globals.v)
#endif

#endif	/* PHP_PHPA_H */


/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
