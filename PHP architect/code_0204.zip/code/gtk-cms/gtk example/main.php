<?php

if (!class_exists('gtk')) {
	if (strtoupper(substr(PHP_OS, 0, 3)) == 'WIN')
		dl('php_gtk.dll');
	else
		dl('php_gtk.so');
}

require_once("data.php");
require_once("defaults.php");

// select the first record in our array of records
// as the currently-edited record
$records = array_keys(news::enum_news());
$current_record = $records[0];



function cancel_confirm() {
	
	// Don't Save the record.
	// Just close the alertwindow and then do nothing.
	
	
}

function save_confirm() {
	global $current_record, $subject_field, $author_field, $story_field;
	
	// The user has the opportunity to see the changes
	// that occured sincle last time they connected
	
	create_dialog();
	
}

function change_selection() {
	global $list, $mode;
	
	if (!$mode) {
		
		$mode = true;
	
		if (!empty($list->selection)) {
		
			$i = 0;

			// Note: Sometimes we encounter a problem
			// where selections are not correctly handled
			// i.e. Even though an otion was selected, it
			// had a bug in telling me it was.
			// I limit it by saying the count of articles.
			// which is one more than required :-)
			
			while(!isset($index) && $i<count(news::enum_news())) {
				$list->unselect_item($i);
				if (empty($list->selection))
					$index = $i;
				$i++;
			}
			$list->select_item($index);

			// load the article at index
			$item = array_keys(news::enum_news());
			load_record($item[$index]);
	
		}
	
	$mode=false;
	
	}
	
}

function reload_interface_elements() {
	global $author_field, $list;

	// The list to the left and the authors will need
	// to be changed when records are saved
		

	$author_field->set_popdown_strings(news::enum_authors());
	
	
	// TODO: This does not seem to correctly append
	// the list in my version of PHP-GTK!
	
	foreach(news::enum_news() as $id => $news_item)
		$items[] = &new GtkListItem($news_item);

//	$list->clear_items(0,-1);  // BUG: php-gtk 0.5.0, not performing as expected!
	$list->append_items($items);
}
	

function load_record($recordID=false) {
	global $subject_field, $author_field, $story_field, $current_record;
	
	// Load a record into the current editing region
	
	// Change the current_record to this new record
	$current_record = new news($recordID);
	
	$story   = $current_record->story;
	$author  = $current_record->author;
	$subject = $current_record->subject;
	
	$story_field->delete_text(0, -1);
	$story_field->insert_text($story, 0);
	$subject_field->set_text($subject);
	$author_field_entry = $author_field->entry;
	$author_field_entry->set_text($author);

	
}


function create_dialog() {
	
	// todo: create a nice looking dialog that
	// works more efficient than this one.

	// Todo:  Also use an alert for when someone clicks the delete key on an item selected

	
	global $alert_window;
	
	if (!$alert_window) {
		$dialog = &new GtkDialog;
		$dialog->set_position(GTK_WIN_POS_CENTER);
		$alert_window = $dialog;
		$dialog->set_title('Syncronisation');
		$dialog->set_border_width(0);
		$dialog->set_usize(200, 110);
		$dialog->connect('delete_event', 'delete_event');

		$button = &new GtkButton('Cancel');
		$button->connect('clicked', 'cancel_confirm');

		$action_area = $dialog->action_area;
		$action_area->pack_start($button, true, true, 0);
		$button->show();
		$button = &new GtkButton('Save');
		$button->connect('clicked', 'save_confirm');
		$button->set_flags(GTK_CAN_DEFAULT);
		$button->grab_default();
		$action_area->pack_start($button, true, true, 0);
		$button->show();
		$vbox = $dialog->vbox;
		$label = &new gtkLabel('Error in syncronisation, please confirm');
		$vbox->pack_start($label);

	}
	
	
	
	if ($alert_window->flags() & GTK_VISIBLE)
		$alert_window->hide();
	else
		$alert_window->show();
}

/*
 * Called when delete-event happens. Returns false to indicate that the event
 * should proceed.
 */
function delete_event()
{
	return false;
}

/*
 * Called when the window is being destroyed. Simply quit the main loop.
 */
function destroy()
{
	// save the defaults and then quit
	Gtk::main_quit();
}


function sync()
{
	global	$window;
	print "Syncronising with the main server!\n";
	news::update_cache();
	
	// Update the main list to add any extras
	
}

function new_item() {

	global $window;
	print "Adding a new fake item\n";
	load_record($new);
	
	// Add another item onto the list
	
	
}

function quit()
{
	global $window;
	print "Quitting the main GTK App\n";
	
	$window->destroy();
	
}

function save_record() {
	global $current_record;
	
	// Check for changes.  If there were changes, then we have to show an alert.
	// If there weren't just save it.
	
	// We have to be online to save!
	
	$latest = new news($current_record->id);
	
	if ($latest->modified > $current_record->modified)
		save_confirm();  // Prompt the user if they want to override
	else	
		save(); // just save the record
}

function save() {
	global $current_record, $subject_field, $author_field, $author_entry, $story_field;
	
		if (is_object($current_record)) {
		
		$current_record->set_property('author', $author_entry->get_chars(0, -1));
		$current_record->set_property('subject', $subject_field->get_chars(0, -1));
		$current_record->set_property('story', $story_field->get_chars(0, -1));
		
		reload_interface_elements();
		load_record($current_record->id);
		
	} else {
		// Error - We should show an Alert
		print "Error: current_record is not an object\n";
		
	}

	
}

function save_new() {
	global $current_record, $subject_field, $author_field, $author_entry, $story_field;
	
	$current_record = new news();
	$current_record->set_property('visible', 1);
	
	$current_record->set_property('author', $author_entry->get_chars(0, -1));
	$current_record->set_property('subject', $subject_field->get_chars(0, -1));
	$current_record->set_property('story', $story_field->get_chars(0, -1));
		
	reload_interface_elements();
	load_record($current_record->id);
		

}


function close_window() {
	// The callback for 	
}


/*
 * Create a new top-level window and connect the signals to the appropriate
 * functions. Note that all constructors must be assigned by reference.
 */
$window = &new GtkWindow();
$window->connect_object('destroy', array('gtk', 'main_quit'));
$window->connect('delete-event', 'delete_event');

$new_button = &new GtkButton('Save as New');
$new_button->connect_object('clicked', 'save_new');

$sync_button = &new GtkButton('Syncronize');
$sync_button->connect_object('clicked', 'sync');

$save_button = &new GtkButton('Save');
$save_button->connect_object('clicked', 'save_record');

$subject_field = &new GtkEntry();
$subject_field->set_text('the_subject');
$author_field  = &new GtkCombo();

$author_entry = $author_field->entry;  // The name of the field component of the author combo

$story_field = &new GtkText();
$story_field->set_editable(true);
$story_field->set_word_wrap(true);


// Create layout boxes.  The First being a horizontal box
// The 1st in the horizontal box is another layout box for the 'options'

$master_box    = &new GtkHBox(false, 10);
$master_box->set_border_width(10);
$options_box    = &new GtkVBox(false, 10);
$options_box->set_border_width(10);
$edit_box      = &new GtkVBox(false, 10);
$edit_box->set_border_width(10);
$subject_box   = &new GtkHBox(false,10);
$author_box    = &new GtkHBox(false, 10);
$saveoptions_box = &new GtkHBox(false, 10);
$author_label  = &new GtkLabel('Author');
$subject_label = &new GtkLabel('Subject');


$list = &new GtkList();
$list->connect_object('selection-changed','change_selection');
$list->set_selection_mode(GTK_SELECTION_BROWSE);

// Add each of the news items to the list for the first time
reload_interface_elements();

	

// Create a scrolled window and add the list widget to it - this provides
// omatic scrollbars.
$scrolled_window = &new GtkScrolledWindow();
$scrolled_window->set_policy(GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
$scrolled_window->add_with_viewport($list);


// Fill the vertical box with 3 rows of information
$options_box->pack_start($scrolled_window);   // Main News
$options_box->pack_start($sync_button, false);       // A syncronisation Button      
$saveoptions_box->pack_start($save_button);
$saveoptions_box->pack_start($new_button);


$subject_box->pack_start($subject_label, false);
$subject_box->pack_start($subject_field);

$author_box->pack_start($author_label, false);
$author_box->pack_start($author_field);

$edit_box->pack_start($subject_box, false);
$edit_box->pack_start($author_box, false);
$edit_box->pack_start($story_field);
$edit_box->pack_start($saveoptions_box, false);

$master_box->pack_start($options_box);
$master_box->pack_start($edit_box);


// Add the vertical box to the window
// Set the title, name and size of the window

$window->add($master_box);
$window->set_title('Manage News');
$window->set_name('MainWindow');
$window->set_usize(600, 400);       // 300 pixels X, 400 pixels Y
$window->set_position(GTK_WIN_POS_CENTER);
$window->show_all();

// Run the Main GTK loop
Gtk::main();



?>