<?php

mysql_connect('localhost','root','');
mysql_select_db('news');

$GLOBALS['cache_policy_default'] = true;

class news {
	var $id;        // primary key auto_increment
	var $author;    // author
	var $subject;   // subject of the news article
	var $date;      // date the article was published
	var $story;     // body of the news
	var $visible;   // boolean, whether or not the record is visible

	function news($id=false, $live='cache_policy_default') {
		
		// The cache policy means where am I going to get the
		// data for this object from (bool)  If no boolean
		// is specified, we seek the configuration
		
		if ($live=='cache_policy_default')
			$live = $GLOBALS['cache_policy_default'];
		
		(int) $id;
	
		if ($id) {

			// Return them an offline version.  TODO: check it is available
			if (!$live)
				return $_SESSION['record'][$id];

			// else - go online
			
			$result = mysql_query("SELECT * FROM news WHERE id = '$id'");
			foreach(mysql_fetch_array($result) as $field => $value)
				$this->$field = $value;
			
		} else {
			
			// We need to create a new item

			mysql_query("INSERT into news (created) VALUES (UNIX_TIMESTAMP())");
			$this->id = mysql_insert_id();
		}
	}
	
	function update_cache() {
		foreach(news::enum_news() as $id => $subject) {

			$object = new news($id);
			// You may even store an object in a default
			$_SESSION['record'][$id] = $object;
		}
	}
	
	
	function set_property($property, $value) {
	
		// set a $property to value in the database
		// Note - this mechanism causes n(fields) database queries
		// to save data.  There are alternatives
		
		mysql_query("UPDATE news SET $property = '$value', modified = UNIX_TIMESTAMP() WHERE id = '".$this->id."'");
		$this->$property = $value;
	}
	
	function enum_authors($visible=true, $live='cache_policy_default') {

		// Return a list of the authors in the
		// database by either online or offline methods
		
		if ($live=='cache_policy_default')
			$live = $GLOBALS['cache_policy_default'];

		if ($visible)
			$subquery = "WHERE visible=1";


		$result = mysql_query("SELECT distinct(author) FROM news $subquery");
		while($r = mysql_fetch_array($result))
			$return[] = $r['author'];
			
		return $return;
		
	}
	
	function enum_news($visible=true, $live='cache_policy_default') {
	
		// return an enumerated list of news
		// by either online or offline methods
		
		if ($live=='cache_policy_default')
			$live = $GLOBALS['cache_policy_default'];

			if ($visible)
			$subquery = "WHERE visible=1";

		$result = mysql_query("SELECT subject,id FROM news $subquery");
		while($r = mysql_fetch_array($result))
			$news[$r['id']] = $r['subject'];
	
		return $news;
	
	}

}

?>