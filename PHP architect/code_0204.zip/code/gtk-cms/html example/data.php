<?php

mysql_connect('localhost','root','morgoth');
mysql_select_db('news');

class news {
	var $id;        // primary key auto_increment
	var $author;    // author
	var $subject;   // subject of the news article
	var $date;      // date the article was published
	var $story;     // body of the news
	var $visible;   // boolean, whether or not the record is visible

	function news($id=false, $disallow_cached=false) {
		
		(int) $id;  // cast the ID to an int to prevent haXors
	
		if ($id) {
			$result = mysql_query("SELECT * FROM news WHERE id = '$id'");

			foreach(mysql_fetch_array($result) as $field => $value)
				$this->$field = $value;
			
		} else {
			// Insert a dummy entry into the database
			mysql_query("INSERT into news (created) VALUES (UNIX_TIMESTAMP())");
			$this->id = mysql_insert_id();
		}
	}
	
	function set_property($property, $value) {
	
		// set a $property to value in the database
		// Note - this mechanism causes n(fields) database queries
		// to save data.  There are alternatives
		
		mysql_query("UPDATE news SET $property = '$value', modified = UNIX_TIMESTAMP() WHERE id = '".$this->id."'");
		$this->$property = $value;
	}
	
	function enum_news($visible=true) {
	
		if ($visible)
			$subquery = "WHERE visible=1";

		$result = mysql_query("SELECT subject,id FROM news $subquery");
		while($r = mysql_fetch_array($result))
			$news[$r['id']] = $r['subject'];
	
		return $news;
	
	}

}

?>