<?php include('data.php');?>
<?php

(int) $_POST['id'];

$news = new news($_POST['id']);

foreach($_POST as $field => $value) {
	if (get_magic_quotes_gpc())
		$news->set_property($field, $value);
	else
		$news->set_property($field, addslashes($value));

}


header("Location: index.php");


?>