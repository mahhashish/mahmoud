<?php include('data.php');?>
<?php

(int) $_GET['id'];

$news = new news($_GET['id']);

?>
<html>
	<head>
		<title>Edit News</title>
	</head>
	<body>
	
	<h2>Edit record <?php echo $news->id?></h2>
	<form method="POST" action="save.php">
	<INPUT type="hidden" name='id' value='<?php echo $news->id?>'>
	<table>
		<tr>
			<td>Subject</td>
			<td><input type='text' name='subject' value='<?php echo htmlentities($news->subject)?>'></td>
		</tr>
		<tr>
			<td>Author</td>
			<td><input type='text' name='author' value='<?php echo htmlentities($news->author)?>'></td>
		</tr>
		<tr>
			<td>Story</td>
			<td><TEXTAREA name="story" cols=72 rows=20><?php echo htmlentities($news->story)?></TEXTAREA></td>
		</tr>
	</table>

	<input type='submit' value='Save'>
	</form>
	
	
	</body>
</html>