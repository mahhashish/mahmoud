<?php include('data.php');?>
<?php

foreach(news::enum_news() as $id => $subject) {

	echo "<A href='edit.php?id=$id'>".htmlentities($subject)."</A><BR>\n";


}

?>