DROP TABLE IF EXISTS news;
CREATE TABLE news (
  id int(11) NOT NULL auto_increment,
  author varchar(64) NOT NULL,
  subject varchar(255) NOT NULL,
  story text NOT NULL,
  created int(10) NOT NULL,
  modified int(10) NOT NULL,
  visible tinyint(1) NOT NULL default '0',
  PRIMARY KEY (id)
);

INSERT INTO news VALUES (1,'Morgan Tocker','The pros and cons of OOP','Object oriented programming presents several advantages over traditional \'linear\' approaches. <ul>\n<li>Reusable Code - write it once</li>\n<li>Ease of Management - disect a larger problem into a series of smaller problems</li>\n<li>Buzz word compliance! - keep on the edge of the .COM lingo</li></ul>',1056947674,UNIX_TIMESTAMP(),1);
INSERT INTO news VALUES (2,'Morgan Tocker','Creating a database abstraction layer','Database abstraction layers provide many advantages over using multiple queries in your database.  Authentication - checking the credentials of the user before making changes.  Logging - create a log of server queries at the time of query.  more++',1056947674,UNIX_TIMESTAMP(),1);
INSERT INTO news VALUES (3,'Morgan Tocker','NEWS - PHP5 beta','PHP.net writes: <i> The PHP development community is proud to announce the release of PHP 5 Beta 1.  Both source packages,  and a Windows build are available in the Downloads Section .</i>',1056947674,UNIX_TIMESTAMP(),1);
INSERT INTO news VALUES (4,'Morgan Tocker','NEWS - PHP Survey','PHP.net writes: <i>PHPZend Technologies is sponsoring a public PHP Usage Survey.  The results will be shared with the PHP Group, and will help us to better understand the ways in which PHP is being used, and what may need improvement.</i>', 1056947674, UNIX_TIMESTAMP(),1);
INSERT INTO news VALUES (5,'Kable','Test message','This is a test message from Morgan.',1056947674,1056947674,1);
INSERT INTO news VALUES (6,'Admin','Clean the Kitchen!','All staff please note:\n\nPersonally I have had enough of the mess in there. \n\nAs of this morning we have started to remove every dirty cup and spoon left.   These will not be returned to the kitchen. \n\nManagement had planned to install a Cappuccino Machine etc.  But Not now. \n\nI came in this morning and you could not see the top of the bench.   We will not clean up your mess. \n\nOn a personal note I wonder why we bother at all. \n',1056947674,1056947674,1);
