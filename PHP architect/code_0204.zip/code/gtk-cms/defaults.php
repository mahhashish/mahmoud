<?php

function __session_open($save_path, $session_name)
{
	return true;
}

function __session_close()
{
	return true;
}

function __session_read($sessid)
{

	$fp = fopen($_SERVER['SCRIPT_FILENAME'].".defaults", 'rb');
	return fread($fp, filesize($_SERVER['SCRIPT_FILENAME'].".defaults"));

}

function __session_write($sessid, $val)
{

	$fp = fopen($_SERVER['SCRIPT_FILENAME'].".defaults",'wb');
	
	fwrite($fp,$val);
	fclose($fp);
}

function __session_destroy($sessid)
{
	return true;
}

function __session_gc($maxlifetime = 900)
{
	true;
}




session_set_save_handler('__session_open', '__session_close', '__session_read', '__session_write', '__session_destroy', '__session_gc');

if (!session_is_registered("default"))	{
	$default = array();
		session_register("default");
}

session_start();

?>