<?php

mysql_connect('localhost','user','password');

mysql_select_db('test2');

if(!isset($_POST['rel']))
{ $_POST['rel'] = 0; }

if(isset($_POST['article']) && !empty($_POST['article']))
{
    $query = "SELECT id, LEFT(article,20) AS content, MATCH
              (article) AGAINST ('{$_POST['article']}') AS rel
              FROM fulltext_test WHERE MATCH
              (article) AGAINST ('{$_POST['article']}') HAVING rel > {$_POST['rel']}";
    $rs = mysql_query($query) or die("1: " . mysql_error());

    if(mysql_num_rows($rs))
    {
        echo '<p>Similar Rows Found:';
        echo '<table border="1">';
        while($r = mysql_fetch_assoc($rs))
        { echo "<tr><td>{$r['id']}</td><td>{$r['content']}</td><td>{$r['rel']}</td></tr>"; }
        echo '</table>';
    }

    $query = "INSERT INTO fulltext_test (article) VALUES ('{$_POST['article']}')";
    $rs = mysql_query($query) or die("2: " . mysql_error());

    echo "<p>New Article Inserted";
}

{
    ?>
    <form method="POST" action="test.php">
    Article:<br />
    <textarea name="article" rows="10" cols="70"></textarea>
    <br />
    Rel Threshold: <input type="text" name="rel" value="<?=$_POST['rel']?>">
    <input type="submit" />
    </form>
    <?php
}

?>