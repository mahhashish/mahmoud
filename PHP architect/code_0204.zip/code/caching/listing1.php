<?php

require_once 'Cache/Lite.php';

$id = 'exampleId';

$options = array(
  'cacheDir' => '/tmp/',
  'lifeTime' => 3600
);

$cache =& new Cache_Lite($options);

if ($data = $cache->get($id)) {
	
  echo $data;

} else {
	
  $data = ?Data to be saved?;
  $cache->save($data);

}

?>