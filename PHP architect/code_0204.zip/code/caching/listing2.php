<?php

require_once ?Cache.php?;

$options = array('cache_dir', '/tmp/');
$cache = new Cache(?file?, $options);
$id = $cache->generateID(?exampleId?);

if ($data = $cache->get($id)) {
	
  echo $data;

} else {
	
  $data = ?Data to be cached?;
  $cache->save($id, $data);

}

?>