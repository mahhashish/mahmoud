<?php
require_once 'Cache/Lite/Function.php';

class YourClass
{
  function yourMethod($arg1, $arg2)
  {
    echo 'Output example';
    return 'Result example';
  }
}

$options = array('cacheDir' => '/tmp/', 'lifeTime' => 10);
$cache =& new Cache_Lite_Function($options);
$obj =& new YourClass;
$cache->call('obj->yourMethod', $arg1, $arg2);

?>