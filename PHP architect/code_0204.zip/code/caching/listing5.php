<?php

require_once 'Cache/Lite/Output.php';

$options = array('cacheDir' => '/tmp/', 'lifeTime' => 10);

$cache =& new Cache_Lite_Output($options);

if (!($cache->start('exampleId'))) {
	
  // Your code goes here.
  $cache->end();
  
}

?>