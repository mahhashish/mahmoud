<?php

require_once 'Cache/Lite/Function.php';

function your_function($arg1, $arg2)
{
  echo 'Output example';
  return 'Result example';
}

$options = array('cacheDir' => '/tmp/', 'lifeTime' => 10);
$cache =& new Cache_Lite_Function($options);
$cache->call('your_function', $arg1, $arg2);

?>