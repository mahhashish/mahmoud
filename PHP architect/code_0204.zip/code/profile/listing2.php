227 print ("<TR CLASS='serendipity_calendar'>");
228 for ($y=0; $y<7; $y++) {
229   // Be able to print borders nicely
230   $cellProp      = "";
231   if ($y==0) $cellProp = "FirstInRow";
232   if ($y==6) $cellProp = "LastInRow";
233   if ($x==4) $cellProp = "LastRow";
234   if ($x==4 && $y==6) $cellProp = "LastInLastRow";
235
236   // Start printing
237   if (($x>0 || $y>=$firstDayWeekDay) && $currDay<=$nrOfDays) {
238     if ($activeDays[$currDay] > 1) $cellProp.='Active';
239       print("<TD CLASS='serendipity_calendarDay$cellProp'>");
240
241     // Print day
242     if ($serendipity["rewrite"]==true)
243           $link = $serendipity["serendipityHTTPPath"]."archives/".
244                   date("Ymd", mktime(0,0,0, $month, $currDay, $year)).
245                   ".html";
246     else
247       $link = $serendipity["serendipityHTTPPath"];;
248     if (date("m") == $month &&
249       date("Y") == $year &&
250       date("j") == currDay) {
251       echo "<I>";
252     }
253     if ($activeDays[$currDay] > 1) {
254       print ("<A HREF='$link'>");
255     }
256     print ($currDay);
257     if ($activeDays[$currDay] > 1) print ("</A>");
258     if (date("m") == $month &&
259       date("Y") == $year &&
260       date("j") == $currDay) {
261       echo "</I>";
262     }
263     print("</TD>");
264     $currDay++;
265   }
266   else {
267     print "<TD CLASS='serendipity_calendarBlankDay$cellProp'>";
268     print "&nbsp;</TD>";
269   }
270 }
271 print ("</TR>");