function serendipity_markup_text($str, $entry_id = 0) {
  global $serendipity;

  $ret = $str;

  $ret = str_replace('\_', chr(1), $ret);
  $ret = preg_replace('/#([[:alnum:]]+?)#/','&\1;',$ret);
  $ret = preg_replace('/\b_([\S ]+?)_\b/','<u>\1</u>',$ret);
  $ret = str_replace(chr(1), '\_', $ret);

  //bold
  $ret = str_replace('\*',chr(1),$ret);
  $ret = str_replace('**',chr(2),$ret);
  $ret = preg_replace('/(\S)\*(\S)/','\1' . chr(1) . '\2',$ret);
  $ret = preg_replace('/\B\*([^*]+)\*\B/','<strong>\1</strong>',$ret);
  $ret = str_replace(chr(2),'**',$ret);
  $ret = str_replace(chr(1),'\*',$ret);

  // monospace font
  $ret = str_replace('\%',chr(1),$ret);
  $ret = preg_replace_callback('/%([\S ]+?)%/', 'serendipity_format_tt', $ret);
  $ret = str_replace(chr(1),'%',$ret) ;

  $ret = preg_replace('/\|([0-9a-fA-F]+?)\|([\S ]+?)\|/',
                      '<font color="\1">\2</font>',$ret);
  $ret = preg_replace('/\^([[:alnum:]]+?)\^/','<sup>\1</sup>',$ret);
  $ret = preg_replace('/\@([[:alnum:]]+?)\@/','<sub>\1</sub>',$ret);
  $ret = preg_replace('/([\\\])([*#_|^@%])/', '\2', $ret);

  if ($serendipity['track_exits']) {
    $serendipity['encodeExitsCallback_entry_id'] = $entry_id;

    $ret = preg_replace_callback(
      "#<a href=(\"|')http://([^\"']+)(\"|')#im",
      'serendipity_encodeExitsCallback',
      $ret
    );
  }

  return $ret;
}