<?php
apd_set_pprof_trace();
hello("George");
goodbye("George");

function hello($name)
{
  echo "Hello $name\n";
  sleep(1);
}

function goodbye($name)
{
  echo "Goodbye $name\n";
}
?>