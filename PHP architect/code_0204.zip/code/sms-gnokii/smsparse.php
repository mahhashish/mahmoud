<?
/*

	Sms parsing utility for gnokiis smsd database.
	LISTING 1
*/
error_reporting(E_ALL);

$CONFIG = array();
$CONFIG['keywords_directory'] = './keywords/';
$CONFIG['default_email'] = 'eric@persson.tm';
$CONFIG['database_username'] = 'root';
$CONFIG['database_password'] = '';
$CONFIG['database_hostname'] = 'localhost';
$CONFIG['database_database'] = 'sms';


/* 
	Error function, will handle an error in desired way. 
	Maybe add some notification functionality to notify an admin?
*/
function return_error($error=''){

	echo date('Y-m-d H:i:s').': '.$error;
	exit();
}


/* 
	Read through the keywords directory and gather filenames and keywords,
	that should be match by a message.
*/
function read_keywords(){
	global $CONFIG;


	$keywords = array();

	$dh = opendir($CONFIG['keywords_directory']);
	if( $dh ){
		while( $filename = readdir($dh) ){
			if( ereg('^([a-z0-9_]*).php$', $filename, $match) ){
				$keywords[$match[1]] = $CONFIG['keywords_directory'].$filename;
				echo date('Y-m-d H:i:s').': '.$match[1].chr(10);
			}
		}

		if( sizeof($keywords)==0 )
			return_error('Keyword directory was empty.');
		else
			return $keywords;
	
	}else{
		return_error('Keyword directory could not be opened.');		
	}

}

/* 
	This function will be executed if a message arrives that
	doesnt match any keyword.
*/
function default_action($message, $sender){
	global $CONFIG;

	#mail($CONFIG['default_email'], 'Unhandled sms', 'Message:'.$message."\n".'Sender:'.$sender);
	echo 'DEFAULT ACTION'.chr(10);
}

/* 
	This function takes the message and the sender as arguments
	and then performs an ereg match for each message. 
*/
function match_message($message, $sender){
	global $keywords;

	$match_message = ereg_replace('([^a-z0-9]*)', '', strtolower($message));
	reset($keywords);
	while( list($keyword, $phpfile)=each($keywords) ){
		if( ereg('^'.$keyword, $match_message) ){

			include_once($phpfile);
			if( function_exists($keyword) )
				$keyword($message, $sender);

			return true;
		}
	}

	default_action($message, $sender);
	return false;
}

/*
	A faster message match process, its not as nice to user mistakes as the one
	above, but its an option, if speed/processor time is important.
*/
function match_message_fast($message, $sender){
	global $keywords;

	if( strpos($message, ' ')>0 )
		$match_part = substr($message, 0, strpos($message, ' '));
	else
		$match_part = $message;

	$match_part = trim(strtolower($match_part));

	if( isset($keywords[$match_part]) ){
		include_once($keywords[$match_part]);
		if( function_exists($match_part) )
			$match_part($message, $sender);
		return true;
	}

	default_action($message, $sender);
	return false;

}

/*
	Just for speed measurements.
*/
function diff_microtime($microtime, $end_microtime){
	
	$start_seconds = substr($microtime, strpos($microtime, ' '), strlen($microtime));
	$start_fraction = substr($microtime, 0, strpos($microtime, ' '));
	$end_seconds = substr($end_microtime, strpos($microtime, ' '), strlen($microtime));
	$end_fraction = substr($end_microtime, 0, strpos($microtime, ' '));

	return sprintf('%1.3fs', (($end_seconds-$start_seconds)+$end_fraction-$start_fraction));

}


/* Connect to the mysql database */
$connection = mysql_connect($CONFIG['database_hostname'], $CONFIG['database_username'], $CONFIG['database_password']);

/* Check if the connection was successful, otherwise return an error. */
if( !$connection )
	return_error('Could not connect to mysql at '.$CONFIG['database_hostname']);

/* Select the database that contains the smsd tables */
mysql_select_db($CONFIG['database_database'], $connection) or return_error('Could not select database');


/* Call the read_keywords() function to get all keywords currently available. */
$keywords = read_keywords();

/* Reversesort the keywords by the arrays key element. */
krsort($keywords);

/*
	Application main loop.
	We will loop 100 times and then finish this script, to prevent memoryclogging.
*/
for( $i=0; $i<10000000; $i++ ){
	$microtime = microtime(); // speed measurements
	
	$res = mysql_query('SELECT * FROM inbox WHERE processed=0 ORDER BY insertdate ASC');
	while( $sms = mysql_fetch_array($res) ){
		
		/* Decide which matching function you wish to use. */
		match_message($sms['text'], $sms['number']);
		//match_message_fast($sms['text'], $sms['number']);

		mysql_query('UPDATE inbox SET processed=1 WHERE id='.$sms['id']);
	}

	/* Enable this for some performance statistics. 
	$end_microtime = microtime(); 
	echo "time:".diff_microtime($microtime, $end_microtime)."\n";
	*/

	sleep(1);
}

?>