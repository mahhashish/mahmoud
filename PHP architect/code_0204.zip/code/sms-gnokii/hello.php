<?
/*
	Example keyword file
	LISTING 2	
*/

function hello($message, $sender){

	$return_message = 'Hello to you my friend!';
	/* Output a log message */
	echo date('Y-m-d H:i:s').': Answeared message "'.$message.'" from "'.$sender.'" with "'.$return_message.'"'.chr(10);
	
	/* Send the reply to the sender */
	mysql_query('INSERT INTO outbox SET number="'.$sender.'", text="'.$return_message.'", processed_date="0", insertdate=now(), error=0, dreport=0');

}


?>