<html>
	<form action="session.php" method="post">
		<input type="text" name="login"/>
		<input type="password" name="password"/>
		<input type="submit" name="submit" value="Login!"/>
	</form>
</html>
