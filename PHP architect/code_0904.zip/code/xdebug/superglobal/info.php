<?php
	session_start();
	echo "You're logged in as {$_SESSION['login']}!";
?>
