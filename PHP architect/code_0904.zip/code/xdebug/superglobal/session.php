<?php
	if ($_POST['login'] == 'derick' &&
	    $_POST['password'] == 42)
	{
		session_start();
		$_SESSION['id'] = $_POST['login'];
		$_SESSION['hash'] = md5($_POST['login'] . $_POST['password']);
	}
	header("Location: info.php");
?>
