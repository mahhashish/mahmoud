<?php

include ("connect.php");

$sql = "SELECT * FROM config_fix";
$sql_result = mysql_query($sql); 

$row = mysql_fetch_array($sql_result);
$email_user = $row["email"];
$secret_location = $row["secret_dir"];
$secret_ext = $row["secret_ext"];

if (! function_exists ("md5_file")) {

	function md5_file ($path) {
		if (! is_readable ($path)) { return false; }

		$ret = md5 (implode ("", file ($path)));
		return ( ($ret) ? $ret : false);
	}
} 

print "File Fixer Robot <br>";

$sql_1 = "SELECT * FROM rep_wat WHERE md5_value = '' ";
$sql_result_1 = mysql_query($sql_1); 

while ($row_1 = mysql_fetch_array($sql_result_1)){ 

	$file_id = $row_1["id"];
	$file_to_MD5a = $row_1["file_path"];
	$file_to_MD5b = $row_1["main_file"];
	$file_to_MD5 = "$file_to_MD5a"."/$file_to_MD5b";
	$file_now_MD5 = md5_file($file_to_MD5);
	
	$secret_file_copy = "$secret_location$file_now_MD5.$secret_ext";
	
	print "<br>Trying to copy $file_to_MD5 to $secret_file_copy<br><br>";
	
	if(!copy($file_to_MD5, $secret_file_copy)){
		print "<br>Protection Failed<br>";
	}else{
		print "<br>File Protected<br>";
		$result = mysql_query("UPDATE rep_wat SET md5_value='$file_now_MD5' WHERE id='$file_id' ");
	}
}

$sql_2 = "SELECT * FROM rep_wat WHERE md5_value != '' ";
$sql_result_2 = mysql_query($sql_2); 

while ($row_2 = mysql_fetch_array($sql_result_2)){ 
	$file_id = $row_2["id"];
	$file_to_MD5a = $row_2["file_path"];
	$file_to_MD5b = $row_2["main_file"];
	$file_to_MD5 = "$file_to_MD5a"."/$file_to_MD5b";
	$file_now_MD5 = md5_file($file_to_MD5);
	
	$cached_MD5_value = $row_2["md5_value"];
	$secret_file_copy = "$secret_location$cached_MD5_value.$secret_ext";
	
	print "<br>Checking $file_to_MD5 against protected file<br><br>";
	
	if($file_now_MD5 == $cached_MD5_value){
		print "$file_to_MD5 is OK";
	}else{
		if(!copy($secret_file_copy, $file_to_MD5)){
			print "Can't replace $file_to_MD5";
		}else{
			mail("$email_user", "File Replaced", "Fixer Bot has detected a change in $file_to_MD5. File has been fixed.", "FROM:root@root.com");
			print "<br>File has been changed Security Level 1: Copying $secret_file_copy to $file_to_MD5<br>";
		}
	}
}

?>

