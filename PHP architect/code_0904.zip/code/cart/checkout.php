<? session_start();
if(isset($_POST['shippingzip'])) $_SESSION['shippingzip']=$_POST['shippingzip'];
if(!isset($_SERVER['HTTPS'])||$_SERVER['HTTPS']!='on') header('Location:  https://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF']);
if(empty($_SESSION['cart'])) header('Location: showcart.php');
require_once 'showcart.php';

$addresstypes=array('shipping', 'billing');
$addressfields=array('full name', 'address 1', 'address 2', 'city', 'state', 'zip');
$contactfields=array('telephone', 'email');

function inputText($addressfieldid, $label) {
return '<div><label for="'.$addressfieldid.'">'.$label.'</label><input type="text" name="'.$addressfieldid.'" id="'.$addressfieldid.'" value="'.@$_POST[$addressfieldid].'" /></div>';
}

function selectPulldown($addressfieldid, $addressfieldlabel, $options) {
$return='<div><label for="'.$addressfieldid.'">'.$addressfieldlabel.'</label><select name="'.$addressfieldid.'" id="'.$addressfieldid.'">';
	foreach($options as $key=>$value) {
	$return.='<option value="'.$key.'"';
	if($key==@$_POST[$addressfieldid]) $return.=' selected="selected"';
	$return.='>'.$value.'</option>';
	}
$return.='</select></div>';
return $return;
}

function getFinalizeValue($label, $value) {
return '<div class="cartfinalizewrapper"><span class="cartfinalizelabel">'.$label.':</span> <span class="cartfinalizevalue">$'.number_format($value, 2).'</span></div>';
}

function getTotal() {
$return=getFinalizeValue($GLOBALS['shipping']->shipmethods[$_POST['ServiceCode']].' shipping', $GLOBALS['shipping']->shippingDetails[$_POST['ServiceCode']]->MonetaryValue);
if($GLOBALS['taxstate']==$_POST['billingstate']) $return.=getFinalizeValue('Tax', $GLOBALS['taxcost']);
$return.=getFinalizeValue('Total', $GLOBALS['total']);
return $return;
}

function digitsOnly(&$string) {
$string=preg_replace('/\D/', '', $string);
}

function confirmUserData() {
global $error;
foreach(array('cc', 'shippingzip', 'billingzip', 'telephone') as $val) digitsOnly($_POST[$val]);

$requiredtextfields=array('full name', 'address 1', 'city');
	foreach($GLOBALS['addresstypes'] as $addresstype) foreach($requiredtextfields as $field) {
	if(strlen($_POST[$addresstype.str_replace(' ', '', $field)])<3)  $error[]=ucfirst($addresstype).' '.$field.' must be filled out';
	}
if(strlen($_POST['billingzip'])!=5) $error[]='Billing zip is invalid';
if(strlen($_POST['telephone'])!=10) $error[]='Invalid telephone number';
if(!preg_match('/([\w!#$%"*+\/=?`{}|~^-]+)@(([\w-]+\.)+[\w-]+)/', $_POST['email'])) $error[]='Invalid email address';

$cc=new cc;
if(!$cc->mod10valid($_POST['cc'])) $error[]='Invalid credit card number';
if(date('ym')>$_POST['expirationyear'].$_POST['expirationmonth']) $error[]='Credit card is expired';
}

function mysql_escape_string_by_reference(&$string) {
$string=mysql_escape_string($string);
}

function trim_by_reference(&$string) {
$string=trim($string);
}

function stripslashes_by_reference(&$string) {
$string=stripslashes($string);
}

array_walk($_POST, 'trim_by_reference');
if(get_magic_quotes_gpc()) array_walk($_POST, 'stripslashes_by_reference');

	if(isset($_SESSION['shippingzip'])) {
	$shipping=new shipping;
	$shipping->xmlaccesskey=$upsxmlaccesskey;
	$shipping->userid=$upsuserid;
	$shipping->password=$upspassword;
	$shipping->originzip=$upsoriginzip;
	$shipping->totalweight=$weight;
	$shipping->shippingzip=$_SESSION['shippingzip'];
	if(!$shipping->getRates()) $error[]=$shipping->errormessage;
	}

	if(isset($_POST['ServiceCode'])) {
	$servicecode=$_POST['ServiceCode'];
	$shippingcost=(Float)$shipping->shippingDetails[$servicecode]->MonetaryValue;
	$total=($subtotal+$shippingcost);
	$taxcost=($taxstate==$_POST['billingstate']?round($total*($taxrate/100), 2):0);
	$total+=$taxcost;
	}

$action='showform';
	if(!isset($_POST['adjustinfo'])) {
		if(isset($_POST['orderconfirmed'])) {
		confirmUserData();
			if(!isset($error)) {
			$cc=new cc;
			$cc->login=$authnetlogin;
			$cc->password=$authnetpassword;
			$authcode=$cc->charge($total, $_POST['cc'], $_POST['expirationmonth'].$_POST['expirationyear']);
			if($authcode!='1') $error[]='Credit card did not clear. '.$cc->responsetext;
			}
		if(!isset($error)) $action='checkoutconfirmed';
		} else if(isset($_POST['shippingaddress1'])) {
		confirmUserData();
		if(!isset($error)) $action='showconfirm';
		} else if(!isset($_SESSION['shippingzip'])||isset($error)||isset($_GET['restart'])) {
		$action='adjustshippingzip';
		}
	}

if(isset($error)) foreach($error as $errormessage) echo '<div class="errormessage">'.$errormessage.'</div>';

switch($action) {
case 'showform':
echo '<form action="'.$_SERVER['PHP_SELF'].'" method="post" title="Checkout" id="checkout"><fieldset><legend>Checkout</legend><fieldset class="checkoutservicecode"><legend>Shipping options</legend>';
if(!isset($_POST['ServiceCode'])) $_POST['ServiceCode']=key($shipping->shippingDetails);
	foreach($shipping->shippingDetails as $ServiceCode=>$obj) {
	echo '<div><input type="radio" name="ServiceCode" value="'.$ServiceCode.'" id="ServiceCode'.$ServiceCode.'"'; 
	if($_POST['ServiceCode']==$ServiceCode) echo ' checked="checked"';
	echo ' /><label for="ServiceCode'.$ServiceCode.'">$'.$obj->MonetaryValue.' '.$shipping->shipmethods[$ServiceCode];
		if((string)$obj->GuaranteedDaysToDelivery!='') {
		echo ' - guaranteed to be delivered in '.$obj->GuaranteedDaysToDelivery.' day';
		if((integer)$obj->GuaranteedDaysToDelivery>1) echo 's';
		}
	if((string)$obj->ScheduledDeliveryTime!='') echo ' by '.$obj->ScheduledDeliveryTime;
	echo '</label></div>';
	}
echo '</fieldset>';

$constantData=new constantData;
if(!isset($_POST['billingzip'])) $_POST['billingzip']=$_SESSION['shippingzip'];
	foreach($addresstypes as $addresstype) {
	echo '<h2>'.ucfirst($addresstype).' Address</h2>';
	if($addresstype=='billing') echo '<script type="text/JavaScript" src="datacopy.js"></script>';
		foreach($addressfields as $addressfield) {
			if($addressfield=='state') {
			echo selectPulldown($addresstype.'state', 'State', $constantData->states);
			continue;
			}
			
			if($addressfield=='zip'&&$addresstype=='shipping') {
			echo '<div><label>Zip:</label> <span class="checkoutuserdata">'.$_SESSION['shippingzip'].' <a href="'.$_SERVER['PHP_SELF'].'?restart=1" title="Adjust shipping zip code; adjusting the shipping zip will discard any form data that was entered">[adjust]</a></span></div>';
			continue;
			}
		echo inputText($addresstype.str_replace(' ', '', $addressfield), ucfirst($addressfield));
		}
	}

echo '<h2>Contact Information</h2>';
foreach($contactfields as $contactfield) echo inputText($contactfield, ucfirst($contactfield));

echo '<h2>Billing Information</h2>';
echo inputText('cc', 'Credit card number');

echo selectPulldown('expirationmonth', 'Expiration month', $constantData->months);
$thisyear=date('Y');
for($year=$thisyear;$year<($thisyear+10);$year++) $years[substr($year, 2)]=$year;
echo selectPulldown('expirationyear', 'Expiration year', $years);

echo '<div><input type="submit" value="Continue to the confirmation page" id="checkoutsubmit" /></div></fieldset></form>';

break;
case 'showconfirm':
echo getTotal();

echo '<div id="cartconfirm">';
$constantData=new constantData;
$_POST['shippingzip']=$_SESSION['shippingzip'];
	foreach($addresstypes as $addresstype) {
	echo '<h2>'.ucfirst($addresstype).'</h2>';
		foreach($addressfields as $addressfield) {
		$userdata=$_POST[$addresstype.str_replace(' ', '', $addressfield)];
		if($addressfield=='state') $userdata=$constantData->states[$userdata];
		echo '<div><label>'.ucfirst($addressfield).':</label> <span class="checkoutuserdata">'.htmlentities($userdata).'</span></div>';
		}
	}

echo '<h2>Contact Information</h2>';
foreach($contactfields as $contactfield) echo '<div><label>'.ucfirst($contactfield).':</label> <span class="checkoutuserdata">'.$_POST[$contactfield].'</span></div>';

echo '<h2>Billing Information</h2>';
echo '<div><label>Credit card number:</label> <span class="checkoutuserdata">'.$_POST['cc'].'</span></div>';
echo '<div><label>Expiration month:</label> <span class="checkoutuserdata">'.$constantData->months[$_POST['expirationmonth']].'</span></div>';
echo '<div><label>Expiration year:</label> <span class="checkoutuserdata">20'.$_POST['expirationyear'].'</span></div>';
echo '</div>';

echo '<form action="'.$_SERVER['PHP_SELF'].'" method="post" title="Checkout" id="checkout"><fieldset><legend>Checkout</legend><div>';
foreach($_POST as $key=>$val) echo '<input type="hidden" name="'.$key.'" value="'.htmlentities($val).'" />';
echo '<input type="submit" name="adjustinfo" value="Make changes" /> <input type="submit" name="orderconfirmed" value="Checkout, this will place your order" id="checkoutbutton" /></div></fieldset></form>';

break;
case 'checkoutconfirmed':
echo getTotal();

array_walk($_POST, 'mysql_escape_string_by_reference');

$sql='select (max(orderid)+1) from orders';
$res=mysql_query($sql);
$row=mysql_fetch_row($res);
mysql_free_result($res);
$orderid=$row[0];

$approvalcode=$cc->approvalcode;
$transactionid=$cc->transactionid;

$orderspecifics=array('orderid', 'subtotal', 'shippingcost', 'taxcost', 'total', 'servicecode', 'approvalcode', 'transactionid');

foreach($orderspecifics as $orderspecific) $orderfields[$orderspecific]=$$orderspecific;
foreach($contactfields as $contactfield) $orderfields[$contactfield]=$_POST[$contactfield];
foreach($addresstypes as $addresstype) foreach($addressfields as $addressfield) {
$fieldid=$addresstype.str_replace(' ', '', $addressfield);
$orderfields[$fieldid]=$_POST[$fieldid];
}

$sql="insert into orders (".implode(',', array_keys($orderfields)).") values ('".implode("','", array_values($orderfields))."')";
mysql_query($sql);

foreach($_SESSION['cart'] as $productid=>$quantity) $orderproducts[]="('".$orderid."','".$productid."','".$productDetails[$productid]->price."','".$quantity."')";
$sql="insert into orderproducts (orderid, productid, price, quantity) values ".implode(',', $orderproducts);
mysql_query($sql);

unset($_SESSION['cart']);
echo '<h2>Thank you, your order has been received.</h2>';
break;
case 'adjustshippingzip':
echo $htmlOutput->getCheckoutForm();
break;
}
?>