function datacopy() {
	if(document.getElementById('samedata').checked) {
	var inputtags=document.body.getElementsByTagName('input');
	var inputtagslength=inputtags.length;
	var billingobject;
	
	for(var x=0; x<inputtagslength; x++) if(inputtags[x].name.substring(0, 8)=='shipping') { 
	document.getElementById(inputtags[x].name.replace('shipping', 'billing')).value=inputtags[x].value;
	}
	
	document.getElementById('billingstate').selectedIndex=document.getElementById('shippingstate').selectedIndex;
	}
}

if(typeof document.getElementById!='undefined') {
document.write('<div><label for="samedata">Same as shipping</label><input type="checkbox" name="samedata" id="samedata" /></div>');
document.getElementById('samedata').onclick=datacopy;
}