<? //this file is provided for testing purposes and is not part of the cart system.
require_once 'global.php';

$htmlOutput=new htmlOutput();
$htmlOutput->title='Product list';
$htmlOutput->keywords='products';
$htmlOutput->description='Product list';
$htmlOutput->css=array('cart.css');
echo $htmlOutput->getPageHeader();

$sql='select productid, name, description from products';
$res=mysql_query($sql);
while($row=mysql_fetch_assoc($res)) echo '<h2>'.$row['name'].'</h2><p>'.$row['description'].'</p>'.$htmlOutput->getAddToCart($row['productid']);
?>