<? if(!isset($_SESSION)) session_start();
class htmlOutput {
public $title, $keywords, $description, $css=array(), $js=array(), $headerfired=0;

public function getPageHeader() {
$return='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<title>'.$this->title.'</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />';
if(!empty($this->keywords)) $return.='<meta name="keywords" content="'.$this->keywords.'" />';
if(!empty($this->description)) $return.='<meta name="description" content="'.$this->description.'" />';
foreach($this->css as $css) $return.='<link rel="stylesheet" type="text/css" href="'.$css.'" />';
foreach($this->js as $js) $return.='<script type="text/JavaScript" src="'.$js.'"></script>';
$return.='</head><body>';
if($this->headerfired) $return='<!-- htmlOutput::getPageHeader() can only be called once -->';
$this->headerfired=1;
return $return;
}

public function __destruct() {
if($this->headerfired) echo '</body></html>';
}

public function getCheckoutForm() {
return '<form method="post" action="checkout.php" title="Checkout" id="checkout"><fieldset><legend>Checkout</legend>
<div><label for="shippingzip">Shipping zip code</label> <input type="text" name="shippingzip" maxlength="5" onkeyup="numbersOnly(this)" onchange="numbersOnly(this)" id="shippingzip" value="'.@$_SESSION['shippingzip'].'" /><input type="submit" value="Checkout" /></div>
</fieldset></form>';
}

public function getAddToCart($productid) {
	if(!isset($_SESSION['cart'][$productid])) {
	$return='<form method="get" action="adjustcart.php" title="Add product to cart"><fieldset><legend>Add product to cart</legend><div><input type="hidden" name="productid" value="'.$productid.'" /><input type="text" name="quantity" value="1" class="cartqauntitytextbox" /><input type="submit" value="Add product to cart" /></div></fieldset></form>';
	} else {
	$return='<div>This product has been added to your cart. <a href="showcart.php" title="View cart">View cart</a></div>';
	}
return $return;
}
} //end-of-class
?>