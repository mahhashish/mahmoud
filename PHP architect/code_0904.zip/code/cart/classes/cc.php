<?
class cc {
public $login, $password, $responsetext, $approvalcode, $transactionid;
protected $mod10digits=array(0=>0, 1=>2, 2=>4, 3=>6, 4=>8, 5=>1, 6=>3, 7=>5, 8=>7, 9=>9);

function mod10valid($cc) {
$cclen=strlen($cc);
if($cclen>16||$cclen<13||!is_numeric($cc)) return 0;
$digitsum=0;
$currentbit=1;
$startbit=($cclen%2);
	for($x=0;$x<$cclen;$x++) {
	$currentbit=!$currentbit;
	if($currentbit==$startbit) $cc[$x]=$this->mod10digits[$cc[$x]];
	$digitsum+=$cc[$x];
	}
return !($digitsum%10);
}

function charge($amount, $cc, $exp) {
$postfields=array(
'x_login'=>$this->login,
'x_password'=>$this->password,
'x_version'=>'3.1',
'x_delim_data'=>'TRUE',
'x_method'=>'CC',
'x_type'=>'AUTH_CAPTURE',
'x_customer_ip'=>$_SERVER['REMOTE_ADDR'],
'x_amount'=>$amount,
'x_card_num'=>$cc,
'x_exp_date'=>$exp);

$postdata=http_build_query($postfields);
$sockheader='POST /gateway/transact.dll HTTP/1.0
Host: secure.authorize.net
Content-type: application/x-www-form-urlencoded
Content-length: '.strlen($postdata).'
Accept: */*';

$fp=stream_socket_client('ssl://secure.authorize.net:443', $errno, $errstr, 30) or die("$errstr ($errno)");
fwrite($fp, $sockheader."\r\n\r\n".$postdata."\r\n\r\n");
while(trim(fgets($fp, 128)));
$responsestring=@fgets($fp);
fclose($fp);

$response=explode(',', $responsestring);
$this->responsetext=$response[3];
$this->approvalcode=$response[4];
$this->transactionid=$response[6];
return $response[0];
}
} //end-of-class
?>