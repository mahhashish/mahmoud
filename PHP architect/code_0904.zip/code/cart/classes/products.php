<?
class products {
public function getProductDetails($productid=array()) {
$productDetails=array();
$sql='select productid, name, price, description, weight from products';
if(!empty($productid)) $sql.=" where productid in ('".implode("','", $productid)."')";
$res=mysql_query($sql);
	while($row=mysql_fetch_assoc($res)) {
	$productDetails[$row['productid']]=new productDetails;
	$productDetails[$row['productid']]->name=$row['name'];
	$productDetails[$row['productid']]->price=$row['price'];
	$productDetails[$row['productid']]->description=$row['description'];
	$productDetails[$row['productid']]->weight=$row['weight'];
	}
mysql_free_result($res);
return $productDetails;
}
} //end-of-class
?>