<?php
define("RDFAPI_INCLUDE_DIR", "./0.8/rdfapi-php/api/");
include(RDFAPI_INCLUDE_DIR . "RdfAPI.php");
include(RDFAPI_INCLUDE_DIR . "vocabulary/DC.php");

//Produced in support of PHP|architect article 2004
//Paul Cowles
//paul@semaview.com

//produce an RDF/XML document to syndicate our site updates using RSS,FOAF and GEO vocabularies

//Generate RDF Model in Memory
$model = new MemModel();

//our site we wish to syndicate
$site = new Resource ("http://www.thehookup.ca/");
$sitel = new Literal ("http://www.thehookup.ca/");

//our syndication pages, for this example we will only syndicate one page
$item = new Resource ("http://www.thehookup.ca/index.php?id=485");
$iteml = new Literal ("http://www.thehookup.ca/index.php?id=485");

//create the channel information
$statements[] = new Statement ($site, new Resource ("http://www.w3.org/1999/02/22-rdf-syntax-ns#type"), new Resource ("http://purl.org/rss/1.0/channel"));
$statements[] = new Statement ($site, new Resource ("http://purl.org/rss/1.0/title"), new Literal("Your Site Title"));
$statements[] = new Statement ($site, new Resource ("http://purl.org/rss/1.0/link"), $sitel);
$statements[] = new Statement ($site, new Resource ("http://purl.org/rss/1.0/description"), new Literal("Your Site Description"));
$statements[] = new Statement ($site, $DC_language, new Literal("en-us"));
$statements[] = new Statement ($site, $DC_date, new Literal(date ("Y-m-d")."T".date ("H:i:s")."-05:00"));

//create the channel item listing
$bNode = new BlankNode($model);
$statements[] = new Statement ($site, new Resource ("http://purl.org/rss/1.0/items"), $bNode);
$statements[] = new Statement ($bNode, new Resource ("http://www.w3.org/1999/02/22-rdf-syntax-ns#type"), new Resource ("http://www.w3.org/1999/02/22-rdf-syntax-ns#Seq"));
$statements[] = new Statement ($bNode, new Resource ("http://www.w3.org/1999/02/22-rdf-syntax-ns#li"), $item);

//create the individual items
$statements[] = new Statement ($item, new Resource ("http://www.w3.org/1999/02/22-rdf-syntax-ns#type"), new Resource ("http://purl.org/rss/1.0/item"));
$statements[] = new Statement ($item, new Resource ("http://purl.org/rss/1.0/title"), new Literal("Your Item Title"));
$statements[] = new Statement ($item, new Resource ("http://purl.org/rss/1.0/link"), $iteml);
$statements[] = new Statement ($item, new Resource ("http://purl.org/rss/1.0/description"), new Literal("Your Item Description"));
$statements[] = new Statement ($item, $DC_subject, new Literal("Your Item Subject"));
$statements[] = new Statement ($item, $DC_creator, new Literal("Your Item Creator"));
$statements[] = new Statement ($item, $DC_date, new Literal(date ("Y-m-d")."T".date ("H:i:s")."-05:00"));

//now add information using the FOAF vocabulary to tell others the email of the syndication channel creator
$bFOAFNode = new BlankNode("", "bNode2");
$statements[] = new Statement (new Resource ("http://www.thehookup.ca/"), new Resource ("http://xmlns.com/foaf/0.1/maker"), $bFOAFNode);
$statements[] = new Statement ($bFOAFNode, new Resource ("http://www.w3.org/1999/02/22-rdf-syntax-ns#type"), new Resource ("http://xmlns.com/foaf/0.1/Person"));
$statements[] = new Statement ($bFOAFNode, new Resource ("http://xmlns.com/foaf/0.1/mbox"), new Literal("mailto:paul@semaview.com"));

//now add information using the GEO vocabulary to tell others the location associated with our syndicated page, in this case the lat/long point to Toronto, Canada
$statements[] = new Statement (new Resource ("http://www.thehookup.ca/index.php?id=485"), new Resource ("http://www.w3.org/2003/01/geo/wgs84_pos#lat"), new Literal ("43.6667"));
$statements[] = new Statement (new Resource ("http://www.thehookup.ca/index.php?id=485"), new Resource ("http://www.w3.org/2003/01/geo/wgs84_pos#long"), new Literal ("-79.4167"));

//add the statements to our model
$i = 0;
while ($i < count($statements)) {
	$model->add($statements[$i]);
	$i++;
}

//save our model as a file to be hosted at http://www.thehookup.ca/rssfoafgeo.rdf
$model->saveAs("rssfoafgeo.rdf", "rdf"); 

$model->close(); 
?>