<?php

// ----------------------------------------------------------------------------------
// Class: StatementIterator
// ----------------------------------------------------------------------------------

/**
 * Iterator for traversing models. 
 * This class can be used for iterating forward and backward trough MemModels.
 * It should be instanced using the getIterator() method of a MemModel.
 * 
 * <BR><BR>History:<UL>
 * <LI>03-29-2004				 : Problems with adding and removing statements fixed.</LI>
 * <LI>02-21-2003                : First version of this class.</LI>
 * </UL>
 * 
 * @version  V0.7
 * @author Chris Bizer <chris@bizer.de>
 *
 * @package util
 * @access	public
 *
 */ 
 class StatementIterator extends Object {

 	/**
	* Reference to the MemModel
	* @var		object MemModel
	* @access	private
	*/	
    var $model;

 	/**
	* Current position
	* StatementIterator does not use the build in PHP array iterator,
	* so you can use serveral iterators on a single MemModel.
	* @var		integer
	* @access	private
	*/	
    var $position;
   
  
   /**
    * Constructor
    *
    * @param	object	MemModel
	* @access	public
    */
    function StatementIterator(&$model) {
		$this->model = &$model;
		$this->position = -1;
	}
 
  /**
   * Returns TRUE if there are more statements.
   * @return	boolean
   * @access	public  
   */
  function hasNext() {
  		if ($this->position < count($this->model->triples) - 1 ) {			
  			return TRUE;
		} else {
			return FALSE;
		}
   }

  /**
   * Returns TRUE if the first statement has not been reached.
   * @return	boolean
   * @access	public  
   */
  function hasPrevious() {
  		if ($this->position > 0) {
			return TRUE;
		} else {
			return FALSE;
		}   }   
   
  /**
   * Returns the next statement.
   * @return	statement or NULL if there is no next statement.
   * @access	public  
   */
  function next() {
  		if ($this->position < count($this->model->triples) - 1) {
  			$this->position++;
			return $this->model->triples[$this->position];
		} else {
			return NULL;
		}
   }

  /**
   * Returns the previous statement.
   * @return	statement or NULL if there is no previous statement.
   * @access	public  
   */
  function previous() {
    	if ($this->position > 0) {
  			$this->position--;
			return $this->model->triples[$this->position];
		} else {
			return NULL;
		}   
  }

  /**
   * Returns the current statement.
   * @return	statement or NULL if there is no current statement.
   * @access	public  
   */
  function current() {
  		if (($this->position >= 0) && ($this->position < count($this->model->triples))) {
			return $this->model->triples[$this->position];
		} else {
			return NULL;
		} 
   }
   
  /**
   * Moves the pointer to the first statement.
   * @return	void
   * @access	public  
   */
  function moveFirst() {
  			$this->position = 0;
   }

  /**
   * Moves the pointer to the last statement.
   * @return	void
   * @access	public  
   */
  function moveLast() {
  			$this->position = count($this->model->triples) - 1;
   }
   
     /**
   * Moves the pointer to a specific statement.
   * If you set an off-bounds value, next(), previous() and current() will return NULL
   * @return	void
   * @access	public  
   */
  function moveTo($position) {
  			$this->position = $position;
   }
   
     /**
   * Returns the current position of the iterator.
   * @return	integer
   * @access	public  
   */
  function getCurrentPosition() {
  	 		return $this->position;
   }
  
} 

?>