<?php

include_once('../adodb-time.inc.php');
adodb_date_test();
?>