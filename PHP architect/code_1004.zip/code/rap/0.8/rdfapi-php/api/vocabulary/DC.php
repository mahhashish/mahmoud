<?php
// ----------------------------------------------------------------------------------
// Dublin Core Vocabulary
// ----------------------------------------------------------------------------------
// Version                   : 0.4
// Authors                   : Chris Bizer (chris@bizer.de)
//
// Description               : Wrapper, defining resources for all terms of the Dublin 
//							   Core Vocabulary. For details about DC see: http://dublincore.org/
// 							   Using the wrapper allows you to define all aspects of 
//                             the vocabulary in one spot, simplifing implementation and 
//                             maintainence. Working with the vocabulary, you should use 
//                             these resources as shortcuts in your code. 
//							   
// ----------------------------------------------------------------------------------
// History:
// 02-21-2003                 : Initial version
// ----------------------------------------------------------------------------------

// define DC namespace
define('DC_NS', 'http://purl.org/dc/elements/1.0/');

// DC concepts
$DC_contributor = new Resource(DC_NS . 'contributor');    
$DC_coverage = new Resource(DC_NS . 'coverage');  
$DC_creator = new Resource(DC_NS . 'creator');  
$DC_date = new Resource(DC_NS . 'date');  
$DC_description = new Resource(DC_NS . 'description');  
$DC_format = new Resource(DC_NS . 'format');  
$DC_identifier = new Resource(DC_NS . 'identifier');  
$DC_language = new Resource(DC_NS . 'language');  
$DC_publisher = new Resource(DC_NS . 'publisher');  
$DC_rights = new Resource(DC_NS . 'rights');  
$DC_source = new Resource(DC_NS . 'source');  
$DC_subject = new Resource(DC_NS . 'subject');  
$DC_title = new Resource(DC_NS . 'title');  
$DC_type = new Resource(DC_NS . 'type');  

?>