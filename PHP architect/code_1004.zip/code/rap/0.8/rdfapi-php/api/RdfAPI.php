<?php

// ----------------------------------------------------------------------------------
// RDF API for PHP 
// ----------------------------------------------------------------------------------
// Version                   : 0.7
// Authors                   : Chris Bizer (chris@bizer.de),
//                             Radoslaw Oldakowski (radol@gmx.de)
// Description               : This file includes all RDFAPI scripts nessesary.
// ----------------------------------------------------------------------------------
// History:
// 11-19-2003                 : Class RdqlResultIterator added
// 07-31-2003                 : Classes N3Parser, N3Serializer added
// 07-27-2003                 : Classes RdqlParser, RdqlEngine, RdqlDbEngine, RdqlMemEngine added
// 06-25-2003                 : Class Model renamed to MemModel.
//                              Classes Model, DbModel, DbStore added.
//                              ADOdb Classes added
// 02-21-2003				  : Vocabularies and StatementIterator added.
// 09-15-2002                 : Version 0.1 of the API
// ----------------------------------------------------------------------------------


// Include Constants and base Object
require( RDFAPI_INCLUDE_DIR . 'constants.php' );
require( RDFAPI_INCLUDE_DIR . 'util/Object.php' );

// Include Model classes
require( RDFAPI_INCLUDE_DIR . 'model/Node.php' );
require( RDFAPI_INCLUDE_DIR . 'model/Literal.php' );
require( RDFAPI_INCLUDE_DIR . 'model/Resource.php' );
require( RDFAPI_INCLUDE_DIR . 'model/Blanknode.php' );
require( RDFAPI_INCLUDE_DIR . 'model/Statement.php' );
require( RDFAPI_INCLUDE_DIR . 'model/Model.php' );
require( RDFAPI_INCLUDE_DIR . 'model/MemModel.php' );
require( RDFAPI_INCLUDE_DIR . 'model/DbModel.php' );
require( RDFAPI_INCLUDE_DIR . 'model/DbStore.php' );

// Include Rdql classes
require( RDFAPI_INCLUDE_DIR . 'rdql/RdqlParser.php' );
require( RDFAPI_INCLUDE_DIR . 'rdql/RdqlEngine.php' );
require( RDFAPI_INCLUDE_DIR . 'rdql/RdqlDbEngine.php' );
require( RDFAPI_INCLUDE_DIR . 'rdql/RdqlMemEngine.php' );
require( RDFAPI_INCLUDE_DIR . 'rdql/RdqlResultIterator.php' );

// Include Utility class
require( RDFAPI_INCLUDE_DIR . 'util/RdfUtil.php' );
require( RDFAPI_INCLUDE_DIR . 'util/StatementIterator.php' );

// Include Parser and Serializer classes
require( RDFAPI_INCLUDE_DIR . 'syntax/RdfParser.php' );
require( RDFAPI_INCLUDE_DIR . 'syntax/RdfSerializer.php' );
require( RDFAPI_INCLUDE_DIR . 'syntax/N3Parser.php' );
require( RDFAPI_INCLUDE_DIR . 'syntax/N3Serializer.php' );
require( RDFAPI_INCLUDE_DIR . 'syntax/NTripleSerializer.php' );

// Include vocabularies
// For a better performance, you should comment vocabularies out, that you are not using.
require( RDFAPI_INCLUDE_DIR . 'vocabulary/RDF.php' );
require( RDFAPI_INCLUDE_DIR . 'vocabulary/RDFS.php' );
require( RDFAPI_INCLUDE_DIR . 'vocabulary/OWL.php' );
require( RDFAPI_INCLUDE_DIR . 'vocabulary/DC.php' );
require( RDFAPI_INCLUDE_DIR . 'vocabulary/VCARD.php' );

// include adodb classes
require(RDFAPI_INCLUDE_DIR .'util/adodb/adodb.inc.php');


?>