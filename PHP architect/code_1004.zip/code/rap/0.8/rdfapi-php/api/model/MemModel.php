<?php

// ----------------------------------------------------------------------------------
// Class: MemModel
// ----------------------------------------------------------------------------------

/**
 * A MemModel is an RDF Model, which is stored in the main memory.
 * This class provides methods for manipulating MemModels.
 *
 * <BR><BR>History:<UL>
 * <LI>03-29-2004				 : Function addModel() fixed, reindexing of triples in remove() added</LI>
 * <LI>11-13-2003				 : Functions load, saveAs moved to class model
 * <LI>11-12-2003				 : Function rdqlQueryAsIterator() added.</LI>
 * <LI>07-31-2003                : Class renamed from Model to MemModel.
 *                                 Variable BaseURI and Function getBaseURI() moved to Model.
 *                                 Functions containsAll(), containsAny(), equals(), unite(),
 *                                           subtract(), intersect(), addModel() can now
 *                                           get DbModel as paramter.
 *                                 Functions load() and saveAs() can now work with n3 format too.
 *                                 Function rdqlQuery added. radol@gmx.de</LI>
 * <LI>05-31-2003                : Functions load(), saveAs() and writeXX() findFirstMatchingStatement() added.
 * 				                   Changed function index() to a faster index type.</LI>
 * <LI>05-28-2003                : Functions addWithoutDuplicates() and addModel() added, optimised bits and pieces.</LI>
 * <LI>05-19-2003                : Function add() made more efficient, optimised bits and pieces. ggrimnes@csd.abdn.ac.uk</LI>
 * <LI>05-19-2003                : Functions index() and isIndexed() added, ggrimnes@csd.abdn.ac.uk</LI>
 * <LI>02-21-2003                : Function findCount() added.</LI>
 * <LI>01-13-2003                : Function equals() made more efficient.</LI>
 * <LI>09-10-2002                : First version of this class.</LI>
 *
 * @version  V0.7
 * @author Chris Bizer <chris@bizer.de>
 * @author Gunnar AAstrand Grimnes <ggrimnes@csd.abdn.ac.uk>
 * @author Radoslaw Oldakowski <radol@gmx.de>
 * @author Daniel Westphal <mail@d-westphal.de>
 *
 * @package model
 * @todo nothing
 * @access	public
 */

class MemModel extends Model {

 	/**
	* Triples of the MemModel
	* @var		array
	* @access	private
	*/		
    var $triples = array(); 

 	/**
	* Search index
	* @var		array
	* @access	private
	*/		
    var $index;

 	/**
	* This is set to true if the MemModel is indexed
	* @var		boolean
	* @access	private
	*/	
    var $indexed;


   /**
    * Constructor
	* You can supply a base_uri
    *
    * @param string $baseURI 
	* @access	public
    */
    function MemModel($baseURI = NULL) {
		$this->setBaseURI($baseURI);
		$this->indexed=false;	  
    }
  
  /**
   * Set a base URI for the MemModel.
   * Affects creating of new resources and serialization syntax.
   * If the URI doesn't end with # : or /, then a # is added to the URI. 
   * @param	string	$uri
   * @access	public
   */
  function setBaseURI($uri) {

	if ($uri != NULL) {
	$c = substr($uri, strlen($uri)-1 ,1);
	if (!($c=='#' || $c==':' || $c=='/' || $c=="\\"))
		$uri .= '#';
	}	
	$this->baseURI = $uri;
  }


  /**
   * Number of triples in the MemModel
   *
   * @return	integer
   * @access	public
   */
   function size() {
     return count($this->triples);
  }

  /**
   * Checks if MemModel is empty
   *
   * @return	boolean
   * @access	public
   */
	function isEmpty() {
		if (count($this->triples) == 0) {
			return TRUE;
		} else {
			return FALSE;
		};
	}

	
  /**
   * Adds a new triple to the MemModel without checking if the statement is already in the MemModel.
   * The function doesn't check if the statement is already in the MemModel.
   * So if you want a duplicate free MemModel use the addWithoutDuplicates() function (which is slower then add())
   *
   * @param		object Statement	$statement
   * @access	public
   * @throws	PhpError 
   */
  function add($statement) {
	
	 if (!is_a($statement, 'Statement')) {
		$errmsg = RDFAPI_ERROR . '(class: MemModel; method: add): Statement expected.';
		trigger_error($errmsg, E_USER_ERROR); 
	 }
	 
     $this->indexed = false;
	 $this->triples[] = $statement;
  }

  
  /**
   * Checks if a new statement is already in the MemModel and adds the statement, if it is not in the MemModel.
   * addWithoutDuplicates() is significantly slower then add().
   *
   * @param		object Statement	$statement
   * @access	public
   * @throws	PhpError 
   */
  function addWithoutDuplicates($statement) {

	 if (!is_a($statement, 'Statement')) {
		$errmsg = RDFAPI_ERROR . '(class: MemModel; method: addWithoutDuplicates): Statement expected.';
		trigger_error($errmsg, E_USER_ERROR); 
	 }
	 
	 if (!$this->contains($statement)) {
	 		$this->indexed=false;	
  		    $this->triples[] = $statement;
	 }
  }

  /**
   * Removes the triple from the MemModel.
   *
   * @param		object Statement	$statement
   * @access	public
   * @throws	PhpError
   */
   function remove($statement) {
     
   	 if (!is_a($statement, 'Statement')) {
		$errmsg = RDFAPI_ERROR . '(class: MemModel; method: remove): Statement expected.';
		trigger_error($errmsg, E_USER_ERROR); 
	}
	  foreach($this->triples as $key => $value) {
			if ($this->matchStatement($value, $statement->subject(), $statement->predicate(), $statement->object())) {
				$this->indexed=false;
				unset($this->triples[$key]);				
			}
	  }
	  $this->triples = array_slice($this->triples, 0);
   }

   /**
   * Short Dump of the MemModel.
   *
   * @access	public 
   * @return	string 
   */  
   function toString() {
       return 'MemModel[baseURI=' . $this->getBaseURI() . ';  size=' . $this->size() . ']';
   }

  /**
   * Dumps of the MemModel including all triples.
   *
   * @access	public 
   * @return	string 
   */  
   function toStringIncludingTriples() {
       $dump = $this->toString() . chr(13);
	   foreach($this->triples as $value) {
	   		$dump .= $value->toString() . chr(13);
	   }
	   return $dump;
   }  



   
  /**
   * Writes the RDF serialization of the MemModel as HTML.
   *
   * @access	public 
   */  
   function writeAsHtml() {
		$ser = new RdfSerializer();
        $rdf =& $ser->serialize($this);
		$rdf = htmlspecialchars($rdf, ENT_QUOTES);
		$rdf = str_replace(' ', '&nbsp;', $rdf);
		$rdf = nl2br($rdf);
		echo $rdf; 
   }  

  /**
   * Writes the RDF serialization of the MemModel as HTML table.
   *
   * @access	public 
   */  
   function writeAsHtmlTable() {
		RDFUtil::writeHTMLTable($this);
   }  

   
  /**
   * Writes the RDF serialization of the MemModel as HTML table.
   *
   * @access	public 
   * @return	string 
   */  
   function writeRdfToString() {
		$ser = new RdfSerializer();
        $rdf =& $ser->serialize($this);
		return $rdf;
   }    

   
 /**
 * Saves the RDF,N3 or N-Triple serialization of the MemModel to a file.
 * You can decide to which format the model should be serialized by using a
 * corresponding suffix-string as $type parameter. If no $type parameter
 * is placed this method will serialize the model to XML/RDF format.
 * Returns FALSE if the MemModel couldn't be saved to the file.
 *
 * @access	public 
 * @param 	string 	$filename
 * @param 	string 	$type
 * @throw     PhpError
 * @return	boolean   
 */  
 function saveAs($filename, $type ='rdf') {

  // get suffix and create a corresponding serializer
  if ($type=='rdf') { 
  	$ser=new RdfSerializer();
  }elseif ($type=='nt') { 
  	$ser=new NTripleSerializer();
  }elseif ($type=='n3') { 
  	$ser=new N3Serializer();
  }else {
  	print ('Serializer type not properly defined. Use a string of "rdf","n3" or "nt".');
  	return false;
  };

  return $ser->saveAs($this, $filename);
 }     
   
   
  /**
   * Tests if the MemModel contains the given triple.
   * TRUE if the triple belongs to the MemModel;
   * FALSE otherwise.
   * To improve the search speed with big MemModels, call index() before seaching.
   *
   * @param	object Statement	&$statement
   * @return	boolean
   * @access	public
   */
  function contains(&$statement) {
	
  		if ($this->indexed) {
			  //Use index for searching
			  $subject = $statement->getSubject();			    
			  if (!isset($this->index[$subject->getLabel()])) 
                return FALSE;			  
			  for ($i=1; $i<=$this->index[$subject->getLabel()][0]; $i++) { 
			    $t=$this->triples[$this->index[$subject->getLabel()][$i]];
			    if ($t->equals($statement))
			        return TRUE;
			  }
			  return FALSE;
		} else { 
		     // If there is no index, use linear search.
		     foreach($this->triples as $value) {
                 if ($value->equals($statement)) 
			     return TRUE;
		     }
		     return FALSE;
		}
  }
  
  /**
   * Determine if all of the statements in a model are also contained in this MemModel.
   * True if all of the statements in $model are also contained in this MemModel and false otherwise.
   *
   * @param	object Model	&$model
   * @return	boolean
   * @access	public
   */
  function containsAll(&$model) {

    if (is_a($model, 'MemModel')) {

       foreach($model->triples as $statement)
	     if(!$this->contains($statement))
           return FALSE;
         return TRUE;
       
    }elseif (is_a($model, 'DbModel'))
    
       return $model->containsAll($this);

    $errmsg = RDFAPI_ERROR . '(class: MemModel; method: containsAll): Model expected.';
    trigger_error($errmsg, E_USER_ERROR);
  }
  
  /**
   * Determine if any of the statements in a model are also contained in this MemModel.
   * True if any of the statements in $model are also contained in this MemModel and false otherwise.
   *
   * @param	object Model	&$model
   * @return	boolean
   * @access	public
   */
  function containsAny(&$model) {

    if (is_a($model, 'MemModel')) {

       foreach($model->triples as $modelStatement)
	 	 if($this->contains($modelStatement))
		   return TRUE;
	     return FALSE;
      
    }elseif (is_a($model, 'DbModel'))
    
       return $model->containsAny($this);

   $errmsg = RDFAPI_ERROR . '(class: MemModel; method: containsAll): Model expected.';
   trigger_error($errmsg, E_USER_ERROR);
  }
 

  /**
   * Builds a search index for the statements in the MemModel.
   * The index is used by the find() and contains() functions.
   * Performance example using a model with 43000 statements on a Linux machine:  
   * Find without index takes 1.7 seconds.
   * Indexing takes 1.8 seconds.
   * Find with index takes 0.001 seconds.
   * So if you want to query a model more then once, build a index first. 
   *
   * @access	public
   */
    function index() {
  
  	  if (!$this->indexed) {
	  	
		  // Delete old index
	      $this->index = NULL;
		  
		 
		  //Generate lookup table.
		  foreach($this->triples as $k => $t) { 
			$s=$t->getSubject();
			if (isset($this->index[$s->getLabel()][0])) {
				$this->index[$s->getLabel()][0]++;
			} else {
				$this->index[$s->getLabel()][0] = 1;
			}	
			$this->index[$s->getLabel()][$this->index[$s->getLabel()][0]] = $k;	
			
			// Debug
			// echo "Key: ". $s->getLabel() . " Position: ". $this->index[$s->getLabel()][0] . " Statement Key: " .$this->index[$s->getLabel()][$this->index[$s->getLabel()][0]] . "<p>";		
	      }
		  
	      $this->indexed=true;
	  }
    } 


  /**
   * Returns TRUE if the MemModel is indexed.
   * @return	boolean
   * @access	public
   */ 
    function isIndexed() { 
      return $this->indexed;
    }
 
    
  /**
   * General method to search for triples.
   * NULL input for any parameter will match anything.
   * Example:  $result = $m->find( NULL, NULL, $node );
   * Finds all triples with $node as object.
   * Returns an empty MemModel if nothing is found.
   * To improve the search speed with big MemModels, call index() before seaching.
   *
   * @param	object Node	$subject
   * @param	object Node	$predicate
   * @param	object Node	$object
   * @return	object MemModel
   * @access	public
   * @throws	PhpError
   */
   function find($subject, $predicate, $object) {
   		
		if (
			(!is_a($subject, 'Resource') && $subject != NULL) || 
			(!is_a($predicate, 'Resource') && $predicate != NULL) || 
			(!is_a($object, 'Node') && $object != NULL)
			) {
			   $errmsg = RDFAPI_ERROR . '(class: MemModel; method: find): Parameters must be subclasses of Node or NULL';
			   trigger_error($errmsg, E_USER_ERROR); 
			}
		
		$res = new MemModel($this->getBaseURI());

		if($this->size() == 0)
			return $res;

		if($subject == NULL && $predicate == NULL && $object == NULL)
			return $this;

		if ($this->indexed && $subject != NULL) {
		  //Use index for searching
		  if (!isset($this->index[$subject->getLabel()])) return $res;
		  for ($i=1; $i<=$this->index[$subject->getLabel()][0]; $i++) { 
		    $t=$this->triples[$this->index[$subject->getLabel()][$i]];
		    if ($this->matchStatement($t,$subject,$predicate,$object))
		      $res->add($t);
		  }
		} else { 
		  // If there is no index, use linear search.
		  foreach($this->triples as $value) {
		    if ($this->matchStatement($value, $subject, $predicate, $object)) 
		      $res->add($value);
		  }
	  }
	  return $res;

   }
  
   
  /**
   * Method to search for triples using Perl-style regular expressions.
   * NULL input for any parameter will match anything.
   * Example:  $result = $m->find_regex( NULL, NULL, $regex );
   * Finds all triples where the label of the object node matches the regular expression.
   * Returns an empty MemModel if nothing is found.
   *
   * @param	string	$subject_regex
   * @param	string	$predicate_regex
   * @param	string	$object_regex
   * @return	object MemModel
   * @access	public
   */
   function findRegex($subject_regex, $predicate_regex, $object_regex) {
   		
		$res = new MemModel($this->getBaseURI());

		if($this->size() == 0)
			return $res;

		if($subject_regex == NULL && $predicate_regex == NULL && $object_regex == NULL)
			return $this;

        foreach($this->triples as $value) {
			if (
				 ($subject_regex == NULL || preg_match($subject_regex, $value->subj->getLabel())) &&
				 ($predicate_regex == NULL || preg_match($predicate_regex, $value->pred->getLabel())) &&
				 ($object_regex == NULL || preg_match($object_regex, $value->obj->getLabel())) 
			   ) $res->add($value);
		}				

		return $res;

	} 
   
  /**
   * Returns all tripels of a certain vocabulary.
   * $vocabulary is the namespace of the vocabulary inluding a # : / char at the end.
   * e.g. http://www.w3.org/2000/01/rdf-schema#
   * Returns an empty MemModel if nothing is found.
   *
   * @param	string	$vocabulary
   * @return	object MemModel
   * @access	public
   */
   function findVocabulary($vocabulary) {

		if($this->size() == 0)
			return $res;
		if($vocabulary == NULL || $vocabulary == '')
			return $this;

		$res = new MemModel($this->getBaseURI());
			
        foreach($this->triples as $value) {
	        if (RDFUtil::getNamespace($value->getPredicate()) == $vocabulary)
				 $res->add($value);
		}
		return $res;

   }   

  /**
   * Searches for triples and returns the first matching statement.
   * NULL input for any parameter will match anything.
   * Example:  $result = $m->findFirstMatchingStatement( NULL, NULL, $node );
   * Returns the first statement of the MemModel where the object equals $node.
   * Returns an NULL if nothing is found.
   *
   * @param	object Node	$subject
   * @param	object Node	$predicate
   * @param	object Node	$object
   * @return	object Statement      
   * @access	public
   */
   function findFirstMatchingStatement($subject, $predicate, $object) {
   		
		$res = $this->find($subject, $predicate, $object);
		if ($res->size() != 0) {
			return $res->triples[0];
		} else {
			return NULL;
		}	

	}   
   
   

  /**
   * Searches for triples and returns the number of matches.
   * NULL input for any parameter will match anything.
   * Example:  $result = $m->findCount( NULL, NULL, $node );
   * Finds all triples with $node as object.
   *
   * @param	object Node	$subject
   * @param	object Node	$predicate
   * @param	object Node	$object
   * @return	integer      
   * @access	public
   */
   function findCount($subject, $predicate, $object) {
   		
		$res = $this->find($subject, $predicate, $object);
		return $res->size();

	}


/**
 * Perform an RDQL query on this MemModel.
 * This method returns an associative array of variable bindings.
 * The values of the query variables can either be RAP's objects (instances of Node)
 * if $returnNodes set to TRUE, or their string serialization.
 *
 * @access	public
 * @param string $queryString
 * @param boolean $returnNodes
 * @return  array   [][?VARNAME] = object Node  (if $returnNodes = TRUE)
 *      OR  array   [][?VARNAME] = string
 *
 */
 function rdqlQuery($queryString, $returnNodes = TRUE) {

   $parser = new RdqlParser();
   $parsedQuery =& $parser->parseQuery($queryString);

   // this method can only query this MemModel
   // if another model was specified in the from clause throw an error
   if (isset($parsedQuery['sources'][1])) {
         $errmsg = RDFAPI_ERROR . '(class: MemModel; method: rdqlQuery):';
         $errmsg .= ' this method can only query this MemModel';
         trigger_error($errmsg, E_USER_ERROR);
   }

   $engine = new RdqlMemEngine();
   $res =& $engine->queryModel($this, $parsedQuery, $returnNodes);

   return $res;
 }

 /**
 * Perform an RDQL query on this MemModel.
 * This method returns an RdqlResultIterator of variable bindings.
 * The values of the query variables can either be RAP's objects (instances of Node)
 * if $returnNodes set to TRUE, or their string serialization.
 *
 * @access	public
 * @param string $queryString
 * @param boolean $returnNodes
 * @return  object RdqlResultIterator = with values as object Node  (if $returnNodes = TRUE)
 *      OR  object RdqlResultIterator = with values as strings if (if $returnNodes = FALSE)
 *
 */
 function rdqlQueryAsIterator($queryString, $returnNodes = TRUE) {

   return new RdqlResultIterator($this->rdqlQuery($queryString, $returnNodes));
 }
 
   /**
   * General method to replace nodes of a MemModel.
   * NULL input for any parameter will match nothing.
   * Example:  $m->replace($node, NULL, $node, $replacement);
   * Replaces all $node objects beeing subject or object in 
   * any triple of the MemModel with the $needle node.
   *
   * @param	object Node	$subject
   * @param	object Node	$predicate
   * @param	object Node	$object   
   * @param	object Node	$replacement
   * @access	public
   * @throws	PhpError
   */
   function replace($subject, $predicate, $object, $replacement) {
   		
		if (
			(!is_a($replacement, 'Node')) || 
			(!is_a($subject, 'Resource') && $subject != NULL) || 
			(!is_a($predicate, 'Resource') && $predicate != NULL) || 
			(!is_a($object, 'Node') && $object != NULL)
			) {
			   $errmsg = RDFAPI_ERROR . '(class: MemModel; method: replace): Parameters must be subclasses of Node or NULL';
			   trigger_error($errmsg, E_USER_ERROR); 
			}
		
		if($this->size() == 0)
			break;

        foreach($this->triples as $key => $value) {
	        	if ($this->triples[$key]->subj->equals($subject)) {
					$this->triples[$key]->subj = $replacement;
					$this->indexed=false;
				}
				if ($this->triples[$key]->pred->equals($predicate))
					$this->triples[$key]->pred = $replacement;
				if ($this->triples[$key]->obj->equals($object))
					$this->triples[$key]->obj = $replacement;		
			
		}
	}
 
  
  /**
   * Internal method that checks, if a statement matches a S, P, O or NULL combination.
   * NULL input for any parameter will match anything.
   *
   * @param	object Statement	$statement   
   * @param	object Node	$subject
   * @param	object Node	$predicate
   * @param	object Node	$object
   * @return	boolean      
   * @access	private
   */
	function matchStatement($statement, $subject, $predicate, $object)  {
	
	    if(($subject != NULL) AND !($statement->subj->equals($subject)))
	      return false;
	  
	    if($predicate != NULL && !($statement->pred->equals($predicate)))
	      return false;
	      
	    if($object != NULL && !($statement->obj->equals($object)))
	      return false;
	
	    return true;
	 }
  
  /**
   * Internal method, that returns a resource URI that is unique for the MemModel.
   * URIs are generated using the base_uri of the MemModel, the prefix and a unique number.
   *
   * @param	string	$prefix   
   * @return	string      
   * @access	private
   */

     function getUniqueResourceURI($prefix) { 
		$counter = 1;
        while (true) {
			$uri= $this->getBaseURI().$prefix.$counter;
			$tempbNode= new BlankNode($uri);
            $res1 = $this->find($tempbNode, NULL, NULL);
			$res2 = $this->find(NULL, NULL, $tempbNode);
			if ($res1->size()==0 && $res2->size()==0)
                return $uri;
            $counter++;
        }
     }
	

  /**
   * Checks if two models are equal.
   * Two models are equal if and only if the two RDF graphs they represent are isomorphic.
   * 
   * Warning: This method doesn't work correct with models where the same blank node has different 
   * identifiers in the two models. We will correct this in a future version.
   *
   * @access	public 
   * @param		object	model &$that
   * @throws    phpErrpr
   * @return	boolean 
   */
  
  function equals(&$that)  {
	 
	if (!is_a($that, 'Model')) {
		$errmsg = RDFAPI_ERROR . '(class: MemModel; method: equals): Model expected.';
		trigger_error($errmsg, E_USER_ERROR); 
	}
	
  	if ($this->size() != $that->size())
		return FALSE;
	
    if (!$this->containsAll($that))
      return FALSE;
   return TRUE;
  }	 
  
 /** 
  * Returns a new MemModel that is the set-union of the MemModel with another model.
  * Duplicate statements are removed. If you want to allow duplicates, use addModel() which is much faster.
  *
  * The result of taking the set-union of two or more RDF graphs (i.e. sets of triples) 
  * is another graph, which we will call the merge of the graphs. 
  * Each of the original graphs is a subgraph of the merged graph. Notice that when forming 
  * a merged graph, two occurrences of a given uriref or literal as nodes in two different 
  * graphs become a single node in the union graph (since by definition they are the same 
  * uriref or literal) but blank nodes are not 'merged' in this way; and arcs are of course 
  * never merged. In particular, this means that every blank node in a merged graph can be 
  * identified as coming from one particular graph in the original set of graphs.
  * 
  * Notice that one does not, in general, obtain the merge of a set of graphs by concatenating 
  * their corresponding N-triples documents and constructing the graph described by the merged 
  * document, since if some of the documents use the same node identifiers, the merged document 
  * will describe a graph in which some of the blank nodes have been 'accidentally' merged. 
  * To merge Ntriples documents it is necessary to check if the same nodeID is used in two or 
  * more documents, and to replace it with a distinct nodeID in each of them, before merging the 
  * documents. (Not implemented yet !!!!!!!!!!!)
  *
  * @param	object Model	$model
  * @return	object MemModel
  * @access	public
  * @throws phpErrpr
  *
  */
  function & unite(&$model)  {
   	 
	if (!is_a($model, 'Model')) {
		$errmsg = RDFAPI_ERROR . '(class: MemModel; method: unite): Model expected.';
		trigger_error($errmsg, E_USER_ERROR); 
	}
  
  	$res = $this;
    $res->indexed=false;
	
    if (is_a($model, 'MemModel')) {
       foreach($model->triples as $value)
		  $res->addWithoutDuplicates($value);

    }
    
    elseif (is_a($model, 'DbModel')) {
       $memModel =& $model->getMemModel();
       foreach($memModel->triples as $value)
		  $res->addWithoutDuplicates($value);
    }

	return $res;
  }
  
 /** 
  * Returns a new MemModel that is the subtraction of another model from this MemModel.
  *
  * @param	object Model	$model
  * @return	object MemModel
  * @access	public
  * @throws phpErrpr
 */ 
  
  function & subtract(&$model)  {
	 
	if (!is_a($model, 'Model')) {
		$errmsg = RDFAPI_ERROR . '(class: MemModel; method: subtract): Model expected.';
		trigger_error($errmsg, E_USER_ERROR); 
	}
	
  	$res = $this;
	$res->indexed=false;
	
    if (is_a($model, 'MemModel')) {
       foreach($model->triples as $value)
		 $res->remove($value);
    }

    elseif (is_a($model, 'DbModel')) {
       $memModel =& $model->getMemModel();
       foreach($memModel->triples as $value)
		 $res->remove($value);
    }
    
	return $res;
  }

 /** 
  * Returns a new MemModel containing all the statements which are in both this MemModel and another.
  *
  * @param	object Model	$model
  * @return	object MemModel
  * @access	public
  * @throws phpErrpr
 */ 
  function & intersect(&$model)  {
  	
	if (!is_a($model, 'Model')) {
		$errmsg = RDFAPI_ERROR . '(class: MemModel; method: intersect: Model expected.';
		trigger_error($errmsg, E_USER_ERROR); 
	}
	
  	$res = new MemModel($this->getBaseURI());
	
    if (is_a($model, 'MemModel')) {
       foreach($model->triples as $value) {
		 if ($this->contains($value))
		 	$res->add($value);
       }
    }
   
    elseif (is_a($model, 'DbModel')) {
       $memModel =& $model->getMemModel();
       foreach($memModel->triples as $value) {
		 if ($this->contains($value))
		 	$res->add($value);
       }
    }
    
	return $res;
  }

  
 /** 
  * Adds another model to this MemModel.
  * Duplicate statements are not removed. 
  * If you don't want duplicates, use unite().
  * If any statement of the model to be added to this model contains a blankNode 
  * with an identifier already existing in this model, a new blankNode is generated.
  *
  * @param	object Model	$model 
  * @access	public
  * @throws phpErrpr
  *
  */
  function addModel(&$model)  {
   	 
	if (!is_a($model, 'Model')) {
		$errmsg = RDFAPI_ERROR . '(class: MemModel; method: addModel): Model expected.';
		trigger_error($errmsg, E_USER_ERROR); 
	}

	$this->index();
	$blankNodes_tmp = array();
	
    if (is_a($model, 'MemModel')) {
       foreach($model->triples as $value)
  	     $this->_addStatementFromAnotherModel($value, $blankNodes_tmp);
    }

    elseif (is_a($model, 'DbModel')) {
      $memModel =& $model->getMemModel();
      foreach($memModel->triples as $value)
  	    $this->_addStatementFromAnotherModel($value, $blankNodes_tmp);
    }
    
  }

  
  /**
   * Reifies the MemModel.
   * Returns a new MemModel that contains the reifications of all statements of this MemModel.
   * 
   * @access	public 
   * @return	object	MemModel
   */  
	function & reify() {
	  	$res = new MemModel($this->getBaseURI());
		
	    foreach($this->triples as $statement) {
			  $pointer =& $statement->reify($res);
			  $res->addModel($pointer); 
		}
		return $res;
    }

  /**
   * Returns a StatementIterator for traversing the MemModel.
   * @access	public 
   * @return	object	StatementIterator
   */  
	function & getStatementIterator() {
		return new StatementIterator($this);
    }	
	
  /**
   * Close the MemModel and free up resources held.
   * 
   * @access	public 
   */  
   function close() {
		unset( $baseURI );
		unset( $triples );
	}
	
} // end: MemModel


?>