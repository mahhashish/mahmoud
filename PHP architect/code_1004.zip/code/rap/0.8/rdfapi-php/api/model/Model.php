<?php

// ----------------------------------------------------------------------------------
// Class: Model
// ----------------------------------------------------------------------------------

/**
 * A model is a programming interface to an RDF graph.
 * An RDF graph is a directed labeled graph, as described in http://www.w3.org/TR/rdf-mt/.
 * It can be defined as a set of <S, P, O> triples, where P is a uriref, S is either
 * a uriref or a blank node, and O is either a uriref, a blank node, or a literal.
 *
 * <BR><BR>History:<UL>
 * <LI>03-26-2004				 : _addStatementFromAnotherModel() added
 *								 : saveAs() moved to the child classes</LI>
 * <LI>11-13-2003				 : Function saveAs added
 * <LI>07-27-2003                : This is an abstract parent class for MemModel and DbModel.
 *                                 The previous class Model has been renamed to MemModel
 *
 *
 *
 * @version  V0.7
 * @author Radoslaw Oldakowski <radol@gmx.de>
 * @author Daniel Westphal <mail@d-westphal.de>
 *
 * @package model
 * @access	public
 */

Class Model extends Object {


/**
 * Base URI of the Model.
 * Affects creating of new resources and serialization syntax.
 *
 * @var     string
 * @access	private
 */
 var $baseURI;


/**
 * Notice for people who are used to work with older versions of RAP.
 *
 * @throws  PHPError
 * @access	public
 */
 function Model() {

   $errmsg  = 'Since RAP 0.6 the class for manipulating memory models has been renamed to MemModel.';
   $errmsg .= '<br>Sorry for this inconvenience.<br>';

   trigger_error($errmsg, E_USER_ERROR);
 }


/**
 * Return current baseURI.
 *
 * @return  string
 * @access	public
 */
 function getBaseURI()  {

   return $this->baseURI;
 }

 
/**
 * Load a model from a file containing RDF, N3 or N-Triples.
 * This function recognizes the suffix of the filename (.n3 or .rdf) and
 * calls a suitable parser, if no $type is given as string ("rdf" "n3" "nt");
 * If the model is not empty, the contents of the file is added to this DbModel.
 *
 * @param 	string 	$filename
 * @param 	string 	$type
 * @access	public
 */
 function load($filename, $type = NULL) {
 	
  if ((isset($type)) && ($type =='n3') OR ($type =='nt')) {
  	$parser = new N3Parser();
  }elseif ((isset($type)) && ($type =='rdf')) {
  	$parser = new RdfParser();
  }else {	
   // create a parser according to the suffix of the filename
   // if there is no suffix assume the file to be XML/RDF
   preg_match("/\.([a-zA-Z0-9_]+)$/", $filename, $suffix);   
   if (isset($suffix[1]) && (strtolower($suffix[1]) == 'n3') OR (strtolower($suffix[1]) == 'nt'))
      $parser = new N3Parser();
   else
      $parser = new RdfParser();
   };
   
   $temp =& $parser->generateModel($filename);   
   $this->addModel($temp);  
   if ($this->getBaseURI() == NULL)
	  $this->setBaseURI($temp->getBaseURI());  
 } 
 

/**
 * Adds a statement from another model to this model. 
 * If the statement to be added contains a blankNode with an identifier 
 * already existing in this model, a new blankNode is generated.
 *
 * @param 	Object Statement   $statement
 * @access	private
 */ 
 function _addStatementFromAnotherModel($statement, &$blankNodes_tmp) {
   	
   $subject = $statement->getSubject();
   $object = $statement->getObject();        
   
   if (is_a($subject, "BlankNode")) {
      $label = $subject->getLabel();	
   	  if (!array_key_exists($label, $blankNodes_tmp)) 
      { 	
        if ($this->findFirstMatchingStatement($subject, NULL, NULL)
           || $this->findFirstMatchingStatement(NULL, NULL, $subject)) 
        {    	       
   	       $blankNodes_tmp[$label] = new BlankNode($this);   	          
   	       $statement->subj = $blankNodes_tmp[$label]; 	    
        } else {
           $blankNodes_tmp[$label] = $subject;
        }
      } else
  		 $statement->subj = $blankNodes_tmp[$label];       
   }

   if (is_a($object, "BlankNode")) {       
      $label = $object->getLabel();	
      if (!array_key_exists($label, $blankNodes_tmp)) 
      { 	
        if ($this->findFirstMatchingStatement($object, NULL, NULL)
           || $this->findFirstMatchingStatement(NULL, NULL, $object)) 
        {           	  
   	       $blankNodes_tmp[$label] = new BlankNode($this);   	          
   	       $statement->obj = $blankNodes_tmp[$label];
        } else {
           $blankNodes_tmp[$label] = $object;
        }
      } else 
  		   $statement->obj = $blankNodes_tmp[$label];    	     
   }
   
   $this->add($statement);
 }
 
} // end: Model

?>