<?php

// ----------------------------------------------------------------------------------
// RAP Net API SPO Query Operaton
// ----------------------------------------------------------------------------------

/**
 * SPO (also known as "Triples" or "find(spo)") is an experimental minimal query language. 
 * An SPO query is a single triple pattern, with optional subject (parameter "s"), predicate (parameter "p"), 
 * and object (parameter "o", if a URIref, parameter "v" for a string literal). 
 * Absence of a parameter implies "any" for matching that slot of the triple pattern.
 *
 * History:<UL>
 * <LI>05-16-2004                : Initial version by Chris Bizer chris@bizer.de</LI><UL>
 *
 * @version  V0.8
 * @author Chris Bizer <chris@bizer.de>
 * @author Phil Dawes <pdawes@users.sf.net>
 *
 * @package netapi
 * @todo Support typed literals.
 * @access	public
 */

function spoQuery($model,$serializer){

  // Get SPO query from HTTP request
  if (isset($_REQUEST['s'])) {
	$subject = new Resource($_REQUEST['s']);
  } else {
  	$subject = NULL;
  }
  if (isset($_REQUEST['p'])) {
	$predicate = new Resource($_REQUEST['p']);
  } else {
  	$predicate = NULL;
  }
  if (isset($_REQUEST['o'])) {
	$object = new Resource($_REQUEST['o']);
  } else if (isset($_REQUEST['v'])) {
	$object = new Literal($_REQUEST['v']);
  } else {
  	$object = NULL;
  }
  if (isset($_REQUEST['closure'])) {
     if (strtoupper($_REQUEST['closure']) == "TRUE" ) {
	   $closure = True;
     } else {
  	   $closure = False;
     }
  } else {
      $closure = False;
  }

  $outm = new MemModel();
  $resultmodel = $model->find($subject, $predicate, $object);
  $it = $resultmodel->getStatementIterator();
  while ($it->hasNext()){
	$stmt = $it->next();
	$outm->add(new Statement($stmt->subject(),$stmt->predicate(), $stmt->object()));
	if (is_a($stmt->object(),'BlankNode') && $closure == True) {
	  getBNodeClosure($stmt->object(),$model,$outm);
	}
	if (is_a($stmt->subject(),'BlankNode') && $closure == True) {
	  getBNodeClosure($stmt->subject(),$model,$outm);
	}
  }  
  echo $serializer->Serialize($outm);   
  $outm->close();
}

?>