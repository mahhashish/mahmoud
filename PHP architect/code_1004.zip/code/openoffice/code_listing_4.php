<?php
// Create a new XSLT processor
$xsltProcessor = xslt_create();

// Transform the XML document according to the XSLT
$xhtmlResult = xslt_process( $xsltProcessor, 'content.xml', 'content.xsl');

// Print error message if transformation was unsuccessful
if ( empty( $xhtmlResult ) )
    die( 'XSLT processing error: ' . xslt_error( $xsltProcessor ) );

// Free the XSLT processor
xslt_free( $xsltProcessor );
// Print the converted XHTML document
print( $xhtmlResult );
?>
