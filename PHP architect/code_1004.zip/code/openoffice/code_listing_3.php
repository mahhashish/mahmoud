function handleNode( $node )
{
    $xhtmlTextContent = "";
    switch ( $node->name() )
    {
        case 'h' :
        {
            $level = $node->attributeValueNS( 'level', 'http://openoffice.org/2000/text' );

            if ( $level >= 1 && $level <= 6 )
            {
                $xhtmlTextContent .= "<h$level>" . $node->textContent() . "</h$level>";
            }
            else
                print( "Unsupported header level" );
        }break;

        case 'p' :
        {
            $paragraphContent = "";
            foreach ( $node->children() as $childNode )
            {
                switch ( $childNode->name() )
                {
                    case "#text" :
                    {
                        $paragraphContent .= $childNode->content();
                    }break;

                    case "image" :
                    {
                        $href = ltrim( $childNode->attributeValueNS( 'href', 'http://www.w3.org/1999/xlink' ), '#' );
                        $paragraphContent .= "<img src='$href' alt=''/>";
                    }break;

                    default:
                    {
                        print( "Unsupported node: " . $childNode->name() . "<br>" );
                    }break;
                }
            }
            $xhtmlTextContent .= '<p>' . $paragraphContent . '</p>';
        }break;

        default:
        {
            print( "Unsupported node " . $node->name() . "<br/" );
        }
    }
    return $xhtmlTextContent;
}
?>
