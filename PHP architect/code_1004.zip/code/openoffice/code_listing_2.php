<h1>OpenOffice XML import test</h1>
<hr />
<?php
include_once( 'lib/ezxml/classes/ezxml.php' );

$xml = new eZXML();
$dom =& $xml->domTree( file_get_contents( "documents/simpledoc/content.xml" ) );

$bodyNodeArray = $dom->elementsByNameNS( 'body', 'http://openoffice.org/2000/office' );

if ( count( $bodyNodeArray ) == 1 )
{
    $bodyNode =& $bodyNodeArray[0];

    $xhtmlTextBody = "";
    foreach ( $bodyNode->children() as $childNode )
    {
        $xhtmlTextBody .= handleNode( $childNode );
    }

    print( $xhtmlTextBody );
}
