<HTML>
<HEAD>
	<TITLE><?=$pageTitle ?></TITLE>
	<link rel="stylesheet" href="css/style.css">
</HEAD>
<BODY>
	<script language="javascript" src="js/generic.js"></script>
	<?=$header?>
	<br>
	<?=$contents?>
	<br>
	<?=$footer?>
</BODY>
</HTML>