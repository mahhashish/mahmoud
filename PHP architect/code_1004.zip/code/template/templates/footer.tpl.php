<TABLE align="center" width="650px" cellpadding="0" cellspacing="0">
	<TR>
		<TD class="tdMenu">
			&copy; <?= date('Y') ?> Some Company
		</TD>
	</TR>
</TABLE>