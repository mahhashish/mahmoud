<TABLE align="center" width="650px" cellpadding="0" cellspacing="0">
	<TR>
		<TD colspan="<?=$nOpts?>" class="tdAppTitle">
			<a href="index.php">Your Store Backend</a>
		</TD>
	</TR>
	
	<TR>
		<? foreach($menuOpt as $opt): ?>
		
		<TD class="tdMenu">
			<a href="index.php?action=<?=$opt->action?>"><?=$opt->label?></a>
		</TD>
		
		<? endforeach; ?>
	</TR>
</TABLE>