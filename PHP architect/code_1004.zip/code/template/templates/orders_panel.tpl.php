<FORM id="form_orders_panel" name="form_orders_panel" action="<?=$formAction?>">
<TABLE align="center" width="650px" cellpadding="0" cellspacing="0">
	<TR>
		<TD class="tdAppSubTitle">
			Orders Control Panel
		</TD>
	</TR>
	
	<? foreach($recs as $rec): ?>
	<TR onclick="javascript:eXpand('orders<?=$rec->id?>');" class="trExpandable">
		<TD class="tdOrder">
			<?= $rec->name ?> (<?= count($rec->orders) ?>)
		</TD>
	</TR>
	<TR id="orders<?=$rec->id?>" style="display: none;">
		<TD>
			
			<TABLE width="95%" align="center" cellpadding="0" cellspacing="0">
			
				<TR>
					<TD class="tdHead">Date</TD>
					<TD class="tdHead">Label</TD>
					<TD class="tdHead">State</TD>
					<TD class="tdHead">Total</TD>
					<TD class="tdHead">Discount</TD>
					<TD class="tdHead">Grand Total</TD>
					<TD class="tdHead">Currency</TD>
					<TD class="tdHead">&nbsp;</TD>
				</TR>
			
				<? foreach($rec->orders as $order): ?>	
			
				<TR class="<?=$plugin->getRowClass($order->grandTotal) ?>">
					<TD class="tdItem"><?=$order->date ?></TD>
					<TD class="tdItem"><?=$order->label ?></TD>
					<TD class="tdItem" style="text-align:center">
						<select name="item[<?=$rec->id?>_<?=$order->id?>]">
						<? foreach($states as $state): ?>
							<option value="<?=$state->id?>" <?=($order->state == $state->id)?'selected':'' ?> >
								<?=$state->label ?>
							</option>
						<? endforeach; ?>
						</select>
					</TD>
					<TD class="tdItem" style="text-align:right"><?=$order->total ?></TD>
					<TD class="tdItem" style="text-align:right"><?=$order->discount ?>%</TD>
					<TD class="tdItem" style="text-align:right"><?=$order->grandTotal ?></TD>
					<TD class="tdItem" style="text-align:right"><?=$order->currency?></TD>
					<TD class="tdItem" style="text-align:right; cursor:hand;" onclick="javascript:eXpand('items<?=$rec->id?>_<?=$order->id?>');">[+]</TD>
				</TR>
				
				<TR id="items<?=$rec->id?>_<?=$order->id?>" style="display: none;">
					<TD colspan="8">
						
						<TABLE width="85%" align="center" cellpadding="0" cellspacing="0">
							
							<TR>
								<TD class="tdHead">ID</TD>
								<TD class="tdHead">Category</TD>
								<TD class="tdHead">Product</TD>
								<TD class="tdHead">Qty</TD>
								<TD class="tdHead">Unit Price</TD>
							</TR>
						
							<? foreach($order->items as $item): ?>	
							
							<TR>
								<TD class="tdItem"><?=$item->id ?></TD>
								<TD class="tdItem"><?=$item->category ?></TD>
								<TD class="tdItem"><?=$item->product ?></TD>
								<TD class="tdItem" style="text-align:right"><?=$item->qty ?></TD>
								<TD class="tdItem" style="text-align:right"><?=$item->unit_price ?></TD>
							</TR>
							
							<? endforeach; ?>
							
						</TABLE>
						
					</TD>
				</TR>
				
				<? endforeach; ?>
				
			</TABLE>
		
		</TD>
	</TR>
	<? endforeach; ?>
	
	<TR>
		<TD class="tdAppSubTitle" style="text-align:right;">
			<input type="reset" name="reset" value="Reset">
			<input type="button" name="save" value="Save Changes">
		</TD>
	</TR>
	
</TABLE>
</FORM>