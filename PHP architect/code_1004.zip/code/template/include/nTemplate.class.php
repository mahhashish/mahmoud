<?

/**
 * Native Template: fast template engine that uses php language in template definition.
 *
 * @author S�rgio Machado <machadosergio@netcabo.pt>
 */
class nTemplate {
	
	/**
	 * Variables used in the template file.
	 *
	 * @access private
	 * @var array
	 */
	var $vars;
	
	/**
	 * The path prefix that will be prefixed to the filename of a template.
	 *
	 * @access private
	 * @var string
	 */
	var $pathPrefix;
	
	/**
	 * Native Template constructor.
	 *
	 * @param string [$pathPrefix] The path prefix that will be prefixed to the filename of a template.
	 */
	function nTemplate($pathPrefix='') {
		$this->vars = array();
		$this->pathPrefix = $pathPrefix;
	}
	
	/**
	 * Binds a variable name (used in the template file) to a value 
	 * of any type including arrays and objects.
	 *
	 * @access public
	 * @param string [$varname] variable name
	 * @param mixed [$value] variable content
	 */
	function set($varname, $value) {
		$this->vars[$varname] = $value;
	}
	
	/**
	 * Binds a variable name (used in the template file) by reference to a value 
	 * of any type including arrays and objects.
	 *
	 * @access public
	 * @param string [$varname] variable name
	 * @param mixed [$value] variable alias (reference)
	 */
	function setByRef($varname, &$value) {
		$this->vars[$varname] = &$value;
	}
	
	/**
	 * Clean variables.
	 */
	function cleanVars() {
		unset($this->vars);
		$this->vars = array();
	}
	
	/**
	 * Processes a template file.
	 *
	 * @access public
	 * @param string [$filename] name and path of the .tpl.php file.
	 * @param bool [$output] the result should be echoed to the client?
	 * @param bool [$keepvars] the vars should be keeped?
	 * @return string
	 */
	function fetch($filename, $output=false, $keepvars=false) {
		
		// local definition of template variables
		foreach ($this->vars as $key => $value) 
			$$key = $value;
		
		// processing
		if ($output) {
			// echoing directly to the client
			require($filename);
		} else {
			// returning back the result
			ob_start();
			require($this->pathPrefix . $filename);
			$content = ob_get_contents();
			ob_end_clean();
		}

		// cleaning variables
		if (!$keepvars) {
			unset($this->vars);
			$this->vars = array();
		}
		
		return $content;
	}
	
}

?>