<?

/**
 * Virtual data source
 */
class DataSrc {
	
	var $curr;
	
	function DataSrc() {
		$this->curr = &$this->getCurrency();
	}
	
	function &getOrders($maxCustomers, $maxOrders, $maxItems) {
		$recs = array();
		
		for($n=0; $n<$maxCustomers; $n++) {
			$recs[$n]->id = $n+1;
			$recs[$n]->name = 'Customer #' . ($n+1);
			$recs[$n]->orders = &$this->getCustomerOrders( rand(5,$maxOrders), $maxItems );
		}
		
		return $recs;
	}
	
	function &getCustomerOrders($maxOrders, $maxItems) {
		$orders = array();
		
		for($n=0; $n<$maxOrders; $n++) {
			$orders[$n]->id = $n+1;
			$orders[$n]->date = date('Y-m-d');
			$orders[$n]->label = 'Order #' . ($n+1);
			$orders[$n]->state = rand(1,5);
			$orders[$n]->items = &$this->getOrderItems( rand(1,$maxItems) );
			$orders[$n]->total = $this->getOrderSum( $orders[$n] );
			$orders[$n]->discount = rand(1,10);
			$orders[$n]->grandTotal = $orders[$n]->total - ($orders[$n]->total * ($orders[$n]->discount/100));
			$orders[$n]->currency = $this->curr[ rand(0,1) ]->desc;
		}
		
		return $orders;
	}
	
	function &getOrderItems($maxItems) {
		$items = array();
		
		for($n=0; $n<$maxItems; $n++) {
			$items[$n]->id = $n+1;
			$items[$n]->category = 'Categ ' . rand(1,4);
			$items[$n]->product = 'Product ' . rand(1,20);
			$items[$n]->qty = rand(1,5);
			$items[$n]->unit_price = rand(1,50);
		}
		
		return $items;
	}
	
	function getOrderSum($order) {
		$sum = 0;
		
		foreach($order->items as $item)
			$sum += $item->unit_price * $item->qty;
			
		return $sum;
	}
	
	function &getStates() {
		$states[0]->id = 1;
		$states[0]->label = 'new';
		$states[1]->id = 2;
		$states[1]->label = 'shipping';
		$states[2]->id = 3;
		$states[2]->label = 'waiting for payment';
		$states[3]->id = 4;
		$states[3]->label = 'returned';
		$states[4]->id = 5;
		$states[4]->label = 'closed';
		
		return $states;
	}
	
	function &getCurrency() {
		$curr[0]->id = 1;
		$curr[0]->symbol = '$';
		$curr[0]->desc = 'USD';
		$curr[1]->id = 2;
		$curr[1]->symbol = '�';
		$curr[1]->desc = 'EUR';
		return $curr;
	}
	
	function &getMenuOps($maxOpts) {
		$menuOpts = array();
		
		for ($n=0; $n<$maxOpts; $n++) {
			$menuOpts[$n]->label = 'Opt' . $n;
			$menuOpts[$n]->action = 'Opt' . $n;
		}		
		
		return $menuOpts;
	}
	
}

?>