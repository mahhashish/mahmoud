<?

class nTemplatePlugin {
	
	function getRowClass($total) {
		return ($total < 200)? 'row1' : 'row2';
	}

}

?>