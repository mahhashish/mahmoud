<?

class Giz_Timer { 
    var $starttime; 
    var $endtime; 
    
    // Constructor.   
    // Purpose: Starts Timer. 
    function Giz_Timer() { 
           $this->starttime = microtime(); 
           return true; 
    } 
    
    // Member Function: Stop_Timer 
    // Purpose: Stop Timing. 
    function Stop_Timer() { 
          $this->endtime = microtime(); 
        return true; 
      } 
      
    // Member Function: Show_Timer 
    // Purpose: Display elapsed time in seconds to precision passed in optional parameter 
    function Show_Timer($decimals=2) { 
        // $decimals will set the number of decimals you want for your milliseconds. 
           // format start time 
        $decimals = intval($decimals); 
        if ($decimals > 8) 
          $decimals = 8; 
        if ($decimals < 0) 
          $decimals = 0; 
        $endtime = explode(" ", $this->endtime); 
           $endtime = (float)$endtime[1] + (float)$endtime[0]; 
           $starttime = explode (" ", $this->starttime); 
           $starttime = (float)$starttime[1] + (float)$starttime[0]; 
        return number_format($endtime - $starttime, $decimals); 
   } 
   
   // Member Function: Stop_Show_Timer 
   // Purpose: Stop the timer and Display elapsed time in seconds to precision passed in optional parameter 
   function Stop_Show_Timer($decimals=2) { 
     $this->Stop_Timer(); 
     return $this->Show_Timer($decimals); 
   } 
} 
?> 
