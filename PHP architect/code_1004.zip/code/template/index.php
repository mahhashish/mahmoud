<?

if (!isset($_SESSION)) 
	session_start();

if (isset($_SESSION['measures'])) {
	$measures = $_SESSION['measures'];
	$sum = $_SESSION['sum'];
} else {
	$measures = array();
}
	
if ($_GET['reset'] == 1)
	$measures = array();

define('INCLUDE_PATH', 'include/');

require_once(INCLUDE_PATH . 'nTemplate.class.php');
require_once(INCLUDE_PATH . 'DataSrc.class.php');
require_once(INCLUDE_PATH . 'timer.class.php');

$oGlobalTimer = new Giz_Timer();

$nTpl = new nTemplate('templates/');
$dSrc = new DataSrc();

// building the header: common to all pages
$menuOpt = &$dSrc->getMenuOps(10);

$oTimer = new Giz_Timer();

$nTpl->set('nOpts', count($menuOpt));
$nTpl->setByRef('menuOpt', $menuOpt);
$header = $nTpl->fetch('header.tpl.php');

$headerFetchTime = $oTimer->Stop_Show_Timer(4);

// building the footer: common to all pages
$oTimer = new Giz_Timer();

$footer = $nTpl->fetch('footer.tpl.php');

$footerFetchTime = $oTimer->Stop_Show_Timer(4);

// getting contents
switch($_GET['action']) {
	
	case 'orders_panel':
		// here we could require the file to process the orders_panel action
		break;
	
	default:
		require_once(INCLUDE_PATH . 'nTemplatePlugin.class.php');
		
		$recs = &$dSrc->getOrders(20,10,10);
		$states = &$dSrc->getStates();
		
		$oTimer = new Giz_Timer();
		
		$plugin = new nTemplatePlugin();
		$nTpl->set('formAction', 'index.php?action=orders_panel&do=save');
		$nTpl->setByRef('plugin', $plugin);
		$nTpl->setByRef('states', $states);	
		$nTpl->setByRef('recs', $recs);
		$contents = $nTpl->fetch('orders_panel.tpl.php');
		
		$contentsFetchTime = $oTimer->Stop_Show_Timer(4);
	
}

// fetching the master template
$oTimer = new Giz_Timer();

$nTpl->set('pageTitle', 'Your Store Backend > Orders Control Panel');	
$nTpl->set('header',$header);
$nTpl->set('contents', $contents);
$nTpl->set('footer',$footer);
$output = $nTpl->fetch('master.tpl.php');

$masterFetchTime = $oTimer->Stop_Show_Timer(4);

// output to client
echo $output;

// ------ END

// performance measures
$globalTime = $oGlobalTimer->Stop_Show_Timer(4);

$total = $headerFetchTime + $footerFetchTime + $contentsFetchTime + $masterFetchTime;

$n = count($measures);
$measures[$n]->header = $headerFetchTime;
$measures[$n]->footer = $footerFetchTime;
$measures[$n]->contents = $contentsFetchTime;
$measures[$n]->master = $masterFetchTime;
$measures[$n]->total = $total;
$measures[$n]->global = $globalTime;
$measures[$n]->percTotal = round(($total/$globalTime)*100,1);
$measures[$n]->percMaster = round(($masterFetchTime/$globalTime)*100,1);
$measures[$n]->percContents = round(($contentsFetchTime/$globalTime)*100,1);
$measures[$n]->percFooter = round(($footerFetchTime/$globalTime)*100,1);
$measures[$n]->percHeader = round(($headerFetchTime/$globalTime)*100,1);

$_SESSION['measures'] = $measures;

$n++;

$sum->header += $headerFetchTime;
$sum->footer += $footerFetchTime;
$sum->contents += $contentsFetchTime;
$sum->master += $masterFetchTime;
$sum->total += $total;
$sum->global += $globalTime;

$_SESSION['sum'] = $sum;

?>
<div align="center">
<br><br><br><br>
Execution Times:<br><br>
<table border="1">
	<tr>
		<td>header</td>
		<td>footer</td>
		<td>contents</td>
		<td>master</td>
		<td>total</td>
		<td>global</td>
	</tr>
	<? foreach($measures as $m): ?>
	
	<tr>
		<td><?=$m->header?> (<?=$m->percHeader?>%)</td>
		<td><?=$m->footer?> (<?=$m->percFooter?>%)</td>
		<td><?=$m->contents?> (<?=$m->percContents?>%)</td>
		<td><?=$m->master?> (<?=$m->percMaster?>%)</td>
		<td><?=$m->total?> (<?=$m->percTotal?>%)</td>
		<td><?=$m->global?></td>
	</tr>
	
	<? endforeach; ?>
	
	<tr><td colspan="6"></br></tr>
	
	<tr>
		<td><?=round(($sum->header/$sum->global) * 100,1)?>%</td>
		<td><?=round(($sum->footer/$sum->global) * 100,1)?>%</td>
		<td><?=round(($sum->contents/$sum->global) * 100,1)?>%</td>
		<td><?=round(($sum->master/$sum->global) * 100,1)?>%</td>
		<td><?=round(($sum->total/$sum->global) * 100,1)?>%</td>
		<td>100%</td>
	</tr>
</table>
</div>