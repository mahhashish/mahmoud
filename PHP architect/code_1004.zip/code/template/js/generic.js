function eXpand(obj){
	var aux = document.getElementById(obj);
	
	if(aux) {
		if (document.all) {
			aux.style.display = (aux.style.display == "none" ) ? "inline" : "none";
		} else {
			aux.style.display = (aux.style.display == "none" ) ? "table-row" : "none";
		}
	}
}