<?php
$java = new Java ("HelloUniverse");
$output = $java->saySomething("Look I got this to work!");
echo $output;
?>
