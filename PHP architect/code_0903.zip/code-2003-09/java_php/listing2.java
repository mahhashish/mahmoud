public class HelloUniverse {
     public HelloUniverse() {}
     public String saySomething (String message) {
        return "I was told to tell you: " + message;
    }
}
