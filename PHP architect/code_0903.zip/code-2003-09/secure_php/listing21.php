<?php

//xsssearch.php
echo "You searched for " . $_GET['query'];

?>
