<?php

//envdisclosurepatched.php
error_reporting(0);
$conn=mysql_connect('dbserver.server.com', 'user', 'pw');
$fp=fopen('/mnt/data/file1.txt', 'rb');

?>
