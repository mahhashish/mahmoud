<html>
<form action="http://www.server.com/trustedvaluesformhandler.php" method="post">
<input type="hidden" name="price" value="1">
<input type="hidden" name="cc" value="5353167819823">
<input type="submit" value="Order Product">
</form>
</html>