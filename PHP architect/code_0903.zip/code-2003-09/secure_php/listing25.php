<form action="subscribe.php" method="POST">
<input type="hidden" name="sid" value="666">
<input type="hidden" name="listid" value="1024">
Email:<input type="text" size="100" name="usermail">
<input type="submit" value="subscribe">
</form>