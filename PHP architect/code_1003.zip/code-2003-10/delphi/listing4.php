<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">
<HTML>
<BODY >
<B><?php  echo "Hello $username on the web" ?></B>
</BODY>
</HTML>
