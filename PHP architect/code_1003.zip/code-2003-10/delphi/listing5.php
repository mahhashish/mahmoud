/* Header Info */

	$HeaderInfo['Description'] =  'Lot Report';
	$HeaderInfo['MenuPath'] = 'Pre Auction,Lots';
	$HeaderInfo['ReportID'] = '102';
	$HeaderInfo['RequiredVars']['AuctionID']= array('Name' => 'AuctionID','Description' => 'Auction','Default' => 'Lookup','ValuesType' => 'Lookup');	
	$HeaderInfo['OptionalVars']['StockID'] = array('Name'=> 'StockID','Description' => 'Select Stock to report on.','Values' => 'Lookup','ValuesType' => 'Lookup');		

/* Header Info */