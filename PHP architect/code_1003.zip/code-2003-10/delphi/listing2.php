<?php

    echo "Hello $username";

?>