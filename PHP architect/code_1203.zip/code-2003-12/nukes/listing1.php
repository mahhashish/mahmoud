<?php

function Ephemeridsdel()
{
    list($eid,
	 $did,
	 $mid) = pnVarCleanFromInput('eid',
				     'did',
				     'mid');

    list($authid) = pnVarCleanFromInput('authid');

    if (!pnSecConfirmAuthKey()) {
        include 'header.php';
        echo _BADAUTHKEY;
        include 'footer.php';
        exit;
    }
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();

    $column = &$pntable['ephem_column'];

    $result = $dbconn->Execute("SELECT $column[content]
                              FROM $pntable[ephem]
                              WHERE $column[eid]=" . pnVarPrepForStore($eid));
    list($content) = $result->fields;
    $result->Close();

    if (!pnSecAuthAction(0, 'Ephemerids::', "$content::$eid", ACCESS_DELETE)) {
        include 'header.php';
        GraphicAdmin();
        OpenTable();
        echo "<center><font class=\"pn-title\"><b>"._EPHEMADMIN."</b></font></center>";
        CloseTable();

        echo _EPHEMDELETENOAUTH;
        include 'footer.php';
        return;
    }

    $dbconn->Execute("DELETE FROM $pntable[ephem] WHERE $column[eid]=" . pnVarPrepForStore($eid));
    pnRedirect('admin.php?module='.$GLOBALS['module'].'&op=Ephemeridsmaintenance&did='.$did.'&mid='.$mid);
}

?>