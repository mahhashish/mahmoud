<?php

/**
 * Delete selected ephemerids
 */
function ephemerids_admin_delete()
{
    list($eid, 
         $confirmation,
         $confirm) = xarVarCleanFromInput('eid',
                                          'confirmation',
                                          'confirm');

    // Security Check
    if(!xarSecurityCheck('DeleteEphemerids')) return;

    // Check for confirmation.
    if (empty($confirmation)) {
    $data['eid'] = $eid;
    $data['submitlabel'] = xarML('Submit');
    $data['authid'] = xarSecGenAuthKey();

    return $data;
    }

    if (!xarSecConfirmAuthKey()) return;

    // The API function is called
    if (xarModAPIFunc('ephemerids',
                      'admin',
                      'delete',
                      array('eid' => $eid))) {

    }

    xarResponseRedirect(xarModURL('ephemerids', 'admin', 'view'));

    // Return
    return true;

}

?>