//Table prefix to add (optional)
$prefix = 'prfx_';

//Load SQL file
$sql_file = 'survey.sql';
$file = file($sql_file);

//Loop through lines of file
foreach($file as $line)
{
    //Skip over SQL comments and empty lines
    if($line{0} != '#' && strlen($line) > 0)
    {
        //Add current line to query
        $query .= trim($line);

        //If last character is semi-colon,
        //then that' the end of the query
        if(substr($query,-1) == ";")
        {
            //Add (optional) prefix to table names by
            //matching beginning of query and inserting
            //the prefix before the existing table name
            //(and after the back tick, if it's there).
            $query = preg_replace('/^CREATE TABLE (`?)/',
                                  "CREATE TABLE \\1$prefix",
                                  $query);
            $query = preg_replace('/^INSERT INTO (`?)/',
                                  "INSERT INTO \\1$prefix",
                                  $query);

            //Remove semi-colon from query
            $query = substr($query,0,-1);

        	//Execute query (ADODB)
            $rs = $db->Execute($query);
            if($rs === FALSE)
            {
                $error = TRUE;
                echo '<br><br>' . $db->ErrorMsg();
            }

            //Reset query
            $query = '';
        }
    }
}

