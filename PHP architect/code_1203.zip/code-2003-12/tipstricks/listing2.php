//Determine protocol of web pages
if(isset($_SERVER['HTTPS']) && strcasecmp($_SERVER['HTTPS'],'ON') == 0)
{ $_CONF['protocol'] = 'https://'; }
else
{ $_CONF['protocol'] = 'http://'; }

//HTML address of this program
$_CONF['html'] = $_CONF['protocol'] . $_SERVER['SERVER_NAME']
    . dirname($_SERVER['SCRIPT_NAME']);

//Determine web address of current page
$_CONF['current_page'] = $_CONF['protocol'] .
    $_SERVER['SERVER_NAME'] . $_SERVER['SCRIPT_NAME'];
