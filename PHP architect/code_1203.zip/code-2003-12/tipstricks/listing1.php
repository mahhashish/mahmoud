<?php

/* Helper class for retrieving
   POST GET REQUEST SESSION and COOKIE
   variables */

class req
{

    /*
     * We don't need a constructor here
     *
     * This set will return the variable if it is set
     * or a default value if supplied, otherwise false.
     * $variable_name is the name as a string.
     * $default can be any type except a reference.
     */

    function get($variable_name,$default=false)
    {
        return (isset($_GET[$variable_name]))?
        $_GET[$variable_name] : $default;
    }

    function post($variable_name,$default=false)
    {
        return (isset($_POST[$variable_name]))?
        $_POST[$variable_name] : $default;
    }

    function request($variable_name,$default=false)
    {
        return (isset($_REQUEST[$variable_name]))?
        $_REQUEST[$variable_name] : $default;
    }

    function server($variable_name,$default=false)
    {
        return (isset($_SERVER[$variable_name]))?
        $_SERVER[$variable_name] : $default;
    }

    function session($variable_name,$default=false)
    {
        return (isset($_SESSION[$variable_name]))?
        $_SESSION[$variable_name] : $default;
    }

    function cookie($variable_name,$default=false)
    {
        return (isset($_COOKIE[$variable_name]))?
        $_COOKIE[$variable_name] : $default;
    }

    /*
     * This set will return TRUE if the variable is set
     * and is equal to the supplied comparison value
     * otherwise returns false.
     * $variable_name is the name as a string.
     * $compare can be any type except a reference.
     */

    function getEQ($variable_name,$compare)
    {
        return (req::get($variable_name) == $compare)?
        true : false;
    }

    function postEQ($variable_name,$compare)
    {
        return (req::post($variable_name) == $compare)?
        true : false;
    }

    function requestEQ($variable_name,$compare)
    {
        return (req::request($variable_name) == $compare)?
        true : false;
    }

    function serverEQ($variable_name,$compare)
    {
        return (req::server($variable_name) == $compare)?
        true : false;
    }

    function sessionEQ($variable_name,$compare)
    {
        return (req::session($variable_name) == $compare)?
        true : false;
    }

    function cookieEQ($variable_name,$compare)
    {
        return (req::cookie($variable_name) == $compare)?
        true : false;
    }
}


