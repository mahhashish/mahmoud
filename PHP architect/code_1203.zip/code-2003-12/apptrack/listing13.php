$result =  $this->db->query($SQL);
      if (DB::isError($result))
      {
        $msg =  $result->getMessage();
        if (stristr($SQL,"DROP"))
          $this->logDrop($msg);
        elseif (stristr($SQL,"DELETE"))
           $this->logDelete($msg);
        elseif (stristr($SQL,"UPDATE"))
           $this->logUpdate($msg);
        elseif (stristr($SQL,"INSERT"))
           $this->logInsert($msg);
        elseif (stristr($SQL,"SELECT"))
           $this->logRead($msg);
        else
           $this->logWrite($msgs);
      }
      return $result;