   function pDisplay ($msg, $break=true) //Should be private
   {
      echo $this->Preferences->PreError;
      echo $msg;
      if ($break)
         echo  "<br>";
      echo $this->Preferences->PostError;
   }
   
   function pWrite($msg)
   {
      $IPAddr = (string)$_ENV['REMOTE_ADDR'];
      $timeStamp = getdate();
      $file = $this->Preferences->Path . $this->LogFileName;
      $line = $msg . "\t"
            . $IPAddr . "\t"
            . $timeStamp["mday"] . " "
            . $timeStamp["month"] . " "
            . $timeStamp["year"] . " "
            . $timeStamp["hours"] . ":"
            . $timeStamp["minutes"] . ":"
            . $timeStamp["seconds"] . "\n";
      $theresult = $this->pWriteFile($file, $line);
   }