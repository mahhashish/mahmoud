// System Types
   define ("DB_READ","ReadingDB");
   define ("DB_INSERT","InsertDB");
   define ("DB_UPDATE","UpdateDB");
   define ("DB_DELETE","DeleteDB");
   define ("DB_DROP","DropDB");
   define ("DB_WRITE","WritingDB");
   define ("FILE_READ","ReadingF");
   define ("FILE_WRITE","WritingF");