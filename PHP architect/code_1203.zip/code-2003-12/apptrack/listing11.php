   function connect($dsn)
   {
      $log = new cSystemLog;
      $log->logMsg("Connecting to $dsn",DB_READ);
      include_once "DB.php";
      $dbLog = new DBTemp;
      $dbLog->db =  DB::connect($dsn);
      return $dbLog;
   }