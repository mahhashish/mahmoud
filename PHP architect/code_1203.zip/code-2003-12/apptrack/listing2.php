class cErrorPref extends cPreferences
{
   var $Level;
   var $PreHTMLTag;
   var $PostHTMLTag;
   var $WhichFiles;
   
   function cErrorPref ($PreHTMLTag = "<font color=ff00ff>"
                       ,$PostHTMLTag = "</font>"
                       ,$WhichFiles = BOTH_FILES
                       ,$display = true
                       ,$file = true
                       ,$PreErrorTag = "<font color=ff0000>"
                       ,$PostErrorTag = "</font>"
                       ,$Path = "log/"
                       )
   {
      parent::cPreferences($display, $file, $PreErrorTag, $PostErrorTag, $Path);
      $this->PreHTMLTag = $PreHTMLTag;
      $this->PostHTMLTag = $PostHTMLTag;
      $this->WhichFiles = $WhichFiles;
      $this->Level= array
         (
            "Validation" => array
            (
               "string"=> array
               (
                  "file"=>true
                 ,"desc"=>"Validation: "
               )
              ,"HTML"=> array
               (
                  "display"=> true
                 ,"desc"=>$PreHTMLTag."Validation: ".$PostHTMLTag
               )
            )
           ,"Authorisation" => array
            (
               "string"=> array
               (
                  "file"=>true
                 ,"desc"=>"Authorisation: "
               )
              ,"HTML"=> array
               (
                  "display"=> true
                 ,"desc"=>$PreHTMLTag."Authorisation Error: ".$PostHTMLTag
               )
            )
         );
   }
}