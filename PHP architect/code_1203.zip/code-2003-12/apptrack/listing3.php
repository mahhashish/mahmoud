<?php

class cFileHandler
{
   var $ouch;
   var $locking;
   var $errorStatus;
   var $retry; // maximum number of locking attempt
   var $pause; // wait in mirco second between attempts

   function cFileHandler($locking = true, $retry = 5, $pause = 1000)
   {
      $this->ouch = new cSevereError;
	  $this->locking = $locking;
	  $this->errorStatus = NO_ERROR;
	  $this->retry = $retry;
	  $this->pause = $pause;
   }
   function AppendLine($file, $msg)
   {
      $handle = $this->OpenFile($file);
	  if ($handle == false)
	     return false;
	  else
	     return $this->WriteToFile($handle, $msg);
   }
   
   function OpenFile ($file, $mode = 'a', $force = true)
   {
      if (file_exists($file))
	  {
	     $handle = @fopen($file, $mode);
		 if (!$handle)
		 {
		    $this->errorStatus = COULD_NOT_OPEN_FILE;
			return false;
		 }
		 else
		    return $handle;
	  }
	  else if ($force)
	  {
	     $handle = @fopen($file, 'a');
		 if (!$handle)
		 {
		    $this->errorStatus = COULD_NOT_CREATE_FILE;
			return false;
		 }
		 else
		    return $handle;
      }
	  else
	  {
		 $this->errorStatus = FILE_DOES_NOT_EXIST;
		 return false;
	  }
   }
   
   function ReadFormat ($handle, $format= "%s\n")
   {
      if ($this->locking)
	  {
	     $locked = flock($handle,LOCK_SH+LOCK_NB);
		 $attempts = 0;
		 while (!$locked and $attempts <= $this->retry)
		 {
		    usleep($this->pause);
			$locked = flock($handle,LOCK_SH+LOCK_NB);
		    $attempts++;
		 }
		 if (!$locked)
		    return false;
	  }
	  $line = fscanf($handle, $format);
      if ($this->locking)
	  {
         $locked = flock($handle,LOCK_UN+LOCK_NB);
		 $attempts = 0;
		 while (!$locked and $attempts <= $this->retry)
		 {
		    usleep($this->pause);
			$locked = flock($handle,LOCK_UN+LOCK_NB);
		    $attempts++;
		 }
		 if (!$locked)
		    $this->ouch->alert("Failed to release a file lock");
      }
	  return $line;
   }

   function FileRead($filename)
   {
      $handle = $this->OpenFile($filename, 'rb', false);
      if ($handle == true)
      {
        if ($this->locking)
        {
            $locked = flock($handle,LOCK_SH+LOCK_NB);
            $attempts = 0;
            while (!$locked and $attempts <= $this->retry)
            {
                usleep($this->pause);
                $locked = flock($handle,LOCK_SH+LOCK_NB);
                $attempts++;
            }
            if (!$locked)
                return false;
        }
        $file = fread($handle, filesize ($filename));
        if ($this->locking)
        {
            $locked = flock($handle,LOCK_UN+LOCK_NB);
            $attempts = 0;
            while (!$locked and $attempts <= $this->retry)
            {
                usleep($this->pause);
                $locked = flock($handle,LOCK_UN+LOCK_NB);
                $attempts++;
            }
            if (!$locked)
                $this->ouch->alert("Failed to release a file lock");
        }
        return $file;
      }
      else
      {
         return false;
      }
   }
   
   function WriteToFile ($handle, $details)
   {
      if ($this->locking)
	  {
	     $locked = flock($handle,LOCK_EX+LOCK_NB);
		 $attempts = 0;
		 while (!$locked and $attempts <= $this->retry)
		 {
		    usleep($this->pause);
			$locked = flock($handle,LOCK_EX+LOCK_NB);
		    $attempts++;
		 }
		 if (!$locked)
		    return false;
	  }
	  $result = fwrite($handle, $details);
	  if ($this->locking)
	  {
         $locked = flock($handle,LOCK_UN+LOCK_NB);
		 $attempts = 0;
		 while (!$locked and $attempts <= $this->retry)
		 {
		    usleep($this->pause);
			$locked = flock($handle,LOCK_UN+LOCK_NB);
		    $attempts++;
		 }
		 if (!$locked)
		    $this->ouch->alert("Failed to release a file lock");
      }
	  if (!$result)
	     fclose($handle);
	  return $result;
   }

}

?>
