   // The cLogging constructor
   function cLogging ($fileName  = "LogFile", $pref = null)
   {
      parent::cFileHandler();
      $this->Preferences = $pref;
      $this->LogFileName = $fileName;
   }
   
   // The cErrorLog constructor
   function cErrorLog ($fileName  = "ErrorLog", $pref = null)
   {
      if ($pref == null)
        $pref = new cErrorPref();
      parent::cLogging($fileName, $pref);
   }