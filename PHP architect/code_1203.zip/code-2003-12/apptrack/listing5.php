   function logMsg ($msg, $lvl, $break=true)
   {
      $this->errLevel = $lvl;
      if ($this->Preferences->Level[$this->errLevel]["HTML"]["display"])
         $this->pDisplay ($msg, $break);
      if ($this->Preferences->Level[$this->errLevel]["string"]["file"])
         $this->pWrite($msg);
   }
