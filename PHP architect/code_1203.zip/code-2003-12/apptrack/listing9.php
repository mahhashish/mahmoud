   function ReadErrorLevelPref($start, $Level)
   {
      // Get the error level section 
      $start = $this->GetPrefSection($Level,$start);
      $pref = $this->$PrefFileSection;
      // Now extract the string section
      $this->GetPrefSection("string",$start);
      $pref = $this->$PrefFileSection;
      // Extract the file and desc details;
      if ($this->GetPrefDetail($pref,'file')=='true')
         $this->Level[$Level]["string"]["file"]=true;
      else
         $this->Level[$Level]["string"]["file"]=false;
      $this->Level[$Level]["string"]["desc"]=$this->GetPrefDetail($pref,'desc');
      // Now extract the HTML section
      $start = $this->GetPrefSection("HTML",$start);
      $pref = $this->$PrefFileSection;
      // Extract the display and desc details;
      if ($this->GetPrefDetail($pref,'display')=='true')
         $this->Level[$Level]["HTML"]["display"]=true;
      else
         $this->Level[$Level]["HTML"]["display"]=false;
      $text =  $this->GetPrefDetail($pref,'desc');
      eval("\$detail=\"$text\";");
      $this->Level[$Level]["HTML"]["desc"] = $detail;
   }