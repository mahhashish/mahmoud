   function query($SQL)
   {
      if (stristr($SQL,"DROP"))
        $this->logDrop($SQL);
      elseif (stristr($SQL,"DELETE"))
         $this->logDelete($SQL);
      elseif (stristr($SQL,"UPDATE"))
         $this->logUpdate($SQL);
      elseif (stristr($SQL,"INSERT"))
         $this->logInsert($SQL);
      elseif (stristr($SQL,"SELECT"))
         $this->logRead($SQL);
      else
         $this->logWrite($SQL);
      include_once "DB.php";
      return $this->db->query($SQL);
   }