[Preferences]
	Display = true
	File = true
	PreError = <font color=ff0000>
	PostError = </font>
	Path = log/
[Preferences-End]
[ErrorPref]
	PreHTMLTag = <font color=ff00ff>
	PostHTMLTag = </font>
	WhichFiles = BOTH_FILES
	[Level]
		[Validation]
			[string]
				file = true
				desc = Validation: 
			[string-End]
			[HTML]
				display = true
				desc = <font color=0088ff>Validation: </font>
			[HTML-End]
		[Validation-End]
		[Authorisation]
			[string]
				file = true
				desc = Authorisation: 
			[string-End]
			[HTML]
				display = true
				desc = $this->PreHTMLTag Authorisation Error: $this->PostHTMLTag
			[HTML-End]
		[Authorisation-End]