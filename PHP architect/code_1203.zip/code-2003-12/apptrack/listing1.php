class cPreferences
{
   var $Display;
   var $PreError;
   var $PostError;
   var $File;
   var $Path;

   function cPreferences ($display = true
                         ,$file = true
                         ,$PreErrorTag = "<font color=ff0000>"
                         ,$PostErrorTag = "</font>"
                         ,$Path = "log/"
                         )
   {
      $this->Display = $display;
      $this->File = $file;
      $this->PreError = $PreErrorTag;
      $this->PostError = $PostErrorTag;
      $this->Path = $Path;
      if (!file_exists($this->Path))
         if (@mkdir($this->Path) === false)
         {
            echo "Permission to create the directory $PreErrorTag";
            system ("pwd");
            echo "/{$this->Path} $PostErrorTag has been denied to the user ";
            system ("whoami");
         }
   }
}