Code for this article is part of the PgMarket project, which you can find at the following URL:

http://www.pgmarket.net/index.php
