<?php

    function smarty_function_i18nfile($params, &$smarty) {
     
        if(empty($params['file'])) {
            $smarty->trigger_error("i18nfile: missing 'file' parameter");
            return;
        }
        
        $filepath = $params['file'];
        $filename = basename($filepath);
        $path = dirname($filepath);
        
        if(isset($params['lang'])) {
            $language = $params['lang'];
        } else {
            $language = $smarty->cur_language;
        }
        
        $newfile = $path . DIR_SEP . $language . DIR_SEP . $filename;
        return $newfile;
    }
?>