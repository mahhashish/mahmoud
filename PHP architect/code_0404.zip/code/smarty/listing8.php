<?php

        function saveLanguageTable() {
           
            if(count($this->translation) != $this->translation_size) {

                $filename = "{$this->lang_path}{$this->cur_language}.php";
                $code = '<?php $__LANG = '.var_export($this->translation, true).'; ?>';
                $fr = fopen($filename, "w");
                
                if(!$fr) {
                    return false;
                }
                    
                fputs($fr, $code);
                fclose($fr);
            
            }
            
            return true;
        }
?>