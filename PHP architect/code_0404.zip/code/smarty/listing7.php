<?php

        function loadLanguageTable($language) {
           
            $filename = "{$this->lang_path}$language.php";
            
            if(file_exists($filename)) {
             
                @require_once($filename);
                
                if(is_array($__LANG)) {
                    
                    $this->translation = $__LANG;
                    $this->cur_language = $language;
                    $this->translation_size = count($this->translation);
                    $this->assign("lang", $this->cur_language);
                    
                    unset($__LANG);
                    return true;  
                } 
                       
            }
            
            return false;
            
        }

?>
