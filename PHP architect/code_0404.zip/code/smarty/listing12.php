<?php
    
    require_once("Smarty.class.php");
        
    class IntSmarty extends Smarty {

        var $default_lang = "en-us";
        var $lang_path    = "/path/to/language/tables/";
                
        var $a_languages;
        var $cur_language;
        var $translation;
        var $translation_size;
        
        function IntSmarty() {
            
            parent::Smarty();
            
            $this->register_prefilter("smarty_lang_prefilter");
            $this->register_function("i18nfile", "smarty_function_i18nfile");
            
            $this->a_languages = $this->_determineLangs();
            
            if(isset($this->a_languages[0])) {
                $this->cur_language = $this->a_languages[0];
            } else {
                $this->cur_language = NULL;
            }
            
            foreach($this->a_languages as $lang) {
                
                $this->cur_language = $lang;
                if($this->loadLanguageTable($this->cur_language)) {
                    break;
                }
                
            }
                        
        }   
        
        function fetch($file, $cache = NULL, $compile_id = "") {
            
            $cid = $this->cur_language.$compile_id;
            
            return $this->fetch($file, $cache, $cid);
        
        }
        
        function _determineLangs() {
                        
            @preg_match_all("/([a-z\-]*)?[,;]+/i", 
                           $_SERVER['HTTP_ACCEPT_LANGUAGE'], 
                           $matches);
        
            $matches[1][] = $this->default_lang;
            
            return $matches[1];
            
        }
        
        function loadLanguageTable($language) {
           
            $filename = "{$this->lang_path}$language.php";
            
            if(file_exists($filename)) {
             
                @require_once($filename);
                
                if(is_array($__LANG)) {
                    
                    $this->translation = $__LANG;
                    $this->cur_language = $language;
                    $this->translation_size = count($this->translation);
                    $this->assign("lang", $this->cur_language);
                    
                    unset($__LANG);
                    return true;  
                } 
                       
            }
            
            return false;
            
        }
        
        function saveLanguageTable() {
           
            if(count($this->translation) != $this->translation_size) {

                $filename = "{$this->lang_path}{$this->cur_language}.php";
                $code = '<?php $__LANG = '.var_export($this->translation, true).'; ?>';
                $fr = fopen($filename, "w");
                
                if(!$fr) {
                    return false;
                }
                    
                fputs($fr, $code);
                fclose($fr);
            
            }
            
            return true;
        }
        
        function assignLang($var, $value = NULL) {
         
            if(is_string($value)) {
                
                $hash = md5($value);   
                
                if(key_exists($hash, $this->translation)) {
                
                    $value = utf8_decode($this->translation[$hash]);
                    
                }  else {
                    
                    $inst->translation[$hash] = $value;
                    
                }
                
                $this->assign($var, $value);
            
            }
            
        }
        
        function _compile_template($tpl_file, $template_source, &$template_compiled) {
            
            if(file_exists(SMARTY_DIR.$this->compiler_file)) {
                require_once SMARTY_DIR.$this->compiler_file;            
            } else {
                // use include_path
                require_once $this->compiler_file;
            }
    
            $smarty_compiler = new $this->compiler_class;
    
            $smarty_compiler->template_dir      = $this->template_dir;
            $smarty_compiler->compile_dir       = $this->compile_dir;
            $smarty_compiler->plugins_dir       = $this->plugins_dir;
            $smarty_compiler->config_dir        = $this->config_dir;
            $smarty_compiler->force_compile     = $this->force_compile;
            $smarty_compiler->caching           = $this->caching;
            $smarty_compiler->php_handling      = $this->php_handling;
            $smarty_compiler->left_delimiter    = $this->left_delimiter;
            $smarty_compiler->right_delimiter   = $this->right_delimiter;
            $smarty_compiler->_version          = $this->_version;
            $smarty_compiler->security          = $this->security;
            $smarty_compiler->secure_dir        = $this->secure_dir;
            $smarty_compiler->security_settings = $this->security_settings;
            $smarty_compiler->trusted_dir       = $this->trusted_dir;
            $smarty_compiler->_reg_objects      = &$this->_reg_objects;
            $smarty_compiler->_plugins          = &$this->_plugins;
            $smarty_compiler->_tpl_vars         = &$this->_tpl_vars;
            $smarty_compiler->default_modifiers = $this->default_modifiers;
            $smarty_compiler->compile_id        = $this->_compile_id;
            $smarty_compiler->parent_inst       = &$this;
            
            if ($smarty_compiler->_compile_file($tpl_file, $template_source, $template_compiled)) {
                return true;
            } else {
                $this->trigger_error($smarty_compiler->_error_msg);
                return false;
            }
            
        }
        
    }
    
    
    function smarty_lang_prefilter($content, &$smarty) {
        
        $inst = &$smarty->parent_inst;
        
        $ldq = preg_quote($inst->left_delimiter, '!');
        $rdq = preg_quote($inst->right_delimiter, '!');
        
        /* Grab all of the tagged strings */
        preg_match_all("!{$ldq}l{$rdq}(.*?){$ldq}/l{$rdq}!s", $content, $match);
        
        foreach($match[1] as $str) {
            
            $q_str = preg_quote($str);
            $hash = md5($str);
            
            /* Do we have a translation for this string? */
            
            if(key_exists($hash, $inst->translation)) {
            
                /* Replace all occurances of this string with its translation */    
                $content = preg_replace("!{$ldq}l{$rdq}$q_str{$ldq}/l{$rdq}!s", 
                                        utf8_decode($inst->translation[$hash]), $content);  
                
            }  else {
                
                /* If not, add it as in its current form to our table,
                   which will be saved for a translator to fix */
                $inst->translation[$hash] = $str;
                
            }
            
            
        }
        
        /* Strip off the tags now that the strings have been replaced */
        $content = preg_replace("!{$ldq}l{$rdq}(.*?){$ldq}/l{$rdq}!s",
                                "\${1}", $content);
              
        return $content;   
            
    }
    
    function smarty_function_i18nfile($params, &$smarty) {
     
        if(empty($params['file'])) {
            $smarty->trigger_error("i18nfile: missing 'file' parameter");
            return;
        }
        
        $filepath = $params['file'];
        $filename = basename($filepath);
        $path = dirname($filepath);
        
        if(isset($params['lang'])) {
            $language = $params['lang'];
        } else {
            $language = $smarty->cur_language;
        }
        
        $newfile = $path . DIR_SEP . $language . DIR_SEP . $filename;
        return $newfile;
    }
 
?>

To actually use this class, it is recommended that you extend it to your own class to set configuration options as shown below in Listing 11:

Listing 11	Extending the IntSmarty class for use
<?php

    require_once("IntSmarty.class.php");
    
    class MyIntSmarty extends IntSmarty {
        
        
        var $default_lang = "en";
        var $lang_path = "/path/to/lang/tables/";
        
        var $template_dir = "/path/to/templates/";
        var $compile_dir = "/path/to/compile/dir/";
        var $config_dir = "/path/to/config/files/";
    
    }
    
?>