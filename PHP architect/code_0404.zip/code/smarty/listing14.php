<?php

    require_once("MyIntSmarty.class.php");
    
    $smarty = new MyIntSmarty();
    $smarty->assignLang("subtitle", "Main Page");
    
    $smarty->display("index.tpl");
    
    $smarty->saveLanguageTable();
    
?>