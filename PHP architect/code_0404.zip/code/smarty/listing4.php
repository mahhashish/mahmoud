<?php 
/* es.php */

$__LANG = array (
  '25f7b4bc753effbce0c836b1968b2262' => 'Este texto ser? traducido',
); 

?>