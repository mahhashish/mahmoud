<HTML>
    <HEAD>
        <TITLE>{l}My international web site -- {$subtitle}{/l}</TITLE>
    </HEAD>
    <BODY>
        {l}Welcome to my first IntSmarty web site!{/l}<BR/><BR/>
        
        Here is a picture of a flag representing your language: <BR/><BR/>
        <IMG SRC="{i18nfile file="gfx/lang_flag.jpg"}" ALT="{l}Your Flag{/l}">
        
    </BODY>
</HTML>