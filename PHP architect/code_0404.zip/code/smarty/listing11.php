<?php

        function assignLang($var, $value = NULL) {
         
            if(is_string($value)) {
                
                $hash = md5($value);   
                
                if(key_exists($hash, $this->translation)) {
                
                    $value = utf8_decode($this->translation[$hash]);
                    
                }  else {
                    
                    $inst->translation[$hash] = $value;
                    
                }
                
                $this->assign($var, $value);
            
            }
            
        }

?>