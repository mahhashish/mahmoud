<HTML>
    <HEAD><TITLE>i18nfile</TITLE></HEAD>
    <BODY>
         <IMG SRC="{i18nfile file='/gfx/myitem.jpg'}">
    </BODY>
</HTML>