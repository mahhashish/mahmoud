<?php

    function smarty_lang_prefilter($content, &$smarty) {
        
        $inst = &$smarty->parent_inst;
        
        $ldq = preg_quote($inst->left_delimiter, '!');
        $rdq = preg_quote($inst->right_delimiter, '!');
        
        /* Grab all of the tagged strings */
        preg_match_all("!{$ldq}l{$rdq}(.*?){$ldq}/l{$rdq}!s", $content, $match);
        
        foreach($match[1] as $str) {
            
            $q_str = preg_quote($str);
            $hash = md5($str);
            
            /* Do we have a translation for this string? */
            
            if(key_exists($hash, $inst->translation)) {
            
                /* Replace all occurances of this string with its translation */    
                $content = preg_replace("!{$ldq}l{$rdq}$q_str{$ldq}/l{$rdq}!s", 
                                        utf8_decode($inst->translation[$hash]), $content);  
                
            }  else {
                
                /* If not, add it as in its current form to our table,
                   which will be saved for a translator to fix */
                $inst->translation[$hash] = $str;
                
            }
            
            
        }
        
        /* Strip off the tags now that the strings have been replaced */
        $content = preg_replace("!{$ldq}l{$rdq}(.*?){$ldq}/l{$rdq}!s",
                                "\${1}", $content);
              
        return $content;   
                }
?>
