<?php

        function _determineLangs() {
                        
            @preg_match_all("/([a-z\-]*)?[,;]+/i", 
                           $_SERVER['HTTP_ACCEPT_LANGUAGE'], 
                           $matches);
        
            $matches[1][] = $this->default_lang;
            
            return $matches[1];
            
        }
?>