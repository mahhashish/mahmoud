<?

// tick function
function Profiler($get_results=false) 
{
    static $functions = array();
    static $t_last = null;

    // save the elapsed time
    if (!$get_results) {    
        $t_now = explode(' ',microtime());
        $t_now = ($t_now[0] + $t_now[1]);
        if (!$t_last)  $t_last = $t_now;
        
        // get the function
        $bktr = debug_backtrace();
        $func = $bktr[1]['class'].
                $bktr[1]['type'].
                $bktr[1]['function'];

        // save the time difference
        $functions['~TOTAL~'] += ($t_now-$t_last);
        $functions[$func] += $t_now-$t_last;
        $t_last = $t_now;

    // get the profile results
    } else {
        arsort($functions);
        return $functions;
    }
}

// register tick function
register_tick_function('Profiler');
declare(ticks=1);

// sleep for 3 seconds
function sleep3() {
    print "Inside sleep3().....";
    for ($i=0; $i<3; $i++)  sleep(1);
    print "Done\n";
}

// sleep for 5 seconds
function sleep5() {
    print "Inside sleep5().....";
    for ($i=0; $i<5; $i++)  sleep(1);
    print "Done\n";
}

// run a blank statement 100 times
function loop100() {
    print "Inside loop100().....";
    for ($i=0; $i<100; $i++);
    print "Done\n";
}

// make the function calls
sleep5();
sleep3();
loop100();

// print out the results
print_r(Profiler(true));

?>
