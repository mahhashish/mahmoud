<?

function tick() 
{
    print " ## TICK ##\n";
}


register_tick_function('tick');
for ($i=0; $i<10; $i++)  
    print "A:$i\n";

declare(ticks=1);
for ($i=0; $i<10; $i++)  
    print "B:$i\n";

declare(ticks=3);
for ($i=0; $i<10; $i++)  
    print "C:$i\n";

unregister_tick_function('tick');
for ($I=0; $i<10; $i++)  
    print "D:$i\n";
