<?

// autosave filename
define(AUTOSAVE_FILE, 'obj.dat');

// object definition
class AutoSaveObject
{
    var $volatile = false;
    var $num = 0;
}

// save the object to the autosave file
function autosave()
{
    global $object;
    if ($object && !$object->volatile) {
        $fh = fopen(AUTOSAVE_FILE, 'w');
        fwrite($fh, serialize($object));
        fclose($fh);
    }
}

// load the object or create a new instance
if (file_exists(AUTOSAVE_FILE)) {
    $file = file_get_contents(AUTOSAVE_FILE);
    $object = unserialize($file);
} else {
    $object = new AutoSaveObject();
}

// start the autosave tick function
register_tick_function('autosave');
declare(ticks=1);

// print and increment the object's num field
while (true) {
    print $object->num.'.';
    $object->num++;
    sleep(1);
}

?>
