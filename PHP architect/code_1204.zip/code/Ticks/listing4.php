<?

// register the tick function
function tick() { print "*"; }
register_tick_function('tick');

// wait function
declare(ticks=2) {
    function wait() 
    { 
        for ($i=0; $i<10; $i++)  print ".";
        print "\n";
    }
}

// no ticks
for ($i=0; $i<10; $i++)  print ".";
print "\n";
wait();

// no ticks
if (false)  declare(ticks=1);
for ($i=0; $i<10; $i++)  print ".";
print "\n";


