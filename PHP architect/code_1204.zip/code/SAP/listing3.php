<?PHP
// ------SAPGraphs.class.php ---------------------------------------------------------------
//  Graph stock data obtained from SOAP service getwbstock()
// --------------------------------------------------------------------------------------
Class SAPStockGraphClass {


	var $stockdata;

	function SAPStockGraphClass(){

		include ("/var/www/jpgraph-1.15/src/jpgraph.php");
		include ("/var/www/jpgraph-1.15/src/jpgraph_pie.php");
		include ("/var/www/jpgraph-1.15/src/jpgraph_pie3d.php");
		$this->stockdata = array();

	}


	function GetStockData(){

		require_once ("/usr/local/lib/php/nusoap.php");
		// Create new saop object to the stock service on the appplication server
		$soapserver = new soapclient("http://webapps/sapdemo/stockservice.php");
		$this->stockdata    = $soapserver->call("getwbstock");
	}

	function PlotGraph(){

		$data = array_values($this->stockdata);
		$labels = array_keys($this->stockdata);

		$graph = new PieGraph(400,200,"auto");
		$graph->SetShadow();

		$graph->title->Set("Current Stock allocation");
		$graph->title->SetFont(FF_FONT1,FS_BOLD);

		$p1 = new PiePlot3D($data);
	
		$p1->SetSize(0.5);
		$p1->SetCenter(0.45);
		$p1->SetLegends($labels);
        $graph->legend->SetAbsPos(300,10,'left','top');
		$graph->Add($p1);
		$graph->Stroke();


	}

}
?>
