<?php
require_once('nusoap.php');
// ------stcokservice.php ---------------------------------------------------------------
// getwbstock()
//
// Stock allocation by area as a percentage
// fills an array with the results
//       EXPORTING
//             VALUE(SYSTEM) LIKE  SY-SYSID
//             VALUE(TRDIR) LIKE  TRDIR STRUCTURE  TRDIR (ARRAY)
//      TABLES
//              JTAB ( ARRAY)
//  SAP FUNCTION /USR/COSMIO0228A
// --------------------------------------------------------------------------------------

function getwbstock(){
	global $LOGIN;
	// Identify custom ABAP RFC function that we need to run on the SAP server
	$function_name = "/USR/COSMIO0228A";

	$rfc = saprfc_open ($LOGIN); // login to the SAP Server then check for errors
	if (!$rfc )
	{
		// Need some better error handing in here
		$error = "RFC connection failed with error:".saprfc_error();
		return new soap_fault("Client","",$error);
	}

	// Make sure that the SAP function we wish to run can be located.
	$fce = saprfc_function_discover($rfc, $function_name);
	if (! $fce )
	{
		$error = "Discovering interface of function module $function_name failed";
		return new soap_fault("Client","",$error);
	}


	// Setup the results table
	saprfc_table_init ($fce,"JTAB");

	// Call the function and check for errors
	$rfc_rc = saprfc_call_and_receive ($fce);
	if ($rfc_rc != SAPRFC_OK)
	{
		if ($rfc == SAPRFC_EXCEPTION )
		$error = ("Exception raised: ".saprfc_exception($fce));
		else
		$error = ("Call error: ".saprfc_error($fce));
		return new soap_fault("Client","",$error);
	}

	// Read the results into variables
	$SYSTEM = saprfc_export ($fce,"SYSTEM");
	$TRDIR = saprfc_export ($fce,"TRDIR");
	;

	// Init our variables to hold the totals in each stock location
	$indexcount  =0;
	$totalstock  =0;
	$totalpurch  =0;
	$totalassemb =0;
	$totalfinish =0;
	$totalspare  =0;
	$totalredund =0;
	$totalobsole =0;
	$JTAB = array();

	// Loop through the number of results returned by SAP
	// Then store the totals for each location so we can calculate our percentages
	$rows = saprfc_table_rows ($fce,"JTAB");
	for ($i=1; $i<= $rows ; $i++)
	{
		$temp = saprfc_table_read ($fce,"JTAB",$i);
		$flag=false;
		foreach ($temp as $key => $value){
			if((int)$value ) $flag=true;
		}
		if($flag) {

			$totalstock   += $temp["TOTAL"];
			$totalpurch   += $temp["PURCH"];
			$totalfinish  += $temp["FINISH"];
			$totalassemb  += $temp["ASSEMB"];
			$totalspare   += $temp["SPARES"];
			$totalredund  += $temp["REDUND"];
			$totalobsole  += $temp["OBSOLE"];
			$indexcount++;
		}
	}


	$JTAB["PURCH"]  = (int) ($totalpurch / ($totalstock/100));
	$JTAB["FINISH"] = (int) ($totalfinish / ($totalstock/100));
	$JTAB["ASSEMB"] = (int) ($totalassemb / ($totalstock/100));
	$JTAB["SPARES"] = (int) ($totalspare / ($totalstock/100));
	$JTAB["REDUND"] = (int) ($totalredund / ($totalstock/100));
	$JTAB["OBSOLE"] = (int) ($totalobsole / ($totalstock/100));

	// Clean up and return our results back to the client
	saprfc_function_free($fce);
	saprfc_close($rfc);
	return $JTAB;

}// ---------------------------- End of Function getwbstock





$server = new soap_server;
$LOGIN = array (
"ASHOST"=>"production01",            // application server host name
"SYSNR"=>"00",                       // system number
"CLIENT"=>"400",                     // client
"USER"=>"rfcfunc",                  // user
"PASSWD"=>"MYPASSWORD",              // password
"CODEPAGE"=>"1100");                 // codepage

$server->register("getwbstock");  // Register the Webservice wbstock
$server->service($HTTP_RAW_POST_DATA);
?>
