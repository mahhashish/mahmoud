<html>
<head>
 <title> SAP Stock allocation </title>
</head>
<body>
 <h1>Live SAP Graph based on Stock Locations</h1>
 <img src="http://webapps/sapdemo/stockgraph.php">
<!� Specify location in this graph - ->
<img src="http://webapps/sapdemo/stockgraph.php?location=PURCH">
</body>
</html>
