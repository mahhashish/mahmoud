<?php
$LOGIN = array (
"ASHOST"=>"PRODUCTION01",  // application server host name
"SYSNR"=>"00",             // system number
"CLIENT"=>"400",           // client
"USER"=>"RFCUSERNAME",     // user
"PASSWD"=>"PLSCHANGEME",   // password
"CODEPAGE"=>"1100");       // codepage

//--------- Set the name of the function
$rfcfunction  = "SO_USER_LIST_READ";
$resultstable = "USER_DISPLAY_TAB";

//--------  Make a connection to the SAP server
$rfc = saprfc_open($LOGIN);

if(!$rfc) {
	// We have failed to connect to the SAP server
	echo "Failed to connect to the SAP server".saprfc_error();
	exit(1);
}

//------- Locate the function and discover the interface
$rfchandle = saprfc_function_discover($rfc, $rfcfunction);

if(!$rfchandle){
	// We have failed to discover the function
	echo "We have failed to discover the function".saprfc_error($rfc);
	exit(1);
}

//------- Setup the results handle
saprfc_table_init($rfchandle,$resultstable);

//------ Call the function and check for errors
$rfcresults = saprfc_call_and_receive($rfchandle);

if ($rfcresults != SAPRC_OK){

	if ($rfcresults == SAP_EXCEPTION){
		$error = ("Exception raised:".saprfc_exception($rfchandle));
	}else{
		$error = ("Call error:".saprfc_error($rfchandle));
	}
	echo $error;
	exit();
}

$results =array();
$numrows = saprfc_table_rows($rfchandle,$resultstable);

for ($i=1; $i <= $numrows; $i++){

	$results[$i] = saprfc_table_read($rfchandle,$resultstable,$i);
}

saprfc_function_free($rfchandle);
saprfc_close($rfc);
var_dump($results);
?>
