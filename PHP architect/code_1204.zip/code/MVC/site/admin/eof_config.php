<?php

// set the filesystem path to the Web site root folder
$path = pathinfo($_SERVER['SCRIPT_FILENAME']);
$eof_config['app_root'] = $path['dirname'];

// required to prevent PHP4 crash using PEAR DB_DataObject class
	define("DB_DATAOBJECT_NO_OVERLOAD", 0);

// set php.ini directives 
$include_path = ".;C:/PHP4/PEAR;".
	$eof_config['app_root']."/lib/Validate;".
	$eof_config['app_root']."/lib";

ini_set("include_path", $include_path);
ini_set("error_reporting", E_ALL^E_NOTICE);
ini_set("display_errors", 1);

/* set global configuration variables $eof_config */

// set default module [mod], screen [scr], event [evt]
$eof_config['default_mod'] = "df";
$eof_config['default_scr'] = "main";
$eof_config['default_evt'] = "init";

// set the database connectiong string - PEAR DB Data Source Name
$eof_config['db']['dsn'] = "mysql://root:@localhost/site";
	
// specify authentication method for the content management admin
$eof_config['auth']['method'] = "FlatFile";

// PEAR DB_DataObject configuration
$options = &PEAR::getStaticProperty('DB_DataObject','options');
  
$options = array(
    'database'         => $eof_config['db']['dsn'],
    'schema_location'  => $eof_config['app_root']."/data-objects",
    'class_location'   => $eof_config['app_root']."/data-objects",
    'require_prefix'   => $eof_config['app_root']."/data-objects",
    'class_prefix'     => 'do_',
    'debug'            => 0
);

$eof_config['app_title'] = "Site Content Manager";

?>
