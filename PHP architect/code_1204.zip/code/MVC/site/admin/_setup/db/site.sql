SET FOREIGN_KEY_CHECKS=0;

CREATE DATABASE `site`;

USE `site`;

#
# Structure for the `pr_release` table : 
#

DROP TABLE IF EXISTS `pr_release`;

CREATE TABLE `pr_release` (
  `id` smallint(6) NOT NULL auto_increment,
  `date` date NOT NULL default '0000-00-00',
  `title` varchar(50) NOT NULL default '',
  `content_markup` text,
  `content_html` text,
  `picture_width` smallint(5) unsigned default '0',
  `picture_height` smallint(5) unsigned default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

