<?php

ini_set("session.use_cookies", 1);
ini_set("session.use_only_cookies", 1);
ini_set("session.cookie_path", "/site/admin/");
ini_set("session.cookie_lifetime", 3600);

ini_set("session.name", "ADMINSESSID");

?>
