<?php
//	Start Session and Authenticate user
	
if (!$_SESSION['auth']['registered'] === true) {
	if (count($_POST) > 0) {
		// authenticate the user
		$_REQUEST['mod'] = "auth";
		$_REQUEST['scr'] = "login";
		$_REQUEST['evt'] = "authenticate";
	}
	else {
		$_SESSION['evt_path'] = $_SERVER['QUERY_STRING'];
		
		// show the login screen
		$_REQUEST['mod'] = "auth";
		$_REQUEST['scr'] = "login";
		$_REQUEST['evt'] = "init";
	}
}

?>
