<?php

// this function returns a string if a particular element in a validation array is invalid

/**
 * returns a string if a particular element in a validation array is invalid
 *
 * @return string
 * @param string name of the validation array
 * @param string name of the field
*/
function isValid($array_name, $element) 
{
	global $eof_out;
	
	$style = (is_array($eof_out[$array_name]) && in_array($element, $eof_out[$array_name])) ? ' class="invalid"' : "";
	
	return $style;
}
	

/**
 * redirects the user to a new eventpath
 *
 * @return void
 * @param string[optional] query string to be appended to the controller: index.php
*/
function maskEventPath($qs = "") 
{
	global $eof_mod, $eof_scr, $eof_evt;
	
	if (empty($qs)) {
		$eof_evtpath = "index.php?mod=$eof_mod&scr=$eof_scr&evt=$eof_evt";
		header("Location: $eof_evtpath");
		exit();
	} 
	else {
		$eof_evtpath = "index.php?$qs";
		header("Location: $eof_evtpath");
		exit();
	}
}


?>
