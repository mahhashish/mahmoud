<?php
/**
 * Table Definition for pr_release
 */
require_once 'DB/DataObject.php';

class do_Pr_release extends DB_DataObject 
{
    ###START_AUTOCODE
    /* the code below is auto generated do not remove the above tag */

    var $__table = 'pr_release';                      // table name
    var $id;                              // int(6)  not_null primary_key auto_increment
    var $date;                            // date(10)  not_null
    var $title;                           // string(50)  not_null
    var $content_markup;                  // blob(65535)  blob
    var $content_html;                    // blob(65535)  blob

    /* ZE2 compatibility trick*/
    function __clone() { return $this;}

    /* Static get */
    function staticGet($k,$v=NULL) { return DB_DataObject::staticGet('do_Pr_release',$k,$v); }

    /* the code above is auto generated do not remove the tag below */
    ###END_AUTOCODE
    
    function do_Pr_release()
    {
    	$this->keys("id");
    }
    
    function getReleases($from, $to)
    {
    	global $oDB;
    	
    	$query = "SELECT id, date, title FROM pr_release 
    	          WHERE (TO_DAYS(date) >= TO_DAYS('".$from."')) AND (TO_DAYS(date) <= TO_DAYS('".$to."')) 
    	          ORDER BY date DESC";
    	
    	$news = $oDB->getAll($query);
    	
    	if (DB::isError($news)){
    		die ($news->getMessage());
    	}
    	
    	if ( count($news) == 0 )
    	{
    		unset($news);
    		$news = "NO NEWS";
    	}
    	
    	return $news;
    }
    
    function ValidateNewsStory() 
    {
		// declare field validation rules for data object
		$validation = array(
			'date'   		 => array('type' =>  "date", 'opt' => array ( 'format' => "%Y-%m-%d")),
			'title'  		 => array('type' =>  "string", 'max_length'  => 50, 'min_length' => 1),
			'content_markup' => array('type' =>  "string", 'max_length'  => 8000)
		);
		
		// validate the array extract of the current state of the data object
		$result = Validate::multiple($this->toArray(), $validation);
		
		// check if any fields have been marked invalid
		if (in_array(false, $result, 1)) {
			// return the array of field names with true,false indicator of validity: array('[field_name]' => [true/false])
			return $result;
		} 
		else {
			// all fields of data object are valid --- the caller will check if return value === TRUE (identical)
			return true;
		}
    }
}
?>