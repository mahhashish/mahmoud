<?php

// Load required libraries into global scope and prepare them for usage

require_once("DB.php");
$oDB = DB::connect($eof_config['db']['dsn']);

if (DB::isError($oDB)) {
	die ($oDB->getMessage());
}

$oDB->setFetchMode(DB_FETCHMODE_ASSOC);

require_once("DB/DataObject.php");

// include classes from NLC namespace
require_once("NLC/Input/Cleaner.php");
require_once("NLC/HTML/FormElement.php");

// include Validate PEAR package
require_once("Validate.php");

?>
