<?php
/* --------------------------------------------------------------------- */
//	Include EOF framework functions (global scope)
/* --------------------------------------------------------------------- */	
require_once("eof_functions.php");

/* --------------------------------------------------------------------- */
//	Prepend session configuration & authentication check (if present)
/* --------------------------------------------------------------------- */	
@include_once("prepend_session.php");
session_start();
@include_once("prepend_auth.php");
  
/* --------------------------------------------------------------------- */
//	Load the PEAR class (require for DB/DataObject configuration)
/* --------------------------------------------------------------------- */
require_once("PEAR.php");
	
/* --------------------------------------------------------------------- */
//  Initialize Variables of HTTP Request Scope
/* --------------------------------------------------------------------- */
$eof_request = array();
$eof_out = array();
  	
/* --------------------------------------------------------------------- */
//  Initialize the Message from SESSION if applicable
/* --------------------------------------------------------------------- */
if (!isset($_SESSION['eof_message'])) {
	$_SESSION['eof_message'] = array(
		"text" => "",
		"type" => null
	);
}
$eof_message = &$_SESSION['eof_message'];

/* --------------------------------------------------------------------- */
//	Load the Application Configuration
/* --------------------------------------------------------------------- */
require_once("eof_config.php");

/* --------------------------------------------------------------------- */
//  Include libraries
/* --------------------------------------------------------------------- */
@include_once("prepend_classes.php");
	
/* --------------------------------------------------------------------- */
//	Clean the GET/POST Request Data
/* --------------------------------------------------------------------- */
Input_Cleaner::cleanInput();

/* --------------------------------------------------------------------- */
//  Determine module [eof_mod], screen [eof_scr] and event [eof_evt]
/* --------------------------------------------------------------------- */
$eof_mod = $eof_config['default_mod']; // set the default module [eof_mod]

if (isset($_REQUEST['mod'])) {
	if ($_REQUEST['mod'] != "") {
		$eof_mod = $_REQUEST['mod'];
	}
}

$eof_scr = $eof_config['default_scr']; // set the default screen [eof_scr]

if (isset($_REQUEST['scr'])) {
	if ($_REQUEST['scr'] != "") {
		$eof_scr = $_REQUEST['scr'];
	}
}

$eof_evt = $eof_config['default_evt']; // set the default event [eof_evt]

if (isset($_REQUEST['evt'])) {
	if ($_REQUEST['evt'] != "") {
		$eof_evt = $_REQUEST['evt'];
	}
}

/* --------------------------------------------------------------------- */
//	Process the Event Chain
/* --------------------------------------------------------------------- */
$eof_request['template_file'] = null;

while (is_null($eof_request['template_file']))
{
	$eof_class = $eof_mod."_".$eof_scr;
  	require_once("classes/$eof_class.php");
	
	$screen = new $eof_class;
	$screen->$eof_evt();
}
	
/* --------------------------------------------------------------------- */
//	Load the output template
/* --------------------------------------------------------------------- */
require_once("templates/".$eof_request['template_file']);

/* --------------------------------------------------------------------- */
//  Clean the Message in Session after the template is processed
/* --------------------------------------------------------------------- */
$_SESSION['eof_message'] = array("text" => "", "type" => null);

?>
