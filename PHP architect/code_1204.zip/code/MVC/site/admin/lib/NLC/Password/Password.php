<?php
/* vim: set expandtab tabstop=4 shiftwidth=4 softtabstop=4: */
// +----------------------------------------------------------------------+
// | NLC namespace classes
// +----------------------------------------------------------------------+
// | Copyright (c) 2004 newline Creations LLC.                            |
// +----------------------------------------------------------------------+
// | Copying, modification and redistribution of this file is prohibited  |
// | without prior written consent of newline Creations LLC. 		      |
// | [http://www.thenewline.com].										  |
// +----------------------------------------------------------------------+
// | Authors: Oto Hlincik <ohlincik@thenewline.com>						  |
// |          Lukasz Karapuda <lkarapuda@thenewline.com>                  |
// +----------------------------------------------------------------------+
//
// $Id: Password.php,v 1.1.1.1 2004/08/14 23:19:15 lkarapuda Exp $

class Password
{
	/** 
	 *	@return string
	 *	@param $intChars integer[optional]
	 *	@desc METHOD: Generates a random password of specified length
	 */
	function makePassword($intChars = 8)
	{
		$pass = "";
		$chars = array(
			"1","2","3","4","5","6","7","8","9","0",
			"a","A","b","B","c","C","d","D","e","E","f","F","g","G","h","H","i","I","j","J",
			"k","K","l","L","m","M","n","N","o","O","p","P","q","Q","r","R","s","S","t","T",
			"u","U","v","V","w","W","x","X","y","Y","z","Z");
	
		$count = count($chars) - 1;
	
		srand((double)microtime()*1000000);

		for($i = 0; $i < $intChars; $i++)
		{
			$pass .= $chars[rand(0, $count)];
		}
	
		return($pass);

	} //end makePassword()
}

/*
 * soft-tabs: 0
 * tab-width: 4
 * line-ending: \n (unix)
 */
?>
	