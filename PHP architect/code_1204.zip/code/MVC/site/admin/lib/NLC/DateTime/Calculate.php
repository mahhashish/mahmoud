<?php
/* vim: set expandtab tabstop=4 shiftwidth=4 softtabstop=4: */
// +----------------------------------------------------------------------+
// | NLC namespace classes
// +----------------------------------------------------------------------+
// | Copyright (c) 2004 newline Creations LLC.                            |
// +----------------------------------------------------------------------+
// | Copying, modification and redistribution of this file is prohibited  |
// | without prior written consent of newline Creations LLC. 		      |
// | [http://www.thenewline.com].										  |
// +----------------------------------------------------------------------+
// | Authors: Oto Hlincik <ohlincik@thenewline.com>						  |
// |          Lukasz Karapuda <lkarapuda@thenewline.com>                  |
// +----------------------------------------------------------------------+
//
// $Id: Calculate.php,v 1.1.1.1 2004/08/14 23:19:13 lkarapuda Exp $

class DateTime_Calculate
{
	/** 
	 *	@return string
	 *	@param $intOffset integer
	 *	@param $intTimestamp integer[optional]
	 *	@param $strDateFormat string[optional]
	 *	@desc METHOD: Accepts GMT timestamp and returns date adjusted to particular time offset and formatted according to date format
	*/
	function getGMT($intOffset, $intTimestamp = "" , $strDateFormat = "Y-m-d H:i:s")
	{
		/* check if the offset makes sense */
		if (!is_numeric($intOffset) || $intOffset == "")
		{
			trigger_error("The time offset is required and must be numeric.",E_USER_ERROR);
		}
		
		if (-12 > $intOffset || $intOffset > 12)
		{
			trigger_error("Invalid time offset range. Must be between -12 and 12.",E_USER_ERROR);
		}
		
		/* convert the time offset into seconds */
		$intOffset = $intOffset * 3600;
		
		/* add extra hour if daylights savings timeis in effect */
		$intDaylight = date("I") * 3600;
		
		/* add the offset to the GMT Timestamp */
		if ($intTimestamp == "")
		{
			$intTimestamp = gmdate("U");
		}
		
		$intTimestamp = $intTimestamp + $intOffset + $intDaylight;
		
		/* format the date for output */
		$output = date($strDateFormat, $intTimestamp);
		
		return $output;
		
	} //end getGMT()
	
	/** 
	 *	@return int
	 *	@param $strUnits string
	 *	@param $dteFirst string
	 *	@param $dteSecond string[optional]
	 *	@desc METHOD: calculates the difference between 2 dates and returns the result in specified units
	*/
	function dateDifference($strUnits, $dteFirst, $dteSecond = "")
	{
		/* calculate the appropriate differnce units */		
		$minute	= 60;
		$hour	= 60 * $minute;
		$day	= 24 * $hour;
		$week	= 7 * $day;
		$year	= 265.25 * $day;
		
		/* determine the second timestamp */
		if ($dteSecond == "")
		{
			$time2 = time();
		}
		else 
		{
			$time2 = strtotime($dteSecond);
		}
		
		/* get the first timestamp */
		$time1 = strtotime($dteFirst);
		
		/* calcualte the difference */
		$time_diff = $time1 - $time2;
		
		/* get the return value in appropriate units */
		if ($strUnits == "m")
		{
			$output = floor($time_diff/$minute);
		}
		elseif ($strUnits == "h")
		{
			$output = floor($time_diff/$hour);
		}
		elseif ($strUnits == "d")
		{
			$output = floor($time_diff/$day);
		}
		elseif ($strUnits == "w")
		{
			$output = floor($time_diff/$week);
		}
		elseif ($strUnits == "y")
		{
			$output = floor($time_diff/$year);
		}
		else 
		{
			$output = 0;
		}
		
		return $output;
	
	} //end dateDifference()
}

/*
 * soft-tabs: 0
 * tab-width: 4
 * line-ending: \n (unix)
 */
?>
