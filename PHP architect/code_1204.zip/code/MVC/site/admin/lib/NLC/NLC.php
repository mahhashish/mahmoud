<?php
/* vim: set expandtab tabstop=4 shiftwidth=4 softtabstop=4: */
// +----------------------------------------------------------------------+
// | NLC namespace classes
// +----------------------------------------------------------------------+
// | Copyright (c) 2004 newline Creations LLC.                            |
// +----------------------------------------------------------------------+
// | Copying, modification and redistribution of this file is prohibited  |
// | without prior written consent of newline Creations LLC. 		      |
// | [http://www.thenewline.com].										  |
// +----------------------------------------------------------------------+
// | Authors: Oto Hlincik <ohlincik@thenewline.com>						  |
// |          Lukasz Karapuda <lkarapuda@thenewline.com>                  |
// +----------------------------------------------------------------------+
//
// $Id: NLC.php,v 1.1.1.1 2004/08/14 23:19:13 lkarapuda Exp $

class NLC
{
	function NLC() {return;}
}

/*
 * soft-tabs: 0
 * tab-width: 4
 * line-ending: \n (unix)
 */
?>
