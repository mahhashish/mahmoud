<?php
/* vim: set expandtab tabstop=4 shiftwidth=4 softtabstop=4: */
// +----------------------------------------------------------------------+
// | NLC namespace classes
// +----------------------------------------------------------------------+
// | Copyright (c) 2004 newline Creations LLC.                            |
// +----------------------------------------------------------------------+
// | Copying, modification and redistribution of this file is prohibited  |
// | without prior written consent of newline Creations LLC. 		      |
// | [http://www.thenewline.com].										  |
// +----------------------------------------------------------------------+
// | Authors: Oto Hlincik <ohlincik@thenewline.com>						  |
// |          Lukasz Karapuda <lkarapuda@thenewline.com>                  |
// +----------------------------------------------------------------------+
//
// $Id: Format.php,v 1.1.1.1 2004/08/14 23:19:15 lkarapuda Exp $

class Text_Format
{
	/** 
	 *	@return string
	 *	@param $intFileSize integer
	 *	@param $blnShowBytes boolean[optional]
	 *	@desc METHOD: Formats file size in bytes for appropriate output
	*/
	function formatFileSize($intFileSize, $blnShowBytes = false)
	{
		if ($intFileSize == 0)
		{
			$strFileSize = "0kB";
		}
		elseif ($intFileSize < 1024)
		{
			$strFileSize = "1kB";
		}
		elseif ($intFileSize < 1048576)
		{
			$strFileSize = intval($intFileSize/1024)."kB";
		}
		else
		{
			$strFileSize = round($intFileSize/1048576, 2)."MB";
		}
		
		if ($blnShowBytes)
		{
			$strFileSize .= " (".$intFileSize." bytes)";
		}
		
		return $strFileSize;
		
	} //end formatFileSize()
	
	
	/** 
	 *	@return string
	 *	@param $strInput integer
	 *	@desc METHOD: Formats plain text input into HTML output (makes all URLs and email links clickable)
	*/
	function textToHtml($strInput)
	{
		$strOutput = htmlentities($strInput);
		$strOutput = ereg_replace("(http://)?([a-zA-Z0-9]+\.[^ \t]+\.[^ \t\n0-9]+[a-zA-Z0-9])","<a href=\"http://\\2\">\\0</a>",$strOutput);
		$strOutput = ereg_replace("([a-zA-Z0-9\.\-_]+@[^ \t]+\.[^ \t\n]+[a-zA-Z0-9])","<a href=\"mailto:\\0\">\\0</a>",$strOutput);
		$strOutput = str_replace ( "\n", "<br>", $strOutput);
		
		return $strOutput;
		
	} //end textToHtml()
	
}

/*
 * soft-tabs: 0
 * tab-width: 4
 * line-ending: \n (unix)
 */
?>
