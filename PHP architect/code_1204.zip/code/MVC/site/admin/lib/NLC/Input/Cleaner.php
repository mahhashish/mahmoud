<?php
/* vim: set expandtab tabstop=4 shiftwidth=4 softtabstop=4: */
// +----------------------------------------------------------------------+
// | NLC namespace classes
// +----------------------------------------------------------------------+
// | Copyright (c) 2004 newline Creations LLC.                            |
// +----------------------------------------------------------------------+
// | Copying, modification and redistribution of this file is prohibited  |
// | without prior written consent of newline Creations LLC. 		      |
// | [http://www.thenewline.com].										  |
// +----------------------------------------------------------------------+
// | Authors: Oto Hlincik <ohlincik@thenewline.com>						  |
// |          Lukasz Karapuda <lkarapuda@thenewline.com>                  |
// +----------------------------------------------------------------------+
//
// $Id: Cleaner.php,v 1.1.1.1 2004/08/14 23:19:15 lkarapuda Exp $

class Input_Cleaner
{
	/** 
	 *	@return void
	 *	@desc METHOD: Steps through the POST variables and cleans them from potentially harmful elements
	 */
	function cleanInputStrictly()
	{
		
		if (count($_POST) > 0)
		{
			foreach ($_POST as $key => $value)
			{
			    /* not array from form element */
			    if (!is_array($value))
				{
				    /* remove plank characters from the front and end of the value */
					$_POST[$key] = trim($_POST[$key]);
					
					/* remove all the HTML */
					$_POST[$key] = strip_tags($_POST[$key]);
					
					/* remove the weird apostrophe */
					$_POST[$key] = str_replace("`","",$_POST[$key]);
					
					/* remove the back-slashes */
					$_POST[$key] = stripslashes($_POST[$key]);
				}
			}
		}
		
		if (count($_GET) > 0)
		{
			foreach ($_GET as $key => $value)
			{
			    /* not array from form element */
			    if (!is_array($value))
				{
				    /* remove plank characters from the front and end of the value */
					$_GET[$key] = trim($_GET[$key]);
					
					/* remove all the HTML */
					$_GET[$key] = strip_tags($_POST[$key]);
					
					/* remove the weird apostrophe */
					$_GET[$key] = str_replace("`","",$_POST[$key]);
					
					/* remove the back-slashes */
					$_GET[$key] = stripslashes($_POST[$key]);
				}
			}
		}
			
	}

	/** 
	 *	@return void
	 *	@desc METHOD: Steps through the POST variables and cleans them from potentially harmful elements
	 *                Don't remove HTML tags
	*/
	function cleanInput()
	{
		
		if (count($_POST) > 0)
		{
		    foreach ($_POST as $key => $value)
			{
			  /* not array from form element */
			  if (!is_array($value))
				{
				    /* remove blank characters from the front and end of the value */
					$_POST[$key] = trim($_POST[$key]);
					
					/* remove the weird apostrophe */
					$_POST[$key] = str_replace("`","",$_POST[$key]);
					
					/* remove the back-slashes */
					$_POST[$key] = stripslashes($_POST[$key]);;
				}
			}
		}
		
		if (count($_GET) > 0)
		{
			foreach ($_GET as $key => $value)
			{
			  if (!is_array($value))
				{
				    /* remove plank characters from the front and end of the value */
					$_GET[$key] = trim($_GET[$key]);
					
					/* remove the weird apostrophe */
					$_GET[$key] = str_replace("`","",$_GET[$key]);
					
					/* remove the back-slashes */
					$_GET[$key] = stripslashes($_GET[$key]);
				}
			}
		}
			
	}
}

/*
 * soft-tabs: 0
 * tab-width: 4
 * line-ending: \n (unix)
 */
?>
