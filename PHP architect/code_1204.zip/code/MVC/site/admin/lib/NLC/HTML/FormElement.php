<?php
/* vim: set expandtab tabstop=4 shiftwidth=4 softtabstop=4: */
// +----------------------------------------------------------------------+
// | PHP version 4                                                        |
// +----------------------------------------------------------------------+
// | Copyright (c) 1997-2004 The PHP Group                                |
// +----------------------------------------------------------------------+
// | This source file is subject to version 3.0 of the PHP license,       |
// | that is bundled with this package in the file LICENSE, and is        |
// | available through the world-wide-web at the following url:           |
// | http://www.php.net/license/3_0.txt.                                  |
// | If you did not receive a copy of the PHP license and are unable to   |
// | obtain it through the world-wide-web, please send a note to          |
// | license@php.net so we can mail you a copy immediately.               |
// +----------------------------------------------------------------------+
// | Authors: Original Author <author@example.com>                        |
// |          Your Name <you@example.com>                                 |
// +----------------------------------------------------------------------+
//
// $Id: FormElement.php,v 1.1.1.1 2004/08/14 23:19:14 lkarapuda Exp $

class HTML_FormElement
{
	function createComboBox($name, $values, $selected = '', $short = false, $css = '', 
	                        $js_on_event = '', $xhtml = true, $id = '')
	{
		$selected_tag = ($xhtml) ? 'selected="selected"' : 'selected';
		$id = ($id == '') ? $name : $id;
		
		ob_start();
		printf("<select name=\"%s\" id=\"%s\" %s %s>\n", 
			$name, 
			$id, 
			($css ? "class=\"$css\"" : ""),
			$js_on_event
		);
	
		if ($short) ksort($values);	
		reset($values);
		
		while (list($abbrev, $name) = each($values))
		{
			printf("<option value=\"%s\" %s>%s</option>\n",
				$abbrev,	
				($selected == $abbrev) ? $selected_tag : '',
				($short) ? $abbrev : $name
			); 
		}
		print "</select>\n";
		
		return ob_get_clean();
	}
	
	function createCheckBoxList($name, $values, $selected = '', $short = false, $css = '', 
	                            $horizontal = false, $js_on_event = '', $id = '')
	{
		$id = ($id == '') ? $name : $id;
		
		if ($short) ksort($values);	
		reset($values);
		
		ob_start();
		
		while (list($value, $text) = each($values))
		{
			printf("<input name=\"%s[]\" id=\"%s\" type=\"checkbox\" value=\"%s\" %s/>%s %s",
				$name,
				$id,
				$value,
				(in_array($value, $selected)) ? "checked" : "",
				($short) ? $value : $text,
				($horizontal) ? "&nbsp;&nbsp" : "<br/>"
			); 
		}
		
		return ob_get_clean();
	}
	
//	/**
//	 * Create a list of checkboxes in vertical or horizontal layout
//	 *	
//	 * Sample output:
//	 * <code>
//	 * 	<input name="name[]" type="checkbox" value="1" checked />material<br/>
//		 * 	<input name="name[]" type="checkbox" value="2" checked />material<br/>
//		 * 	<input name="name[]" type="checkbox" value="3" checked />material
//	 * </code>
//	 *
//	 * @return string
//	 * @param array $a_stName
//	 * @param array $a_aValues
//	 * @param array $a_aChecked
//	 * @param bool $a_bHorizontal
//	 */
//	function createCheckboxList($a_stName, $a_aValues, $a_aChecked = array(), $a_bHorizontal = false)
//	{
//	
//		// check for input errors
//		if (!is_string($a_stName))
//		{
//			trigger_error(__CLASS__.'::'.__FUNCTION__.' argument $a_stName [1] is invalid - string expected', E_USER_ERROR); 
//		}
//		
//		if (!((int)strlen($a_stName) > 0))
//		{
//			trigger_error(__CLASS__.'::'.__FUNCTION__.' argument $a_stName [1] is invalid - min length = 1 char', E_USER_ERROR); 
//		}
//		
//		if (!is_array($a_aValues))
//		{
//			trigger_error(__CLASS__.'::'.__FUNCTION__.' argument $a_aValues [2] is invalid - array expected', E_USER_ERROR); 
//		}
//		
//		if (!is_array($a_aChecked))
//		{
//			trigger_error(__CLASS__.'::'.__FUNCTION__.' argument $a_aChecked [3] is invalid - array expected', E_USER_ERROR); 
//		}
//			
//		// assemble the checkbox list
//  		foreach($a_aValues as $l_aRow)
//  		{
//  			$l_stCheckboxList .= "<input name=\"{$a_stName}[]\" type=\"checkbox\" value=\"{$l_aRow[0]}\" ".
//  								 (in_array($l_aRow[0], $a_aChecked) ? "checked" : "")." />{$l_aRow[1]}".
//  			 					 ($a_bHorizontal === true ? "&nbsp;&nbsp;" : "<br />");
//  	
//		}
//		
//		return $l_stCheckboxList;
//	}
//	
	/** 
	 *	@return string
	 *	@param $strName string
	 *	@param $arrValues array
	 * 	@param $intSize int
	 *	@param $strCss string[optional]
	 *	@desc METHOD: Creates a ListBox from array input
	*/
	function createListBox($strName, $arrValues, $intSize, $arrSelected = array(), $strCss = "")
	{
		/* check if an options array has been submitted */
		if (!is_array($arrValues))
		{
			trigger_error(__CLASS__.'::'.__FUNCTION__.' argument $arrValues [2] is invalid - array expected', E_USER_ERROR); 
		}
		
		$strListBox = "<select name=\"".$strName."[]\" id=\"".$strName."\" size=\"".$intSize."\" multiple";
		
		if ($strCss != "")
		{
			$strListBox .= " class=\"".$strCss."\"";
		}
		
		$strListBox .= ">\n";
		
		
		/* determine whether the supplied array is 1D or 2D and create options accordingly */
		if (count($arrValues[0]) == 1)
		{
			/* generate the options */
			foreach ($arrValues as $value)
			{
				$strListBox .= "<option value=\"".$value."\"";
				if (in_array($value, $arrSelected))
				{
				 	$strListBox .= " selected";
				}
				$strListBox .= ">".$value."</option>\n";
			}
		}
		else 
		{
			/* generate the options */
			foreach ($arrValues as $value)
			{
				$strListBox .= "<option value=\"".$value[0]."\"";
				if (in_array($value[0], $arrSelected))
				{
				 	$strListBox .= " selected";
				}
				$strListBox .= ">".$value[1]."</option>\n";
			}
		}
		
		$strListBox .= "</select>\n";
		
		/* return the finished combo box */
		return $strListBox;
		
	} //end createListBox()	
	
}

/*
 * soft-tabs: 0
 * tab-width: 4
 * line-ending: \n (unix)
 */
?>
