<?php
/* vim: set expandtab tabstop=4 shiftwidth=4 softtabstop=4: */
// +----------------------------------------------------------------------+
// | NLC namespace classes
// +----------------------------------------------------------------------+
// | Copyright (c) 2004 newline Creations LLC.                            |
// +----------------------------------------------------------------------+
// | Copying, modification and redistribution of this file is prohibited  |
// | without prior written consent of newline Creations LLC. 		      |
// | [http://www.thenewline.com].										  |
// +----------------------------------------------------------------------+
// | Authors: Oto Hlincik <ohlincik@thenewline.com>						  |
// |          Lukasz Karapuda <lkarapuda@thenewline.com>                  |
// +----------------------------------------------------------------------+
//
// $Id: SimpleMail.php,v 1.1.1.1 2004/08/14 23:19:14 lkarapuda Exp $

/**
*
*  Sends simple mail using the mail() functionality in PHP
*
*  <b>Date Started:</b>      2003-05-08 <br />
*  <b>Date Last Revised:</b> 2003-06-21 [Oto Hlincik]
*
*  This class uses the built-in <em>mail()</em> functionality of PHP.
*  It sends only simple emails, that means it is not capable of sending MIME attachments.
*  The email can be formatted in HTML and sent as HTML email.
*
*  <b><i>Example Usage:</i></b>
*  <code>
*  <?php
*    // include SimpleMail core class
*    require("simplemail.phpclass");
*    // instantiate Email object - required
*    $objEmail = new SimpleMail();
*    // set the email recipient
*    $objEmail->addTo($toEmail, $toName);
*    // set the email sender
*    $objEmail->from($fromEmail, $fromName);
*    // set the subject and body
*    $objEmail->subject($strSubject);
*    $objEmail->body($strBody);
*    // send email
*    $objEmail->send();
*  ?>
*  </code>
*
*  To use an email template see {@link loadTemplate loadTemplate method}
*
*  <b><i>Notes</i></b>:<br />
*  On Windows platform it is important to set the <b>SMTP switch</b> in the <b>php.ini</b>
*  to the appropriate SMTP server and the account of the sender needs to be set up to a valid
*  user account on that SMTP server. Also, the {@link $blnIsWindows $blnIsWindows} class variable
*  needs to be set to TRUE in order for the SMTP server to use headers appropriately.<br />
*  On Linux platform it is important to set up the <b>sendmail</b> in the <b>php.ini</b>.
*
*  @package Core
*  @author Oto Hlincik <oto@thenewline.com>
*  @version 1.2
*  @copyright 2003 newline Creations, LLC [http://www.thenewline.com]
*
*/

class SimpleMail
{
	
	/**
	* Sets if the class is running under Windows. If yes, the To field is handled differently.
	*
 	* @since v1.2
 	* @access public
 	* @var boolean
 	*/
	var $blnIsWindows = false;
	
	/**
	* Information about the email sender
	*
 	* @access private
 	* @var string
 	*/
	var $from_header = "";
	
	/**
	* Information about the email recipient(s)
	*
 	* @access private
 	* @var string
 	*/
	var $to_header = "";
	
	/**
	* Information about the Carbon Copy recipient(s)
	*
 	* @access private
 	* @var string
 	*/
	var $cc_header = "";
	
	/**
	* Information about the Blind Carbon Copy recipient(s)
	*
 	* @access private
 	* @var string
 	*/
	var $bcc_header = "";
	
	/**
	* The destination email address
	*
 	* @access private
 	* @var string
 	*/
	var $to_field = "";
	
	/**
	* The Subject of the email
	*
 	* @access private
 	* @var string
 	*/
	var $subject_field = "";
	
	/**
	* The Subject of the email
	*
 	* @access private
 	* @var string
 	*/
	var $body_field = "";
	
	/**
	* Identifies whether the email is to be sent in HTML format
	*
 	* @access private
 	* @var boolean
 	*/
	var $is_html = false;
	
	/**
	* Identifies whether the methods will function in debug mode (print out values to screen)
	* If this is set to TRUE, the email will be printed to the screen and not sent.
	*
 	* @access public
 	* @var boolean
 	*/
	var $debug = false;
	
	function SimpleMail()
	{ } 

/* --------------------------------------------------------------------- */
//	METHODS
/* --------------------------------------------------------------------- */
	
	/**
	*  Adds a recipient to recipient list and to header information
	*
	*  @return void
	*  @param string $strEmail Email address of recipient
	*  @param string[optional] $strName Name of the recipient
	*/
	function addTo($strEmail, $strName = "")
	{
		
		if ($this->to_field)
		{
			$this->to_field .= ",".$strEmail;
		}
		else 
		{
			$this->to_field = $strEmail;
		}
		
		if ($strName == "")
		{
			$to = "<".$strEmail.">";
		}
		else 
		{
			$to = "\"".$strName."\" <".$strEmail.">";
		}
		
		if ($this->to_header)
		{
			$this->to_header .= ", ".$to;
		}
		else 
		{
			$this->to_header = "To: ".$to;
		}	
	
	} //end addTo()
	
	/**
	*  Sets the sender to a From header
	*
	*  @return void
	*  @param string $strEmail Email address of the sender
	*  @param string[optional] $strName Name of the sender
	*/
	function from($strEmail, $strName = "")
	{
		
		if ($strName == "")
		{
			$this->from_header= "From: <".$strEmail.">";
		}
		else 
		{
			$this->from_header = "From: \"".$strName."\" <".$strEmail.">";
		}
		
	} //end from()
	
	
	/**
	*  Adds a recipient to a Cc header
	*
	*  @return void
	*  @param string $strEmail Email address of the Carbon Copy recipient
	*  @param string $strName[optional] Name of the Carbon Copy recipient
	*/
	function addCc($strEmail, $strName = "")
	{
		
		if ($strName == "")
		{
			$to = "<".$strEmail.">";
		}
		else 
		{
			$to = "\"".$strName."\" <".$strEmail.">";
		}
		
		if ($this->cc_header)
		{
			$this->cc_header .= ", ".$to;
		}
		else 
		{
			$this->cc_header = "Cc: ".$to;
		}	
	
	} //end addCc()
	
	/**
	*  Adds a recipient to a Bcc header
	*
	*  @return void
	*  @param string $strEmail Email address of the Blind Carbon Copy recipient
	*  @param string[optional] $strName Name of the Blind Carbon Copy recipient
	*  @desc 
	*/
	function addBcc($strEmail, $strName = "")
	{
		
		if ($strName == "")
		{
			$to = "<".$strEmail.">";
		}
		else 
		{
			$to = "\"".$strName."\" <".$strEmail.">";
		}
		
		if ($this->cc_header)
		{
			$this->cc_header .= ", ".$to;
		}
		else 
		{
			$this->cc_header = "Bcc: ".$to;
		}	
	
	} //end addBcc()
	
	
	/**
	*  Sets the email subject
	*
	*  @return void
	*  @param string $strSubject Email Subject
	*/
	function subject($strSubject)
	{
		
		$this->subject_field = $strSubject;
		
	} //end subject()
	
	/**
	*  Sets the email body
	*
	*  @return void
	*  @param string $strBody Email body text
	*/
	function body($strBody)
	{
		
		$this->body_field = $strBody;
		
	} //end body()
	
	/**
	*  Sets whether the email is in HTML format or not
	*
	*  @return void
	*  @param boolean $blnIsHtml 
	*/
	function isHtml($blnIsHtml)
	{
		
		$this->is_html = $blnIsHtml;
		
	} //end isHtml()
	
	/**
	*  Clears the recipient list and the To header
	*
	*  @return void
	*/
	function clearTo()
	{
		
		$this->to_field = "";
		$this->to_header = "";
		
	} //end clearTo()
	
	/**
	*  Clears the Cc header
	*
	*  @return void
	*/
	function clearCc()
	{
		
		$this->cc_header = "";
		
	} //end clearCc()
	
	/**
	*  Clears the Bcc header
	*
	*  @return void
	*/
	function clearBcc()
	{
		
		$this->bcc_header = "";
		
	} //end clearBcc()
	
	/**
	*  Loads an email from XML email template, replaces variables in the message body and sets up the email properties
	*
	*  <b><i>Example usage:</i></b>
	*  <code>
	*  <?php
	*    // include SimpleMail core class
	*    require("simplemail.phpclass");
	*    // instantiate Email object - required
	*    $objEmail = new SimpleMail();
	*    // set some information that will replace the place holders in template
	*    $email['date'] = date("Y-m-d H:i");
	*    $email['name'] = $strName;
	*    // set the email recipient
	*    $objEmail->addTo($toEmail, $toName);
	*    // set the email sender
	*    $objEmail->from($fromEmail, $fromName);
	*    // load the XML email template and send email
	*    $objEmail->loadTemplate($strPathToTemplate."template.email.xml", $email);
	*    $objEmail->send();
	*  ?>
	*  </code>
	*
	*  <b><i>XML Template Structure</i></b>:
	*  <code>
	*  <?xml version="1.0" encoding="UTF-8"?>
	*  <template html="false">
	*    <sender email="jdoe@domain.com">John Doe</sender>
	*    <subject>Subject of the email</subject>
	*    <body><![CDATA[...this {name} and {date} will be replaced...]]></body>
	*  </template>
	*  </code>
	*
	*  The placeholders are the keys of the supplied array and are enclosed in curly braces.
	*
	*  @return void
	*  @param string $strXmlEmailTemplate Full path to the email template
	*  @param array[optional] $arrEmailVariables An array of variables that should be replaced inside the email body
	*/
	function loadTemplate($strXmlEmailTemplate, $arrEmailVariables = "")
	{
		/* load the xml template */
		if (!$arrTemplate = file($strXmlEmailTemplate))
		{
			trigger_error("Could not load the Template file.",E_USER_ERROR);
		}
		
		$strXml = implode($arrTemplate,"");
		
		/* parse XML data into associative array */
		$xmlParser = xml_parser_create();
		xml_parse_into_struct($xmlParser, $strXml, $arrEmail);
		xml_parser_free($xmlParser);
		
		/* set the local variables from the array */
		foreach ($arrEmail as $element)
		{
			if ($element['tag'] == "TEMPLATE" && $element['type'] == "open")
			{
				$blnIsHtml = $element['attributes']['HTML'];
			}
			
			if ($element['tag'] == "SENDER")
			{
				$strSenderEmail = $element['attributes']['EMAIL'];
				$strSenderName = $element['value'];
			}
			
			if ($element['tag'] == "SUBJECT")
			{
				$strSubject = $element['value'];
			}
			
			if ($element['tag'] == "BODY")
			{
				$strBody = $element['value'];
			}
		}

		if ($this->debug)
		{		
			print "<pre>";
			print "XML Struct Dump...\n\n";
			print_r($arrEmail);
			print "\n\n";
			print "Local Variables Dump...\n\n";
			print "isHTML: ".$blnIsHtml."\n";
			print "Sender: ".$strSenderName."<".$strSenderEmail.">\n";
			print "Subject: ".$strSubject."\n";
			print "Body: ".$strBody."\n";
			print "</pre>";
		}
		
		/* set the object variables */
		if ($strSenderEmail != "") $this->from($strSenderEmail, $strSenderName);
		
		$this->subject($strSubject);
		
		$blnIsHtml = strtolower($blnIsHtml);
		if ($blnIsHtml == "true" || $blnIsHtml == "yes" || $blnIsHtml == "1") $this->isHtml(true);
		
		/* parse email body variables */
		if (is_array($arrEmailVariables))
		{
			foreach ($arrEmailVariables as $key => $value)
			{
				$strBody = str_replace("{".$key."}", $value, $strBody);
			}
		}
		
		$this->body($strBody);
		
	} //end loadTemplate()
	
	/**
	*  Sends the email using the information set up through the property methods
	*
	*  @return void
	*/
	function send()
	{
		
		if (!$this->to_field)
		{
			trigger_error("Need to add email recipients. Use 'addTo'.",E_USER_ERROR);
		}
		
		if (!$this->from_header)
		{
			trigger_error("Need to add email sender. Use 'from'.",E_USER_ERROR);
		}
		
		$headers = $this->from_header."\r\n".$this->to_header."\r\n";
		
		if ($this->cc_header != "")
		{
			$headers .= $this->cc_header."\r\n";
		}
		
		if ($this->bcc_header)
		{
			$headers .= $this->bcc_header."\r\n";
		}
		
		if ($this->is_html)
		{
			$headers .= "MIME-Version: 1.0\r\nContent-type: text/html; charset=iso-8859-1\r\n";
		}
		
		if ($this->debug)
		{
			print "<pre>";
			print "\n___HEADERS___\n".htmlentities($headers);
			print "\n\n___TO___\n".$this->to_field;
			print "\n\n___SUBJECT___\n".$this->subject_field;
			print "\n\n___BODY___\n".htmlentities($this->body_field);
			print "</pre>";
		}
		else 
		{
			if ($this->blnIsWindows)
			{
				mail($this->to_field, $this->subject_field, $this->body_field, $headers);
			}
			else 
			{
				mail("", $this->subject_field, $this->body_field, $headers);
			}
		}
				
	} //end send()

} //end SimpleMail class

/*
 * soft-tabs: 0
 * tab-width: 4
 * line-ending: \n (unix)
 */
?>
