<?php
/* vim: set expandtab tabstop=4 shiftwidth=4 softtabstop=4: */
// +----------------------------------------------------------------------+
// | NLC namespace classes
// +----------------------------------------------------------------------+
// | Copyright (c) 2004 newline Creations LLC.                            |
// +----------------------------------------------------------------------+
// | Copying, modification and redistribution of this file is prohibited  |
// | without prior written consent of newline Creations LLC. 		      |
// | [http://www.thenewline.com].										  |
// +----------------------------------------------------------------------+
// | Authors: Oto Hlincik <ohlincik@thenewline.com>						  |
// |          Lukasz Karapuda <lkarapuda@thenewline.com>                  |
// +----------------------------------------------------------------------+
//
// $Id: Transform.php,v 1.1.1.1 2004/08/14 23:19:13 lkarapuda Exp $

class Array_Transform
{
	/**
	 * Transform 2-d array with one column into a 1-d array
	 * If array argument has more than 1 column, only the first column will be used
	 * If argument is not an array it will be returned unmodified.
	 * NOTE! Function is inefficient for large arrays.
	 *
	 * @return array
	 * @param array $arr2d 2-d array with 1 column
	 */
	function flattenArray($arr2d)
	{
	    /* checking array format */
	    
	    if(!is_array($arr2d)) {
	        return $arr2d;
	    }
	    
	    $arr1d = array();
	    
	    /* transform array */ 
	    foreach($arr2d as $row) {
	        $arr1d[] = $row[0];    
	    }
	    
	    return $arr1d;
	}
}

/*
 * soft-tabs: 0
 * tab-width: 4
 * line-ending: \n (unix)
 */
?>
