<?php
/* vim: set expandtab tabstop=4 shiftwidth=4 softtabstop=4: */
// +----------------------------------------------------------------------+
// | PHP version 4                                                        |
// +----------------------------------------------------------------------+
// | Copyright (c) 1997-2004 The PHP Group                                |
// +----------------------------------------------------------------------+
// | This source file is subject to version 3.0 of the PHP license,       |
// | that is bundled with this package in the file LICENSE, and is        |
// | available through the world-wide-web at the following url:           |
// | http://www.php.net/license/3_0.txt.                                  |
// | If you did not receive a copy of the PHP license and are unable to   |
// | obtain it through the world-wide-web, please send a note to          |
// | license@php.net so we can mail you a copy immediately.               |
// +----------------------------------------------------------------------+
// | Authors: Original Author <author@example.com>                        |
// |          Your Name <you@example.com>                                 |
// +----------------------------------------------------------------------+
//
// $Id: Manipulate.php,v 1.1.1.1 2004/08/14 23:19:14 lkarapuda Exp $

class File_Manipulate
{
	/** 
	 *	@return array
	 *	@param $strPath
	 *	@param $strExtensionList
	 *	@desc PRIVATE: reads the contents of a directory into array
	*/
	function readDir($strPath, $strExtensionList = "")
	{
		$arrFiles = array();
		
		if ($handle = @opendir($strPath)) 
		{
			if ($strExtensionList == "")
    		{
				while(($file = readdir($handle)) !== false) 
    			{ 
    				if ($file != "." && $file != ".." && !is_dir($file))  
        			{ 
            			$arrFiles[] = $file;
        			}
        		}
    		}
    		else 
			{
				$arrExt = explode("||", $strExtensionList);
				foreach($arrExt as $strExt)
				{
					while(false !== ($file = readdir($handle))) 
	    			{ 
	    				if ($file != "." && $file != ".." && !is_dir($file) && strpos($file, '.'.$strExt) != 0)
	        			{ 
	            			$arrFiles[] = $file;
	        			}
	        		}
				}
			}
			
		@closedir($handle); 
		
		}
		
		return $arrFiles;
		
	} //end _readDir()
	
	/** 
	 *	@return boolean
	 *	@param string $strMessage
	 *	@param string $strPath
	 *	@desc write contents to text file; place file pointer at beginning of file
	*/
	function writeFile($strMessage = "", $strPath)
	{	
		if (is_file($strPath) && !is_writeable($strPath))
		{
			return false;
		}
		else
		{
			if(!$rscHandle = fopen($strPath, 'w'))
			{
				trigger_error("fopen() failed on file <b>".$strPath."</b>.",E_USER_ERROR);
			}
			fwrite($rscHandle, $strMessage);
			fclose($rscHandle);
		}
		
		return true;
		
	} //end ()
	
	/** 
	 *	@return array
	 *	@param $strPath string
	 *	@desc METHOD: Parses a file into an array (multidimensional if more than 1 element per line, seperated with '||'
	*/
	function createArrayFromFile($strPath)
	{
		/* load file into array */
		$arrFile = file($strPath);
		
		foreach($arrFile as $key => $strLine)
		{
			$arrFile[$key] = $strLine =trim($strLine);
			
			if (strstr($strLine,"||"))
			{
				$arrTemp[] = explode("||", $strLine);	
			}
		}	
		
		if (is_array($arrTemp))
		{
			$arrFile = $arrTemp;
		}
		
		return $arrFile;
		
	} //end createArrayFromFile()
	
	/** 
	 *	@return array $arrRow array containing CSV fields; structure [row_no][field_no]
	 *	@param string $strCSVPath path to CSV file
	 *	@param string $strSeparator CSV fields separator; default=","
	 *	@desc METHOD: parses CSV file into array
	*/
	function parseCSV($strCSVPath, $strSeparator=",")
	{
	    /* if file extension is not *.csv send a user warning */
	    if ($this->_getFileExt($strCSVPath) != "csv")
	    {
	        Core::throwException("Filesystem", "parseCSV()", "<b>".$strCSVPath."</b> is not a *.csv file", __FILE__, __LINE__, E_USER_WARNING);
	    }
	    
	    /* open file */
	    $rscHandle = $this->openFile($strCSVPath);
	    
	    /* we're counting lines from 1 */ 
	    $icount = 1;
	    
	    while (!feof($rscHandle))
	    {
	        $strRow = fgets ($rscHandle);
	        $arrRow[$icount] = explode ($strSeparator, trim($strRow));
	        $icount++;
	    }
	    fclose($rscHandle);
	    
	    return $arrRow;
	} //end parseCSV()
	
	function rmDirRec($strDirPath)
	{
		if ($handle = @opendir($strDirPath))
		{
			while(($file = readdir($handle)) !== false)
			{
				if ($file == "." || $file == "..")
				{
					continue;
				}
				
				if (is_dir($strDirPath."/".$file))
				{
					/*call self for this directory */
					Filesystem::rmDirRec($strDirPath."/".$file);
					/* remove empty directory */
					@rmdir($strDirPath."/".$file);
				}
				else
				{
					/* remove file */
					@unlink($strDirPath."/".$file);
				}
			}
		}

		/* deleting dir itself */
		if (is_dir($strDirPath))
		{
			@rmdir($strDirPath);
		}
		
		@closedir($handle);
		
		return;
	
	} //end rmDirRec()
}

/*
 * soft-tabs: 0
 * tab-width: 4
 * line-ending: \n (unix)
 */
?>

