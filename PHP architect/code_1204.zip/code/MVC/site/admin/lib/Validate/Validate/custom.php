<?php

  class Validate_custom 
  {
    function pcode() {return true;}
    function phone() {return true;}
  }

?>