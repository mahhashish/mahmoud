<?php
	
class pr_edit
{
	function pr_edit() {return;}

/* --------------------------------------------------------------------- */
//	EVENTS
/* --------------------------------------------------------------------- */

    function init() 
    {
		global $eof_mod, $eof_scr, $eof_evt, $eof_request, $eof_out, $oDB,
		       $options, $eof_message, $eof_config;
		
		$oPr_Report = DB_DataObject::factory("pr_release");
		$oPr_Report->get($_GET['id']);
		
		$eof_out = $oPr_Report->toArray("story[%s]");
		
		$eof_evt = "display";
		
        return;
    }
    
    function display()
    {
		global $eof_mod, $eof_scr, $eof_evt, $eof_request, $eof_out, $oDB,
		       $options, $eof_message, $eof_config;
		       
		$eof_request['template_file'] = get_class($this).".htm";
		return;
    }
    
    function update()
    {
    	global $eof_mod, $eof_scr, $eof_evt, $eof_request, $eof_out, $oDB,
		       $options, $eof_message, $eof_config;
		
		// code to update the news story in the DB
		$oPr_Report = DB_DataObject::factory("pr_release");
		$oPr_Report->get($_GET['id']);
		$return = $oPr_Report->setFrom($_POST['story']);
		
		// create the content HTML and store in DO property
		require("Textile.php");
		$oTextile = new Textile;
		$oPr_Report->content_html = $oTextile->process($oPr_Report->content_markup);
		
		if ($return === true) {
			
			// validate DO properties before updating DB
			$valid = $oPr_Report->ValidateNewsStory();
			
			if ($valid === TRUE) {
				
				// include the event ID as a parameter for insert... This will add the game report ID to the event table
				$oPr_Report->update();
				
				$eof_message['type'] = "success";
			  	$eof_message['text'] = "The press release has been updated...";
				
				// set event path
				$eof_scr = "main";
				$eof_evt = "init";
				
				// redirect event path masking the last event path
				maskEventPath();
				
			}  else {
			  	// errors detected in input --- prefill input HTML elements with current DO data
			  	$eof_message['type'] = "error";
			  	$eof_message['text'] = "There is an error in your input. Please review the highlighted fields below...";
			}
		} else {
			// errors detected in input --- prefill input HTML elements with current do_Client data
			$eof_message['type'] = "error";
			$eof_message['text'] = "Input error. Cannot put the \$_POST data in DataObject";
		}
		
		$eof_out = $oPr_Report->toArray('story[%s]');
		
		// get array of field names that contained invalid input --- to display error message in UI
		$eof_out['story_invalid'] = array_keys($valid, false);
		
        $eof_evt = "display";
        return;
    }
    
    function preview()
    {
    	global $eof_mod, $eof_scr, $eof_evt, $eof_request, $eof_out, $oDB,
		       $options, $eof_message, $eof_config;
		
		
		require("Textile.php");
		// code to parse the form values and prepare the preview output
		$oTextile = new Textile;
		$eof_out['content_html'] = $oTextile->process($_POST['story']['content_markup']);
		$eof_out['title'] = $_POST['story']['title'];
		$eof_out['date'] = $_POST['story']['date'];
		
		$eof_request['template_file'] = $eof_mod."_preview.htm";	
    }
}

/*
 * soft-tabs: 0
 * tab-width: 4
 * line-ending: \n (unix)
 */
?>
