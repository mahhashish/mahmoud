<?php

class auth_login
{
	function auth_login() {return;}

/* --------------------------------------------------------------------- */
//	EVENTS
/* --------------------------------------------------------------------- */

	function init()
	{
		global $eof_mod, $eof_scr, $eof_evt, $eof_request, $eof_out;
		
		$eof_request['template_file'] = get_class($this).".htm";
	}
	
	function authenticate()
	{
		global $eof_config;
		
		switch ($eof_config['auth']['method']) {
			case "NLCSMTPServer": 
				$method = "authenticateNLCSMTPServer";
				break;
			default: 
				$method = "authenticateFlatFile";
				break;
		}
		
		$this->$method();
	}
	
	function authenticateFlatFile() {
		global $eof_mod, $eof_scr, $eof_evt, $eof_request, $eof_out, $eof_message, $eof_config;
		
		require("config/users.php"); // config file containing the USERS
		require("config/admins.php"); // config file containing the ADMINISTRATORS for the application
		    
		$username = $_POST['username'];
		$password = $_POST['password'];

	    if ($username != "" && $password != "")
	    {
	    	$eof_out['username'] = $username;
	    	
	    	if (key_exists($username, $USERS)) {
				if ($USERS[$username]['passw'] == $password)
				{
					$_SESSION['auth']['data']['name'] = $USERS[$username]['name'];
					$_SESSION['auth']['registered'] = true;
					$_SESSION['auth']['username'] = $username;
					$_SESSION['auth']['timestamp'] = time();
					$_SESSION['auth']['idle'] = $_SESSION['auth']['timestamp'];
					
					$eof_message = array(
						'text' => "User <strong>".$_SESSION['auth']['data']['name']."</strong> successfully logged in...",
						'type'    => 'success'
					);
						
					if (!empty($_SESSION['evt_path'])) {
						maskEventPath($_SESSION['evt_path']);
					}
					else {
						$eof_mod = $eof_config['default_mod']; // set the default module [eof_mod]
						$eof_scr = $eof_config['default_scr']; // set the default screen [eof_scr]
						$eof_evt = $eof_config['default_evt']; // set the default event [eof_evt]
						
						maskEventPath();
					}
				}
				else 
				{
					$eof_message = array(
						'text' => "The Password you have provided is incorrect.",
						'type'    => 'error'
					);

					$eof_mod = "";
					$eof_scr = "";
					$eof_evt = "";
					
					// redirect event path masking the last event path
					maskEventPath();
				}
	    	}
	    	elseif (key_exists($username, $ADMINS)) {
				if ($ADMINS[$username]['passw'] == $password)
				{
					$_SESSION['auth']['data']['name'] = $ADMINS[$username]['name'];
					$_SESSION['auth']['registered'] = true;
					$_SESSION['auth']['username'] = $username;
					$_SESSION['auth']['timestamp'] = time();
					$_SESSION['auth']['idle'] = $_SESSION['auth']['timestamp'];
					$_SESSION['auth']['admin'] = true;
						
					$eof_message = array(
						'text' => "User <strong>".$_SESSION['auth']['data']['name']."</strong> successfully logged in...",
						'type'    => 'success'
					);
						
					if (!empty($_SESSION['evt_path'])) {
						maskEventPath($_SESSION['evt_path']);
					}
					else {
						$eof_mod = $eof_config['default_mod']; // set the default module [eof_mod]
						$eof_scr = $eof_config['default_scr']; // set the default screen [eof_scr]
						$eof_evt = $eof_config['default_evt']; // set the default event [eof_evt]
						
						maskEventPath();
					}
				}
				else 
				{
					$eof_message = array(
						'text' => "The Password you have provided is incorrect.",
						'type'    => 'error'
					);

					$eof_mod = "";
					$eof_scr = "";
					$eof_evt = "";
					
					// redirect event path masking the last event path
					maskEventPath();
				}
	    	}
	    	else {
				$eof_message = array(
					'text' => "The Username you have provided is incorrect.",
					'type'    => 'error'
				);

				$eof_mod = "";
				$eof_scr = "";
				$eof_evt = "";
				
				// redirect event path masking the last event path
				maskEventPath();
	    	}
	    		
	    }	
	    else {
	    	$eof_message = array(
				'text' => "Please provide both the Username and the Password...",
				'type'    => 'error'
			);

			$eof_mod = "";
			$eof_scr = "";
			$eof_evt = "";
			
			// redirect event path masking the last event path
			maskEventPath();
	    }
	}	

}

/*
 * soft-tabs: 0
 * tab-width: 4
 * line-ending: \n (unix)
 */
?>
