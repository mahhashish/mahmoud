<?php
	
class auth_logout
{
	function auth_logout() {return;}

/* --------------------------------------------------------------------- */
//	EVENTS
/* --------------------------------------------------------------------- */
	
	function init()
	{
		global $eof_mod, $eof_scr, $eof_evt, $eof_request, $eof_out;
		
		$eof_out['name'] = $_SESSION['auth']['data']['name'];
		
		session_destroy();

		$eof_request['template_file'] = get_class($this).".htm";
	}

}

/*
 * soft-tabs: 0
 * tab-width: 4
 * line-ending: \n (unix)
 */
?>
