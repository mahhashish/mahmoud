<?php

class df_main
{
	function df_main() {return;}

/* --------------------------------------------------------------------- */
//	EVENTS
/* --------------------------------------------------------------------- */

	function init() 
	{
		global $eof_mod, $eof_scr, $eof_evt, $eof_request, $eof_out, $oDB,
		       $options, $eof_message, $eof_config;
	  
		$eof_evt = "display";
		return;
	}
	
	function display()
	{
		global $eof_mod, $eof_scr, $eof_evt, $eof_request, $eof_out, $oDB,
		       $options, $eof_message, $eof_config;
		
		$eof_request['template_file'] = get_class($this).".htm";
		return;
	}
}

/*
 * soft-tabs: 0
 * tab-width: 4
 * line-ending: \n (unix)
 */
?>
