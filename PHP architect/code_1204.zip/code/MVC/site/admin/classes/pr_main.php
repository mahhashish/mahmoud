<?php
	
class pr_main
{
	function pr_main() {return;}

/* --------------------------------------------------------------------- */
//	EVENTS
/* --------------------------------------------------------------------- */

    function init() 
    {
		global $eof_mod, $eof_scr, $eof_evt, $eof_request, $eof_out, $oDB,
		       $options, $eof_message, $eof_config;
		
		//check the inputs
		if ($_POST['from'] != "")
		{
			$from = $_POST['from'];
		}
		elseif (isset($_SESSION['pr']['from']))
		{
			$from = $_SESSION['pr']['from'];
		}
		else 
		{
			$from = date("Y-m-d");
		}
		
		if ($_POST['to'] != "")
		{
			$to = $_POST['to'];
		}
		elseif (isset($_SESSION['pr']['to']))
		{
			$to = $_SESSION['pr']['to'];
		}
		
		// predefined period specified
		if ($_GET['period'] != "")
		{
			$period = $_GET['period'];
		}
		elseif (isset($_SESSION['pr']['period'])) 
		{
			$period = $_SESSION['pr']['period'];
		}
		else 
		{
			// default period = cur_month
		  $period = "cur_month";
		}
		
		// predefined period specified
		if ($period == "custom")
		{
		  if (($from_time = strtotime($from)) > 0 )
			{
				$from = date("Y-m-d",$from_time);
				
				if (($to_time = strtotime($to)) > 0 )
				{
					if ($to_time > $from_time)
					{
						$to = date("Y-m-d",$to_time);
					}
					else 
					{
						$to = date("Y-m-d",mktime(0,0,0,date("m",$from_time),date("d",$from_time)+7,date("Y",$from_time)));
					}
				}
				else 
				{
					$to = date("Y-m-d",mktime(0,0,0,date("m",$from_time),date("d",$from_time)+7,date("Y",$from_time)));
				}
			}
			else 
			{
			// get current date information
		    $date = getdate();
		    // get last day of month
		    $last_day = date("t");
		    
		    $from = date("Y-m-d");
		    $to = date("Y-m-d", mktime(0, 0, 0, $date['mon'], $last_day, $date['year']));
		    $period = "cur_month";
			}
		} 
		else
		{
		  if ($period == "cur_month") 
		  {
		    // get current date information
		    $date = getdate();
		    // get last day of month
		    $last_day = date("t");
		    
			  $from = date("Y-m-d", mktime(0, 0, 0, $date['mon'], 1, $date['year']));
		    $to = date("Y-m-d", mktime(0, 0, 0, $date['mon'], $last_day, $date['year']));
			}
		}

		$do_Release = DB_DataObject::factory("pr_release");
		$releases = $do_Release->getReleases($from, $to);
				
		if ($releases)
		{
			$eof_out['show_releases'] = true;
			$eof_out['releases'] = $releases;
		}
		else
		{
			$eof_out['show_releases'] = false;
		}
		
		$eof_out['from'] = $_SESSION['pr']['from'] = $from;
		$eof_out['to'] = $_SESSION['pr']['to'] = $to;
		$eof_out['period'] = $_SESSION['pr']['period'] = $period;
			
		$eof_evt = "display";
        return;
    }
    
    function display()
    {
		global $eof_mod, $eof_scr, $eof_evt, $eof_request, $eof_out, $oDB,
		       $options, $eof_message, $eof_config;

		$eof_request['template_file'] = get_class($this).".htm";
		return;
    }
    
    function delete()
    {
    	global $eof_mod, $eof_scr, $eof_evt, $eof_request, $eof_out, $oDB,
		       $options, $eof_message, $eof_config;
    	
    	// code to delete the specified report
    	$oSc_event = DB_DataObject::factory("pr_release");
    	
    	$oSc_event->get($_GET['id']);
    	$oSc_event->delete();
    	
    	$eof_message['type'] = "success";
		$eof_message['text'] = "The News Story has been deleted...";
    	
    	$eof_evt = "init";
    	
    	maskEventPath();
    }
}

/*
 * soft-tabs: 0
 * tab-width: 4
 * line-ending: \n (unix)
 */
?>
