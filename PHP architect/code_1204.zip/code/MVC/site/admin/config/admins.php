<?php
$ADMINS = array(
'nlc' => array(
	'passw' => "nlclo2003",
	'name' => "nlC Administrator"
)
);
?>