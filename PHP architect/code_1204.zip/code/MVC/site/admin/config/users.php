<?php
$USERS = array(
'test' => array(
	'passw' => "test",
	'name' => "Test Account"
));
?>