<?php
require_once("DB.php");

$config['db']['dsn'] = "mysql://root:@localhost/site";
	
$query = "SELECT id, date, title, content_html
	       FROM pr_release
	       ORDER BY date DESC";

$oDB = DB::connect($config['db']['dsn']);

if (DB::isError($oDB)) {
		die ($oDB->getMessage());
}

$oDB->setFetchMode(DB_FETCHMODE_ASSOC);

$press_releases = $oDB->getAll($query);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>Site</title>
<meta http-equiv="content-language" content="en" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</head>
<body>
	<p>Welcome to my sample site with dynamic content...</p>
	<h1>Press Releases</h1>
	<?php if (!empty($press_releases)):?>
		<?php foreach($press_releases as $story):?>
			<h3><?php echo $story['title']?></h3>
			<p>
				<?php echo date("l, M j, Y",strtotime($story['date']))?><br />
				<?php echo $story['content_html']?>
			</p>
		<?php endforeach;?>
	<?php else:?>
		<p>There are no press releases...</p>
	<?php endif;?>	
</body>
</html>