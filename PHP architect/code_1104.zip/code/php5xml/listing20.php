<?php

$xsl = new XsltProcessor;
$xsl->importStylesheet($xslD);
echo $xsl->transformToXML($xmlD);

?>