<?php

$d = new domDocument(); // instantiate DOM object
$d->loadXML('<xml><a>Test</a></xml>'); // parse XML string
foreach ($d->getElementsByTagName('a') as $n)
        echo $n->nodeValue; // print element data

?>