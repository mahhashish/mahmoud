<?php

$d = new domDocument();    
$d->loadXML('<xml><a id="1">Test</a></xml>');
// documentElement->firstChild == 1st <a> element
$n =& $d->documentElement->firstChild;   
if ($n->hasAttribute('id')) // check if attribute exists
	echo $n->getAttribute('id'); // fetch attribute

?>