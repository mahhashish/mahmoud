<?php

function tag_start_func($x, $tag, $attr) {
	global $tmp_data;

	$tmp_data = array($tag, $attr, '');	
}

?>