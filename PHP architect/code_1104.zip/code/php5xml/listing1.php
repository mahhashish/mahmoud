<?php

$x = xml_parser_create(); // initialize XML parser
// specify tag start and end handlers
xml_set_element_handler($x,'tag_start_func', 'tag_end_func');
// this function will handle the data inside the tag
xml_set_character_data_handler($x, 'tag_data_func');
xml_parse($x, "xml_file.xml"); // parse document
xml_parser_free($x); // free memory

?>