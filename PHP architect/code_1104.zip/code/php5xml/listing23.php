<?php

$soap_c = new SoapClient(null, 
	array('location' => 'http://localhost/s.php',
                  'uri' => 'http://localhost/'));
echo $soap_c->ls(new SoapParam("/*", "dir"));

?>