<?php

$s = '<xml><b><c><a>Value 1</a><a>Value 2</a></c></b></xml>';
$r = simplexml_load_string($s);
echo $r->b->c->a[1];

?>