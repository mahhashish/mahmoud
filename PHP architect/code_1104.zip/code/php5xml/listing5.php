<?php

// Create XML object from a file
$d1 = simplexml_load_file("my_xml_file.xml");
// Create XML object from a string
$d2 = simplexml_load_string("<xml><hello>World</hello></xml>");

?>