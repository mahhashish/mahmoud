<?php

$d = new domDocument('1.0');
$r = $d->createElement('root');
$n = $d->createElement('a');
$n->appendChild($d->createTextNode('Test'));
$r->appendChild($n); $d->appendChild($r);
echo $d->saveXML();

?>