<?php

$s = '<xml><a>Value 1</a><b id="1">Value 2</b></xml>';
$x = simplexml_load_string($s); // parse XML string
echo $x->a; // will print value of <a> field, "Value 1"
echo $x->b['id']; // will print attribute of b field, "1"

?>