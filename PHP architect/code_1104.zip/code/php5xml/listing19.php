<?php

$xslD = new domdocument;  
$xslD->load('template.xsl');
$xmlD = new domdocument;  
$xmlD->load('data.xml');

?>