<?php

function tag_end_func($x, $tag) {
	global $final, $tmp_data;

	if (isset($final[$tag])) {
		$final[$tag] = array();
	}
	$final[$tag][] = array('val' => $tmp_data[1], 
			'attr' => $tmp_data[2]);
	unset($tmp_data);
}

?>