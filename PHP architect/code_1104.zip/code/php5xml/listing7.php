<?php

$s = '<xml><a>Value 1</a><a>Value 2</a></xml>';
foreach (simplexml_load_string($s) as $a) {
	echo $a; // print value of element <a>
}

?>