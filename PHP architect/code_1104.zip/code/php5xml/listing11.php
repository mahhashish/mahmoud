<?php

$s = '<xml><b><a id="1">One</a><a id="2">Two</a></b></xml>';
$r = simplexml_load_string($s);
$r->b->a[0]['id'] = 5; // modify attribute of 1st <a> element
$r->b->a[1] = "Three"; // modify value of 2nd <a> element
echo $r->asXML(); // print modified XML

?>