<?php

$soap_c = new SoapClient('xmethods-delayed-quotes.wsdl');
echo $soap_c->getQuote("YHOO");

?>