<?php

$d = new domDocument(); 
$d->loadXML('<xml><a id="1">Test</a></xml>');
$e = $d->createElement('b');
$e->setAttribute("id", 2);
$e->appendChild($d->createTextNode("Test 2"));
$d->documentElement->appendChild($e);
echo $d->saveXML();

?>