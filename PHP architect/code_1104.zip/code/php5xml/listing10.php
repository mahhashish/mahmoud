<?php

$s = '<xml><b><a id="1">One</a><a id="3">Two</a></b></xml>';
$r = simplexml_load_string($s);
echo array_pop($r->xpath("//a[@id=3]"));

?>