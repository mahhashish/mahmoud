<?php

$d = new DomDocument();
$d->loadHTMLFile("http://www.php.net/"); // load HTML page
$x = new DomXpath($d); // create XPath object
/* use XPath to get the title of the page */    
echo $x->query("//title/text()")->item(0)->nodeValue;

?>