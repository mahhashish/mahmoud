<?php

class filesystem {
        public function ls($dir) {
              return shell_exec("ls ".$dir);
        }
}
$soap_s = new SoapServer(null,
	array('uri' => 'http://localhost'));
$soap_s->setClass('filesystem'); 
$soap_s->handle();

?>