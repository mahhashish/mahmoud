<?php

function tag_data_func($x, $data) {
	global $tmp_data;

	$tmp_data[2] .= $data;	
}

?>