<?php

$dom = new domDocument;
$dom->loadHTMLFile("http://www.php.net/");
ini_set("track_errors", 1); // store errors in $php_errormsg
echo (@$dom->validate() ? "valid XML" : $php_errormsg);

?>