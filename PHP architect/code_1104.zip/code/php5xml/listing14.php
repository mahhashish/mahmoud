<?php

$d = new domDocument();
$d->loadXML('<xml><b><c><a>Test</a></c><c>foo</c></b></xml>');
$root = $d->documentElement; // go to the beginning
$i = 0;
do {
  if ($root->nodeType == XML_ELEMENT_NODE)
    echo str_repeat("-", $i)."{$root->nodeName}\n";

    if ($root->hasChildNodes()) { // iterate through children
      $root = $root->firstChild; $i++;   
    } else {
      // for non-nodes we need to go back to parent node
      if ($root->nodeType != XML_ELEMENT_NODE)
        $root = $root->parentNode; $i--;
      // go to next parent node, if available
      $root = $root->parentNode->nextSibling; $i--;
    }
} while ($root);

?>