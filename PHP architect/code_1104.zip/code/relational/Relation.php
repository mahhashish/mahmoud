<?php

/*  file: Relation.php   */

class Relation
{

    //A relation can be a table or view, or possibly in the future
    //even a set-returning function--essentially anything that returns a result set

    var $dbconn;
    var $schema;
    var $relname;
    var $relcolumns; //information about columns, types, constraints, etc...
    var $arguments;
    var $resultset;
    var $status;
    var $error;


    function Relation($relname = null)
    {
        $this->relname = $relname;

        $this->schema = 'public'; //defaults to the standard default namespace in PostgreSQL, can be explicitly set by set_schema()

        $this->arguments = '';

    }

    function set_connection(&$dbconn)
    {
        $this->dbconn = $dbconn;

        if(!$this->dbconn)
        {
            $this->status = 'failed';
            $this->error = pg_last_error();
        }
        else
        {
            $this->status = 'success';
        }

    }

    function set_schema($schema)
    {
        $this->schema = $schema;
    }

    function get_constraint($obj_name)
    {

        $domconstraint_sql =
        "
        SELECT
                conname,
                contype,
                pg_catalog.pg_get_constraintdef(oid, true) AS consrc
        FROM
                pg_catalog.pg_constraint
        WHERE
                contypid = (SELECT oid FROM pg_catalog.pg_type
                                                WHERE typname='$domainname'
                                                AND typnamespace = (SELECT oid FROM pg_catalog.pg_namespace
                                WHERE nspname = '{$this->schemaname}'))
        ORDER BY
                conname
        ";


    }

    function is_domain($coltype)
    {

        $is_domain_sql = "SELECT true AS is_domain FROM information_schema.domains WHERE domain_schema='{$this->schema}' AND domain_name = '{$coltype}'";


        if(pg_num_rows(pg_query($is_domain_sql)))
        {
            return true;
        }
    }

    function get_domain_def($domainname)
    {

        $domain_sql =

        "SELECT
                t.typname AS domname,
                pg_catalog.format_type(t.typbasetype, t.typtypmod) AS domtype,
                t.typnotnull AS domnotnull,
                t.typdefault AS domdef,
                pg_catalog.pg_get_userbyid(t.typowner) AS domowner,
                pg_catalog.obj_description(t.oid, 'pg_type') AS domcomment
        FROM
                pg_catalog.pg_type t
        WHERE
                t.typtype = 'd'
                AND t.typname = '$domainname'
                AND t.typnamespace = (
                    SELECT oid FROM pg_catalog.pg_namespace
                        WHERE nspname = '{$this->schemaname}')
        ";

        return pg_fetch_array(pg_query($this->dbconn, $domain_sql));

    }

    function get_varlen_size($colname)
    {
        $size_query = "
        select attname , atttypmod -4 as field_len
        from pg_attribute, pg_class
        where relname='{$this->relname}'
        and attrelid=relfilenode
        and attname='$colname'
        ";

        return pg_fetch_result(pg_query($this->dbconn,$size_query),0,'field_len');

    }

    function get_domain_size($domainname)
    {
        return pg_fetch_result(pg_query($this->dbconn,"SELECT character_maximum_length FROM information_schema.domains WHERE domain_schema='{$this->schema}' AND domain_name='{$domainname}'"),0,0);
    }

    function get_col_default($colname)
    {
        $getdefault_sql = "SELECT column_default FROM information_schema.columns WHERE table_schema='{$this->schema}' AND table_name='{$this->relname}' AND column_name='{$colname}'";

        return pg_fetch_result(pg_query($this->dbconn,$getdefault_sql),0,0);
    }

    function set_args($arguments)
    {
        //takes an associative array of key=>value pairs and turns it into
        //standard SQL arguments, of the form key='value'
        foreach($arguments as $key=>$val)
        {
            //we must determine if the column type is numeric or text-based, in order to construct the correct SQL string

            //echo $key . '-' . $this->relcolumns[$key]["type"] . "<br>\n"; //for debug output

            if(in_array($this->relcolumns[$key]["type"], array('int','int2','int4','int8','smallint','integer','float','double','decimal','numeric')))
            {
                $this->arguments .= " AND {$key}={$val} ";
            }
            elseif(in_array($this->relcolumns[$key]["basetype"], array('int','int2','int4','int8','smallint','integer','float','double','decimal','numeric')))
            {
                $this->arguments .= " AND {$key}={$val} ";
            }
            else
            {
                $this->arguments .= " AND {$key}='{$val}' ";
            }
        }

        //echo $this->arguments . "<br>\n"; //for debug output

    }

    function get_metadata()
    {
        $this->relcolumns = pg_meta_data($this->dbconn, $this->relname);

        foreach($this->relcolumns as $colname => $colinfo)
        {


            if($this->is_domain($colname))
            {
                $domain_meta = $this->get_domain_def($colname["type"]);
                $colinfo["default"] = $domain_meta["domdef"];
                $colinfo["basetype"] = $domain_meta["domtype"];

                $colinfo["len"] = $this->get_domain_size($colname["type"]);

            }
            else
            {
                if($colinfo["len"] <= -1)
                {
                    //get length for variable width cols
                    $colinfo["len"] = $this->get_varlen_size($colname);
                }

                if($colinfo["has default"])
                {
                    $colinfo["default"] = $this->get_col_default($colname);
                }
            }
            $this->relcolumns[$colname] = $colinfo;

        }

        return $this->relcolumns;

    }

    function do_select()
    {

        if($this->arguments)
        {
            $final_sql = "SELECT * FROM {$this->relname} WHERE true {$this->arguments}";
        }
        else
        {
            $final_sql = "SELECT * FROM {$this->relname}";
        }

        $this->resultset = pg_query($this->dbconn, $final_sql);

        //echo $final_sql; //for debug output

    }

    function do_insert($newvalues)
    {

        $insert_a = "INSERT INTO {$this->relname} ";
        $insert_b = '(';
        $insert_c = ')';
        $insert_d = 'VALUES(';
        $insert_e = ')';

        foreach($newvalues as $colname => $colval)
        {

            $insert_b .= $colname . ',';

            //we must determine if the column type is numeric or text-based, in order to construct the correct SQL string

            if(in_array($relcolumns[$colname]["type"], array('int','integer','float','double','decimal','numeric')))
            {
                $insert_d .= $colval . ',';
            }
            elseif(in_array($relcolumns[$colname]["basetype"], array('int','integer','float','double','decimal','numeric')))
            {
                $insert_d .= $colval . ',';
            }
            else
            {
                $insert_d .= "'{$colval}',";
            }

        }

        $insert_sql = $insert_a . $insert_d . $insert_c . $insert_d . $insert_e;

        if(pg_query($this->dbconn, $insert_sql))
        {
            return true;
        }
        else
        {
            $this->error = pg_last_error();
            return false;
        }


    }

    function do_update($newvalues)
    {


        $update_sql = "UPDATE {$this->relname} SET ";

        foreach($newvalues as $colname => $colval)
        {

            //we must determine if the column type is numeric or text-based, in order to construct the correct SQL string

            if(in_array($relcolumns[$colname]["type"], array('int','integer','float','double','decimal','numeric')))
            {
                $update_sql .= "{$colname} = {$colval},";
            }
            elseif(in_array($relcolumns[$colname]["basetype"], array('int','integer','float','double','decimal','numeric')))
            {
                $update_sql .= "{$colname} = {$colval},";
            }
            else
            {
                $update_sql .= "{$colname} = '{$colval}',";
            }

        }

        $update_sql = substr($update_sql, 0. -1); //take off the final trailling comma

        //assume $arguments already set during 'edit' view of record
        $update_sql .= "WHERE {$this->arguments}";

        if(pg_query($this->dbconn, $update_sql))
        {
            return true;
        }
        else
        {
            $this->error = pg_last_error();
            return false;
        }


    }

    function fetch_row()
    {
        return pg_fetch_assoc($this->resultset);
    }

}

?>