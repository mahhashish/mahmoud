<?php

/*  file: relpage.php   */

include ('./relfiles.php'); //include Domain.php, all datatypes, and Relation.php

$dbuser = 'pgsql';
$password = 'noregress';
$host = 'localhost';
$dbname = 'test1';

//$dbconn = pg_connect("host={$host} user={$dbuser} password={$password} dbname={$dbname}");
$dbconn = pg_connect("user={$dbuser} password={$password} dbname={$dbname}");

$relname = $_GET["relname"];

$rel = new Relation($relname); //Uses functions from phpPgAdmin

$rel->set_connection($dbconn);

if($_GET["arguments"])
{
    $otherargs = unserialize(stripslashes($_GET["arguments"]));

    $rel->set_args($otherargs);
}
$gui = new relGui($rel);

//print_r($otherargs); //debug output

$gui->set_mode($_GET["mode"]); //valid modes are "list", "view", "edit", "add", "insert", "update', "search"

echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">
<html>
<head>
  <meta http-equiv=\"Content-Type\" content=\"text/html\"
    charset=\"UTF-8\">
  <title>{$_GET["mode"]} {$relname}</title>
</head>
<body>";

$gui->render();

//uncomment for object dump as HTML comment
//echo "<!--";
//var_dump($gui);
//echo "-->";

echo "</body>
</html>";

?>