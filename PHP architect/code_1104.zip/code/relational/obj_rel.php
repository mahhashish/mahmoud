<?php

/*  file: obj_rel.php   */

    require_once "HTML/QuickForm.php";

    $form = new HTML_QuickForm('user_signup', 'get');
    $form->addElement('header',     '', 'New User Sign-up');
    $form->addElement('text',       'username', 'Username');
    $form->addElement('password',   'password', 'Password');    
    $form->addElement('text',       'firstname', 'First Name');
    $form->addElement('text',       'lastname', 'Last Name');    
    $form->addElement('text',       'email', 'Email Address');    
    $form->addElement('reset',      'btnClear', 'Clear');
    $form->addElement('submit',      'btnSubmit', 'Submit');
    
    $form->addRule('username', 'Your username is required', 'required');
    $form->addRule('password', 'Your password is required', 'required');
    $form->addRule('email',    'Your email address is required', 'required');
        
    if ($form->validate()) {

        if($db->create_entry('new_user', $_POST))
        {
            echo "Your validation email has been sent";
        }
        else
        {
            echo $db->last_error();
        }        
    }
    else
    {
        $form->display();
    }
?>