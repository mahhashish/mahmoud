<?php

/*  file: RelGui.php   */

require_once("HTML/QuickForm.php");
require_once("HTML/Table.php");
require_once("./relfiles.php");

class RelGui
{

    var $relation;
    var $quickform;
    var $mode;
    var $dbconn;
    var $metadata;
    var $data; //collection of actual data retrieved
    var $gui;

    function RelGui($relation)
    {
        //$this->mode = $mode;
        $this->relation = $relation;
        //$this->dbconn = $this->relation->dbconn; //share the same database connection already established in the $relation object
        $this->prepare();

    }

    function set_mode($mode)
    {

        $valid_modes = array("list", "view", "edit", "add", "insert", "update", "search");
        //view, list, edit, etc...
        if(in_array($mode,$valid_modes))
        {
            $this->mode = $mode;

            if($this->mode == 'list')
            {
                $this->gui = new HTML_Table();
            }
            elseif($this->mode)
            {
                //if mode is not 'list', it is implied that we are in single-record view/edit mode
                $this->gui = new HTML_QuickForm("{$this->relation->relname}", 'POST');
            }

        }
        else
        {
            die("Invalid mode selected;");
        }

    }

    function prepare()
    {

        $this->metadata = $this->relation->get_metadata();

        foreach($this->metadata as $colname => $colinfo)
        {
            
            if(in_array($colinfo["type"], array('integer','int4','int2','int8' )))
            {
                $colinfo["type"] = 'int';    
            }
            
            $classname = "rel_{$colinfo["type"]}";
            
            echo $classname;
            
            if(class_exists($classname))
            {

                //compose column types in here
                $this->data[$colname] = new $classname;

            }
            else
            {

                //default to char domain
                $this->data[$colname] = new rel_text;

            }

        }

    }

    function render()
    {

        $this->relation->do_select();

        if($this->mode == 'list')
        {

            //set header row
            $colnum = 0;
            $rownum = 0;
            $this->gui->setHeaderContents( $rownum, $colnum, ''); //empty space
            $colnum++;
            foreach($this->metadata as $colname => $colinfo)
            {

                $this->gui->setHeaderContents( $rownum, $colnum, $colname);
                $colnum++;
            }

            //create data rows

            $rownum = 1;
            while($row = $this->relation->fetch_row())
            {
                $colnum = 0;
                $escaped_args = urlencode(serialize($row)); //argumenst to uniquely identify a row
                $this->gui->setCellContents($rownum, $colnum, "<a href=\"{$_SERVER["PHP_SELF"]}?relname={$this->relation->relname}&mode=edit&arguments={$escaped_args}\">edit</a>");
                $colnum++;
                foreach($row as $colname => $colval)
                {
                    $this->gui->setCellContents($rownum, $colnum, $colval);
                    $colnum++;
                }

                $rownum++;
            }

            echo $this->gui->toHTML();
        }
        else
        {
            //in all other cases there should be only one row returned

            $this->gui->addElement('header',     '', "Edit {$this->relation->relname}");

            $row = $this->relation->fetch_row();


            foreach($row as $colname => $colval)
            {

                $html_attribs = array("value"=>$colval);

                //additional HTML attribs are set here
                if(is_array($this->data[$colname]->css_attribs))
                {
                    $html_attribs = array_merge($html_attribs, $this->data[$colname]->css_attribs);
                }
                if(is_array($this->data[$colname]->css_class))
                {
                    $html_attribs = array_merge($html_attribs, $this->data[$colname]->css_class);
                }

                //set max size attribute for textboxes
                if($this->metadata[$colname]['len'] > 0)
                {
                    $html_attribs = array_merge($html_attribs, array('maxlength' => $this->metadata[$colname]['len']));
                }

                $this->gui->addElement('text',       $colname, $colname, $html_attribs);
            }

            $this->gui->addElement('submit',      'btnSubmit', 'Submit');

            $this->gui->display();

        }

    }


}