<?php

/*  file: relfiles.php   */

require_once('./RelDomain.php');
require_once('./Relation.php');
require_once('./RelGui.php');
?>