<?php

/*  file: RelDomain.php   */

class RelDomain
{
    /***
    * Abstract class to instantiate a relational datatype object,
    *
    ***/

    var $visible;
    var $value;
    var $size;
    var $mode;
    var $css_class;       // sets the CSS class
    var $cssjs_attribs;   // sets any arbitrary CSS style or Javascript event
    function RelDomain(){}
    function setVal($value){}
    function getVal($value){}
    function setMode($mode){}
    function setCssStyle($css_attribs){}
    function setCssClass($css_class){}

}

class rel_int extends RelDomain
{

    var $visible;
    var $value;
    var $size;
    var $mode;
    var $css_class;       // sets the CSS class
    var $css_attribs;

    function rel_int()
    {
        $this->value = 0;
        $this->size = 0;
        $this->visible = true;
        //$this->setCssClass(''); //set default CSS class here 
        //$this->setCssStyle(array('color'=>'red')); //set default CSS styles here
    }

    function setSize($size)
    {
        $this->size = (int)$size;
    }

    function setVal($value)
    {

        if(!is_int($value))
        {
            trigger_error("attempt to set non-integer value in class relInt", E_USER_WARNING);
            return false;
        }
        else
        {
            $this->value = (int)$value;
        }

    }

    function getVal()
    {
        return $this->value;
    }

    function setMode($mode){}


    function setCssStyle($css_attribs)
    {

        $attrib_string = '';
        foreach($css_attribs as $name => $val)
        {
            $attrib_string .= "{$name}:{$val};";
        }

        $this->css_attribs = array('style'=>$attrib_string);

    }

    function setCssClass($css_class)
    {
        $this->css_class = array('class'=>$css_class);
    }

}

class rel_char extends RelDomain
{

    var $visible;
    var $value;
    var $size;
    var $mode;
    var $css_class;       // sets the CSS class
    var $css_attribs;

    function rel_char()
    {
        $this->value = '';
        $this->size = 0;
        $this->visible = true;
        //$this->setCssClass(''); //set default CSS class here 
        //$this->setCssStyle(array('color'=>'red')); //set default CSS styles here
    }

    function setSize($size)
    {
        $this->size = (int)$size;
    }

    function setVal($value)
    {
        $this->value = (string)$value;
    }

    function getVal()
    {
        return $this->value;
    }

    function setMode($mode){}

    function setCssStyle($css_attribs)
    {

        $attrib_string = '';
        foreach($css_attribs as $name => $val)
        {
            $attrib_string .= "{$name}:{$val};";
        }

        $this->css_attribs = array('style'=>$attrib_string);

    }

    function setCssClass($css_class)
    {
        $this->css_class = array('class'=>$css_class);
    }

}

class rel_varchar extends RelDomain
{

    var $visible;
    var $value;
    var $size;
    var $mode;
    var $css_class;       // sets the CSS class
    var $css_attribs;

    function rel_char()
    {
        $this->value = '';
        $this->size = 0;
        $this->visible = true;
        //$this->setCssClass(''); //set default CSS class here 
        //$this->setCssStyle(array('color'=>'red')); //set default CSS styles here
    }

    function setSize($size)
    {
        $this->size = (int)$size;
    }

    function setVal($value)
    {
        $this->value = (string)$value;
    }

    function getVal()
    {
        return $this->value;
    }

    function setMode($mode){}

    function setCssStyle($css_attribs)
    {

        $attrib_string = '';
        foreach($css_attribs as $name => $val)
        {
            $attrib_string .= "{$name}:{$val};";
        }

        $this->css_attribs = array('style'=>$attrib_string);

    }

    function setCssClass($css_class)
    {
        $this->css_class = array('class'=>$css_class);
    }

}

class rel_text extends RelDomain
{

    var $visible;
    var $value;
    var $size;
    var $mode;
    var $css_class;       // sets the CSS class
    var $cssjs_attribs;

    function rel_text()
    {
        $this->intvalue = 0;
        $this->intsize = 0;
        $this->visible = true;
        //$this->setCssClass(''); //set default CSS class here 
        //$this->setCssStyle(array('color'=>'red')); //set default CSS styles here
        
    }

    function setVal($value)
    {
        $this->value = (string)$value;
    }

    function getVal()
    {
        return $this->value;
    }

    function setMode($mode){}

    function setCssStyle($css_attribs)
    {

        $attrib_string = '';
        foreach($css_attribs as $name => $val)
        {
            $attrib_string .= "{$name}:{$val};";
        }

        $this->css_attribs = array('style'=>$attrib_string);

    }

    function setCssClass($css_class)
    {
        $this->css_class = array('class'=>$css_class);
    }

}

class rel_float extends RelDomain
{

    var $visible;
    var $value;
    var $size;
    var $mode;
    var $css_class;       // sets the CSS class
    var $css_attribs;

    function rel_float()
    {
        $this->value = 0.0;
        $this->size = 0;
        $this->visible = true;
        //$this->setCssClass(''); //set default CSS class here 
        //$this->setCssStyle(array('color'=>'red')); //set default CSS styles here
    }

    function setSize($size)
    {
        $this->size = (int)$size;
    }

    function setVal($value)
    {
        $this->value = (float)$value;
    }

    function getVal()
    {
        return $this->value;
    }

    function setMode($mode){}

    function setCssStyle($css_attribs)
    {

        $attrib_string = '';
        foreach($css_attribs as $name => $val)
        {
            $attrib_string .= "{$name}:{$val};";
        }

        $this->css_attribs = array('style'=>$attrib_string);

    }

    function setCssClass($css_class)
    {
        $this->css_class = array('class'=>$css_class);
    }

}

?>