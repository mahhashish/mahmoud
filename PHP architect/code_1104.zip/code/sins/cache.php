<?php

function cache_shm_get_cached_version ($id)
{
	// Recreate the numeric ID associated with this resource

	$id = crc32 ($id);
	
	// Try to create and acquire our semaphore
	
	$sem = sem_get ($id, 1);
	
	if (!is_resource ($sem)) {
		
		// Something went wrong and we don't have a semaphore
		// Let the caching mechanism fail.
		
		return false;
	}
	
	if (!sem_acquire ($sem)) {
		
		// Can't acquire a lock on the semaphore.
		// Let the caching mechanism fail.
		
		sem_remove ($sem);		
		return false;
	}
	
	// Now, let's try to open our shared-memory segment
	
	$shm = shmop_open ($id, 'a', 0, 0);
	
	if (!$shm) {
		
		// Can't open the shm segment. Let the caching
		// mechanism fail
		
		sem_release ($sem);
		sem_remove ($sem);
		
		return false;
	}
	
	$value = @unserialize (shmop_read ($shm, 0, shmop_size ($shm)));
	
	// Release the memory block
	
	shmop_close ($shm);
	
	// Release the semaphore and delete it
	
	sem_release ($sem);
	sem_remove ($sem);
	
	return $value;
}

function cache_shm_cache ($id, $value)
{
	// First of all, create a numeric ID that can be associated
	// with this resource. We simply use crc32() for this purpose.

	$id = crc32 ($id);
	
	// Next, we serialize our value, so that it can be safely
	// stored in shared memory space
	
	$value = serialize ($value);
	$value_length = strlen ($value);
	
	// Next, acquire a semaphore associated with this resource.
	// This is necessary to ensure that one process doesn't write
	// over the shared memory while another is reading from it
	
	$sem = sem_get ($id, 1);
	
	if (!is_resource($sem)) {
		
		// Something went wrong and we don't have a semaphore.
		// Since caching is not safe under these circumstances,
		// we do nothing and return false.
		
		// This is where you may want to send yourself an e-mail
		// to let you know that there's a problem.
		
		return false;
	}
	
	// Now, acquire the semaphore
	
	if (!sem_acquire ($sem)) {
		// We can't acquire the semaphore. Release it and fail
		
		sem_remove ($sem);
		return false;
	}
	
	// Next, get a pointer to our shared-memory area
	
	$shm = shmop_open ($id, "c", 0664, $value_length);
	
	if (!$shm) {
		// We can't acquire the memory block. Fail.
		
		sem_release ($sem);
		sem_remove ($sem);
		return false;
	}
	
	// Write the data in the memory block

	shmop_write ($shm, $value, 0);
	
	// Release the memory block
	
	shmop_close ($shm);
	
	// Release the semaphore and delete it
	
	sem_release ($sem);
	sem_remove ($sem);
	return true;
	
}

function cache_disk_lock ($id)
{
	// Determine the lock directory name
	
	$dir = "$id.lock";
	
	// Try to create the directory
	
	while (!@mkdir ($dir));
	
	// Return. Lock has succeeded
}

function cache_disk_unlock ($id)
{
	// Determine the lock directory name
	
	$dir = "$id.lock";
	
	// Try to delete the lock directory
	
	@rmdir ($dir);
	
	// Return. Lock has been released
}

function cache_disk_get_cached_version ($id)
{
	// Determine a file name	

	$id = $_SERVER['TMP'] . "/CACHEXXX" . md5($id) . ".cache";
	
	// Lock access to the file
	
	cache_disk_lock($id);
	
	// Access the output file
	
	$f = @fopen ($id, "r");
	
	if (!$f) {
		cache_disk_unlock($id);
		return false;
	}
	
	// Read the value
	
	$result = unserialize (file_get_contents ($id));
	
	// Unlock the file
	
	cache_disk_unlock($id);
	
	// Return the value
	
	return $value;
}

function cache_disk_cache ($id, $value)
{
	// Determine a file name
	
	$id = $_SERVER['TMP'] . "/CACHEXXX" . md5($id) . ".cache";
	
	// Lock access to the file
	
	cache_disk_lock($id);
	
	// Access the output file
	
	$f = @fopen ($id, "w");
	
	if (!$f) {
		cache_disk_unlock();
		return false;
	}
	
	// Write the result value
	
	$value = serialize ($value);
	
	// Return
	
	return true;
}

function cache_get_cached_version ($id)
{
	// HACK: Ignore memory requests if our OS doesn't
	// support memory functions
	
	if ($id[0] == 'M' && !function_exists ('shmop_open')) {
		$id[0] = 'F';
	}
	
	// Determine where we should dispatch the call
	
	switch ($id[0]) {
		case 'F' : 
		
			// This item was cached via file
			
			$cache = cache_disk_get_cached_version ($id);
			
			break;
			
		case 'M' :
		
			// This item was cached via shared memory
			
			$cache = cache_shm_get_cached_version ($id);
			
			break;
			
		default :
		
			// Nothing useful... raise an error and bail out
		
			user_error("Unknown cache ID token '{$id}'", E_ERROR);
			die();
	}

	if ($cache && is_array ($cache) && count ($cache = 2)) {
		// Now that we have the cached object, let's make sure that it's still good
		
		if ($cache[0] <= time()) {
			return $cache[1];	
		} else {
			return false;
		}
	} else {
		// The cache failed
		
		return false;
	}
}

function cache_cache ($id, $value, $timeout)
{
	// Prepare cache
	
	$cache = array (time() + $timeout, $value);
	
	// HACK: Ignore memory requests if our OS doesn't
	// support memory functions
	
	if ($id[0] == 'M' && !function_exists ('shmop_open')) {
		$id[0] = 'F';
	}
	
	// Determine where we should dispatch the call
	
	switch ($id[0]) {

		case 'F' : 

			return cache_disk_cache ($id, $value);
			
		case 'M' :

			return cache_shm_cache ($id, $value);
		
		default :
		
			// Nothing useful... raise an error and bail out
		
			user_error("Unknown cache ID token '{$id}'", E_ERROR);
			die();
	}
}

if (defined ("CACHE_THIS_PAGE")) {

	function cache_ob_uniqueid()
	{
		return $_SERVER['REQUEST_URI'];
	}
	
	function cache_ob_handler ($buffer)
	{
		// Determine a unique ID for this page
		
		$id = cache_ob_uniqueid();
		
		// Cache this value
		
		cache_cache ($id, $buffer, CACHE_TIMEOUT);
		
		// Return
		
		return $buffer;
	}
	
	// Determine the unique ID for this page
	
	$id = cache_ob_uniqueid();
	
	// Make sure that there is a timeout defined.
	// Use an hour by default
	
	if (!defined ("CACHE_TIMEOUT")) {
		define (CACHE_TIMEOUT, 3600);
	}
	
	// Determine the type of cache to use
	
	if (!defined ("CACHE_TYPE")) {
		// Use file-based caching by default
		
		define ("CACHE_TYPE", "FILE");
	}
	
	switch (CACHE_TYPE) {
		
		case "FILE"	:
		
			$id = "f" . $id;
			break;
			
		case "SHM" :
		
			$id = "m" . $id;
			break;
			
		default :
		
			// Output an error
			
			user_error ("Invalid cache type " . CACHE_TYPE, E_ERROR);
			die();
	}
	
	// Check if a cached version of this page already exists
	
	if (($data = cache_get_cached_version($id)) == false) {
		// Ok, we have it and it's good.
		// Output it and stop the script
		
		echo ($data);
		die();	
	} else {
		// We don't have a valid one. Let's set things up to
		// get one
		
		ob_start ("cache_ob_handler");
	}
	
	// Clear up any variables used
	
	unset ($id);
	unset ($data);
	
}

?>