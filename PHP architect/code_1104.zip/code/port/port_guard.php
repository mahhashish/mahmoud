<?php

//Listing 1
$allowed_list = array("21","80");
$email = "email@yoursite.com";

//Listing 2
$nestat_res = shell_exec("netstat -utnp");

//Listing 3
$nestat_res = ereg_replace("tcp", "proto", $nestat_res);
$nestat_res = ereg_replace("udp", "proto", $nestat_res);
$nestat_array = explode("proto", $nestat_res);

//Listing 4
foreach($nestat_array as $netstat_line){

preg_match_all("/[:](.*?) /", $netstat_line, $netstat_ports);

$check_port_1 = $netstat_ports[0][0];
$check_port_2 = $netstat_ports[0][1];

$check_port_1 = ereg_replace("[:]", "", $check_port_1);
$check_port_1 = ereg_replace(" ", "", $check_port_1);

$check_port_2 = ereg_replace("[:]", "", $check_port_2);
$check_port_2 = ereg_replace(" ", "", $check_port_2);

//Listing 5
if($check_port_1 != ''){

foreach($allowed_list as $compare_port){

if($compare_port == $check_port_1){
$port_1_ok = '1';
}
if($compare_port == $check_port_2){
$port_2_ok = '1';
}
}

//Listing 6
if($port_1_ok== '1' OR $port_2_ok == '1'){

//Listing 7
}else{
$check_est = ereg("ESTABLISHED", $netstat_line);
if($check_est == '1'){
$check_est_res = '1';
}else{
$check_est_res = '0';
}

//Listing 8
if($check_est_res == '1'){
print "Intrusion Detected | $netstat_line |<br>";


$error_throw = '1';


$netstat_error[] ="$netstat_line\n\n";
}
}

//Listing 9
$port_1_ok = '';
$port_2_ok = '';

}
}

//Listing 10
if($error_throw == '1'){
$email_errors = implode(" ", $netstat_error);
mail("$email", "Check Intrusion", "Possible Intrusion \n\n $email_errors", "From:system@yoursite.com\r\nReturn-to:system@yoursite.com");

//Listing 11
sleep(30);
shell_exec("ifconfig eth0 down"); //Shutdown the ethernet ports
//shell_exec("shutdown -h now"); //shutdown the server completly
//shell_exec("cat /etc/iptables_extra_protect | iptables-restore -c"); //switch the current firewall with a limited one

//Listing 12
}

?>