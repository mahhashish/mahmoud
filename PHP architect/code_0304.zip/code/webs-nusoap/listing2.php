<?php
if(empty($_GET["asin"]))
    die("<h3>No ASIN specified</h3>");

require("nusoap.php");
$_GET["asin"] = sprintf("%010d", $_GET["asin"]);
    
$client = new soapclient("http://soap.amazon.com/schemas2/AmazonWebServices.wsdl", true);
$proxy = $client -> getProxy(); // Creates a WSDL client and a proxy

$param = array(
		   'asin'   => $_GET["asin"],
		   'tag'    => 'webservices-20',
		   'type'   => 'heavy',
		   'devtag' => 'YOUR-DEV-TOKEN'
         );

$results = $proxy -> AsinSearchRequest($param); // Calls the method
?>
<h1><?=$results["Details"][0]["ProductName"] ?></h1>
<img src="<?=$results["Details"][0]["ImageUrlLarge"] ?>" align="left" height="350" />
<b>Authors:</b> <?=@implode(', ', $results["Details"][0]["Authors"])?><br /><br />
<b>Published by</b> <?=$results["Details"][0]["Manufacturer"]?>
<b> on</b> <?=$results["Details"][0]["ReleaseDate"]?><br /><br />
<b>List Price</b>: <?=$results["Details"][0]["ListPrice"] ?> - 
<b>Our Price</b>: <?=$results["Details"][0]["OurPrice"] ?> - 
<b>Used Price</b>: <?=$results["Details"][0]["UsedPrice"] ?><br /><br /><br />
<!-- Form to purchase on Amazon.com -->
<form method="POST" action="http://www.amazon.com/o/dt/assoc/handle-buy-box=<?=$_GET["asin"] ?>">
<input type="hidden" name="asin.<?=$_GET["asin"] ?>" value="1">
<input type="hidden" name="tag-value" value="webservices-20">
<input type="hidden" name="tag_value" value="webservices-20">
<input type="hidden" name="dev-tag-value" value="YOUR-DEV-TOKEN">
<input type="submit" name="submit.add-to-cart" value="Buy From Amazon.com">&nbsp;&nbsp;
<input type="submit" name="submit.add-to-registry.wishlist" value="Add to Wish List"> 
</form>
<!-- End Form -->
<b>ISBN:</b> <?=$results["Details"][0]["Isbn"]?><br /><br />
<b>Availability:</b> <?=$results["Details"][0]["Availability"]?><br /><br /><br />
<b>Sales Ranking:</b> <?=$results["Details"][0]["SalesRank"]?><br /><br />
<b>Average customer rating:</b> <?=$results["Details"][0]["Reviews"]["AvgCustomerRating"]?>
<br /><br /><h2>Read user reviews:</h2>
<?php
foreach($results["Details"][0]["Reviews"]["CustomerReviews"] as $res)
    echo "<h3>".$res["Summary"]."</h3>"
	    ."<b>Rating: </b>".$res["Rating"]."<br /><br />".$res["Comment"]."<br /><hr />";
?>
