<form action="<?=$PHP_SELF ?>" method="GET">
  <input type="text" name="keyword" value="" />
  <input type="hidden" name="page" value=1 />
  <input type="submit" name="button" value="Search!" />
</form>
<?php
if (empty($_GET["keyword"])) // If the form has'n been submitted
    exit;                     // Stops the execution

require("nusoap.php");
    
$client = new soapclient("http://soap.amazon.com/schemas2/AmazonWebServices.wsdl", true);
$proxy = $client -> getProxy(); // Creates a WSDL client and a proxy

$param = array(
		   'keyword' => $_GET["keyword"],
		   'page'    => $_GET["page"],
		   'mode'    => 'books',
		   'tag'     => 'webservices-20',
		   'type'    => 'lite',
		   'devtag'  => 'YOUR-DEV-TOKEN'
         );

$results = $proxy -> KeywordSearchRequest($param); // Calls the method

if(empty($results["Details"])) // Checks whether there are results
    die("<h3>No results found for &quot;".$_GET["keyword"]."&quot;.</h3>");

echo "<h3>Searched Amazon.com for &quot;".$_GET["keyword"]."&quot; - page "
     .$_GET["page"]." of ".$results["TotalPages"]."</h3>";

foreach($results["Details"] as $res) // Prints each product details
    echo "<img src='".$res["ImageUrlMedium"]."' align='left' /><br/>\n"
	    ."<a href='details.php?asin=".$res["Asin"]."'><b>".$res["ProductName"]."</b></a><br /><br />\n"
		."<b>Authors</b>: ".@implode(', ', $res["Authors"])."<br />\n"
		."<b>Publishing Company</b>: ".$res["Manufacturer"]."<br />"
		."<b>List Price</b>: ".$res["ListPrice"]." - <b>Our Price</b>: "
        .$res["OurPrice"]." - <b>Used Price</b>: ".$res["UsedPrice"]."<br /><br /><br />\n\n";

if($_GET["page"] > 1) // Prints a link to prev. page if any
    echo "<a href='$PHP_SELF?keyword=".$_GET["keyword"]."&page=".($_GET["page"]-1)."'>Previous Page</a>&nbsp;\n";
if($_GET["page"] < $results["TotalPages"]) // Prints a link to next page if any		
    echo "&nbsp;&nbsp;<a href='$PHP_SELF?keyword=".$_GET["keyword"]."&page=".($_GET["page"]+1)."'>Next Page</a>";
?>