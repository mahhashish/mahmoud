<?PHP
require_once 'XML/Serializer.php';
$data = array(
                "foo"   => 42,
                "files" => array(
                                  "main"   => "Auth.php",
                                  "driver" => "DB.php"
                                )
            );

$serializer = new XML_Serializer();

$result = $serializer->serialize($data);

if( $result === true ) {
    $xml = $serializer->getSerializedData();
    print $xml;
}
?>