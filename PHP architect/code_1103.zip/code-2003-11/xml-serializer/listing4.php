<?PHP
require_once 'XML/Serializer.php';

$rdf = array(
             "channel" => array(
                                "title" => "JLA Distress Calls",
                                "link"  => "http://www.dccomics.com",
                                ),
            array(
                   "title" => "Doomsday is destroying Metropolis",
                   "description" => "Superman has already reacted but needs help!",
                  ),
            array(
                   "title" => "Rogues loot Flash Museum",
                   "description" => "Captain Cold and Mirror Master have been sighted in Keystone City",
                  ),
            );


$options = array(
                 "indent" => "  ",
                 "defaultTagName" => "item",
                 "rootName" => "rdf",
                 "rootAttributes" => array("version" => "0.91")
                );
            
$serializer = new XML_Serializer($options);

$result = $serializer->serialize($rdf);

if( $result === true ) {
    $xml = $serializer->getSerializedData();
    echo "<pre>";
    echo htmlspecialchars($xml);
    echo "</pre>";
}
?>