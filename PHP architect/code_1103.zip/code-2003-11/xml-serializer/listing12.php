<?PHP
require_once 'listing9.php';
require_once 'XML/Unserializer.php';

$xml = '<superheroteam>
  <abbrev>JLA</abbrev>
  <name>Justice League of America</name>
  <members>
    <name>Superman</name>
    <realname>Clark Kent</realname>
    <powers>Flight</powers>
    <powers>Superhuman strength</powers>
  </members>
  <members>
    <name>The Flash</name>
    <realname>Wally West</realname>
    <powers>Superspeed</powers>
  </members>
  <members>
    <name>Aquaman</name>
    <realname>Arthur Curry</realname>
    <powers>Telepathic abilities</powers>
    <powers>Commands sea life</powers>
  </members>
 </superheroteam>';

$options = array(
                  "complexType" => "object",
                  "tagMap"      => array(
                                          "members" => "superhero"
                                        )
                );

$unserializer = new XML_Unserializer($options);

$result = $unserializer->unserialize($xml);

if( $result === true ) {
    $team = $unserializer->getUnserializedData();
    print_r( $team );
}
?>