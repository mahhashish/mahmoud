<?PHP
require_once 'listing9.php';

require_once 'XML/Serializer.php';

$superman = new superhero;
$superman->setName("Superman");
$superman->setRealname("Clark Kent");
$superman->addPower("Flight");
$superman->addPower("Superhuman strength");

$flash = new superhero;
$flash->setName("The Flash");
$flash->setRealname("Wally West");
$flash->addPower("Superspeed");

$jla = new superheroTeam;
$jla->setAbbrev("JLA");
$jla->setName("Justice League of America");
$jla->addHero($superman);
$jla->addHero($flash);

$options = array(
                 "indent" => "  ",
                 "mode"   => "simplexml"
                );
            
$serializer = new XML_Serializer($options);

$result = $serializer->serialize($jla);

if( $result === true ) {
    $xml = $serializer->getSerializedData();
    print $xml;
}
?>