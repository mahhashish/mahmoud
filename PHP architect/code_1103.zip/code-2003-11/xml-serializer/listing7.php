<?PHP
require_once 'XML/Unserializer.php';
$unserializer = new XML_Unserializer();

$result = $unserializer->unserialize("listing6.xml", true);

if( $result === true ) {
    $data = $unserializer->getUnserializedData();
    print_r($data);
}
?>