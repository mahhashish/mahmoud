<?PHP
/**
 * class to store a superhero
 *
 * @access public
 */
class superhero
{
    var $name;
    var $realname;
    var $powers = array();
    
    function setName($name)
    {
        $this->name     = $name;
    }

    function setRealname($name)
    {
        $this->realname     = $name;
    }

    function setPowers($powers)
    {
        if (!is_array($powers)) {
            $powers = array($powers);
        }
        $this->powers = $powers;
    }

    function addPower($power)
    {
        array_push($this->powers, $power);
    }
}

/**
 * superhero team
 *
 * @access public
 */
class superheroTeam
{
    var $abbrev;
    var $name;
    var $members = array();
    
    function setAbbrev($abbrev)
    {
        $this->abbrev = $abbrev;
    }

    function setName($name)
    {
        $this->name     = $name;
    }
    
    function setMembers($members)
    {
        if (!is_array($members)) {
            $members = array($members);
        }

        $this->members     = $members;
    }

    function addHero($hero)
    {
        array_push($this->members, $hero);
    }
}
?>
