<?PHP
require_once 'XML/Serializer.php';
$data = new stdClass;
$data->item = array("zero","one", "two", "three");

$serializer = new XML_Serializer();
$serializer->setOption("indent", "    ");

$result = $serializer->serialize($data);

if( $result === true ) {
    $xml = $serializer->getSerializedData();
    print $xml;
}
?>