<?PHP
require_once 'XML/Serializer.php';
$data = new stdClass;
$data->foo = 42;
$data->bar = array("one", "two");

$serializer = new XML_Serializer();
$serializer->setOption("indent", "    ");
$serializer->setOption("typeHints", true);
$serializer->setOption("defaultTagName", "anyTag");

$result = $serializer->serialize($data);

if( $result === true ) {
    $xml = $serializer->getSerializedData();
    print $xml;
}
?>