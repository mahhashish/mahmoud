<?php
	$db = sqlite_open(":memory:");
	if(!$db) die("Could not create the temporary database");

	$query = "CREATE TABLE people(name VARCHAR)";
	@sqlite_query($db, $query);
	
	$names = array ("John Coggeshall", "Marco Tabini", "Joe Shmoe",
                    "John Doe", "Mark Smith", "Jason Smith");
	
	foreach($names as $name) {
	    $query = "INSERT INTO people VALUES('$name')";
	    if(!sqlite_query($db, $query)) {
		trigger_error("Could not insert into database!");
	    }
	}
	
	/* Retrieve all the people whose first name is "John" */
	$query = "SELECT name FROM people WHERE name LIKE 'John %'";
	$results = sqlite_query($db, $query);
	
	echo "Matching Names:\n\n";
	while($row = sqlite_fetch_array($results, SQLITE_ASSOC)) {
	    echo "{$row['name']}\n";
    }
    
    /* Retrieve all the people whose name starts with "Mar" */
    $query = "SELECT name FROM people WHERE name LIKE 'Mar%'";
    $results = sqlite_unbuffered_query($db, $query);
    
    echo "\nMatching Names:\n\n";
    while($row = sqlite_fetch_array($results, SQLITE_NUM)) {
        echo "{$row[0]}\n";
    }
    
	sqlite_close($db);
?>