<?php
	$db = sqlite_open(":memory:");
	if(!$db) die("Could not create the temporary database");

	$query = "CREATE TABLE people(name VARCHAR)";
	@sqlite_query($db, $query);
	
	$names = array ("John Coggeshall", "Marco Tabini", "Joe Shmoe");
	
	foreach($names as $name) {
	    $query = "INSERT INTO people VALUES('$name')";
	    if(!sqlite_query($db, $query)) {
		trigger_error("Could not insert into database!");
	    }
	}
	
	sqlite_close($db);
?>
