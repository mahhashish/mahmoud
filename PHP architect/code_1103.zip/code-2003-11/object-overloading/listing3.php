<?php

function greet($name) // An user-defined function
{
    return "Hi $name! <br/>";
}

class TryCall
{
    var $accept;
    function TryCall() { } // Constructor is empty

    function __call($FuncName, $FuncArg, &$RetValue)
    {
        $this -> accept = array("greet", "sqrt"); // Array of valid functions
        if(in_array($FuncName, $this -> accept)): // If a valid function is called
            $RetValue = $FuncName($FuncArg[0]);   // Executes the function
            return TRUE;                          // And returns TRUE
        else:
            return FALSE;                         // Else returns FALSE
        endif;
    }
}

overload('TryCall'); // Overloads the class
$overloaded = new TryCall();
echo $overloaded -> greet("John"); // Calls greet()  as method
echo $overloaded -> sqrt(16);      // Calls sqrt() as method
echo $overloaded -> log(10);       // Calls log() as method

?>