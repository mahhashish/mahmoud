<?php

class MySQL
  {
    var $link;
    var $accept_l;
    var $accept;


    function MySQL($server, $user, $pass)
      { // The constructor opens the connection
        $this->link = mysql_connect($server, $user, $pass)
            or die(mysql_error());;
      }


    function __call($FuncName, $FuncArg, &$RetValue)
      {

               /* Accepted funcs that need a resource link */
        $this->accept_l = array("close" => "close",     // mysql_close()
                                "db" => "select_db",    // mysql_select_db()
                                "newdb" => "create_db", // mysql_create_db()
                                "dropdb" => "drop_db",  // mysql_drop_db()
                                "query" => "query",     // mysql_query()
                                );

               /* Accepted func.s that don't need a resource link */
        $this->accept = array("arows" => "affected_rows", // mysql_affected_rows()
                              "nrows" => "num_rows",      // mysql_num_rows()
                              "afetch" => "fetch_array",  // mysql_fetch_array()
                              "rfetch" => "fetch_row",    // mysql_fetch_row()
                              "ofetch" => "fetch_object", // mysql_fetch_object()
                              );

        if(isset($this->accept_l[$FuncName]))
          {                           // If the function requires $link
            $FuncArg[] = $this->link; // Adds $link to the parameters of the array
            $RetValue = call_user_func_array("mysql_".$this->accept_l[$FuncName], $FuncArg)
                or die(mysql_error());
            return TRUE;

          }elseif(isset($this->accept[$FuncName])){
                 /* If the function doesn't require $link calls the function */
            $RetValue = call_user_func_array("mysql_".$this->accept[$FuncName], $FuncArg)
                or die(mysql_error());
            return TRUE;
          }else             // If the function isn't accepted
            return FALSE;   // Returns an error

      } // End __call()

  } // End class


overload('MySQL'); // Overloads the class

$db = new MySQL('localhost', 'user', 'pass'); // Creates the object
$db->db("mydb");                              // Selects the db
$res = $db->query("SELECT * FROM names");     // Executes the query

         /* Fetchs and prints the data */
while( ($data = $db->afetch($res, MYSQL_ASSOC)) !== FALSE )
    echo $data["id"].": &nbsp;".$data["name"]."<br/>";

$db->close();                                 // Closes the connection

?>