<?php

class JavaOverLoad
{
    function JavaOverLoad() { } // The constructor is empty

    function __call($FuncName, $FuncArg, &$RetValue)
    {
        $NumArgs = count($FuncArg); // Counts the number of arguments to find the right meth.
        $RetValue =  call_user_func_array(array(&$this, $FuncName.$NumArgs), $FuncArg);
        return TRUE;
    }
              /* Some methods... */
    function greet0()
    {
        echo "Hello World! <br/>";
    }
    
    function greet1($name)
    {
        echo "Hello $name! <br/>";
    }
    
    function greet2($name, $from)
    {
        echo "Hello $name! Greetings from $from! <br/>";
    }
    
    function power1($i)
    {
        echo pow(2, $i)." <br/>";
    }
    
    function power2($base, $i)
    {
        echo pow($base, $i)." <br/>";
    }
}

overload('JavaOverLoad'); // Overloads the class
$overloaded = new JavaOverLoad();
$overloaded -> greet();
$overloaded -> greet("Peter");
$overloaded -> greet("John", "London");
$overloaded -> power(4);    // It should return 2^4
$overloaded -> power(3, 4); // It should return 3^4

?>