<?php

class TrySet
{
    function __set($PropName, &$PropValue)
    {
        $this -> elem[$PropName] = $PropValue; // Stores the prop. and its value in $elem array
        return TRUE;
    }

    function __get($PropName, &$PropValue)
    {
        if (isset($this -> elem[$PropName]))             // If the prop. is in $elem
            $PropValue = $this -> elem[$PropName];       // Assigns the value in the array
        else
           $PropValue = "$PropName isn't defined <br/>"; // Else sets another value
        
        return TRUE;
    }
}

overload('TrySet'); // Overloads the class
$overloaded = new TrySet();
$overloaded -> foo = 3.14;         // Sets an undefined property
echo $overloaded -> foo . "<br/>"; // And prints it
echo $overloaded -> bar;           // Prints an undefined and never set property

?>