<?php

class TryGet
{
    var $greet = "Hello World! <br/>";

    function __get($PropName, &$PropValue)
    {
        $PropValue = "$PropName isn't defined <br/>"; // Sets the value
        return TRUE; // Returns TRUE = doesn't display errors
    }
}

overload('TryGet');        // Overloads the class
$overloaded = new TryGet();
echo $overloaded -> greet; // Prints the defined var
echo $overloaded -> foo;   // Prints an undefined one
echo $overloaded -> bar;   // Prints another undefined one

?>
