<?php

class TryCallParam
{
    function TryCallParam() { }  // The constructor is empty

    function __call($FuncName, $FuncArg, &$RetValue)
    {
        $RetValue = call_user_func_array($FuncName, $FuncArg); // Calls the function
        return TRUE;                                           // And returns TRUE
    }
}

overload('TryCallParam'); // Overloads the class
$overloaded = new TryCallParam();
echo $overloaded -> sqrt(144) . "<br/>";
echo $overloaded -> pow(2, 8) . "<br/>";
echo $overloaded -> base_convert("FA", 16, 2);

?>