class Greet {
  hello() {
    System.out.println("Hello World");
  }

  hello(string name) {
    System.out.println("Hello " + name);
  }

  hello(string name, string from) {
    System.out.println("Hello " + name);
    System.out.println("Greetings from " + from);
  }
}
