$query = "INSERT INTO Example (username) VALUES (�John�)";
$result = mysql_query($query);
if($error_number = mysql_errno())
{
    if($error_number == 1062)
    { echo "Duplicate username, please choose another."; }
    else
    { echo "Unknown error. Message: " . mysql_error(); }
}
else
{ echo "Username successfully added"; }

