<?php

$ar = array(1,2,array('a','b','c'));

$result = var_export($ar,TRUE);
$str1 = '<?php $ar2 = ' . $result . '; ?>';

$fp = fopen('foobar1.inc','w');
fputs($fp,$str1);
fclose($fp);

include('foobar1.inc');

print_r($ar2);

$fp2 = fopen('foobar2.inc','w');
fputs($fp2,$result);
fclose($fp2);

$str2 = '$ar3 = ' . file_get_contents('foobar2.inc') . ';';

eval($str2);

print_r($ar3);

?>

