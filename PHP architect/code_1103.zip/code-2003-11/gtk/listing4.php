<?php

/* 
Load the gtk library, a tiny check to see if we should use the dll or the so file.
The so file is normally used on *nix
*/
dl('php_gtk.'.(strstr(PHP_OS, 'WIN')?'dll':'so'));

/* This function is started when the program quits, quite like a destructor function */
function quit(){
	Gtk::main_quit();
}

/* Create the glade_app object and load the glade file */
$glade_app = &new GladeXML('listing5.glade');


$WIDGETS = array();

/* Get all interesting objects in the user interface */
$WIDGET['window'] = $glade_app->get_widget('window');
$WIDGET['progressbar'] = $glade_app->get_widget('progressbar');
$WIDGET['statusbar'] = $glade_app->get_widget('statusbar');
$WIDGET['resultlist'] = $glade_app->get_widget('resultlist');

/* Get all input objects */
$WIDGET['ipadress'] = $glade_app->get_widget('ipadress');
$WIDGET['timeout'] = $glade_app->get_widget('timeout');
$WIDGET['portrangestart'] = $glade_app->get_widget('portrangestart');
$WIDGET['portrangeend'] = $glade_app->get_widget('portrangeend');
$WIDGET['scanbutton'] = $glade_app->get_widget('scanbutton');

/* 	This function does the actual connection attempt to the port. */
function port_check($ipadress, $port, $timeout){

	$fp = @fsockopen($ipadress, $port, $errno, $errstr, $timeout);
	if( !$fp )
		return false;
	
	fclose($fp);
	return true;
}

/* This function returns a service that is likely to be run on a port number. */
function port_service($port){

	$ports = array(
		20	=>	'FTP Data',
		21	=>	'FTP Control',
		22	=>	'Secure Shell (ssh)',
		23	=>	'Telnet',
		25	=>	'SMTP (email)',
		53	=>	'DNS',
		70	=>	'Gopher',
		79	=>	'Finger',
		80	=>	'HTTP (Web)',
		88	=>	'Kerberos',
		105	=>	'PH (directory)',
		106	=>	'Poppass (change password)',
		110	=>	'POP3 (email)',
		111	=>	'Remote Procedure Call (RPC)',
		113	=>	'AUTH',
		119	=>	'NNTP (News)',
		139	=>	'NETBIOS Session',
		143	=>	'IMAP (new email)',
		311	=>	'AppleShare Web Admin',
		384	=>	'ARNS (tunneling)',
		387	=>	'AURP (tunneling)',
		389	=>	'LDAP (directory)',
		407	=>	'Timbuktu 5.2 or later',
		427	=>	'SLP (service location)',
		443	=>	'SSL (HTTPS)',
		497	=>	'Retrospect',
		510	=>	'FirstClass server',
		515	=>	'LPR (printing)',
		548	=>	'AFP (AppleShare)',
		554	=>	'RTSP (QuickTime server)',
		591	=>	'FileMaker Pro Web',
		626	=>	'IMAP Admin',
		631	=>	'IPP (Internet Printing Protocol)',
		660	=>	'ASIP Remote Admin',
		666	=>	'Now Contact Server',
		687	=>	'ASIP Shared U? Port',
		1080	=>	'WebSTAR Admin',
		1417	=>	'Timbuktu Control (pre-5.2)',
		1418	=>	'Timbuktu Observe (pre-5.2)',
		1419	=>	'Timbuktu Send Files (pre-5.2)',
		1420	=>	'Timbuktu Exchange (pre-5.2)',
		1443	=>	'WebSTAR/SSL Admin',
		3031	=>	'Program Linking (Apple Events)',
		4000	=>	'Now Public Event Server',
		4199	=>	'EIMS Admin',
		4347	=>	'LANsurveyor Responders',
		5003	=>	'FileMaker Pro',
		5190	=>	'AOL Instant Messenger',
		5498	=>	'Hotline Tracker',
		5500	=>	'Hotline Server',
		5501	=>	'Hotline Server',
		6699	=>	'Napster/Macster client',
		7070	=>	'Real Player',
		7648	=>	'CuSeeMe (video)',
		7649	=>	'CuSeeMe (video)',
		8080	=>	'Common HTTP alternate',
		19813	=>	'4D server',
		);

		if( isset($ports[$port]) )
			return $ports[$port];
		else
			return 'Unknown open port';

}

/*
	This function will create a dialog window, with some text and an OK-button.
	The object of the dialog is saved in $WIDGET['dialog'] so it can be accessed
	by close_dialog()
*/
function dialog($message){
	global $WIDGET;

	$WIDGET['dialog'] = &new GtkDialog();
	$label = &new GtkLabel($message);
	$button = &new GtkButton('Ok');

	$dialog_vbox = $WIDGET['dialog']->vbox;
	$dialog_action_area = $WIDGET['dialog']->action_area;

	/* 
		The dialog window should be set modal to freeze the rest of the application from
		user input.
	*/
	$WIDGET['dialog']->set_modal(true);
	$WIDGET['dialog']->set_policy(true, false, false);
	$WIDGET['dialog']->set_position(GTK_WIN_POS_CENTER);

	$dialog_vbox->pack_start($label);
	$dialog_action_area->pack_start($button);
	$WIDGET['dialog']->show_all();

	/* Connect the OK-button with close_dialog() */
	$button->connect('clicked', 'close_dialog');

}

/* This function closes the dialog opened by dialog() */
function close_dialog(){
	global $WIDGET;
	
	$WIDGET['dialog']->destroy();
}

/* 
	This function updates the statusbar with the supplied text. 
	The gtk main loop must be started to make this changes active, see separate explanation in the article.
*/
function update_statusbar($text){
	global $WIDGET;

	$WIDGET['statusbar']->push($WIDGET['statusbar']->get_context_id(''), $text);
}

/* 
	This function updates the progressbar with the supplied value. 
	The gtk main loop must be started to make this changes active, see separate explanation in the article.
*/
function update_progressbar($value){
	global $WIDGET;

	if( $value>1 )
		$value = 1;

	$WIDGET['progressbar']->set_percentage($value);
}

/*
	This is the	main function of this application, it performs the control of the scanning,
	and also updates the user interface meanwhile. 
*/
function scan(){
	global $WIDGET;

	/* Get all needed variables from the options tab and the ip-adress from the Scan tab. */
	$portrangestart = $WIDGET['portrangestart']->get_value_as_int();
	$portrangeend = $WIDGET['portrangeend']->get_value_as_int();
	$timeout = $WIDGET['timeout']->get_value_as_int();
	$ipadress = $WIDGET['ipadress']->get_text();

	/* Make sure that we always start scanning on a lower port than what we are heading for. */
	if( $portrangestart>$portrangeend )
		dialog('Port range start cant be higher than port range end.');

	/* Make sure the ip-adress is valid, only IPV4. */
	if( !ereg('^([0-9]{1,2}|[01][0-9]{2}|2[0-4][0-9]|25[0-5])\.([0-9]{1,2}|[01][0-9]{2}|2[0-4][0-9]|25[0-5])\.([0-9]{1,2}|[01][0-9]{2}|2[0-4][0-9]|25[0-5])\.([0-9]{1,2}|[01][0-9]{2}|2[0-4][0-9]|25[0-5])$', $ipadress) )
		dialog('IP-adress does not seem to be valid.');

	/* Clear the clist widget to make room for new results */
	$WIDGET['resultlist']->clear();

	/* Check how many ports we are scanning and how much the progressbar should increase for each one. */
	$progress_addon = 100/($portrangeend-$portrangestart);

	$current_progress = 0;
	$open_ports = 0;
	$clist_row = 0;

	$current_port = $portrangestart;
	while( $current_port<=$portrangeend ){
		
		/* Increase $current_progress and then update the progressbar. */
		$current_progress+=$progress_addon;
		update_progressbar(($current_progress/100));
		
		/* Update the statusbar to inform the user on the current port */
		update_statusbar('Contacting '.$ipadress.' on port '.$current_port);
		
		/* 
			Perform the actual port scan, if the port is open, add a line to the clist widget with the result. 
			Also, increment the number of open ports found.	
		*/
		if( port_check($ipadress, $current_port, $timeout) ){
			$WIDGET['resultlist']->append(array( $current_port, port_service($current_port)));
			$open_ports++;
		}

		/*
			This is a very important part, without the two following lines, the result of the application is very
			confusing. Since we have change a lot of things when we get here, as updateing the progress/status-bar.
			Those things have to be performed by the gtk main loop, a lot of gtk events will be waiting for their
			turn to finish. Although, if you skip this, the application will still work, it will do the scanning and
			so on, but the increments on the progressbar wont change until its finished, the same with the statusbar 
			and the clist to. 
		*/
		while( gtk::events_pending() )
			gtk::main_iteration();

		/* Go on to the next port number now */
		$current_port++;
	}

	/* Update the statusbar and state that the scanning is finished and how many ports where found. */
	update_statusbar('Scanning finished ('.$open_ports.' open port(s) found)');
}

/* Connect the scan() function with the scanbutton */
$WIDGET['scanbutton']->connect('clicked', 'scan');

/* Connect the quit() function to the delete_event signal */
$WIDGET['window']->connect('delete_event', 'quit');

/* Align the window centered on the screen */
$WIDGET['window']->set_position(GTK_WIN_POS_CENTER);
$WIDGET['window']->set_policy(true, false, false);

/* Show the window that we created. */
$WIDGET['window']->show_all();

/* Start the gtk main loop */
Gtk::main();

?>