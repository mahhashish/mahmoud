<?php

/* 
Load the gtk library, a tiny check to see if we should use the dll or the so file.
The so file is normally used on *nix
*/
dl('php_gtk.'.(strstr(PHP_OS, 'WIN')?'dll':'so'));

/* This function is started when the program quits, quite like a destructor function */
function quit(){
	Gtk::main_quit();
}

/* This function is started when the Ok-button is clicked. */
function click_button(){
	
	/* Change the text in the $label text box. */
	$GLOBALS['label']->set_text('Thanks for clicking ok.');
}

/* Create the window with "Hello world" as title and a fixed size */
$window = &new GtkWindow;
$window->set_title('Hello world');
$window->set_default_size(300,150);

/* Create a small label with the following text*/
$label = &new GtkLabel('test');

/* Create a button */
$button = &new GtkButton('Ok');

/* Connect the click_button() function to the clicked signal */
$button->connect('clicked', 'click_button');

/* Use a verticle box container */
$box = &new GtkVBox();

/* Pack both of the to objects in there. */
$box->pack_start($label);
$box->pack_start($button);

/* Fit the box into the window */
$window->add($box);

/* Connect the quit() function to the delete_event signal */
$window->connect('delete_event', 'quit');

/* Show the fantastic window that we created. */
$window->show_all();

/* Start the gtk main loop */
Gtk::main();

?>