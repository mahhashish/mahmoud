<?php

/* 
Load the gtk library, a tiny check to see if we should use the dll or the so file.
The so file is normally used on *nix
*/
dl('php_gtk.'.(strstr(PHP_OS, 'WIN')?'dll':'so'));

/* This function is started when the program quits, quite like a destructor function */
function quit(){
	Gtk::main_quit();
}

/* This function is started when the Ok-button is clicked. */
function click_button(){
	
	/* Change the text in the $label text box. */
	$GLOBALS['label']->set_text('Thanks for clicking ok.');
}

/* Create the glade_app object and load the glade file */
$glade_app = &new GladeXML('listing4.glade');

/* Get all interesting objects in the user interface */
$window = $glade_app->get_widget('window');
$label = $glade_app->get_widget('label');
$button = $glade_app->get_widget('okbutton');

/* Connect the click_button() function to the clicked signal */
$button->connect('clicked', 'click_button');

/* Connect the quit() function to the delete_event signal */
$window->connect('delete_event', 'quit');

/* Show the fantastic window that we created. */
$window->show_all();

/* Start the gtk main loop */
Gtk::main();

?>