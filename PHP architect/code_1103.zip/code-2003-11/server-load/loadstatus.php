<?php

// setup LOADMGMT session. data in this
// session is shared amongst all requests

session_id( "LOADMGMT" );
session_start();

// load management parameters
// servicetime: in average, how long does a user takes in the server?

$servicetime = 1*60;

// script control variables

$now = time();
$sequenceval = $_SESSION[ "shared_sequenceval" ];
$running = $_SESSION[ "shared_running" ];
$queue = $_SESSION[ "shared_queue" ];

?>
<!doctype html public "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title> Load Status </title>
<meta http-equiv="refresh" content="2"> 
</head>
<body>
users in the server:<br>
<?php
  if ($running)
    foreach( $running as $i => $usertime )
      echo "&nbsp;&nbsp;[$i] ".($usertime - $now)." seconds to leave<br>";
  else
    echo "&nbsp;&nbsp;none<br>";
?>
users in queue:<br>
<?php
  $pos = 0;
  $n = count( $running );

  if ($queue)
    foreach( $queue as $sequence => $lastrefresh ) {
      $waittime = $running[ $pos % $n ] - $now
                + $servicetime * floor( $pos / $n );
      echo "&nbsp;&nbsp;[$sequence] ".($now - $lastrefresh)." idle. ";
      echo "using line [".($pos % $n)."]. ";
      echo "$waittime seconds to enter<br>";
      $pos++;
    }
  else
    echo "&nbsp;&nbsp;none<br>";
?>
</body>
</html>