<?php

// setup LOADMGMT session. data in this
// session is shared amongst all requests

session_id( "LOADMGMT" );
session_start();

// load management parameters
// servicetime: in average, how long does a user takes in the server?
// maxusers: how many users can server handle at the same time?
// timeout: how long does the browser have to refresh the page?
// refreshtime: how often does the browser should refresh the page?

$servicetime = 1*60; // in seconds
$maxusers = 3; // number of simultaneous users
$timeout = 10; // timeout for queue, in seconds
$refreshtime = 2; // refresh time for browser, in seconds

// script control variables
// now: current timeout
// sequenceval: incremental value for labling new requests
// running: data on number of users in servers
// queue: data on number of users in queue
// freetogo: flag to indicate whether service must be provided
// myposition: if in queue, indicates request position in line
// mywaittime: if in queue, indicates wait time for service

$now = time();
$sequenceval = $_SESSION[ "shared_sequenceval" ];
$running = $_SESSION[ "shared_running" ];
$queue = $_SESSION[ "shared_queue" ];
$freetogo = false;
$myposition = 0;
$mywaittime = 0;

// mysequence is an uniqueid for a user that accesses the server
// if mysequence is from a cookie, then the user is in queue
if ($_COOKIE[ "mysequence" ])
  $mysequence = $_COOKIE[ "mysequence" ];

// cleanup list of users running in the webserver
if ($running) {
  $newrunning = array();
  foreach( $running as $usertime )
    if ($usertime > $now)
      $newrunning[] = $usertime;
  $running = $newrunning;
}

// cleanup list of users in queue with refresh timed out
if ($queue) {
  $newqueue = array();
  foreach( $queue as $usersequence => $lastrefresh )
    if ($now - $lastrefresh < $timeout)
      if ($usersequence == $mysequence) {
        $newqueue[ $usersequence ] = $now;
        $myposition = count( $newqueue );
      }
      else
        $newqueue[ $usersequence ] = $lastrefresh;
  $queue = $newqueue;
}

// should the request be put in a waitline or is it free to go?
if (count( $running ) < $maxusers && empty( $queue )) {
  $running[] = $now + $servicetime;
  $freetogo = true;
}

// if it is not free to go, then check queue
if (!$freetogo) {

  if (empty( $myposition )) {
    // if $myposition is empty, consider it a new request to serve
    $sequenceval++;
    $mysequence = "S$sequenceval";
    setcookie( "mysequence", $mysequence );
    $queue[ $mysequence ] = $now;
    $myposition = count( $queue );
  }
  else if (count( $running ) < $maxusers && $myposition == 1) {
    // if current user is next in line, and the server is within capacity
    // then move user from queue to server
    array_shift( $queue );
    $running[] = $now + $servicetime;
    $freetogo = true;
  }

  if (!$freetogo) {
    $myposition--; // so far, my position started in 1
    $n = count( $running );
    $mywaittime = $running[ $myposition % $n ] - $now
                + $servicetime * floor( $myposition / $n );
    if ($mywaittime < 0)
      $mywaittime = 0;
  }

}

$_SESSION[ "shared_sequenceval" ] = $sequenceval;
$_SESSION[ "shared_running" ] = $running;
$_SESSION[ "shared_queue" ] = $queue;

if ($freetogo) {
  setcookie( "mysequence", false, mktime(0,0,0,10,20,1972) );
  echo "Greetings! You have the server!";
}
else {
?>
<!doctype html public "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title> Queue Status </title>
<meta http-equiv="refresh" content="<?=$refreshtime?>"> 
</head>
<body>
<?php
  echo "Hello! You ";
  echo ($myposition == 0)
    ? "are the next user to be served"
    : "have $myposition user(s) waiting to be served before you";
  echo ". Your estimated wait time is ".($mywaittime)." seconds. Please wait.";
  echo "<br>&nbsp;<br>(pid: $mysequence)";
?>
</body>
</html>
<?php
} // end not $freetogo

?>