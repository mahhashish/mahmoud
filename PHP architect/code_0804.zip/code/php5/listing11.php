<?php
	$animals = array ("dog", "cat", "iguana");

	/* stagger the case of each entry in the array */
	foreach($animals as $k => $animal) {

		for($i = 0; $i < strlen($animals[$k]); $i++) {
			$animals[$k]{$i} = ($i % 2) ? strtoupper($animals[$k]{$i}) :
					              strtolower($animals[$k]{$i});
		}
	}
	
	var_dump($animals);
?>
