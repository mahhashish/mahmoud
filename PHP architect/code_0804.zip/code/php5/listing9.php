<?php

    $simplexml = simplexml_load_file("example.xml");

    foreach($simplexml->extension->authors->author as $author) {
        echo "Author Name: $author<BR/>\n";
    }
    
            
?>