<?php
    
    $dom = new DomDocument();
    $dom->load("example.xml");

    $authors = $dom->getElementsByTagName("authors");
    
    $author = $dom->createElement("author");
    $authorname = $dom->createTextNode("Joe PHP Guy");
    $author->appendChild($authorname);
    
    $authors->item(0)->appendChild($author);

    $simplexml = simplexml_import_dom($dom);
    
    foreach($simplexml->extension->authors->author as $author) {
        echo "Author Name: $author<BR/>\n";
    }
    
?>