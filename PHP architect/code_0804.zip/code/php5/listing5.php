<?php

    $dom = new DomDocument();
    $dom->load("example.xml");
    
    $valid = $dom->schemaValidate("example.xsd");
    
    if(!$valid) {
        
        echo "The document was not valid!<BR/>\n";
        exit;    
    }
        
    $authors = $dom->getElementsByTagName("author");
    var_dump($authors);    
    foreach($authors as $author) {
        /* Alternatively we could have used $author->textContent */       
        echo "Author name: {$author->firstChild->data}<BR/>\n";
    }
    
?>
