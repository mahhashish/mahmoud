<?php
	$link = mysqli_connect("localhost",
 	 		       "username",
			       "password");

	mysqli_autocommit(false);
	
	mysqli_query("INSERT INTO foo values(1)");
	mysqli_commit();
	mysqli_query("INSERT INTO foo values(2)");
	mysqli_query("INSERT INTO foo values(3)");
	mysqli_rollback();

	mysqli_autocommit(true);

	mysqli_query("INSERT INTO foo values(4)");

	mysqli_close($link);

?>
