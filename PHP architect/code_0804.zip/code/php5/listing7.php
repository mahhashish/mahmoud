<?php
    
    $dom = new DomDocument();
    $dom->load("example.xml");

    $xpath = new DOMXPath($dom);
    $nodes = $xpath->query("/phpextensions/extension//author");
    
    foreach($nodes as $author) {
        
        echo "Author Name: {$author->textContent}<BR/>\n";
        
    }
    
?>