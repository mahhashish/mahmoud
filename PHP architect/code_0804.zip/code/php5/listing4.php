<?php

	$names = array("John Coggeshall", "Marco Tabini", "Joe Internet");

	$sqlite = sqlite_open(":memory:");
	
	$query = "CREATE TABLE mynames (first STRING, last STRING)";
	sqlite_query($sqlite, $query);
	
	foreach($names as $fullname) {
		list($first, $last) = explode(" ", $fullname);
		$first = sqlite_escape_string($first);
		$last = sqlite_escape_string($last);
		$query = "INSERT INTO mynames VALUES('$first', '$last')";
		sqlite_query($sqlite, $query);
	}

	$query = "SELECT * FROM mynames";
	$res = sqlite_query($sqlite, $query);
	while($row = sqlite_fetch_array($res))
	{
		var_dump($row);
	}
	sqlite_close($sqlite);

?>
