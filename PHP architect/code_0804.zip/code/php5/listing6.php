<?php
    
    function dumpdocument(DOMNodeList $e, $indent = 0   ) {
        
        foreach ($e as $node) {
         
            if($node->nodeType == XML_ELEMENT_NODE) {

                echo str_repeat(" ", $indent);
                echo "Node: {$node->nodeName}<BR/>\n";
                dumpdocument($node->childNodes, $indent+4);
                
            }
            
            if($node->nodeType == XML_TEXT_NODE) {
                $text = trim($node->textContent);
                if(!empty($text)) {
                    echo str_repeat(" ", $indent+4);
                    echo "Text: $text<BR/>\n";
                }
            }
            
        }
        
    }
    
    $dom = new DomDocument();
    $dom->load("example.xml");
    dumpdocument($dom->documentElement->childNodes);
    
?>