<?php
	$names = array(array('first' => "John",
		             'last' => "Coggeshall"),
		       array('first' => "Marco",
                             'last' => "Tabini"));

	$link = mysqli_connect("localhost",
 	 		       "username",
			       "password");

	
	$query = "INSERT INTO mytable (first, last) VALUES(?,?)";
	$stmt = mysqli_prepare($link, $query);

	foreach($names as $name) {

		mysqli_bind_param($stmt, "ss", $name['first'], $name['last']);
		mysqli_execute($stmt);

	}
	
	mysqli_stmt_close($stmt);

	mysqli_close($link);

?>
