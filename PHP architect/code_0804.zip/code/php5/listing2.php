<?php

	$link = mysqli_connect("localhost",
 	 		       "username",
			       "password");
	
	$query = "SELECT first, last FROM mytable";
	$stmt = mysqli_prepare($link, $query);
	
	mysqli_bind_result($stmt, $first, $last);
	mysqli_execute($stmt);

	while(mysqli_stmt_fetch($stmt)) {

		echo "Name: $first $last<BR/>\n";
		
	}

	mysqli_stmt_close($stmt);

	mysqli_close($link);

?>
