<?php
    
    $dom = new DomDocument();
    $dom->load("example.xml");

    $authors = $dom->getElementsByTagName("authors");
    
    $author = $dom->createElement("author");
    $authorname = $dom->createTextNode("Joe PHP Guy");
    $author->appendChild($authorname);
    
    $authors->item(0)->appendChild($author);
    echo $dom->saveXML();
    
?>