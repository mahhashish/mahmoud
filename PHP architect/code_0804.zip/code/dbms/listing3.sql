/* One table per class hierarchy */

CREATE TABLE person(
    person_id int4 NOT NULL PRIMARY KEY,
    customer_id int4 NULL,
    company_name varchar(128) NULL,
    employee_id int4 NULL,    
    employee_startdate timestamp NULL,
    first_name varchar(64) NOT NULL,
    last_name varchar(64) NOT NULL,
    address1 varchar(255) NOT NULL,
    address2 varchar(255) NOT NULL,
    city varchar(64) NOT NULL,
    state_province varchar(64) NOT NULL,
    postal_code char(10) NOT NULL,
    phone varchar(32) NOT NULL,
    fax varchar(32) NULL
);