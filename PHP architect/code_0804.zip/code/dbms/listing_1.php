<?php

class customer
{

    var $customer_id;
    var $first_name;
    var $last_name;
    var $company_name;
    var $address1;
    var $address2;
    var $city;
    var $state_province;
    var $postal_code
    var $phone;
    var $fax;
    
    var $db_connection;
    
    function customer($customer_id)
    {
        //instantiate customer object, by pulling records from DB
        $query = "SELECT * FROM customers WHERE id=" (int)$customer_id;
        $row = db_fetch_assoc(db_query($query, $this->db_connection));

        //if we want to be slick, and make sure our column names are the same as our class vars:
        foreach($row as $name=>$value)
        {
            $this->$name = $value;
        }

    }

}

?>