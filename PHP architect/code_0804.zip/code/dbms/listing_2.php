<?php

class person
{

    var $first_name;
    var $last_name;
    var $address1;
    var $address2;
    var $city;
    var $state_province;
    var $postal_code
    var $phone;

}

class customer extends person
{

    var $person_id;
    var $customer_id;
    var $company_name;
    var $fax;
    var $salescontact;

}

class employee extends person
{

    var $person_id;
    var $employee_id;
    var $position;
    var $startdate;
    var $current_salary;

}

?>