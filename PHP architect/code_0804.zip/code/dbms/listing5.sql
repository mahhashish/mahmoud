/* One table per actual class */

CREATE TABLE person(
    person_id int4 NOT NULL PRIMARY KEY,
    first_name varchar(64) NOT NULL,
    last_name varchar(64) NOT NULL,
    address1 varchar(255) NOT NULL,
    address2 varchar(255) NOT NULL,
    city varchar(64) NOT NULL,
    state_province varchar(64) NOT NULL,
    postal_code char(10) NOT NULL,
    phone varchar(32) NOT NULL
);

CREATE TABLE customer(
    customer_id int4 NOT NULL PRIMARY KEY REFERENCES person(person_id),
    company_name varchar(128) NOT NULL,
    fax varchar(32) NOT NULL
);

CREATE TABLE person(
    employee_id int4 NOT NULL PRIMARY KEY REFERENCES person(person_id),    
    employee_startdate timestamp NOT NULL
);