<?php
/**
 * script to create bugs open/closed by week graph
 *
 * @author  Jason E. Sweat
 * @since  2002-12-13
 * @version $Id: 8368_07_cs3ex1.php,v 1.2 2004/07/06 17:18:37 sweatje Exp $
 */
require_once('phpa_db.inc.php');

require_once('jpgraph/jpgraph.php');
require_once('jpgraph/jpgraph_bar.php');
require_once('jpgraph/jpgraph_line.php');
require_once('jpgraph/jpgraph_regstat.php'); 


define('WIDTH', 500);
define('HEIGHT', 310);
define('NUM_POINTS', 200);
//controls for the different versions of the graph presented in the article
define('SMOOTH_PLOT', false);
define('STEP_STYLE', true);
//test of a version of JpGraph with alpha blending, was not released when I origianlly wrote the article
define('BAR_TEST', true);


$sql = <<<EOS
SELECT YEARWEEK(`ts1`) AS dt, COUNT( 1 ) AS cnt
FROM `bugdb`
WHERE YEARWEEK(`ts1`) > '200201'
GROUP BY YEARWEEK(`ts1`)
ORDER BY YEARWEEK(`ts1`) ASC
EOS;


$rs =& $conn->Execute($sql);
if ($rs && !$rs->EOF) {
  $openDbData = $rs->GetAssoc();
}


$sql = <<<EOS
SELECT YEARWEEK(`ts2`) AS dt, COUNT( 1 ) AS cnt
FROM `bugdb`
WHERE YEARWEEK(`ts2`) > '200201'
AND `status` IN ('Closed', 'Bogus')
GROUP BY YEARWEEK(`ts2`)
ORDER BY YEARWEEK(`ts2`) ASC
EOS;

$rs =& $conn->Execute($sql);
if ($rs && !$rs->EOF) {
  $closeDbData = $rs->GetAssoc();
}

$i = 0;
foreach($openDbData as $key => $value) {
  $xData[$i] = $key;
  $openData[$i] = $value;
  $closeData[$i] = $closeDbData[$key];
  //convert week into year back to a date for display
  $labelX[$i] =  strftime('%m/%d', mktime(0, 0, 0, 1, 1+(int)substr($key, 4, 2)*7, substr($key, 0, 4)));
  //$maxData[$i] = max(array($value, $closeData[$i]));
  $minData[$i] = min($openData[$i] , $closeData[$i]);
  
  if ($openData[$i] >= $closeData[$i]) {
  	$openBarData[$i] = $openData[$i] - $closeData[$i];
  	$closeBarData[$i] = 0;
  } else {
  	$openBarData[$i] = 0;
  	$closeBarData[$i] = $closeData[$i] - $openData[$i];
  }
  $i++;
}

/*
here is the data since I really can't provide the bug database itself
$openData = unserialize(a:49:{i:0;s:3:"131";i:1;s:3:"106";i:2;s:3:"119";i:3;s:3:"107";i:4;s:3:"136";i:5;s:3:"108";i:6;s:3:"106";i:7;s:3:"147";i:8;s:3:"137";i:9;s:3:"142";i:10;s:3:"119";i:11;s:3:"125";i:12;s:3:"103";i:13;s:3:"124";i:14;s:3:"125";i:15;s:3:"165";i:16;s:3:"126";i:17;s:3:"151";i:18;s:3:"149";i:19;s:3:"122";i:20;s:3:"129";i:21;s:3:"102";i:22;s:3:"117";i:23;s:3:"150";i:24;s:3:"139";i:25;s:3:"138";i:26;s:3:"129";i:27;s:3:"118";i:28;s:3:"158";i:29;s:3:"119";i:30;s:3:"119";i:31;s:3:"113";i:32;s:3:"126";i:33;s:3:"122";i:34;s:2:"79";i:35;s:3:"123";i:36;s:3:"135";i:37;s:3:"108";i:38;s:3:"121";i:39;s:3:"108";i:40;s:3:"113";i:41;s:3:"118";i:42;s:3:"110";i:43;s:3:"109";i:44;s:3:"126";i:45;s:3:"144";i:46;s:3:"138";i:47;s:3:"142";i:48;s:2:"60";}');
$closeData = unserialize(a:49:{i:0;s:3:"134";i:1;s:2:"67";i:2;s:2:"58";i:3;s:2:"97";i:4;s:3:"143";i:5;s:2:"83";i:6;s:2:"58";i:7;s:3:"113";i:8;s:2:"88";i:9;s:2:"80";i:10;s:2:"97";i:11;s:2:"60";i:12;s:3:"105";i:13;s:3:"201";i:14;s:2:"87";i:15;s:3:"168";i:16;s:3:"106";i:17;s:2:"89";i:18;s:2:"98";i:19;s:3:"180";i:20;s:3:"121";i:21;s:3:"207";i:22;s:3:"150";i:23;s:3:"467";i:24;s:3:"160";i:25;s:3:"176";i:26;s:3:"155";i:27;s:2:"92";i:28;s:3:"125";i:29;s:2:"92";i:30;s:3:"107";i:31;s:3:"176";i:32;s:3:"124";i:33;s:2:"88";i:34;s:2:"63";i:35;s:3:"154";i:36;s:3:"132";i:37;s:3:"141";i:38;s:3:"211";i:39;s:3:"111";i:40;s:3:"108";i:41;s:2:"76";i:42;s:3:"132";i:43;s:2:"87";i:44;s:3:"131";i:45;s:3:"104";i:46;s:3:"116";i:47;s:3:"111";i:48;s:2:"68";}');
$minData = unserialize(a:49:{i:0;s:3:"131";i:1;s:2:"67";i:2;s:2:"58";i:3;s:2:"97";i:4;s:3:"136";i:5;s:2:"83";i:6;s:2:"58";i:7;s:3:"113";i:8;s:2:"88";i:9;s:2:"80";i:10;s:2:"97";i:11;s:2:"60";i:12;s:3:"103";i:13;s:3:"124";i:14;s:2:"87";i:15;s:3:"165";i:16;s:3:"106";i:17;s:2:"89";i:18;s:2:"98";i:19;s:3:"122";i:20;s:3:"121";i:21;s:3:"102";i:22;s:3:"117";i:23;s:3:"150";i:24;s:3:"139";i:25;s:3:"138";i:26;s:3:"129";i:27;s:2:"92";i:28;s:3:"125";i:29;s:2:"92";i:30;s:3:"107";i:31;s:3:"113";i:32;s:3:"124";i:33;s:2:"88";i:34;s:2:"63";i:35;s:3:"123";i:36;s:3:"132";i:37;s:3:"108";i:38;s:3:"121";i:39;s:3:"108";i:40;s:3:"108";i:41;s:2:"76";i:42;s:3:"110";i:43;s:2:"87";i:44;s:3:"126";i:45;s:3:"104";i:46;s:3:"116";i:47;s:3:"111";i:48;s:2:"60";}');
$openBarData = unserialize(a:49:{i:0;i:0;i:1;i:39;i:2;i:61;i:3;i:10;i:4;i:0;i:5;i:25;i:6;i:48;i:7;i:34;i:8;i:49;i:9;i:62;i:10;i:22;i:11;i:65;i:12;i:0;i:13;i:0;i:14;i:38;i:15;i:0;i:16;i:20;i:17;i:62;i:18;i:51;i:19;i:0;i:20;i:8;i:21;i:0;i:22;i:0;i:23;i:0;i:24;i:0;i:25;i:0;i:26;i:0;i:27;i:26;i:28;i:33;i:29;i:27;i:30;i:12;i:31;i:0;i:32;i:2;i:33;i:34;i:34;i:16;i:35;i:0;i:36;i:3;i:37;i:0;i:38;i:0;i:39;i:0;i:40;i:5;i:41;i:42;i:42;i:0;i:43;i:22;i:44;i:0;i:45;i:40;i:46;i:22;i:47;i:31;i:48;i:0;}');
$closeBarData = unserialize(a:49:{i:0;i:3;i:1;i:0;i:2;i:0;i:3;i:0;i:4;i:7;i:5;i:0;i:6;i:0;i:7;i:0;i:8;i:0;i:9;i:0;i:10;i:0;i:11;i:0;i:12;i:2;i:13;i:77;i:14;i:0;i:15;i:3;i:16;i:0;i:17;i:0;i:18;i:0;i:19;i:58;i:20;i:0;i:21;i:105;i:22;i:33;i:23;i:317;i:24;i:21;i:25;i:38;i:26;i:26;i:27;i:0;i:28;i:0;i:29;i:0;i:30;i:0;i:31;i:63;i:32;i:0;i:33;i:0;i:34;i:0;i:35;i:31;i:36;i:0;i:37;i:33;i:38;i:90;i:39;i:3;i:40;i:0;i:41;i:0;i:42;i:22;i:43;i:0;i:44;i:5;i:45;i:0;i:46;i:0;i:47;i:0;i:48;i:8;}');
*/

$graph =& new graph(WIDTH, HEIGHT);
$graph->SetMarginColor('white'); 
$graph->SetShadow();
$graph->title->Set('PHP Bugs Opened Vs. Closed by Week');
$graph->title->SetFont(FF_ARIAL, FS_BOLD, 12);

if (BAR_TEST) {
	$graph->SetScale('textlin');

	$b1 =& new BarPlot($minData);
	$b1->SetColor('white@1');
	$b1->SetFillColor('white@1');

	$b2 =& new BarPlot($openBarData);
	$b2->SetFillColor('red');
	$b2->SetLegend('more bugs opened');

	$b3 =& new BarPlot($closeBarData);
	$b3->SetFillColor('green');
	$b3->SetLegend('more bugs closed');

	$ab =& new AccBarPlot(array($b1, $b2, $b3));
	$ab->SetWidth(0.98);

	$l3 =& new LinePlot($minData);
	$l3->SetStepStyle();

	$graph->Add($l3);
	$graph->Add($ab);

}else{

	if (SMOOTH_PLOT) {

	  $graph->SetScale('linlin', 1, 1, min($xData), max($xData));
	  $spline =& new Spline($xData, $openData); 
	  list($openXSmooth, $openYSmooth) = $spline->Get(NUM_POINTS); 
	  $spline =& new Spline($xData, $closeData); 
	  list($closeXSmooth, $closeYSmooth) = $spline->Get(NUM_POINTS); 

	  $minData = array();
	  for ($i=0, $j=count($openYSmooth); $i<$j; $i++) {
		$minData[$i] = min(array($openYSmooth[$i], $closeYSmooth[$i]));
	  }

	  $l1 =& new LinePlot($openYSmooth, $openXSmooth);
	  $l1->SetFillColor('red');
	  $l1->SetLegend('more bugs opened');
	  $l2 =& new LinePlot($closeYSmooth, $closeXSmooth);
	  $l2->SetFillColor('green');
	  $l2->SetLegend('more bugs closed');
	  $l3 =& new LinePlot($minData, $openXSmooth);
	  $l3->SetFillColor('white');

	} else {

	  $graph->SetScale('textlin');
	  $l1 =& new LinePlot($openData);
	  $l1->SetFillColor('red');
	  $l1->SetLegend('more bugs opened');
	  $l2 =& new LinePlot($closeData);
	  $l2->SetFillColor('green');
	  $l2->SetLegend('more bugs closed');
	  $l3 =& new LinePlot($minData);
	  $l3->SetFillColor('white');
	  if (STEP_STYLE) {
		$l1->SetStepStyle();
		$l2->SetStepStyle();
		$l3->SetStepStyle();
	  }
	}

	$t1 =& new Text("PHP 4.2.2\nReleased 7/22/02");
	$t1->Pos(0.55, 0.35);
	$t1->SetOrientation('h');
	$t1->SetFont(FF_ARIAL, FS_BOLD);
	$t1->SetBox('yellow', 'red', 'gray');
	$t1->SetColor('black');

	$graph->ygrid->show(false);

	$graph->Add($l1);
	$graph->Add($l2);
	$graph->Add($l3);
	if (SMOOTH_PLOT) { 
	  $graph->AddText($t1);
	}
}

$graph->xaxis->SetTickLabels($labelX);
$graph->xaxis->SetLabelAngle(90);
$graph->xaxis->SetTextLabelInterval(2); 
$graph->legend->SetFillColor('white');

$graph->Stroke();


#?>
