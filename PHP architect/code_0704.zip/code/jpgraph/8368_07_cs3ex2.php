<?php
/**
 * bug comparison navigation
 *
 * @author	Jason E. Sweat
 * @since	2002-12-17
 * @version	$Id: 8368_07_cs3ex2.php,v 1.2 2004/07/06 17:20:19 sweatje Exp $
 */
require_once('phpa_db.inc.php');
require_once('Smarty.class.php');

define('TEMPLATE', 'bug_compare.tpl');
define('GRAPH_FILE', 'bug_radar_graph.php?bug=');

$bug = check_passed_bug('bug');
$b1 = check_passed_bug('b1');
$b2 = check_passed_bug('b2');

$sql = <<<EOS
SELECT COUNT( 1 ) AS votes, 
	b.`id`, 
	b.`bug_type`, 
	b.`status`, 
	b.`sdesc`, 
	AVG( v.`score` ) AS avg_score, 
	AVG( v.`reproduced` ) AS avg_repro, 
	AVG( v.`sameos` ) AS avg_os, 
	AVG( v.`samever` ) AS avg_samever, 
	AVG( v.`tried` )  AS avg_tried
FROM `bugdb_votes` v, `bugdb` b
WHERE v.`bug` = b.`id`
	AND b.`status` <> "Closed"
	AND b.`status` <> "Bogus"
GROUP BY b.`id`, 
	b.`bug_type`, 
	b.`status`, 
	b.`sdesc`
ORDER BY 1 DESC  
LIMIT 0, 30 
EOS;

$rs =& $conn->Execute($sql);
if ($rs && !$rs->EOF) {
	$bugData = $rs->getArray();
} else {
	die('DB Error');
}

$t =& new Smarty;
$t->autoload_filters = array( 'pre'   	=> array('showinfoheader')
							, 'output'  => array('trimwhitespace'));
$t->assign(array(
	'bug'		=>	$bug,
	'b1'		=>	$b1,
	'b2'		=>	$b2,
	'bugData'	=>	$bugData,
	'graphSrc'	=>	GRAPH_FILE,
	'selfLink'	=>	phpself()
	));

$t->display(TEMPLATE);

exit;

function check_passed_bug( $parm )
{
	global $conn;
	
$sql = <<<EOS
SELECT COUNT( 1 ) AS cnt,
	`id`
FROM `bugdb`
WHERE `id` = ?
GROUP BY `id`
EOS;

	if (array_key_exists($parm,$_GET)) {
		$bug_id = $_GET[$parm];
		$rs =& $conn->Execute($sql, array($bug_id));
		if ($rs && !$rs->EOF) {
			$row = $rs->fetchRow();
			if ($row['cnt'] == '1') {
				return $row['id'];
			}
		}
	}
	return false;
}

function phpself()
{
	global $sid;

	$protocol = 'http';
	
	if (443 == $_SERVER['SERVER_PORT']) {
		$protocol .= 's';
	}

	$ret = $protocol.'://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?';

	if (isset($sid)) {
		$ret .= "sid={$sid}&";
	}

	return $ret;
}




#?>
