<?php
/**
 * generate radar chart for bug based on vote info
 *
 * @author  Jason E. Sweat
 * @since  2002-12-12
 * @version	$Id: bug_radar_graph.php,v 1.2 2004/07/06 17:23:09 sweatje Exp $
 */
require_once('phpa_db.inc.php');

require_once('jpgraph/jpgraph.php');
require_once('jpgraph/jpgraph_canvas.php');
require_once('jpgraph/jpgraph_radar.php');

define('WIDTH', 200);
define('HEIGHT', 200);
define('GRAPH_MAX', 10);
define('VOTE_SCALE', 20);
define('SCORE_SCALE', 0.2);
define('REPRO_SCALE', 0.1);
define('OS_SCALE', 0.1);
define('VER_SCALE', 0.1);
define('TRIED_SCALE', 0.1);

$bugColors = array('lightyellow', 'lightblue', 'lightgreen');

$bug = check_passed_bug('bug');
if (!$bug) {
  graph_error('bug parameter incorrect');
}

if (array_key_exists('bn', $_GET)) {
  $bn = abs((int)$_GET['bn']);
  if ($bn>count($bugColors)) {
    $bn=0;
  }
} else {
  $bn = 0;
}


$sql = <<<EOS
SELECT COUNT( 1 ) AS votes, 
  b.`id`, 
  b.`bug_type`, 
  b.`status`, 
  b.`sdesc`, 
  AVG( v.`score` ) AS avg_score, 
  AVG( v.`reproduced` ) AS avg_repro, 
  AVG( v.`sameos` ) AS avg_os, 
  AVG( v.`samever` ) AS avg_samever, 
  AVG( v.`tried` )  AS avg_tried
FROM `bugdb_votes` v, `bugdb` b
WHERE v.`bug` = b.`id`
  AND b.`id` = ?
GROUP BY b.`id`, 
  b.`bug_type`, 
  b.`status`, 
  b.`sdesc`
EOS;

$rs =& $conn->Execute($sql, array($bug));
if ($rs && !$rs->EOF) {
  $bugData = $rs->fetchRow();
} else {
  graph_error('DB Error');
}

$graphData = array();

$graphData[] = $bugData['votes'] / VOTE_SCALE;
$graphData[] = $bugData['avg_score'] / SCORE_SCALE;
$graphData[] = $bugData['avg_repro'] / REPRO_SCALE;
$graphData[] = GRAPH_MAX - $bugData['avg_os'] / OS_SCALE;
$graphData[] = GRAPH_MAX - $bugData['avg_samever'] / VER_SCALE;
$graphData[] = $bugData['avg_tried'] / TRIED_SCALE;

for ($i=0,$j=count($graphData); $i<$j; $i++) {
  if ($graphData[$i] > GRAPH_MAX) {
    $graphData[$i] = GRAPH_MAX;
  } elseif ($graphData[$i] <0) {
    $graphData[$i] = 0;
  }
}

$axesTitles = array( 'Votes', 'Score', 'Repr.', 'Same OS', 'Ver.', 'Tried');

$graph =& new RadarGraph(WIDTH, HEIGHT);
$graph->SetScale('lin', 0, GRAPH_MAX);
$graph->SetTitles($axesTitles);
$graph->yscale->ticks->Set(5, 5);
$graph->axis->SetColor('silver');
$graph->axis->SetLabelFormatCallback('no_format');
$graph->SetFrame(false); 
$graph->ShowMinorTickMarks(2);
$graph->SetCenter(0.5, 0.4);
$graph->SetSize(.60);
$graph->grid->Show();
$graph->grid->SetColor('silver');
$graph->grid->SetLineStyle('dotted');

$r1 =& new RadarPlot($graphData);
$r1->SetLegend("Bug $bug");
$r1->SetColor('red', $bugColors[$bn]);
$r1->SetLineWeight(2);

$graph->Add($r1);
$graph->legend->SetLayout(LEGEND_HOR);
$graph->legend->Pos(0.5, 0.95, "center", "bottom");
$graph->legend->SetLineWeight(0);
$graph->legend->SetShadow(false);
$graph->legend->SetFillColor('white');
$graph->Stroke();

function no_format()
{
  return '';
}

function graph_error($msg) 
{
  $graph =& new CanvasGraph(WIDTH, HEIGHT);    

  $t1 =& new Text($msg);
  $t1->Pos(0.05, 0.5);
  $t1->SetOrientation('h');
  $t1->SetFont(FF_ARIAL, FS_BOLD);
  $t1->SetColor('red');
  $graph->AddText($t1);

  $graph->Stroke();
  exit;
}

function check_passed_bug( $parm )
{
  global $conn;
  
$sql = <<<EOS
SELECT COUNT( 1 ) AS cnt,
  `id`
FROM `bugdb`
WHERE `id` = ?
GROUP BY `id`
EOS;

  if (array_key_exists($parm, $_GET)) {
    $bug_id = (int)$_GET[$parm];
    $rs =& $conn->Execute($sql, array($bug_id));
    if ($rs && !$rs->EOF) {
      $row = $rs->fetchRow();
      if (1 == $row['cnt']) {
        return $row['id'];
      }
    }
  }
  return false;
}

?>
