/**
 * stanard database include file
 *
 * @author	Jason E. Sweat
 * @since	2004-07-06
 * @version	$Id: phpa_db.inc.php,v 1.1 2004/07/06 17:26:09 sweatje Exp $
 */
<?php

require_once('adodb/adodb.inc.php');
define('MYSQL_DT_FMT', '%Y-%m-%d');

$conn =& ADONewConnection('mysql');
$conn->Connect('localhost', 'phpauser', 'phpapass', 'phpa');
$ADODB_FETCH_MODE = ADODB_FETCH_ASSOC;

#?>
