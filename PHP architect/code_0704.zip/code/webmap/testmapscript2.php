<?php

dl( "php_mapscript_42.dll" );

$mapfile = "/pathto/simple.map";
$map     = ms_newMapObj( $mapfile );
$img     = $map->draw();

header( "Content-Type: image/gif" );
$img->saveImage( "" );

?>