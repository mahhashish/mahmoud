<?php

dl( "php_mapscript_42.dll" );
if (!extension_loaded( "MapScript" )) {
	echo "MapScript hasn't been successfully loaded";
	exit();
}

require_once( "query_point.inc" );

$mapfile   = "/pathto/webmapping/glogger.map";
$map       = ms_newMapObj( $mapfile ); // load the mapfile

// hard encoded two points, an extension of this interface
// would be nedded to include forms for managing this
// information.
$locations = array(
	 array( "Place"  => "Paris",
			"Who"    => "John Doe",
			"Note"   => "Lovely place!",
			"Lat"    => 49.3174,
			"Long"   => 1.9929 ),
	 array( "Place"  => "Toronto",
			"Who"    => "Mary Jane",
			"Note"   => "Coolest place!",
			"Lat"    => 44.4299, 
			"Long"   => -79.4663 ) );

$glogger = $map->getLayerByName( "Glogger" );
foreach( $locations as $location ) {
	$shp = ms_newShapeObj( MS_SHAPE_POINT );
	$geom = ms_newLineObj();
	$geom->addXY( $location["Long"], $location["Lat"] );
	$shp->add( $geom );
	$glogger->addFeature( $shp );
}

// the following lines do the processing considering
// the selected action by the user.
$action = $_GET["action"];
if (!empty( $action )) {
	if ($_GET["restart"]!="yes") {
		$click = ms_newPointObj();
		$click->setXY( $_GET["map_x"], $_GET["map_y"] );
		if ($action=="query") {
			$mapext_lst = explode( " ", $_GET["mapext"] );
			$map->extent->setextent( $mapext_lst[0], $mapext_lst[1], $mapext_lst[2], $mapext_lst[3] );
			reset( $locations );
			foreach( $locations as $location ) {
				if (query_point( $map, $location["Long"], $location["Lat"], $click, 5 )) {
					$query_result = "Place: ".$location["Place"].
						          "\\nWho: ".$location["Who"].
					              "\\nNote: ".$location["Note"];
					break;
				}
			}
		}
		else {
			switch ($action ) {
				case "pan_to": $zoom = 1; break;
				case "zoom_in": $zoom = 2; break;
				case "zoom_out": $zoom = -2; break;
			}
			$mapext_lst = explode( " ", $_GET["mapext"] );
			$mapext = ms_newRectObj();
			$mapext->setextent( $mapext_lst[0], $mapext_lst[1], $mapext_lst[2], $mapext_lst[3] );
			$map->zoompoint( $zoom, $click, $map->width, $map->height, $mapext );
		}
	}
}
else
	$action = "zoom_in";

$img        = $map->draw();
$img_url    = $img->saveWebImage();

$sbimg      = $map->drawScaleBar();
$sbimg_url  = $sbimg->saveWebImage();
 
$refimg     = $map->drawReferenceMap();
$refimg_url = $refimg->saveWebImage();

$legimg     = $map->drawLegend();
$legimg_url = $legimg->saveWebImage();

?>
<!doctype html public "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title> Glogger </title>
<script language='javascript'>
	function doRestart() {
		form.restart.value = 'yes';
		form.submit();
	}
	function showQueryResult() {
		<?php
			if (!empty( $query_result ))
				echo "alert( '$query_result' );"
		?>
	}
</script>
</head>
<body onload='showQueryResult()'>
<table>
	<form name='form'>
	<input name='restart' type='hidden' value='no'>
	<input name='mapext' type='hidden' value='<?=$map->extent->minx." ".$map->extent->miny." ".$map->extent->maxx." ".$map->extent->maxy?>'>
	<tr>
		<td rowspan='4'><input name='map' type='image' src='<?=$img_url?>'></td>
		<td><img src='<?=$refimg_url?>'></td>
	</tr>
	<tr>
		<td><B>Legend:</B><BR><img src='<?=$legimg_url?>'></td>
	</tr>
	<tr>
		<td><B>Action:</B><BR>
		    <input name='action' type='radio' value='zoom_in'<?=($action=="zoom_in") ? " checked" : ""?>>Zoom in<BR>
			<input name='action' type='radio' value='zoom_out'<?=($action=="zoom_out") ? " checked" : ""?>>Zoom out<BR>
			<input name='action' type='radio' value='pan_to'<?=($action=="pan_to") ? " checked" : ""?>>Pan to<BR>
			<input name='action' type='radio' value='query'<?=($action=="query") ? " checked" : ""?>>Query</td>
	</tr>
	<tr>
		<td><input name='btRestart' type='button' value='Restart' onclick='doRestart()'></td>
	</tr>
	<tr>
		<td align=center><img src='<?=$sbimg_url?>'></td>
	</form>
</table>
</body>
</html>