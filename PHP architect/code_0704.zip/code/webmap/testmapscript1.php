<?php

dl( "php_mapscript_42.dll" );
if (extension_loaded( "MapScript" )) {
	echo ms_GetVersion();
}
else {
	echo "MapScript hasn't been successfully loaded";
}

?>