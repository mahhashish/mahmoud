<?php

dl( "php_mapscript_42.dll" );

$mapfile   = "/pathto/myworld1.map";
$map       = ms_newMapObj( $mapfile ); // load the mapfile
$img       = $map->draw(); // draw the map

$img_url = $img->saveWebImage(); // save img & get the URL
echo "<IMG SRC='$img_url'>"; // display map with an IMG tag

?>