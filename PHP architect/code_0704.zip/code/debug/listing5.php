<?php

// start watching all of the variables named in the // parameter list 
function dbg_monitor_start(/*...*/) {
         global $dbg_monitor_vars;
         $dbg_monitor_vars = array();
         foreach (func_get_args() AS $key)  $dbg_monitor_vars[$key] = null;

         // start the error handler and tick function
         set_error_handler('dbg_monitor_handler');
         register_tick_function('user_error','',E_USER_ERROR);
}

// stop watching the variables previously defined by // 
dbg_monitor_start() function dbg_monitor_stop() {
         unregister_tick_function('user_error');
         restore_error_handler();
}

// error handler used to watch variables function 
dbg_monitor_handler($no,$str,$file,$line,$context) {
         global $dbg_monitor_vars;

         // prevent tick functions from executing here
         declare(ticks=0) {
                 if ($no === E_USER_ERROR) {

                         // compare all of the defined vars to find 
those  that
                         // have changed
                         foreach ((array)$dbg_monitor_vars AS $key =>
 $value) {
                                 if ($context[$key] !== $value) {
                                         dbg_entry('WA', $file, $line);
                                         dbg_log("$key =  
".dbg_tostring($context[$key]),'  ');
                                         $dbg_monitor_vars[$key] =  
$context[$key];
                                 }
                         }
                 }
         }
}

?>