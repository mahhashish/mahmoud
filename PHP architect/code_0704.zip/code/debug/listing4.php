<?php

register_tick_function('dbg_checkpoint');
declare(ticks=5) {
         // big confusing block of code } 
unregister_tick_function('dbg_checkpoint');

?>