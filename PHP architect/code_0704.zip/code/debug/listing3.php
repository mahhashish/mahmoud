<?php 

function dbg_checkpoint() {
         $trace = debug_backtrace();
         if ($trace[0]['file'])  $trace = $trace[0];
         else  $trace = $trace[1];
         dbg_entry('CP', $trace['file'], $trace['line']); }

?>