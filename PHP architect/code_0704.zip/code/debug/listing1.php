<?php

class MyClass {
     function MyClassMethod($arg1) {
                print_r(debug_backtrace());
         }
}

function MyFunction() {
     MyClass::MyClassMethod(14);
}

MyFunction();

?>