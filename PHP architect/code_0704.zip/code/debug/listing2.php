<?

define(DBG_LOG_FILE, '/var/logs/php_dbg_log'); define(DBG_FILE_PREFIX, $_SERVER['DOCUMENT_ROOT']);

// place a message in the debug log
function dbg_log($log,$indent='') {
     static $fh;

         // if the file hasn't been opened, open it and display a header line
     if ($fh === null) {
         $fh = fopen(DBG_LOG_FILE,'a+');
                 $php_file = dbg_trim_filename($_SERVER['SCRIPT_FILENAME']);
                 $timestamp = date('m/d/Y H:i:s');
         fwrite($fh, "\n--== file=[$php_file] time=[$timestamp] ==--\n");
         }

         // convert the log to a string
         $str = dbg_tostring($log);

         // add indentation
         if ($indent) {
                 $str = $indent.str_replace("\n","\n$indent",$str);
         }

         // display the log entry
         fwrite($fh,"$str\n");
}

// convert an array to a string, scalar values are returned untouched 
function dbg_tostring($ary) {
     if (!is_scalar($ary)) {
                 ob_start();
                 var_export($ary);
                 $ary = ob_get_contents();
                 ob_end_clean();
         }
         return (string)$ary;
}

// remove DBG_FILE_PREFIX from the string function 
dbg_trim_filename($filename) {
         return str_replace(DBG_FILE_PREFIX,'',$filename);
}

// place a line of info in the debug log function dbg_entry($type, 
$file, $line, $indent='') {
         $str = '';
         if ($type)  $str .= "[$type]";
         if ($file)  $str .= "  file=[".dbg_trim_filename($file)."]";
         if ($line)  $str .= "  line=[$line]";
         dbg_log($str,$indent);
}

?>