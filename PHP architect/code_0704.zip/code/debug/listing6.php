<?

dbg_monitor_start('key','value');
declare(ticks=5) {
         // big confusing block of code that
         // modifies $key and $value many times } dbg_monitor_stop();

?>