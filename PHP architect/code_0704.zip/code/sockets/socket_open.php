<?php

fwrite(STDOUT, "What website would you like to see?\n");

$website = trim(fgets(STDIN));
$service_port = 80; // we are using port 80 for standard HTTP requests
$address = gethostbyname($website);

/* Create a TCP/IP socket. */
$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);

$result = socket_connect($socket, $address, 80);
if ($result < 0) {
   echo "socket_connect() failed.\nReason: ($result) " . socket_strerror($result) . "\n";
} else {
   echo "OK.\n";
}

$in = "HEAD / HTTP/1.1\r\n";
$in .= "Host: $website\r\n";
$in .= "Connection: Close\r\n\r\n";
$out = '';

echo "Sending HTTP HEAD request...";
socket_write($socket, $in, strlen($in));
echo "OK.\n";

echo "Reading response:\n\n";
while ($out = socket_read($socket, 2048)) {
   echo $out;
}

echo "Closing socket...";
socket_close($socket);
echo "OK.\n\n";

?>