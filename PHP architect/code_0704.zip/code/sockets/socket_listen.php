<?php

$address = 'localhost';
$port = 10001;

if (($sock = socket_create(AF_INET, SOCK_STREAM, SOL_TCP)) < 0) {
   echo "socket_create() failed: reason: " . socket_strerror($sock) . "\r\n";
}

if (($ret = socket_bind($sock, $address, $port)) < 0) {
   echo "socket_bind() failed: reason: " . socket_strerror($ret) . "\r\n";
}

if (($ret = socket_listen($sock, 5)) < 0) {
   echo "socket_listen() failed: reason: " . socket_strerror($ret) . "\r\n";
}

do {
   if (($msgsock = socket_accept($sock)) < 0) {
       echo "socket_accept() failed: reason: " . socket_strerror($msgsock) . "\r\n";
       break;
   }
   /* Send instructions. */
   $msg = "\nWelcome to the PHP Test Server. \r\n" .
       "To quit, type 'quit'. To shut down the server type 'shutdown'.\r\n";
   socket_write($msgsock, $msg, strlen($msg));

   do {
       if (false === ($buf = socket_read($msgsock, 2048, PHP_NORMAL_READ))) {
           echo "socket_read() failed: reason: " . socket_strerror($ret) . "\r\n";
           break 2;
       }
       if (!$buf = trim($buf)) {
           continue;
       }
       if ($buf == 'quit') {
           break;
       }
       if ($buf == 'shutdown') {
           socket_close($msgsock);
           break 2;
       }
       $talkback = "PHP: You said '$buf'.\r\n";
       socket_write($msgsock, $talkback, strlen($talkback));
       echo "$buf\n";
   } while (true);
   socket_close($msgsock);
} while (true);

socket_close($sock);
?>
