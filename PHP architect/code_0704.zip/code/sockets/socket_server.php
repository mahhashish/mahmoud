<?php

/*--- messaging functions ----*/

/* send a message to a socket */
function send_single($sock, $message)
{
  socket_write($sock, "$message\n");
}

/* send a message to all client sockets */
function send_all($message, $state = STATE_CHATTING) {
  global $s_clients, $cdata;

  foreach ($s_clients as $sock)
  {
    if ($cdata[$sock]['state'] == $state || $state == 0)
    {
        send_single($sock, $message);
    }
  }
}

/* handle incoming data */
function handle_data($sock, $read)
{
    global $cdata, $debugout;

    if ($cdata[$sock]['buf'] != '')
    {
        $read = $cdata[$sock]['buf'] . $read;
    }

    $read = str_replace("\r", '', $read);

    $cdata[$sock]['buf'] = substr(strrchr($read, "\n"), 1);
    $read = substr($read, 0, strpos($read, "\n"));

    if ($cdata[$sock]['state'] == STATE_CLIENTNAME)
    {
        handle_clientname($sock, $read);
    }
    else
    {
        handle_chat($sock, $read);
    }
}

/* handle clientname entry */
function handle_clientname($sock, $client)
{
  global $s_clients, $cdata;

  if (!preg_match('/^[a-zA-Z]{1,10}$/', $client))
  {
    send_single($sock, "That is an invalid name. Please use only letters and numbers:");
    return;
  }

  foreach ($s_clients as $mysock)
  {
    if (strcasecmp($cdata[$mysock]['client'], $client) == 0)
    {
      send_single($sock, "That name is already in use:");
      return;
    }
  }

  $cdata[$sock]['client'] = $client;
  $cdata[$sock]['state'] = STATE_CHATTING;
  on_join($sock);
}


function get_sockname($sock)
{
  global $s_clients, $cdata;
  return $cdata[$sock]['client'];
}

function get_sockbyname($client)
{
  global $s_clients, $cdata;

  foreach ($s_clients as $mysock)
  {
    if (strcasecmp($cdata[$mysock]['client'], $client) == 0)
    {
      return $mysock;
    }
  }
}

/* handle chat text */
function handle_chat($sock, $data) 
{
  global $cdata;

  $client = $cdata[$sock]['client'];

  /* do who command */

  if ($data{0} == ':')
  {

    if ($data == ':who')
    {
      do_who($sock);
      return;
    }

    else
    {

      $to_client = trim(strtok($data, ':'));
      $tosock = get_sockbyname($to_client);
      send_single($tosock, substr($data, (strlen($to_client) + 2)));
      return;

    }

    send_single($sock, "Invalid command.");
    return;
  }

}


/* client has joined */
function on_join($sock) {
  global $cdata;

  $client = $cdata[$sock]['client'];
  $addr = $cdata[$sock]['addr'];
  //send_all("*** Joins: $client ($addr)");
}

/* client has quit */
function on_quit($sock) {
  global $cdata;

  $client = $cdata[$sock]['client'];
  $addr = $cdata[$sock]['addr'];

}

/* who command */
function do_who($sock) {
  global $s_clients, $cdata;

  foreach ($s_clients as $mysock) 
  {
    $state = $cdata[$mysock]['state'];

    if ($state == STATE_CLIENTNAME)
    {
      send_single($sock, sprintf('[clientname] (%s)', $cdata[$mysock]['addr']));
    }
    else
    {
      send_single($sock, sprintf('[connected] %10s (%s)', $cdata[$mysock]['client'], $cdata[$mysock]['addr']));
    }  
  }
}

function send_to($sock, $client, $message)
{
    handle_chat($sock, ':' . $client . ':' . $message);
}


$listen_addr = 'localhost';
$listen_port = 10001;

define('STATE_CLIENTNAME', 1);
define('STATE_CHATTING', 2);

/* assign listening socket */
$s_listen = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);

/* reuse listening socket address */
socket_set_option($s_listen, SOL_SOCKET, SO_REUSEADDR, 1);

/* bind listening socket to specific address/port */
socket_bind($s_listen, $listen_addr, $listen_port);

/* listen on listening socket */
socket_listen($s_listen);

/* set initial vars and loop until $abort is set to true */
$s_clients = Array();
$abort = false;

while (!$abort)
{
  /* sockets we want to pay attention to */
  $set = array_merge((array)$s_listen, (array)$s_clients);

  if (socket_select($set, $set_w = NULL, $set_e = NULL, 0, 10) > 0)
  {
    /* loop through sockets */
    foreach ($set as $sock)
    {
      /* listening socket has a connection, deal with it */
      if ($sock == $s_listen)
      {
          $s_this = socket_accept($s_listen);

          /* add socket to client list and announce connection */
          $s_clients[$s_this] = $s_this;
          socket_getpeername($s_this, $addr);
          $cdata[$s_this]['addr']  = $addr;
          $cdata[$s_this]['buf']   = '';
          $cdata[$s_this]['state'] = STATE_CLIENTNAME;

          send_single($s_this, 'What is your name?:');

      }
      else
      {
        /* client socket has incoming data */
        if (($read = socket_read($sock, 1024)) === false || $read == '')
        {
          //connection was closed, so tell everyone
          on_quit($sock);

          // remove client from arrays 
          unset($s_clients[$sock]);
          unset($cdata[$sock]);
        }
        else
        {
          /* only want data with a newline */
          if(!strpos($read, "\n"))
          {
            $cdata[$sock]['buf'] .= $read;
          }
          else
          {

              $num_newlines = substr_count($read, "\n");

              if($num_newlines > 1)
              {

                  $split_str = explode("\n", $read);

                  for($i = 0; $i < $num_newlines; $i++)
                  {
                      handle_data($sock, $split_str[$i] . "\n");
                  }

              }
              else
              {

                  handle_data($sock, $read);

              }

          }
        }
      }
    }
  }
}

?>