<?php

/* decides if a message part should be displayed inline */
function is_inline($part_name, $part_data)
{
	/* if it contains child parts, it cannot have valid MIME content on its own */
	if (strncmp($part_data['content-type'], 'multipart/', 10) == 0) {
		return false;
	}

	/* if the part explicitly states what to do, listen */
	if (isset($part_data['content-disposition'])) {
		return strcasecmp($part_data['content-disposition'], 'attachment') == 0 ? false : true;
	}

	/* if the part is the first in a sequence, and it is text based,
	 * then we can display it */
	if ((substr($part_name, -2) == '.1' || $part_name == '1') && strncmp($part_data['content-type'], 'text/', 5) == 0) {
		return true;	
	}

	return false;
}
	
?>
