<?php

include './common.php';
	
$filename = 'figure5.txt';

/* We're pretending that we're reading the message directly from a socket here.
 * Rember that mailparse needs one pass to parse the message, and then needs to
 * be able to seek to fetch the content that you request.
 * This is the use as little RAM as possible version; we spool the content into
 * a temporary file instead of storing it into a string.  You could view this
 * as a hybrid of figure9 and figure10
 */

/* first, open the file; we will pretend that this handle is really a socket
 * stream */
$socket = fopen($filename, 'rb');

/* We're going to store the content in a file as we go.
 * Note that you can also use tmpfile() and pass the stream handle to
 * mailparse_msg_extract_part_file() instead of the filename.
 * You may use any stream in this fashion, provided that it is a seekable stream.
 */
$tmp_file_name = tempnam('/tmp', 'mp');
$tmpfile = fopen($tmp_file_name, 'wb');

/* create a message resource to parse into */
$message = mailparse_msg_create();

/* now stream the content through */
do {
	$x = fread($socket, 8192);
	if (!strlen($x))
		break;
	fwrite($tmpfile, $x);
	mailparse_msg_parse($message, $x);
} while (true);

/* close the socket */
fclose($socket);

/* close temporary file */
fclose($tmpfile);

/* now $message holds the parsed state, and the file named $tmp_file_name holds the entire message.
 * From this point, the code is identical to figure9.php, except for the name of the source file. */

// foreach message part
foreach (mailparse_msg_get_structure($message) as $part_name) {
	// get a handle on that part
	$part = mailparse_msg_get_part($message, $part_name);

	// get the data for that part
	$data = mailparse_msg_get_part_data($part);
	
	// let's assume that we want to render only non attachments for a webmail application.
	if (is_inline($part_name, $data)) {
		echo "Part: $part_name is not an attachment\n\n";

		/* now we need to extract the body content for that message part.
		 * Since we're in a web mail application, we want to quote the contents so we
		 * don't mess with the rest of the HTML there (remember: DONT TRUST MAIL!).
		 * If you wanted to do a really good job, this is where you would screen
		 * text/html content and make it safe.  I'm just going to splat it out
		 * with the entities quoted, so it will show up as the HTML source. */

		 /* This is the "no-brainer" way to do it; you should be familiar with
		  * this trick.  You can instead name a callback function as the third
		  * parameter and receive the content in chunks; harder to manage, but
		  * uses less resources overall */
		 ob_start();
		 /* this next line is different from figure9.php */
		 mailparse_msg_extract_part_file($part, $tmp_file_name);
		 $contents = ob_get_contents();
		 ob_end_clean();
		 echo nl2br(htmlentities($contents)) . "\n\n";
	} else {
		echo "Part: $part_name is an attachment or other data; skipping\n";
	}
}

/* remove the temporary file */
unlink($tmp_file_name);

echo "\nDone\n";

?>
