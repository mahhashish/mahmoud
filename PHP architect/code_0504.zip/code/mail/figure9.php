<?php

include './common.php';
	
$filename = 'figure5.txt';

// Parse the message from a named file and return a resource
$message = mailparse_msg_parse_file($filename);

// foreach message part
foreach (mailparse_msg_get_structure($message) as $part_name) {
	// get a handle on that part
	$part = mailparse_msg_get_part($message, $part_name);

	// get the data for that part
	$data = mailparse_msg_get_part_data($part);
	
	// let's assume that we want to render only non attachments for a webmail application.
	if (is_inline($part_name, $data)) {
		echo "Part: $part_name is not an attachment\n\n";

		/* now we need to extract the body content for that message part.
		 * Since we're in a web mail application, we want to quote the contents so we
		 * don't mess with the rest of the HTML there (remember: DONT TRUST MAIL!).
		 * If you wanted to do a really good job, this is where you would screen
		 * text/html content and make it safe.  I'm just going to splat it out
		 * with the entities quoted, so it will show up as the HTML source. */

		 /* This is the "no-brainer" way to do it; you should be familiar with
		  * this trick.  You can instead name a callback function as the third
		  * parameter and receive the content in chunks; harder to manage, but
		  * uses less resources overall */
		 ob_start();
		 mailparse_msg_extract_part_file($part, $filename);
		 $contents = ob_get_contents();
		 ob_end_clean();
		 echo nl2br(htmlentities($contents)) . "\n\n";
	} else {
		echo "Part: $part_name is an attachment or other data; skipping\n";
	}
}

echo "\nDone\n";

?>
