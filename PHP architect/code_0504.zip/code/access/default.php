<? error_reporting(E_ALL);
$mysqlconnection=mysql_connect('localhost','username','password');
$database='phpa';
$cssfile=(!isset($_GET['printable'])?'primary.css':'printable.css');

	if(!mysql_select_db($database)) {
	include_once 'InitializeDatabase.php';
	new InitializeDatabase($database);
	}

$pageid=(isset($_GET['pageid'])?$_GET['pageid']:'default');
if(!get_magic_quotes_gpc()) $pageid=mysql_escape_string($pageid);
$sql="select title, body, replace(keywords, '\"', '&quot;') as keywords, replace(description, '\"', '&quot;') as description from pagecontent where pageid='$pageid'";
$res=mysql_query($sql);
$pagecontent=mysql_fetch_assoc($res);
mysql_free_result($res);

if(!$pagecontent) {
header ('HTTP/1.0 404 Not Found');
$pagecontent['title']='404 Not Found';
$pagecontent['body']='We are sorry, this page cannot be found.';
$metatags=array();
} else {
foreach(array('keywords','description') as $metaname) $metatags[$metaname]=$pagecontent[$metaname];
}

include_once 'ContainerTags.php';
$ContainerTags=new ContainerTags();
echo $ContainerTags->PageHeader($pagecontent['title'], $cssfile, $metatags);
register_shutdown_function(array(&$ContainerTags, 'ShutdownFooter'));

$bodycontent=$ContainerTags->HeaderContainer($pagecontent['title']);
$paragraphs=explode("\r\n\r\n",$pagecontent['body']);
foreach($paragraphs as $paragraph) $bodycontent.=$ContainerTags->ParagraphContainer(nl2br($paragraph));
echo $ContainerTags->GenericContainer($bodycontent, 'bodycontent');

echo $ContainerTags->ShowNavigation();

$adcontent=file_get_contents('http://dynamicink.com/ad');
echo $ContainerTags->GenericContainer($adcontent, 'adcontent');

echo $ContainerTags->GenericContainer('<img src="header.png" alt="Accessible Code" />', 'headerimage');

include_once 'footer.php';
echo $ContainerTags->GenericContainer($footerlinks, 'footerlinks');

mysql_close($mysqlconnection);
?>