<?
$footerlinks='<a href="#top" title="Scroll To Top" accesskey="S" tabindex="'.$ContainerTags->tabindex++.'">Scroll To Top</a> | <a href="'.$_SERVER['PHP_SELF'].'?printable=1&amp;pageid='.urlencode(stripslashes($pageid)).'" title="Printable Version" accesskey="P" tabindex="'.$ContainerTags->tabindex++.'">Printable Version</a>';

$links=array('default'=>'Home','accessibility'=>'Accessibility','privacy'=>'Privacy Policy','contact'=>'Contact Us');

foreach($links as $linkpageid=>$linktitle) $footerlinks.=' | <a href="'.$_SERVER['PHP_SELF'].'?pageid='.$linkpageid.'" title="'.$linktitle.'" accesskey="'.substr($linktitle, 0, 1).'" tabindex="'.$ContainerTags->tabindex++.'">'.$linktitle.'</a>';
?>