<?
class InitializeDatabase {

	function InitializeDatabase($database) {
	$sql='create database '.$database;
	mysql_query($sql);
	mysql_select_db($database);
	
	$sql='create table pagecontent (
	pageid varchar(20) not null primary key,
	title varchar(255) not null,
	body text not null,
	description text null,
	keywords text null
	)';
	mysql_query($sql);
	
	$sql="insert into pagecontent (pageid, title, body, description, keywords) values ('default','Default page','This is placeholder text on the default index page and should be changed.','Placeholder for the description','accessibility, XHTML, Section 508, WAI')";
	mysql_query($sql);
	}

}
?>