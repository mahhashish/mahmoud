<?
class ContainerTags {

	var $PageHeaderFired=0;
	var $PageFooterFired=0;
	var $tabindex=1;

	/* private */ function BasicContainer($tag, $content, $class, $id) {
	$return='<'.$tag;
	if(!empty($class)) $return.=' class="'.$class.'"';
	if(!empty($id)) $return.=' id="'.$id.'"';
	$return.='>'.$content.'</'.$tag.'>';
	return $return;
	}

	function HeaderContainer($content, $class='', $id='', $headerlevel='1') {
	return $this->BasicContainer('h'.$headerlevel, $content, $class, $id);
	}
		
	function ParagraphContainer($content, $class='', $id='') {
	return $this->BasicContainer('p', $content, $class, $id);
	}
	
	function FormContainer($content, $class='', $id='', $legend='') {
	if(!empty($legend)) $content='<legend>'.$legend.'</legend>'.$content;
	return $this->BasicContainer('fieldset', $content, $class, $id);
	}

	function GenericContainer($content, $class='', $id='') {
	return $this->BasicContainer('div', $content, $class, $id);
	}
	
	function PageHeader($title='', $css='', $metatags=array()) {
	$return='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<title>'.$title.'</title>';
	
	if(!empty($css)) $return.='<link rel="stylesheet" type="text/css" href="'.$css.'" />';
	
	$return.='<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />';

	foreach($metatags as $metaname=>$metavalue) if(!empty($metavalue)) $return.='<meta name="'.$metaname.'" content="'.$metavalue.'" />';
	
	$return.='</head><body>';
	$return.=$this->GenericContainer('<a id="top"></a><a href="#navigation" title="Skip to navigation" id="skiptonav" accesskey="S" tabindex="'.$this->tabindex++.'"></a>');

		if($this->PageHeaderFired) {
		$return='<!-- ContainerTags::PageHeader should only be called once per page -->';
		} else {
		$this->PageHeaderFired=1;
		}
		
	return $return;
	}
	
	function PageFooter() {
		if($this->PageFooterFired) {
		$return='<!-- ContainerTags::PageFooter should only be called once per page -->';
		} else {
		$this->PageFooterFired=1;
		$return='</body></html>';
		}
	return $return;
	}
	
	function ShutdownFooter() {
	echo $this->PageFooter();
	}
	
	function ShowNavigation() {
	$return=$this->GenericContainer('<a id="navigation"></a><a href="#top" title="Skip to body content" id="skiptobody" accesskey="S" tabindex="'.$this->tabindex++.'"></a>');

	$sql="select pageid, replace(title, '\"', '&quot;') as title from pagecontent order by title";
	$res=mysql_query($sql);
	while($row=mysql_fetch_assoc($res)) $return.=$this->GenericContainer('- <a href="'.$_SERVER['PHP_SELF'].'?pageid='.urlencode($row['pageid']).'" title="'.$row['title'].'" accesskey="'.substr($row['title'], 0, 1).'" tabindex="'.$this->tabindex++.'">'.$row['title'].'</a>');
	mysql_free_result($res);
	return $this->GenericContainer($return, 'navigation');
	}
	
}
?>