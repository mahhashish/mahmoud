<?php

// Creates a list of all the pages
// that are present in a document

function pdf_read_pages (&$c, &$pages, &$result)
{
	// Get the kids dictionary
	
	$kids = pdf_resolve_object ($c, $pages[1][1]['/Kids']);
	
	foreach ($kids[1] as $v) {
		$pg = pdf_resolve_object ($c, $v);

		if ($v[1][1]['/Type'] === 'Pages') {
			
			// If one of the kids is an embedded
			// /Pages array, resolve it as well.
			
			pdf_read_pages ($c, $v, $result);
		} else {
			$result[] = $pg;
		}
	}
}

?>