<?php

/*
 * Writes an immediate object to the
 * output stream
 */

function pdf_write_value ($f, &$value)
{
	switch ($value[0]) {
		
		case	PDF_TYPE_NUMERIC	:
		case	PDF_TYPE_TOKEN		:

			// A numeric value or a token.
			// Simply output them
		
			fwrite ($f, $value[1]);
			break;
			
		case	PDF_TYPE_ARRAY		:
		
			// An array. Output the proper
			// structure and move on.
			
			fwrite ($f, "[");
			
			for ($i = 0; $i < count ($value[1]); $i++) {
				pdf_write_value ($f, $value[1][$i]);
				fwrite ($f, ' ');	
			}
			
			fwrite ($f, "]");
			break;
			
		case	PDF_TYPE_DICTIONARY	:
		
			// A dictionary. For the sake
			// of clarity, here we output
			// a newline in a few strategic
			// places. This is completely
			// optional, as you don't need any
			// delimiter between <</>> and the
			// next token.
		
			fwrite ($f, "<<\n");
			
			reset ($value[1]);
			
			while (list ($k, $v) = each ($value[1])) {
				fwrite ($f, $k . " ");
				pdf_write_value ($f, $v);
				fwrite ($f, "\n"); 	
			}
			
			fwrite ($f, ">>");
			break;
			
		case	PDF_TYPE_OBJREF :
		
			// An indirect object reference
		
			fwrite ($f, "{$value[1]} {$value[2]} R");
			break;
			
		case	PDF_TYPE_STRING :
		
			// A string. A bit of escaping (for
			// backslashes and parentheses) is 
			// required.
			
			fwrite ($f, '(' . str_replace ('\\', '\\\\', str_replace ('(', '\\(', str_replace (')', '\\)', $value[1]))) . ')');
			break;

		case	PDF_TYPE_STREAM :
		
			// A stream. First, output the
			// stream dictionary, then the 
			// stream data itself.
		
			pdf_write_value ($f, $value['dict']);
			fwrite ($f, "\nstream\n");
			fwrite ($f, $value['stream']);
			fwrite ($f, "\nendstream");
			break;
			
		case	PDF_TYPE_NULL 	:
		
			// The null object.
		
			fwrite ($f, "null");
			break;
	}
}

/*
 * Writes a series of objects to
 * the output stream
 */

function pdf_write_objects ($f, &$values)
{
	// Simply cycle through the object list,
	// output an indirect object marker, the
	// object data itself and an end-of-object
	// marker.
	
	for ($i = 0; $i < count ($values); $i++) {

		$obj = &$values[$i];
		$obj['pos'] = ftell ($f);
		
		fwrite ($f, "{$obj['obj']} {$obj['gen']} obj\r\n");
		
		pdf_write_value ($f, $obj[1]);
		
		fwrite ($f, "\nendobj\n");
		
	}
}

/*
 * Writes a new cross-reference table.
 */

function pdf_write_xref ($f, &$delta, &$root, $max_object) 
{
	global $xref_data;
	
	// Mark the current position, so that we
	// can insert in the trailer.
	
	$xref_pos = ftell ($f);
	
	echo $xref_pos;
	
	// Output the cross-reference table
	// by cycling through all the objects
	// and outputting their position.
	
	fwrite ($f, "xref\r\n");

	for ($i = 0; $i < count ($delta); $i++) {

		fwrite ($f, "{$delta[$i]['obj']} 1\r\n");
		fwrite ($f, str_pad ($delta[$i]['pos'], 10, '0', STR_PAD_LEFT) . ' ' . str_pad ($delta[$i]['gen'], 5, '0', STR_PAD_LEFT) . " n\r\n");
	}
	
	// Output the trailer. At a minimum,
	// this should contain a pointer to the
	// Root object, an object count and a
	// pointer to the previous xref table,
	// if present.
	
	fwrite ($f, "trailer\r\n");
	
	$trailer = array (
		PDF_TYPE_DICTIONARY,
		array (
			'/Size' => array (
				PDF_TYPE_NUMERIC,
				$max_object
			),
			'/Root' => array (
				PDF_TYPE_OBJREF,
				$root['obj'],
				$root['gen']
			),
			'/Prev' => array (
				PDF_TYPE_NUMERIC,
				$xref_data['xref_location']
			)
		)
	);
	pdf_write_value ($f, $trailer);
	
	fwrite ($f, "\nstartxref\n{$xref_pos}\n%%EOF\n");
}

?>