<?php

/*
 * Resolves an object reference,
 * ensuring that the result value
 * is always a direct object
 */

function pdf_resolve_object (&$c, $obj_spec, $encapsulate = true)
{
	global $xref_data;
	
	// Exit if we get invalid data
	
	if (!is_array ($obj_spec)) {
		return false;
	}
	
	if ($obj_spec[0] == PDF_TYPE_OBJREF) {
		
		// This is a reference, resolve it
		
		if (isset ($xref_data['xref'][$obj_spec[1]][$obj_spec[2]])) {
			
			// Save current file position
			// This is needed if you want to resolve
			// references while you're reading another object
			// (e.g.: if you need to determine the length
			// of a stream)
			
			$old_pos = ftell ($c->file);
			
			// Reposition the file pointer and
			// load the object header.
			
			$c->reset ($xref_data['xref'][$obj_spec[1]][$obj_spec[2]]);
			$header = pdf_read_value ($c);
			
			if ($header[0] != PDF_TYPE_OBJDEC || $header[1] != $obj_spec[1] || $header[2] != $obj_spec[2]) {
				die ("Unable to find object ({$obj_spec[1]}, {$obj_spec[2]}) at expected location");
			}
			
			// If we're being asked to store all the information
			// about the object, we add the object ID and generation
			// number for later use
			
			if ($encapsulate) {
				$result = array (
					PDF_TYPE_OBJECT,
					'obj' => $obj_spec[1],
					'gen' => $obj_spec[2]
				);
			} else {
				$result = array();
			}
			
			// Now simply read the object data until
			// we encounter an end-of-object marker
			
			while(1) {
				$value = pdf_read_value ($c);
				
				if ($value === false) {
					return false;
				}
				
				if ($value[0] == PDF_TYPE_TOKEN && $value[1] === 'endobj') {
					break;
				}
				
				$result[] = $value;
			}
			
			$c->reset ($old_pos);
			
			return $result;			
		}	
	} else {
		return $obj_spec;
	}
}

/*
 * Generates a new object container
 * with the proper object ID and
 * a generation number of zero
 */

function pdf_new_object()
{
	global $xref_data;
	
	return array (
		PDF_TYPE_OBJECT,
		'obj' => $xref_data['max_object']++,
		'gen' => 0
	);
}

?>