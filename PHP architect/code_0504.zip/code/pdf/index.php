<?php

// Include relevant files

include "findxref.php";
include "readxref.php";
include "tokenizer.php";
include "readvalue.php";
include "objects.php";
include "readpages.php";
include "page.php";
include "writer.php";

// Input and output file names

$input_file = "editorial.pdf";
$output_file = "out.pdf";

// Rotation, expressed in degrees

$rotation = 45;

// x and y coordinates, expressed
// in the PDF document's coordinate system

$x = 100;
$y = 100;

// Font size, in points

$size = 10;

// The text to be displayed

$text = "This is a test!";

// Open the input file

$f = fopen ($input_file, "r");

$xref_data = array();

// Read the xref table

pdf_read_xref ($f, $xref_data, pdf_find_xref($f));

// Create a new context we can work with

$c = new pdf_context ($f);

// Read the root object

$root = pdf_resolve_object($c, $xref_data['trailer'][1]['/Root']);

// Find the pages array

$pages = array();

pdf_read_pages ($c, pdf_resolve_object($c, $root[1][1]['/Pages']), $pages);

// Use page 1

$page = $pages[0];

// Find resource object for this page
// Or create a new one if needed

$resources = pdf_find_resources($c, $page);

if ($resources === false) {
	$resources = pdf_new_object();
	$resources[1][0] = PDF_TYPE_DICTIONARY;
}

// Find font resources

if (isset ($resources[1][1]['/Font'])) {
	$font_resources = pdf_resolve_object ($c, $resources[1][1]['/Font']);
} else {
	$font_resources = pdf_new_object();
	$resources[1][] = array (
		PDF_TYPE_OBJREF,
		$font_resources['obj'],
		$font_resources['gen'],
		array()
	);
}

// Find the highest font resource
// used with the "F" prefix

$max_font = 0;

foreach ($font_resources[1][1] as $k => $v) {
	preg_match ('#/(\w+)(\d+)#', $k, $matches);

	if ($matches[1] == 'F') {
		$max_font = max ($max_font, (int) $matches[2]);
	}
}

$max_font++;	// Increment so that we can create a new one

// Create font resource
// Use Helvetica embedded font

$font = pdf_new_object();

$font[1][0] = PDF_TYPE_DICTIONARY;
$font[1][1] = array (
	'/Type' => array (
		PDF_TYPE_TOKEN,
		'/Font'
	),
	'/Subtype' => array (
		PDF_TYPE_TOKEN,
		'/Type1'
	),
	'/BaseFont' => array (
		PDF_TYPE_TOKEN,
		'/Helvetica'
	)
);

// Assign font to resources

$font_resources[1][1]['/F' . $max_font] = array (PDF_TYPE_OBJREF, $font['obj'], $font['gen']);

// Create stream

// Calculate the interline spacing
// for the current font.
// Note: this is arbitrary, but usually
//       works for western fonts

$interline = $size / 2;

// Determine the appropriate
// tranformation values for
// rotating the text

$ma = cos (deg2rad($rotation));
$mb = sin (deg2rad($rotation));
$mc = -$mb;
$md = $ma; 

// Create a string with the text
// data

$text_data = "(" . str_replace ("\n", ") '\nT*\n(", str_replace ('(', '\\(', str_replace (')', '\\)', $text))) . ") '";

// Create the stream itself

$stream_commands = <<<EOT
BT
	/F{$max_font} $size Tf
	$ma $mb $mc $md $x $y Tm
	$interline TL
	$text_data
ET
EOT;

$stream = pdf_new_object();
$stream[1][0] = PDF_TYPE_STREAM;
$stream[1]['stream'] = $stream_commands;
$stream[1]['dict'] = array (
	PDF_TYPE_DICTIONARY,
	array (
		'/Length' => array (
			PDF_TYPE_NUMERIC,
			strlen ($stream_commands)
		)
	)
);

// Add stream to page contents

if (!isset ($page[1][1]['/Contents'])) {
	// If the page has no contents, we create new ones
	
	$contents = array (
		PDF_TYPE_ARRAY,
		array(),
	);
	$page[1][1]['/Contents'] = &$contents;
} else {
	if ($page[1][1]['/Contents'][0] == PDF_TYPE_OBJREF) {
		
		// If the page has a single content object, we
		// turn it into an array so that we can add our
		// own
		
		$contents = array (
			PDF_TYPE_ARRAY,
			array($page[1][1]['/Contents'])
		);
		$page[1][1]['/Contents'] = &$contents;
	} else {
		
		// If the page has a content array, we
		// simply piggyback on it!
		
		$contents = &$page[1][1]['/Contents'];
	}
}

// Write our content entry

$contents[1][] = array (
	PDF_TYPE_OBJREF,
	$stream['obj'],
	$stream['gen']
);

// Open output file

copy ($input_file, $output_file);
$out_file = fopen ($output_file, 'a');
fseek ($out_file, 0, SEEK_END);

// Write new objects to the file

$delta = array (
	&$resources,
	&$page,
	&$font_resources,
	&$font,
	&$stream
);

pdf_write_objects($out_file, $delta);

// Write new xref table and trailer

pdf_write_xref ($out_file, $delta, $root, $xref_data['max_object']);

// Close output file

fclose ($out_file);

// All done!

?>