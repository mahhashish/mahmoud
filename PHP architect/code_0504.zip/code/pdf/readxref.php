<?php

/*
 * Reads a cross-reference table
 *
 * if $offset is provided and $start and $end are
 * set to Null, the function will start reading the
 * xref table from the current position in the file.
 * If more than one parts of xref table are present,
 * the function will recurse onto itself as many times
 * as needed.
 */

function pdf_read_xref ($f, &$result, $offset, $start = null, $end = null)
{
	// If we didn't get a start and end, we need
	// to get them from the document itself.
	
	if (is_null ($start) || is_null ($end)) {
		
		// Move to the start of the table
		
		fseek ($f, $offset);
		
		// Make sure that PHP keeps track of
		// the line endings properly
		
		$old_ini = ini_get ('auto_detect_line_endings');
		
		// Get a line of text from the file
		
		$data = trim (fgets ($f));
		
		// Make sure the xref marker is where we
		// expect it.
		
		if ($data !== 'xref') {
			die ("Unable to find xref table");
		}
		
		// Now get the next line and split
		// it across a single space character
		
		$data = explode (' ', trim (fgets ($f)));
		
		// Make sure the format is what we expected
		
		if (count ($data) != 2) {
			die ("Unexpected header in xref table");
		}
		
		// Calculate the start and end object
		// in the xref table
		
		$start = $data[0];
		$end = $start + $data[1];
	}
	
	if (!isset ($result['xref_location'])) {
		$result['xref_location'] = $offset;
	}
	
	if (!isset ($result['max_object']) || $end > $result['max_object']) {
		$result['max_object'] = $end;
	}
		
	// Now cycle through each object
	// pointer
	
	for (; $start < $end; $start++) {

		// Get a line of text from the
		// file and extract the proper
		// information out of there
		
		$data = trim (fgets ($f));
		
		$offset = substr ($data, 0, 10);
		$generation = substr ($data, 11, 5);
		
		if (!isset ($result['xref'][$start][(int) $generation])) {
			$result['xref'][$start][(int) $generation] = (int) $offset; 
		}
	}
	
	// Get the next line, which could either be the beginning
	// of the trailer dictionary or the header of another
	// xref section
	
	$data = trim (fgets ($f));
	
	if ($data === 'trailer') {

		// Read trailer dictionary

		$c =  new pdf_context ($f);
		$trailer = pdf_read_value ($c);
		
		// Check whether there is a /Prev
		// entry, which indicates that there
		// is another xref table from before
		
		if (isset ($trailer['/Prev'])) {
			pdf_read_xref ($f, $result, $trailer['/Prev']);
			$result['trailer'] = array_merge ($result['trailer'], $trailer);
		} else {
			$result['trailer'] = $trailer;
		}

	} else {
		
		// We have another xref segment
		// to read. Extract the start
		// and length, and recurse into
		// this function

		$data = explode (' ', $data);
		pdf_read_xref ($f, $result, null, $data[0], $data[0] + $data[1]);

	}
}

?>