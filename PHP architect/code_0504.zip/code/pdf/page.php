<?php

/*
 * Finds the resources associated with a page
 */

function pdf_find_resources (&$c, $obj)
{
	$obj = pdf_resolve_object($c, $obj);
	
	// If the current object has a resources
	// dictionary associated with it, we use
	// it. Otherwise, we move back to its
	// parent object.
	
	if (isset ($obj[1][1]['/Resources'])) {
		return pdf_resolve_object ($c, $obj[1][1]['/Resources']);
	} else {
		if (!isset ($obj[1][1]['/Parent'])) {
			return false;
		} else {
			return pdf_find_resources ($obj[1][1]['/Parent']);
		}
	}
}

?>