<?php

// Define various data types
// that we use throughout the system

define ('PDF_TYPE_NULL', 0);
define ('PDF_TYPE_NUMERIC', 1);
define ('PDF_TYPE_TOKEN', 2);
define ('PDF_TYPE_HEX', 3);
define ('PDF_TYPE_STRING', 4);
define ('PDF_TYPE_DICTIONARY', 5);
define ('PDF_TYPE_ARRAY', 6);
define ('PDF_TYPE_OBJDEC', 7);
define ('PDF_TYPE_OBJREF', 8);
define ('PDF_TYPE_OBJECT', 9);
define ('PDF_TYPE_STREAM', 10);

/*
 * Reads a value from the current
 * data stream
 */

function pdf_read_value (&$c, $token = null)
{
	// Get a token from the stream.
	
	if (is_null ($token)) {
		$token = pdf_read_token ($c);
	}
	
	if ($token === false) {
		return false;
	}
	
	switch ($token) {

		case	'<'		:

			// This is a hex string.
			// Read the value, then the terminator
		
			$s = pdf_read_token ($c);
			
			if ($s === false) {
				return false;
			}
			
			$term = pdf_read_token ($c);
			
			if ($term !== '>') {
				die ("Unexpected data after hex string");
			}
			
			return array (PDF_TYPE_HEX, $s);
		
			break;
			
		case	'<<'	:
		
			// This is a dictionary.
		
			$result = array();
		
			// Recurse into this function until we reach
			// the end of the dictionary.
			
			while (($key = pdf_read_token ($c)) !== '>>') {
				if ($key === false) {
					return false;
				}
				
				if (($value = pdf_read_value ($c)) === false) {
					return false;
				}
				
				$result[$key] = $value;
			}

			return array (PDF_TYPE_DICTIONARY, $result);
			
		case	'['		:
		
			// This is an array.
		
			$result = array();

			// Recurse into this function until we reach
			// the end of the array.

			while (($token = pdf_read_token ($c)) !== ']') {
				if ($token === false) {
					return false;
				}
				
				if (($value = pdf_read_value ($c, $token)) === false) {
					return false;
				}
				
				$result[] = $value;
			}
			
			return array (PDF_TYPE_ARRAY, $result);
			
		case	'('		:
		
			// This is a string
		
			$pos = $c->offset;
			
			while(1) {
				
				// Start by finding the next closed
				// parenthesis
				
				$pos = strpos ($c->buffer, ')', $pos);
				
				// If you can't find it, try
				// reading more data from the stream
				
				if ($pos == -1) {
					if (!$c->increase_length()) {
						return false;
					}
				}
				
				// Make sure that there is no backslash
				// before the parenthesis. If there is,
				// move on. Otherwise, return the string.
				
				if ($c->buffer[$pos - 1] !== '\\') {
					$result = substr ($c->buffer, $c->offset, $pos - $c->offset + 1);
					$c->offset = $pos + 1;
					return array (PDF_TYPE_STRING, $result);
				} else {
					$pos++;
					
					if ($pos > $c->offset + $c->length) {
						$c->increase_length();
					}
				}
			}
						
		default	:
		
			if (is_numeric ($token)) {
				
				// A numeric token. Make sure that
				// it is not part of something else.
				
				if (($tok2 = pdf_read_token ($c)) !== false) {
					if (is_numeric ($tok2)) {
						
						// Two numeric tokens in a row.
						// In this case, we're probably in
						// front of either an object reference
						// or an object specification.
						// Determine the case and return the data
						
						if (($tok3 = pdf_read_token ($c)) !== false) {
							switch ($tok3) {
							
								case	'obj'	:
								
									return array (PDF_TYPE_OBJDEC, (int) $token, (int) $tok2);
									
								case	'R'		:
								
									return array (PDF_TYPE_OBJREF, (int) $token, (int) $tok2);
							}
							
							// If we get to this point, that numeric value up
							// there was just a numeric value. Push the extra
							// tokens back into the stack and return the value.
							
							array_push ($c->stack, $tok3);
						}
					}
						
					array_push ($c->stack, $tok2);
				}				
				
				return array (PDF_TYPE_NUMERIC, $token);
			} else {
				// Just a token. Return it.
				
				return array (PDF_TYPE_TOKEN, $token);
			}
		
	}
}

?>