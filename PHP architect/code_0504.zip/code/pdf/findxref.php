<?php

/*
 * Returns the offset of the most recent
 * cross-reference table in the file
 */

function pdf_find_xref ($f)
{
	// First, seek to the end of the file,
	// allowing for 50 bytes just so that
	// we have enough data to look into.
	
	fseek ($f, -50, SEEK_END);
	
	// Next, try to find the proper sequence
	// of data. Note that the information can be 
	// separated by a Windows-style, Mac-style
	// or Unix-style newline
	
	$data = fread ($f, 50);
	
	if (!preg_match ('/startxref(?:\r|\n|\r\n)(\d+)(?:\r|\n|\r\n)%%EOF(?:\r|\n|\r\n)$/', $data, $matches)) {
		die ("Unable to find pointer to xref table");
	}
	
	// If we get here, then we have the offset
	// where the most recently introduced xref
	// table is.
	
	return (int) $matches[1];
}

?>