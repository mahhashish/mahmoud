<?php

/*
 * This class is used to 
 * read data from the input
 * file in a bufferized way
 * and to store unused tokens
 */

class pdf_context
{
	var $file;
	var $buffer;
	var $offset;
	var $length;
	
	var $stack;

	// Constructor
	
	function pdf_context ($f)
	{
		$this->file = $f;
		$this->reset();
	}

	// Optionally move the file
	// pointer to a new location
	// and reset the buffered data 
	
	function reset($pos = null)
	{
		if (!is_null ($pos)) {
			fseek ($this->file, $pos);
		}
				
		$this->buffer = fread ($this->file, 100);
		$this->offset = 0;
		$this->length = strlen ($this->buffer);
		$this->stack = array();
	}
	
	// Make sure that there is at least one
	// character beyond the current offset in
	// the buffer to prevent the tokenizer
	// from attempting to access data that does
	// not exist
	
	function ensure_content()
	{
		if ($this->offset >= $this->length - 1) {
			return $this->increase_length();
		} else {
			return true;
		}
	}
	
	// Forcefully read more data into the buffer
	
	function increase_length()
	{
		if (feof ($this->file)) {
			return false;
		} else {
			$this->buffer .= fread ($this->file, 100);
			$this->length = strlen ($this->buffer);
			return true;
		}
	}
}
	
/*
 * Reads a token from the file
 */

function pdf_read_token (&$c)
{
	// If there is a token available
	// on the stack, pop it out and
	// return it.
	
	if (count ($c->stack)) {
		return array_pop($c->stack);
	}
	
	// Strip away any whitespace
	
	do {
		if (!$c->ensure_content()) {
			return false;
		}
		$c->offset += strspn ($c->buffer, " \n\r", $c->offset);
	} while ($c->offset >= $c->length - 1);
		
	// Get the first character in the stream
	
	$char = $c->buffer[$c->offset++];
	
	switch ($char) {

		case '['	:
		case ']'	:
		case '('	:
		case ')'	:
		
			// This is either an array or literal string
			// delimiter, Return it
		
			return $char;
		
		case '<'	:
		case '>'	:
		
			// This could either be a hex string or 
			// dictionary delimiter. Determine the
			// appropriate case and return the token
			
			if ($c->buffer[$c->offset] == $char) {
				if (!$c->ensure_content()) {
					return false;
				}
				$c->offset++;
				return $char . $char;	
			} else {
				return $char;
			}

		default		:
		
			// This is "another" type of token (probably
			// a dictionary entry or a numeric value)
			// Find the end and return it.
		
			if (!$c->ensure_content()) {
				return false;
			}
			
			while(1) {
				
				// Determine the length of the token
				
				$pos = strcspn ($c->buffer, " []<>()\r\n/", $c->offset);
				
				if ($c->offset + $pos < $c->length - 1) {
					break;
				} else {
					// If the script reaches this point,
					// the token may span beyond the end
					// of the current buffer. Therefore,
					// we increase the size of the buffer
					// and try again--just to be safe.
					
					$c->increase_length();
				} 
			}
			
			$result = substr ($c->buffer, $c->offset - 1, $pos + 1);
			
			$c->offset += $pos;
			return $result;
	}
}

?>