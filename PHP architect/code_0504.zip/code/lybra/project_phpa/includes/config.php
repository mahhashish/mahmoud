<?
	$this->parameters["tableDbtype"]="mysql";  
	$this->parameters["tableDbname"]="lybra_core_db";  
	$this->parameters["tableServer"]="localhost";  
	$this->parameters["tablePort"]="";  
	$this->parameters["tableUser"]="root";  
	$this->parameters["tablePassword"]=""; 
?>
