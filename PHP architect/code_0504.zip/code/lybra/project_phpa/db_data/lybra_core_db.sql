-- MySQL dump 9.10
--
-- Host: localhost    Database: lybra_core_db
-- ------------------------------------------------------
-- Server version	4.0.18'-Max'

--
-- Current Database: lybra_core_db
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ lybra_core_db;

USE lybra_core_db;

--
-- Table structure for table `lybra_auth`
--

CREATE TABLE lybra_auth (
  user_id int(12) unsigned NOT NULL auto_increment,
  username varchar(50) NOT NULL default '',
  PASSWORD varchar(32) NOT NULL default '',
  PRIMARY KEY  (user_id),
  UNIQUE KEY username (username),
  KEY PASSWORD (PASSWORD)
) TYPE=MyISAM COMMENT='store users';

--
-- Dumping data for table `lybra_auth`
--

INSERT INTO lybra_auth (user_id, username, PASSWORD) VALUES (1,'admin','21232f297a57a5a743894a0e4a801fc3');

--
-- Table structure for table `lybra_auth_group_permission`
--

CREATE TABLE lybra_auth_group_permission (
  group_id int(8) NOT NULL default '0',
  permission_id bigint(20) NOT NULL default '0',
  active tinyint(1) unsigned NOT NULL default '0',
  mode int(6) unsigned NOT NULL default '1',
  PRIMARY KEY  (group_id,permission_id)
) TYPE=MyISAM COMMENT='stores group permission (wide, not relative to an object)';

--
-- Dumping data for table `lybra_auth_group_permission`
--

INSERT INTO lybra_auth_group_permission (group_id, permission_id, active, mode) VALUES (1,1,0,0);

--
-- Table structure for table `lybra_auth_group_permission_on_object`
--

CREATE TABLE lybra_auth_group_permission_on_object (
  group_id int(8) unsigned NOT NULL default '0',
  permission_id bigint(20) unsigned NOT NULL default '0',
  object_id int(12) unsigned NOT NULL default '0',
  object_type int(8) unsigned NOT NULL default '0',
  active tinyint(1) unsigned NOT NULL default '0',
  mode int(6) unsigned NOT NULL default '1',
  description varchar(255) NOT NULL default '',
  PRIMARY KEY  (group_id,permission_id,object_id,object_type)
) TYPE=MyISAM COMMENT='store group permission relative to an object';

--
-- Dumping data for table `lybra_auth_group_permission_on_object`
--

INSERT INTO lybra_auth_group_permission_on_object (group_id, permission_id, object_id, object_type, active, mode, description) VALUES (1,3,0,4,0,1,'Garantisce agli utenti del gruppo ROOT il READ_ACCESS sulla categoria root dei documenti');

--
-- Table structure for table `lybra_auth_group_permission_on_object_type`
--

CREATE TABLE lybra_auth_group_permission_on_object_type (
  group_id int(8) unsigned NOT NULL default '0',
  permission_id bigint(20) unsigned NOT NULL default '0',
  object_type int(8) unsigned NOT NULL default '0',
  active tinyint(1) unsigned NOT NULL default '0',
  mode int(6) unsigned NOT NULL default '1',
  PRIMARY KEY  (group_id,permission_id,object_type)
) TYPE=MyISAM COMMENT='stores group permissions on object types';

--
-- Dumping data for table `lybra_auth_group_permission_on_object_type`
--


--
-- Table structure for table `lybra_auth_groups`
--

CREATE TABLE lybra_auth_groups (
  group_id int(8) unsigned NOT NULL auto_increment,
  group_description varchar(255) NOT NULL default '',
  description varchar(255) NOT NULL default '',
  PRIMARY KEY  (group_id)
) TYPE=MyISAM COMMENT='group of users';

--
-- Dumping data for table `lybra_auth_groups`
--

INSERT INTO lybra_auth_groups (group_id, group_description, description) VALUES (1,'LYBRA ROOT ADMINISTRATOR','Has all permissions (manager+developer)');
INSERT INTO lybra_auth_groups (group_id, group_description, description) VALUES (2,'LYBRA PANEL ADMINISTRATOR','Has all permission on core scripts (developer)');
INSERT INTO lybra_auth_groups (group_id, group_description, description) VALUES (3,'PROJECT ROOT ADMINISTRATOR','Has permission on project scripts (manager+developer)');
INSERT INTO lybra_auth_groups (group_id, group_description, description) VALUES (4,'PROJECT PANEL ADMINISTRATOR','Has access on project panel (developer)');
INSERT INTO lybra_auth_groups (group_id, group_description, description) VALUES (5,'CMS ADMINISTRATOR','Has access on all administration pages relative to the project');
INSERT INTO lybra_auth_groups (group_id, group_description, description) VALUES (6,'USER/AUTHENTICATION ADMINISTRATOR','Has access on project panel, only about user authentication');
INSERT INTO lybra_auth_groups (group_id, group_description, description) VALUES (7,'AUTHORIZATION ADMINISTRATOR','Has access on project panel only relative to authorizations');
INSERT INTO lybra_auth_groups (group_id, group_description, description) VALUES (8,'SCRIPT ADMINISTRATOR','Has access on project panel only relative to script management (activate scripts and associate templates)');

--
-- Table structure for table `lybra_auth_object_types`
--

CREATE TABLE lybra_auth_object_types (
  object_type int(8) unsigned NOT NULL auto_increment,
  object_type_description varchar(255) NOT NULL default '',
  define varchar(120) NOT NULL default '',
  PRIMARY KEY  (object_type),
  UNIQUE KEY define (define)
) TYPE=MyISAM COMMENT='stores object types';

--
-- Dumping data for table `lybra_auth_object_types`
--

INSERT INTO lybra_auth_object_types (object_type, object_type_description, define) VALUES (1,'CORE SCRIPTS','LYBRA_OBJECT_TYPE_CORE_SCRIPTS');
INSERT INTO lybra_auth_object_types (object_type, object_type_description, define) VALUES (2,'NON CORE SCRIPTS','LYBRA_OBJECT_TYPE_NON_CORE_SCRIPTS');
INSERT INTO lybra_auth_object_types (object_type, object_type_description, define) VALUES (3,'SCRIPT','LYBRA_OBJECT_TYPE_SCRIPT');
INSERT INTO lybra_auth_object_types (object_type, object_type_description, define) VALUES (4,'DOCUMENT CATEGORY','LYBRA_OBJECT_TYPE_DOCUMENT_CATEGORY');

--
-- Table structure for table `lybra_auth_permission_policies`
--

CREATE TABLE lybra_auth_permission_policies (
  permission_policy_id int(6) unsigned NOT NULL auto_increment,
  define varchar(80) NOT NULL default '',
  description varchar(80) NOT NULL default '',
  PRIMARY KEY  (permission_policy_id)
) TYPE=MyISAM COMMENT='Stores sets of permissions, used as policies';

--
-- Dumping data for table `lybra_auth_permission_policies`
--


--
-- Table structure for table `lybra_auth_permissions`
--

CREATE TABLE lybra_auth_permissions (
  permission_id bigint(20) NOT NULL auto_increment,
  define varchar(120) NOT NULL default '',
  description varchar(255) NOT NULL default '',
  PRIMARY KEY  (permission_id)
) TYPE=MyISAM COMMENT='stores single permission';

--
-- Dumping data for table `lybra_auth_permissions`
--

INSERT INTO lybra_auth_permissions (permission_id, define, description) VALUES (1,'LYBRA_ACCESS_SCRIPT','just the possibility to access a script');
INSERT INTO lybra_auth_permissions (permission_id, define, description) VALUES (2,'LYBRA_SUBMIT_SCRIPT','just the possibility to submit from this script');
INSERT INTO lybra_auth_permissions (permission_id, define, description) VALUES (3,'READ_ACCESS','read access');
INSERT INTO lybra_auth_permissions (permission_id, define, description) VALUES (4,'WRITE_ACCESS','write access');
INSERT INTO lybra_auth_permissions (permission_id, define, description) VALUES (5,'MODIFY_ACCESS','modify access');
INSERT INTO lybra_auth_permissions (permission_id, define, description) VALUES (6,'REMOVE_ACCESS','remove access');

--
-- Table structure for table `lybra_auth_permissions_in_policies`
--

CREATE TABLE lybra_auth_permissions_in_policies (
  permission_policy_id int(6) unsigned NOT NULL default '0',
  permission_id bigint(20) unsigned NOT NULL default '0',
  PRIMARY KEY  (permission_policy_id,permission_id)
) TYPE=MyISAM COMMENT='Associate permissions to permission policies';

--
-- Dumping data for table `lybra_auth_permissions_in_policies`
--


--
-- Table structure for table `lybra_auth_role_permission`
--

CREATE TABLE lybra_auth_role_permission (
  role_id int(8) unsigned NOT NULL default '0',
  permission_id bigint(20) unsigned NOT NULL default '0',
  mode int(6) unsigned NOT NULL default '1',
  active tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (role_id,permission_id)
) TYPE=MyISAM COMMENT='associate permissions to roles';

--
-- Dumping data for table `lybra_auth_role_permission`
--


--
-- Table structure for table `lybra_auth_roles`
--

CREATE TABLE lybra_auth_roles (
  role_id int(8) unsigned NOT NULL auto_increment,
  role_description varchar(255) NOT NULL default '',
  PRIMARY KEY  (role_id)
) TYPE=MyISAM COMMENT='store roles for users';

--
-- Dumping data for table `lybra_auth_roles`
--


--
-- Table structure for table `lybra_auth_subgroup`
--

CREATE TABLE lybra_auth_subgroup (
  group_id int(8) unsigned NOT NULL default '0',
  father_group_id int(8) unsigned NOT NULL default '0',
  active tinyint(1) unsigned NOT NULL default '0',
  mode smallint(6) unsigned NOT NULL default '1',
  PRIMARY KEY  (group_id,father_group_id)
) TYPE=MyISAM COMMENT='stores subgroups';

--
-- Dumping data for table `lybra_auth_subgroup`
--


--
-- Table structure for table `lybra_auth_user_group`
--

CREATE TABLE lybra_auth_user_group (
  user_id int(12) unsigned NOT NULL default '0',
  group_id int(8) unsigned NOT NULL default '0',
  mode smallint(6) unsigned NOT NULL default '1',
  active tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (user_id,group_id)
) TYPE=MyISAM COMMENT='stores association from user and groups';

--
-- Dumping data for table `lybra_auth_user_group`
--

INSERT INTO lybra_auth_user_group (user_id, group_id, mode, active) VALUES (1,1,0,0);

--
-- Table structure for table `lybra_auth_user_has_role`
--

CREATE TABLE lybra_auth_user_has_role (
  user_id int(12) unsigned NOT NULL default '0',
  role_id int(8) unsigned NOT NULL default '0',
  object_id int(12) unsigned NOT NULL default '0',
  object_type int(8) unsigned NOT NULL default '0',
  mode int(6) unsigned NOT NULL default '1',
  active tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (user_id,role_id,object_id,object_type)
) TYPE=MyISAM COMMENT='associate role to user for a specific object';

--
-- Dumping data for table `lybra_auth_user_has_role`
--


--
-- Table structure for table `lybra_auth_user_has_role_on_object_type`
--

CREATE TABLE lybra_auth_user_has_role_on_object_type (
  user_id int(12) unsigned NOT NULL default '0',
  role_id int(8) unsigned NOT NULL default '0',
  object_type int(8) unsigned NOT NULL default '0',
  mode int(6) unsigned NOT NULL default '1',
  ative tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (user_id,role_id,object_type)
) TYPE=MyISAM COMMENT=' associate role to user for a specific object_type';

--
-- Dumping data for table `lybra_auth_user_has_role_on_object_type`
--


--
-- Table structure for table `lybra_auth_user_permission`
--

CREATE TABLE lybra_auth_user_permission (
  user_id int(12) unsigned NOT NULL default '0',
  permission_id bigint(20) unsigned NOT NULL default '0',
  mode int(6) unsigned NOT NULL default '1',
  active tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (user_id,permission_id)
) TYPE=MyISAM COMMENT='stores user permissions (wide, not relative to an object)';

--
-- Dumping data for table `lybra_auth_user_permission`
--

INSERT INTO lybra_auth_user_permission (user_id, permission_id, mode, active) VALUES (1,1,0,1);

--
-- Table structure for table `lybra_auth_user_permission_on_object`
--

CREATE TABLE lybra_auth_user_permission_on_object (
  user_id int(12) unsigned NOT NULL default '0',
  permission_id bigint(20) unsigned NOT NULL default '0',
  object_type int(8) unsigned NOT NULL default '0',
  object_id int(12) unsigned NOT NULL default '0',
  mode int(6) NOT NULL default '1',
  active tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (user_id,permission_id,object_id,object_type)
) TYPE=MyISAM COMMENT='stores user permission relative to an object';

--
-- Dumping data for table `lybra_auth_user_permission_on_object`
--

INSERT INTO lybra_auth_user_permission_on_object (user_id, permission_id, object_type, object_id, mode, active) VALUES (1,1,0,109,0,0);

--
-- Table structure for table `lybra_auth_user_permission_on_object_type`
--

CREATE TABLE lybra_auth_user_permission_on_object_type (
  user_id int(12) unsigned NOT NULL default '0',
  permission_id bigint(20) unsigned NOT NULL default '0',
  object_type int(8) unsigned NOT NULL default '0',
  mode int(6) unsigned NOT NULL default '1',
  active tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (user_id,permission_id,object_type)
) TYPE=MyISAM COMMENT='stores user permission on specific object id+type';

--
-- Dumping data for table `lybra_auth_user_permission_on_object_type`
--


--
-- Table structure for table `lybra_auto_template`
--

CREATE TABLE lybra_auto_template (
  lybra_auto_template_id int(12) NOT NULL auto_increment,
  template_varname varchar(50) NOT NULL default '',
  internal_type varchar(40) NOT NULL default '',
  priority int(3) unsigned NOT NULL default '0',
  lybra_event_id int(6) unsigned NOT NULL default '1',
  composite int(4) unsigned NOT NULL default '0',
  entry_type int(4) unsigned NOT NULL default '0',
  active tinyint(1) NOT NULL default '1',
  max_cardinality int(6) unsigned NOT NULL default '999999999',
  non_core int(2) unsigned NOT NULL default '1',
  PRIMARY KEY  (lybra_auto_template_id)
) TYPE=MyISAM COMMENT='Store values or variables to substitute to template tags';

--
-- Dumping data for table `lybra_auto_template`
--

INSERT INTO lybra_auto_template (lybra_auto_template_id, template_varname, internal_type, priority, lybra_event_id, composite, entry_type, active, max_cardinality, non_core) VALUES (155,'marathon_table','',0,3,0,2,1,999999999,1);

--
-- Table structure for table `lybra_auto_template_language_association`
--

CREATE TABLE lybra_auto_template_language_association (
  lybra_auto_template_id int(12) unsigned NOT NULL default '0',
  language_id smallint(6) unsigned NOT NULL default '0',
  value varchar(255) NOT NULL default '',
  PRIMARY KEY  (lybra_auto_template_id,language_id)
) TYPE=MyISAM;

--
-- Dumping data for table `lybra_auto_template_language_association`
--

INSERT INTO lybra_auto_template_language_association (lybra_auto_template_id, language_id, value) VALUES (155,0,'1');

--
-- Table structure for table `lybra_auto_template_script_association`
--

CREATE TABLE lybra_auto_template_script_association (
  lybra_auto_template_id int(12) unsigned NOT NULL default '0',
  script_id int(6) unsigned NOT NULL default '0',
  PRIMARY KEY  (lybra_auto_template_id,script_id)
) TYPE=MyISAM;

--
-- Dumping data for table `lybra_auto_template_script_association`
--

INSERT INTO lybra_auto_template_script_association (lybra_auto_template_id, script_id) VALUES (155,110);

--
-- Table structure for table `lybra_auto_templates_variable_types`
--

CREATE TABLE lybra_auto_templates_variable_types (
  auto_template_variable_type_id int(4) unsigned NOT NULL default '0',
  description varchar(120) default NULL,
  PRIMARY KEY  (auto_template_variable_type_id)
) TYPE=InnoDB COMMENT='contiene i tipi di variabile sostituibili ai tag-template';

--
-- Dumping data for table `lybra_auto_templates_variable_types`
--

INSERT INTO lybra_auto_templates_variable_types (auto_template_variable_type_id, description) VALUES (0,'static value');
INSERT INTO lybra_auto_templates_variable_types (auto_template_variable_type_id, description) VALUES (1,'class variable');
INSERT INTO lybra_auto_templates_variable_types (auto_template_variable_type_id, description) VALUES (2,'visual instance');
INSERT INTO lybra_auto_templates_variable_types (auto_template_variable_type_id, description) VALUES (3,'connect template');
INSERT INTO lybra_auto_templates_variable_types (auto_template_variable_type_id, description) VALUES (4,'session variable');
INSERT INTO lybra_auto_templates_variable_types (auto_template_variable_type_id, description) VALUES (5,'get variable');
INSERT INTO lybra_auto_templates_variable_types (auto_template_variable_type_id, description) VALUES (6,'post variable');
INSERT INTO lybra_auto_templates_variable_types (auto_template_variable_type_id, description) VALUES (7,'smarty sql template');
INSERT INTO lybra_auto_templates_variable_types (auto_template_variable_type_id, description) VALUES (8,'html static string');
INSERT INTO lybra_auto_templates_variable_types (auto_template_variable_type_id, description) VALUES (9,'phplayersmenu entries');
INSERT INTO lybra_auto_templates_variable_types (auto_template_variable_type_id, description) VALUES (10,'smarty subtemplate');

--
-- Table structure for table `lybra_code_chunks`
--

CREATE TABLE lybra_code_chunks (
  code_chunks_id int(5) unsigned NOT NULL auto_increment,
  code_source text NOT NULL,
  description text NOT NULL,
  PRIMARY KEY  (code_chunks_id)
) TYPE=InnoDB COMMENT='Memorizza funzioni PHP per decisioni automatiche con variabi';

--
-- Dumping data for table `lybra_code_chunks`
--


--
-- Table structure for table `lybra_condition_tests`
--

CREATE TABLE lybra_condition_tests (
  condition_test_id int(3) unsigned NOT NULL default '0',
  define varchar(80) NOT NULL default '',
  description varchar(255) NOT NULL default '',
  PRIMARY KEY  (condition_test_id)
) TYPE=MyISAM;

--
-- Dumping data for table `lybra_condition_tests`
--

INSERT INTO lybra_condition_tests (condition_test_id, define, description) VALUES (0,'EVENTDRIVEN_TEST_EQUAL_VALUE1','if (!strcmp($var_value,$var_value1))');
INSERT INTO lybra_condition_tests (condition_test_id, define, description) VALUES (1,'EVENTDRIVEN_TEST_EQUAL_BOTH','if ((!strcmp($var_value,$var_value1)) || (!strcmp($var_value,$var_value2)))');
INSERT INTO lybra_condition_tests (condition_test_id, define, description) VALUES (2,'EVENTDRIVEN_TEST_EQUAL_VALUE2','(!strcmp($var_value,$var_value2))');
INSERT INTO lybra_condition_tests (condition_test_id, define, description) VALUES (3,'EVENTDRIVEN_TEST_NOT_EQUAL_VALUE1','if (strcmp($var_value,$var_value1))');
INSERT INTO lybra_condition_tests (condition_test_id, define, description) VALUES (4,'EVENTDRIVEN_TEST_NOT_EQUAL_VALUE2','if (strcmp($var_value,$var_value2))');
INSERT INTO lybra_condition_tests (condition_test_id, define, description) VALUES (5,'EVENTDRIVEN_TEST_NOT_EQUAL_BOTH','if ((strcmp($var_value,$var_value1)) && (strcmp($var_value,$var_value2)))');
INSERT INTO lybra_condition_tests (condition_test_id, define, description) VALUES (6,'EVENTDRIVEN_TEST_GT_VALUE1','if ($var_value > $var_value1)');
INSERT INTO lybra_condition_tests (condition_test_id, define, description) VALUES (7,'EVENTDRIVEN_TEST_LT_VALUE1','if ($var_value < $var_value1)');
INSERT INTO lybra_condition_tests (condition_test_id, define, description) VALUES (8,'EVENTDRIVEN_TEST_GE_VALUE1','if ($var_value >= $var_value1)');
INSERT INTO lybra_condition_tests (condition_test_id, define, description) VALUES (9,'EVENTDRIVEN_TEST_LE_VALUE1','if ($var_value <= $var_value1)');
INSERT INTO lybra_condition_tests (condition_test_id, define, description) VALUES (10,'EVENTDRIVEN_TEST_GT_VALUE2','if ($var_value > $var_value2)');
INSERT INTO lybra_condition_tests (condition_test_id, define, description) VALUES (11,'EVENTDRIVEN_TEST_LT_VALUE2','if ($var_value < $var_value2)');
INSERT INTO lybra_condition_tests (condition_test_id, define, description) VALUES (12,'EVENTDRIVEN_TEST_GE_VALUE2','if ($var_value >= $var_value2)');
INSERT INTO lybra_condition_tests (condition_test_id, define, description) VALUES (13,'EVENTDRIVEN_TEST_LE_VALUE2','if ($var_value <= $var_value2)');
INSERT INTO lybra_condition_tests (condition_test_id, define, description) VALUES (14,'EVENTDRIVEN_TEST_BETWEEN_1YES_2NO','if (($var_value >= $var_value1) && ($var_value < $var_value2))');
INSERT INTO lybra_condition_tests (condition_test_id, define, description) VALUES (15,'EVENTDRIVEN_TEST_BETWEEN_1NO_2YES','if (($var_value > $var_value1) && ($var_value <= $var_value2))');
INSERT INTO lybra_condition_tests (condition_test_id, define, description) VALUES (16,'EVENTDRIVEN_TEST_BETWEEN_1YES_2YES','if (($var_value >= $var_value1) && ($var_value <= $var_value2))');
INSERT INTO lybra_condition_tests (condition_test_id, define, description) VALUES (17,'EVENTDRIVEN_TEST_BETWEEN_1NO_2NO','if (($var_value > $var_value1) && ($var_value < $var_value2))');
INSERT INTO lybra_condition_tests (condition_test_id, define, description) VALUES (18,'EVENTDRIVEN_TEST_EQUAL_STRING_VALUE1','if (!strcmp($var_value,$var_value1))');
INSERT INTO lybra_condition_tests (condition_test_id, define, description) VALUES (19,'EVENTDRIVEN_TEST_EQUAL_STRING_VALUE2','if (!strcmp($var_value,$var_value2))');
INSERT INTO lybra_condition_tests (condition_test_id, define, description) VALUES (20,'EVENTDRIVEN_TEST_EQUAL_SUBSTRING_VALUE1','if (ereg($var_value,$var_value1))');
INSERT INTO lybra_condition_tests (condition_test_id, define, description) VALUES (21,'EVENTDRIVEN_TEST_EQUAL_SUBSTRING_VALUE2','if (ereg($var_value,$var_value2))');
INSERT INTO lybra_condition_tests (condition_test_id, define, description) VALUES (99,'EVENTDRIVEN_USER_DEFINED_TEST','call a user define function');

--
-- Table structure for table `lybra_conditions`
--

CREATE TABLE lybra_conditions (
  lybra_condition_id int(8) unsigned NOT NULL auto_increment,
  goto_if_true int(8) unsigned NOT NULL default '0',
  goto_if_false int(8) unsigned NOT NULL default '0',
  test_id int(3) unsigned NOT NULL default '0',
  variable1_name varchar(120) NOT NULL default '',
  variable1_set_id int(4) unsigned NOT NULL default '0',
  variable2_name varchar(120) NOT NULL default '',
  variable2_set_id int(4) unsigned NOT NULL default '0',
  variable3_name varchar(120) NOT NULL default '',
  variable3_set_id int(4) unsigned NOT NULL default '0',
  personal_method_id int(6) unsigned NOT NULL default '0',
  PRIMARY KEY  (lybra_condition_id)
) TYPE=InnoDB COMMENT='Store automatic conditions to test';

--
-- Dumping data for table `lybra_conditions`
--

INSERT INTO lybra_conditions (lybra_condition_id, goto_if_true, goto_if_false, test_id, variable1_name, variable1_set_id, variable2_name, variable2_set_id, variable3_name, variable3_set_id, personal_method_id) VALUES (1,0,0,3,'login',2,'1',1,'',0,0);
INSERT INTO lybra_conditions (lybra_condition_id, goto_if_true, goto_if_false, test_id, variable1_name, variable1_set_id, variable2_name, variable2_set_id, variable3_name, variable3_set_id, personal_method_id) VALUES (5,0,0,0,'login',5,'Submit',1,'',0,0);

--
-- Table structure for table `lybra_connect_parameters`
--

CREATE TABLE lybra_connect_parameters (
  connect_id int(6) unsigned NOT NULL default '0',
  post_get varchar(4) NOT NULL default 'GET',
  param_name varchar(120) NOT NULL default '',
  param_value varchar(120) default NULL,
  variable_name varchar(120) NOT NULL default '',
  variable_set_id int(4) unsigned default '0',
  PRIMARY KEY  (connect_id,param_name)
) TYPE=InnoDB COMMENT='Store all parameters relative to connect_id connection';

--
-- Dumping data for table `lybra_connect_parameters`
--


--
-- Table structure for table `lybra_document_category`
--

CREATE TABLE lybra_document_category (
  category_id int(6) unsigned NOT NULL auto_increment,
  root tinyint(1) unsigned NOT NULL default '0',
  category_name varchar(60) NOT NULL default '',
  father_category_id int(6) unsigned NOT NULL default '0',
  PRIMARY KEY  (category_id)
) TYPE=MyISAM COMMENT='Stores the tree of categories';

--
-- Dumping data for table `lybra_document_category`
--


--
-- Table structure for table `lybra_documents`
--

CREATE TABLE lybra_documents (
  document_id bigint(20) unsigned NOT NULL auto_increment,
  document_name varchar(120) NOT NULL default '',
  document_description varchar(255) NOT NULL default '',
  PRIMARY KEY  (document_id)
) TYPE=MyISAM COMMENT='lybra document module main table';

--
-- Dumping data for table `lybra_documents`
--


--
-- Table structure for table `lybra_files`
--

CREATE TABLE lybra_files (
  file_id bigint(20) unsigned NOT NULL auto_increment,
  document_id bigint(20) unsigned NOT NULL default '0',
  filename varchar(255) NOT NULL default '',
  path varchar(255) NOT NULL default '',
  description varchar(255) NOT NULL default '',
  PRIMARY KEY  (file_id),
  KEY document_id (document_id)
) TYPE=MyISAM COMMENT='stores files to manage';

--
-- Dumping data for table `lybra_files`
--


--
-- Table structure for table `lybra_html_strings`
--

CREATE TABLE lybra_html_strings (
  html_string_id int(12) unsigned NOT NULL auto_increment,
  html_string text NOT NULL,
  description varchar(120) NOT NULL default '',
  language int(2) unsigned NOT NULL default '0',
  PRIMARY KEY  (html_string_id)
) TYPE=InnoDB COMMENT='contiene stringhe HTML';

--
-- Dumping data for table `lybra_html_strings`
--


--
-- Table structure for table `lybra_languages`
--

CREATE TABLE lybra_languages (
  language_id smallint(6) unsigned NOT NULL default '0',
  description varchar(20) NOT NULL default '',
  active tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (language_id)
) TYPE=InnoDB COMMENT='Una entry per ogni linguaggio supportato';

--
-- Dumping data for table `lybra_languages`
--

INSERT INTO lybra_languages (language_id, description, active) VALUES (1,'Italiano',1);
INSERT INTO lybra_languages (language_id, description, active) VALUES (2,'Inglese',0);
INSERT INTO lybra_languages (language_id, description, active) VALUES (3,'Spagnolo',0);
INSERT INTO lybra_languages (language_id, description, active) VALUES (4,'Tedesco',0);
INSERT INTO lybra_languages (language_id, description, active) VALUES (5,'Francese',0);

--
-- Table structure for table `lybra_methods`
--

CREATE TABLE lybra_methods (
  method_id int(6) unsigned NOT NULL auto_increment,
  module_id int(3) unsigned NOT NULL default '0',
  method_name varchar(80) NOT NULL default '',
  description varchar(120) default NULL,
  PRIMARY KEY  (method_id)
) TYPE=InnoDB COMMENT='Store default method for automatic calls';

--
-- Dumping data for table `lybra_methods`
--

INSERT INTO lybra_methods (method_id, module_id, method_name, description) VALUES (1,6,'login_redirect','save browser request and redirect to login page');
INSERT INTO lybra_methods (method_id, module_id, method_name, description) VALUES (2,6,'login_return_to_page','retrieve browser request and redirect to previous page');
INSERT INTO lybra_methods (method_id, module_id, method_name, description) VALUES (3,8,'generic_table_builder','Create a generic HTML table');

--
-- Table structure for table `lybra_modules`
--

CREATE TABLE lybra_modules (
  module_id int(3) unsigned NOT NULL default '0',
  active tinyint(1) NOT NULL default '0',
  class_name varchar(80) NOT NULL default '',
  auto_instantiate tinyint(3) unsigned NOT NULL default '0',
  factory_init tinyint(1) NOT NULL default '0',
  init_order int(4) unsigned NOT NULL default '0',
  description varchar(50) NOT NULL default '',
  filename varchar(255) NOT NULL default '',
  PRIMARY KEY  (module_id)
) TYPE=InnoDB;

--
-- Dumping data for table `lybra_modules`
--

INSERT INTO lybra_modules (module_id, active, class_name, auto_instantiate, factory_init, init_order, description, filename) VALUES (0,1,'table',0,0,0,'Table: db access','');
INSERT INTO lybra_modules (module_id, active, class_name, auto_instantiate, factory_init, init_order, description, filename) VALUES (1,1,'smarty',1,1,2,'Templates','');
INSERT INTO lybra_modules (module_id, active, class_name, auto_instantiate, factory_init, init_order, description, filename) VALUES (2,1,'multi_log',1,0,2,'Log','');
INSERT INTO lybra_modules (module_id, active, class_name, auto_instantiate, factory_init, init_order, description, filename) VALUES (3,1,'session',1,1,1,'Session','');
INSERT INTO lybra_modules (module_id, active, class_name, auto_instantiate, factory_init, init_order, description, filename) VALUES (4,0,'ecommerce',0,0,4,'Ecommerce','');
INSERT INTO lybra_modules (module_id, active, class_name, auto_instantiate, factory_init, init_order, description, filename) VALUES (5,1,'',1,0,2,'Language support','');
INSERT INTO lybra_modules (module_id, active, class_name, auto_instantiate, factory_init, init_order, description, filename) VALUES (6,1,'',0,0,0,'fake: misc. parameters in table ecommerce_paramete','');
INSERT INTO lybra_modules (module_id, active, class_name, auto_instantiate, factory_init, init_order, description, filename) VALUES (7,1,'',0,0,0,'Session User Manager','');
INSERT INTO lybra_modules (module_id, active, class_name, auto_instantiate, factory_init, init_order, description, filename) VALUES (8,1,'html',1,0,3,'Html builder','');
INSERT INTO lybra_modules (module_id, active, class_name, auto_instantiate, factory_init, init_order, description, filename) VALUES (9,0,'',0,0,3,'XHtml','');
INSERT INTO lybra_modules (module_id, active, class_name, auto_instantiate, factory_init, init_order, description, filename) VALUES (10,1,'auth',1,1,3,'Authentication','');
INSERT INTO lybra_modules (module_id, active, class_name, auto_instantiate, factory_init, init_order, description, filename) VALUES (11,1,'html_cdsagenda',1,0,3,'html_cdsagenda','');
INSERT INTO lybra_modules (module_id, active, class_name, auto_instantiate, factory_init, init_order, description, filename) VALUES (12,1,'layersmenu',1,1,3,'php layers menu','');
INSERT INTO lybra_modules (module_id, active, class_name, auto_instantiate, factory_init, init_order, description, filename) VALUES (14,1,'DB_DataObject',1,1,3,'database abstraction layer','');
INSERT INTO lybra_modules (module_id, active, class_name, auto_instantiate, factory_init, init_order, description, filename) VALUES (15,1,'document_manager',0,0,4,'document manager','');
INSERT INTO lybra_modules (module_id, active, class_name, auto_instantiate, factory_init, init_order, description, filename) VALUES (16,1,'file_manager',0,0,4,'file manager','');
INSERT INTO lybra_modules (module_id, active, class_name, auto_instantiate, factory_init, init_order, description, filename) VALUES (17,1,'authorization_manager',1,1,4,'authorization manager','');

--
-- Table structure for table `lybra_parameters`
--

CREATE TABLE lybra_parameters (
  lybra_parameter_id int(5) unsigned NOT NULL auto_increment,
  lybra_parameter_id_prefix int(5) unsigned NOT NULL default '0',
  lybra_parameter_id_suffix int(5) unsigned NOT NULL default '0',
  module_id int(3) unsigned NOT NULL default '0',
  parameter_name varchar(50) NOT NULL default '',
  parameter_value varchar(255) NOT NULL default '',
  send_to_module smallint(5) unsigned NOT NULL default '0',
  core tinyint(1) unsigned NOT NULL default '0',
  script_id int(6) unsigned NOT NULL default '0',
  description varchar(255) default NULL,
  PRIMARY KEY  (lybra_parameter_id)
) TYPE=InnoDB COMMENT='Store project main static parameters';

--
-- Dumping data for table `lybra_parameters`
--

INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (2,0,0,1,'par_tem_path','/template',1,0,0,'Template realtive path (relative to main path)');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (5,0,0,5,'par_default_language','1',0,0,0,'default language (internationalisation)');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (8,0,0,5,'par_language_get_varname','l',0,0,0,'GET variable name, used to specify active language (internationalisation)');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (9,0,0,5,'par_language_session_varname','ses_md5_l',0,0,0,'Session variable name storing currently used language (internationalisation)');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (13,0,0,7,'par_user_id_into_ses','md7_usrId',0,0,0,'Session variable storing current user ID');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (14,0,0,1,'par_tem_autorun','1',0,0,0,'Activa/deactivate auto-template system');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (16,0,0,5,'par_language_file_active','0',0,0,0,'Enable (1) or Disable (0) system to include language files (internationalisation)');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (17,0,0,6,'par_main_path','/var/www/html/project_phpa',0,0,0,'Root project directory (absolute path)');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (18,0,0,1,'par_tem_autorun_dynamic','1',0,0,0,'Enable (1) or Disable (0) dynamic auto-template system');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (19,0,0,1,'par_tem_autorun_connect','1',0,0,0,'Enable (1) or Disable (0) auto-template system (static) to connect-scripts (table script_connect)');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (20,0,0,2,'par_log_mode','2',1,0,0,'Log method for module multi_log (2: USE_FILE)');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (21,17,0,2,'par_log_file','/log/prova.log',1,0,0,'Specify log file location');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (22,0,0,2,'par_log_arglist','TIMESTAMP14 SCRIPT LINE PROCESS_ID ADDRESS BROWSER MESSAGE',1,0,0,'List of arguments to add into a log entry');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (23,0,0,2,'par_log_dateformat','Y-m-d/H:i:s(T)',1,0,0,'PHP Date format to use for timestamp entries');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (24,0,0,2,'par_log_activation','1 1 1 0',1,0,0,'Activate log types (ERROR DEBUG EXEC SYSTEM)');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (25,0,0,1,'par_tem_autorun_connect_dynamic','1',0,0,0,'Enable (1) or Disable (0) auto-template system (dynamic) to connect-scripts (table script_connect)');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (26,0,0,3,'par_first_execute_active','0',0,0,0,'If active (1) execute first_submit_only method at first run (based on session)');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (27,0,0,3,'par_first_execute_variable','lyb_first_run',0,0,0,'Used to know if is first script execution (based on session)');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (28,0,0,3,'par_first_execute_method_name','first_submit_only',0,0,0,'method to call for first submit call');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (29,0,0,6,'par_tem_sql_autorun','1',0,0,0,'Enable (1) or Disable (0) automatic construction of visual instances');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (30,0,0,6,'par_error_template_name','error',1,0,0,NULL);
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (31,0,0,6,'par_home_page_name','home',0,0,0,NULL);
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (32,0,0,6,'par_event_driven_active_init','1',0,0,0,'Enable (1) or Disable (0) Event-driven system at init mode (called static)');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (33,0,0,6,'par_event_driven_active_action','1',0,0,0,'Enable (1) or Disable (0) Event-driven system in core mode (\"action\" time)');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (34,0,0,6,'par_event_driven_active_render','1',0,0,0,'Enable (1) or Disable (0) Event-driven system in core mode (\"render\" time)');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (35,0,0,6,'par_mainpage_name','mainpage',1,0,0,'label to identify \"mainpage\"');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (36,0,0,6,'par_errorpage_name','error',0,0,0,'label that identifies \"error\" page');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (37,0,0,6,'par_default_language','1',0,0,0,'Define default language (used when lo language is specified)');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (49,17,0,12,'libjsdir','/phplayersmenu/libjs',2,0,0,'js path');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (50,0,0,12,'libjswww','phplayersmenu/libjs/',2,0,0,'www js path');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (51,0,0,12,'menu_jscript_0','layersmenu-browser_detection_func.js',2,0,0,'js files');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (52,0,0,12,'menu_jscript_1','layersmenu-library.js',2,0,0,'js files');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (53,0,0,12,'menu_jscript_2','layersmenu.js',2,0,0,'js files');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (54,0,0,12,'menu_jscript_3','layerstreemenu-cookies.js',2,0,0,'js files');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (55,17,0,12,'dir_images','/phplayersmenu/images',2,0,0,'images dir');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (56,0,0,12,'www_dir_images','phplayersmenu/images/',2,0,0,'www images dir');
INSERT INTO lybra_parameters (lybra_parameter_id, lybra_parameter_id_prefix, lybra_parameter_id_suffix, module_id, parameter_name, parameter_value, send_to_module, core, script_id, description) VALUES (57,0,0,12,'dir_template','phplayersmenu/templates/',2,0,0,'templates dir');

--
-- Table structure for table `lybra_phplayersmenu`
--

CREATE TABLE lybra_phplayersmenu (
  Name varchar(50) NOT NULL default '',
  id int(11) NOT NULL auto_increment,
  parent_id int(11) NOT NULL default '1',
  text text,
  link text,
  title text,
  icon text,
  target text,
  label varchar(50) default NULL,
  orderfield int(11) default '0',
  expanded tinyint(4) default '0',
  PRIMARY KEY  (id,Name)
) TYPE=InnoDB;

--
-- Dumping data for table `lybra_phplayersmenu`
--


--
-- Table structure for table `lybra_phplayersmenu_i18n`
--

CREATE TABLE lybra_phplayersmenu_i18n (
  language varchar(15) NOT NULL default '',
  Name varchar(50) NOT NULL default '',
  id int(11) NOT NULL default '0',
  text text,
  title text,
  PRIMARY KEY  (language,id,Name)
) TYPE=InnoDB;

--
-- Dumping data for table `lybra_phplayersmenu_i18n`
--


--
-- Table structure for table `lybra_phplayersmenu_istance`
--

CREATE TABLE lybra_phplayersmenu_istance (
  layout_id int(6) unsigned NOT NULL auto_increment,
  layersmenu_parameter_id int(8) unsigned NOT NULL default '0',
  script_id int(6) unsigned NOT NULL default '0',
  name varchar(50) NOT NULL default '',
  label text NOT NULL,
  type varchar(40) NOT NULL default '',
  repository varchar(255) NOT NULL default '',
  PRIMARY KEY  (layout_id)
) TYPE=InnoDB;

--
-- Dumping data for table `lybra_phplayersmenu_istance`
--


--
-- Table structure for table `lybra_phplayersmenu_parameters`
--

CREATE TABLE lybra_phplayersmenu_parameters (
  layersmenu_parameter_id int(8) unsigned NOT NULL auto_increment,
  css varchar(80) NOT NULL default '',
  arrows_down varchar(80) NOT NULL default '',
  arrows_forward varchar(80) NOT NULL default '',
  layer_position varchar(80) NOT NULL default '',
  template varchar(80) NOT NULL default '',
  sub_template varchar(80) NOT NULL default '',
  visibility tinyint(1) unsigned NOT NULL default '1',
  abscissa_step int(6) unsigned NOT NULL default '0',
  menu_format varchar(30) NOT NULL default '',
  PRIMARY KEY  (layersmenu_parameter_id)
) TYPE=InnoDB COMMENT='stores single layersmenu parameters';

--
-- Dumping data for table `lybra_phplayersmenu_parameters`
--


--
-- Table structure for table `lybra_phplayersmenu_tag`
--

CREATE TABLE lybra_phplayersmenu_tag (
  name varchar(50) NOT NULL default '',
  tag varchar(80) NOT NULL default '',
  status tinyint(1) unsigned NOT NULL default '1',
  PRIMARY KEY  (name)
) TYPE=InnoDB;

--
-- Dumping data for table `lybra_phplayersmenu_tag`
--


--
-- Table structure for table `lybra_project_parameters`
--

CREATE TABLE lybra_project_parameters (
  parameter_id int(5) unsigned NOT NULL auto_increment,
  script_id int(6) unsigned NOT NULL default '0',
  active int(2) unsigned NOT NULL default '0',
  parameter_name varchar(50) NOT NULL default '',
  parameter_value varchar(255) NOT NULL default '',
  parameter_name_array varchar(50) NOT NULL default '',
  PRIMARY KEY  (parameter_id)
) TYPE=InnoDB;

--
-- Dumping data for table `lybra_project_parameters`
--


--
-- Table structure for table `lybra_query_retrieve_modes`
--

CREATE TABLE lybra_query_retrieve_modes (
  retrieve_mode_id int(3) unsigned NOT NULL default '0',
  description varchar(255) NOT NULL default '',
  PRIMARY KEY  (retrieve_mode_id)
) TYPE=InnoDB COMMENT='store modes to retrieve data from database';

--
-- Dumping data for table `lybra_query_retrieve_modes`
--

INSERT INTO lybra_query_retrieve_modes (retrieve_mode_id, description) VALUES (0,'PEAR DB_FETCHMODE_DEFAULT<-pear define lybra-> LYBRA_DB_FETCHMODE_DEFAULT');
INSERT INTO lybra_query_retrieve_modes (retrieve_mode_id, description) VALUES (1,'DB_FETCHMODE_ORDERED<-pear define lybra->LYBRA_DB_FETCHMODE_ORDERED');
INSERT INTO lybra_query_retrieve_modes (retrieve_mode_id, description) VALUES (2,'DB_FETCHMODE_ASSOC<-pear define lybra->LYBRA_DB_FETCHMODE_ASSOC');
INSERT INTO lybra_query_retrieve_modes (retrieve_mode_id, description) VALUES (3,'DB_FETCHMODE_OBJECT->pear define lybra<-LYBRA_DB_FETCHMODE_OBJECT');
INSERT INTO lybra_query_retrieve_modes (retrieve_mode_id, description) VALUES (4,'DB_FETCHMODE_FLIPPED->pear define <-LYBRA_DB_FETCHMODE_FLIPPED');

--
-- Table structure for table `lybra_script_auth`
--

CREATE TABLE lybra_script_auth (
  lybra_script_auth_id int(8) unsigned NOT NULL auto_increment,
  script_id int(6) unsigned NOT NULL default '0',
  condition_id int(8) unsigned NOT NULL default '0',
  true_out_script_id int(6) unsigned NOT NULL default '0',
  false_out_script_id int(6) unsigned NOT NULL default '0',
  active tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (lybra_script_auth_id)
) TYPE=MyISAM COMMENT='store auth conditions on scripts';

--
-- Dumping data for table `lybra_script_auth`
--


--
-- Table structure for table `lybra_script_connect`
--

CREATE TABLE lybra_script_connect (
  connect_id int(6) unsigned NOT NULL auto_increment,
  source_id int(6) unsigned NOT NULL default '0',
  target_id int(6) unsigned NOT NULL default '0',
  mode_id int(4) unsigned NOT NULL default '0',
  language int(2) unsigned NOT NULL default '0',
  description varchar(120) default NULL,
  PRIMARY KEY  (connect_id)
) TYPE=InnoDB COMMENT='Store connection method from source to target scripts';

--
-- Dumping data for table `lybra_script_connect`
--


--
-- Table structure for table `lybra_script_group_perm`
--

CREATE TABLE lybra_script_group_perm (
  script_id int(6) unsigned NOT NULL default '0',
  group_id int(11) NOT NULL default '0',
  language_id smallint(6) unsigned NOT NULL default '0',
  right_level tinyint(3) unsigned default NULL,
  PRIMARY KEY  (script_id,group_id)
) TYPE=MyISAM COMMENT='store script permission by group';

--
-- Dumping data for table `lybra_script_group_perm`
--


--
-- Table structure for table `lybra_script_permission`
--

CREATE TABLE lybra_script_permission (
  script_id int(6) unsigned NOT NULL default '0',
  right_id int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (script_id,right_id)
) TYPE=MyISAM COMMENT='store access permission by right';

--
-- Dumping data for table `lybra_script_permission`
--


--
-- Table structure for table `lybra_script_templates`
--

CREATE TABLE lybra_script_templates (
  script_id int(6) unsigned NOT NULL default '0',
  template_file varchar(60) NOT NULL default '',
  template_label varchar(40) NOT NULL default '',
  parse_into varchar(60) default '0',
  priority smallint(3) NOT NULL default '0',
  PRIMARY KEY  (script_id,template_label)
) TYPE=InnoDB COMMENT='Associated a script to its templates';

--
-- Dumping data for table `lybra_script_templates`
--

INSERT INTO lybra_script_templates (script_id, template_file, template_label, parse_into, priority) VALUES (109,'index.ihtml','mainpage','0',0);
INSERT INTO lybra_script_templates (script_id, template_file, template_label, parse_into, priority) VALUES (110,'index.ihtml','mainpage','0',0);
INSERT INTO lybra_script_templates (script_id, template_file, template_label, parse_into, priority) VALUES (111,'login.ihtml','mainpage','0',0);

--
-- Table structure for table `lybra_scripts`
--

CREATE TABLE lybra_scripts (
  script_id int(6) unsigned NOT NULL auto_increment,
  script_name varchar(120) NOT NULL default '',
  non_core int(2) unsigned NOT NULL default '1',
  protected tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (script_id)
) TYPE=InnoDB COMMENT='One entry for each script';

--
-- Dumping data for table `lybra_scripts`
--

INSERT INTO lybra_scripts (script_id, script_name, non_core, protected) VALUES (110,'index.php',1,0);
INSERT INTO lybra_scripts (script_id, script_name, non_core, protected) VALUES (111,'login.php',1,0);

--
-- Table structure for table `lybra_sql`
--

CREATE TABLE lybra_sql (
  sql_id int(10) unsigned NOT NULL auto_increment,
  sql text NOT NULL,
  description varchar(255) default NULL,
  evaluate tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (sql_id)
) TYPE=InnoDB COMMENT='Ogni entry rappresenta una query, scritta in PHP (con $this-';

--
-- Dumping data for table `lybra_sql`
--

INSERT INTO lybra_sql (sql_id, sql, description, evaluate) VALUES (1,'select marathon_name,marathon_place,marathon_date from project_phpa_data order by marathon_date ASC','Simple static query without variables',0);

--
-- Table structure for table `lybra_submit_actions`
--

CREATE TABLE lybra_submit_actions (
  submit_action_id int(6) unsigned NOT NULL auto_increment,
  lybra_condition_id int(8) unsigned NOT NULL default '0',
  script_id int(6) unsigned NOT NULL default '0',
  execute_method_id int(6) unsigned NOT NULL default '0',
  event_id int(3) unsigned NOT NULL default '0',
  priority int(3) unsigned NOT NULL default '0',
  active tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (submit_action_id)
) TYPE=InnoDB COMMENT='Memorizza le chiamate automatiche dipendentemente dalle subm';

--
-- Dumping data for table `lybra_submit_actions`
--

INSERT INTO lybra_submit_actions (submit_action_id, lybra_condition_id, script_id, execute_method_id, event_id, priority, active) VALUES (6,5,111,2,1,1,1);
INSERT INTO lybra_submit_actions (submit_action_id, lybra_condition_id, script_id, execute_method_id, event_id, priority, active) VALUES (7,1,110,1,1,1,1);

--
-- Table structure for table `lybra_timer_to_daytimer_association`
--

CREATE TABLE lybra_timer_to_daytimer_association (
  timer_id bigint(20) NOT NULL default '0',
  timer_day_id bigint(20) NOT NULL default '0',
  PRIMARY KEY  (timer_id,timer_day_id)
) TYPE=MyISAM COMMENT='Associate timers with daily intervals';

--
-- Dumping data for table `lybra_timer_to_daytimer_association`
--


--
-- Table structure for table `lybra_timers`
--

CREATE TABLE lybra_timers (
  timer_id bigint(20) unsigned NOT NULL auto_increment,
  start_time timestamp(14) NOT NULL,
  end_time timestamp(14) NOT NULL default '00000000000000',
  recursive_bitmap smallint(1) unsigned NOT NULL default '0',
  week_bitmap smallint(1) unsigned NOT NULL default '0',
  timer_category varchar(40) NOT NULL default '',
  description varchar(255) NOT NULL default '',
  PRIMARY KEY  (timer_id)
) TYPE=MyISAM COMMENT='Stores timers and period tests';

--
-- Dumping data for table `lybra_timers`
--


--
-- Table structure for table `lybra_timers_day`
--

CREATE TABLE lybra_timers_day (
  timer_day_id bigint(20) unsigned NOT NULL auto_increment,
  start_time time NOT NULL default '00:00:00',
  end_time time NOT NULL default '00:00:00',
  description varchar(120) NOT NULL default '',
  PRIMARY KEY  (timer_day_id)
) TYPE=MyISAM COMMENT='Store a period within a day';

--
-- Dumping data for table `lybra_timers_day`
--


--
-- Table structure for table `lybra_variable_sets`
--

CREATE TABLE lybra_variable_sets (
  variable_set_id int(4) unsigned NOT NULL auto_increment,
  description varchar(80) default NULL,
  active tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (variable_set_id)
) TYPE=InnoDB;

--
-- Dumping data for table `lybra_variable_sets`
--

INSERT INTO lybra_variable_sets (variable_set_id, description, active) VALUES (1,'explicit value',1);
INSERT INTO lybra_variable_sets (variable_set_id, description, active) VALUES (2,'session',1);
INSERT INTO lybra_variable_sets (variable_set_id, description, active) VALUES (3,'class variable',1);
INSERT INTO lybra_variable_sets (variable_set_id, description, active) VALUES (4,'GET',1);
INSERT INTO lybra_variable_sets (variable_set_id, description, active) VALUES (5,'POST',1);
INSERT INTO lybra_variable_sets (variable_set_id, description, active) VALUES (6,'SQL FIELD',1);

--
-- Table structure for table `lybra_variable_types`
--

CREATE TABLE lybra_variable_types (
  variable_id int(4) unsigned NOT NULL default '0',
  description varchar(80) NOT NULL default '',
  PRIMARY KEY  (variable_id)
) TYPE=InnoDB COMMENT='type of variables (used for event-driven php)';

--
-- Dumping data for table `lybra_variable_types`
--

INSERT INTO lybra_variable_types (variable_id, description) VALUES (1,'flag');
INSERT INTO lybra_variable_types (variable_id, description) VALUES (2,'int');
INSERT INTO lybra_variable_types (variable_id, description) VALUES (3,'string');
INSERT INTO lybra_variable_types (variable_id, description) VALUES (4,'array');
INSERT INTO lybra_variable_types (variable_id, description) VALUES (5,'hash');
INSERT INTO lybra_variable_types (variable_id, description) VALUES (6,'float');

--
-- Table structure for table `lybra_visual_istance_parameters`
--

CREATE TABLE lybra_visual_istance_parameters (
  visual_istance_id int(10) unsigned NOT NULL default '0',
  position smallint(5) unsigned NOT NULL default '0',
  value varchar(255) NOT NULL default '',
  variable_name varchar(80) NOT NULL default '',
  sql_id int(10) NOT NULL default '0',
  sql_field int(4) unsigned NOT NULL default '0',
  optional tinyint(1) unsigned NOT NULL default '0',
  parameter_set_id int(4) unsigned NOT NULL default '0',
  parameter_type_id int(4) unsigned NOT NULL default '0',
  PRIMARY KEY  (visual_istance_id,position)
) TYPE=InnoDB COMMENT='Memorizza la lista dei parametri associati ad una visual ist';

--
-- Dumping data for table `lybra_visual_istance_parameters`
--

INSERT INTO lybra_visual_istance_parameters (visual_istance_id, position, value, variable_name, sql_id, sql_field, optional, parameter_set_id, parameter_type_id) VALUES (1,0,'2','',0,0,0,1,0);
INSERT INTO lybra_visual_istance_parameters (visual_istance_id, position, value, variable_name, sql_id, sql_field, optional, parameter_set_id, parameter_type_id) VALUES (1,1,'','',1,0,0,6,4);

--
-- Table structure for table `lybra_visual_istances`
--

CREATE TABLE lybra_visual_istances (
  visual_istance_id int(10) unsigned NOT NULL auto_increment,
  father_visual_istance_id int(10) unsigned default NULL,
  position_into_father int(10) unsigned default NULL,
  description varchar(255) NOT NULL default '',
  method_id int(6) unsigned NOT NULL default '0',
  PRIMARY KEY  (visual_istance_id)
) TYPE=InnoDB COMMENT='Memorizza istanze di oggetti visuali (html), la composizione';

--
-- Dumping data for table `lybra_visual_istances`
--

INSERT INTO lybra_visual_istances (visual_istance_id, father_visual_istance_id, position_into_father, description, method_id) VALUES (1,NULL,NULL,'Build marathon data html',3);

--
-- Table structure for table `project_phpa_data`
--

CREATE TABLE project_phpa_data (
  marathon_id int(4) unsigned NOT NULL auto_increment,
  marathon_name varchar(120) NOT NULL default '',
  marathon_place varchar(80) NOT NULL default '',
  marathon_date timestamp(14) NOT NULL,
  PRIMARY KEY  (marathon_id)
) TYPE=MyISAM COMMENT='Stores a list of 2004 Marathons';

--
-- Dumping data for table `project_phpa_data`
--

INSERT INTO project_phpa_data (marathon_id, marathon_name, marathon_place, marathon_date) VALUES (1,'Chronicle Marathon','San Francisco',20040401120527);
INSERT INTO project_phpa_data (marathon_id, marathon_name, marathon_place, marathon_date) VALUES (2,'Venice Marathon','Venezia',20040401120956);
INSERT INTO project_phpa_data (marathon_id, marathon_name, marathon_place, marathon_date) VALUES (3,'Pisa Marathon','Pisa',20040401121030);
INSERT INTO project_phpa_data (marathon_id, marathon_name, marathon_place, marathon_date) VALUES (4,'Dublin Marathon','Dublin',20040401121115);

