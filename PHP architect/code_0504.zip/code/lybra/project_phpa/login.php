<?
	require_once("objects/project_phpa.php");
	session_start();
	$script = new project_phpa($_GET,$_POST,$_SESSION,"login.php");
	$script->render($script->action());
	exit;
?>