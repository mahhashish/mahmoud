<?
 /**********************************************************************************************
 		Lybra: A general purpose framework for fast web development
		Copyright (C) 2002-2004 Simone Grassi, Andrea Giorgini

	    scheleton_script.php
	    --------------------
		begin:  	9/2002 Simone Grassi (Ci S.B.i.C. snc)
		copyright:	(C) 2002, Simone Grassi,  Andrea Giorgini
					viale Marconi 438, 47023 Cesena (FC), Italy.
		email:		lybra@cisbic.com

	    This program is free software; you can redistribute it and/or modify
	    it under the terms of the GNU General Public License as published by
	    the Free Software Foundation; either version 2 of the License, or
	    (at your option) any later version.

	    This program is distributed in the hope that it will be useful,
	    but WITHOUT ANY WARRANTY; without even the implied warranty of
	    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	    GNU General Public License for more details.

	    You should have received a copy of the GNU General Public License
	    along with this program; if not, write to the Free Software
	    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************************************/

	require_once("config_scheleton_script.php");
	require_once("lybra/core/api/abstract_factory.php");
	
	include_once("lybra/debug_utils.php");

	class scheleton_script extends abstract_factory
	{
		// {{{ properties

		// Activation vars
		var $init_values;
		// Store last lybra-core status (error or not)
		var $core_status;
		// Base to extend to create new scripts
		var $modules_istances = array();
		// Array containing istance collecting module parameters
		var $core_module_parameters = array();
		// Store module status (active/not active)
		var $active_modules = array();
		// Used to store parameters query position indexed by parameter id
		var $_lybra_parameters_idx = array();
		
		// }}}
		// {{{ constructor

		/**
		 * scheleton_script constructor
		 *
		 * @access public
		 *
		 * $GET hash address of the GET variables
		 * $POST hash address of the POST variables
		 * $SESSION hash address of the SESSION variables
		 * $init_values array module activation flags
		 *
		 * @return bool true on success false otherwise
		 */
		function scheleton_script(&$GET,&$POST,&$SESSION,$init_values="")
		{
			// By default no error
			$this->core_error = LYBRA_NO_ERROR;
			$this->GET = $GET;
			$this->POST = $POST;
			$this->SESSION = $SESSION;
			$this->init_values = $init_values;
			if (is_array($init_values))
				$use_init_values = TRUE;
			else
				$use_init_values = FALSE;
			// Mandatory modules
			$this->init_values[TABLE_MODULE] = ON;
			$this->init_values[FAKE_MODULE] = ON;
			$this->init_values[LANGUAGE_MODULE] = ON;
			// Always initialize output print buffer
			$this->print_buffer = "";

			// Init DB access for first even if not selected from the DB ;)
			if ($this->init_values[TABLE_MODULE])
			{
				// Retrieve project config parameters
				$this->project_module_parameters[TABLE_MODULE] = new param_container();
				$this->project_module_parameters[TABLE_MODULE]->dbtype = $this->parameters["tableDbtype"];
				$this->project_module_parameters[TABLE_MODULE]->dbname = $this->parameters["tableDbname"];
				$this->project_module_parameters[TABLE_MODULE]->host = $this->parameters["tableServer"];
				$this->project_module_parameters[TABLE_MODULE]->port = $this->parameters["tablePort"];
				$this->project_module_parameters[TABLE_MODULE]->user = $this->parameters["tableUser"];
				$this->project_module_parameters[TABLE_MODULE]->password = $this->parameters["tablePassword"];
			    if (!$this->table = new table($this->project_module_parameters[TABLE_MODULE]))
			    {
			    	$this->core_error = TRUE;
					return DB_INIT_ERROR;
			    }
			    else
			    {
			    	// Make local some variables
					$this->results = &$this->table->results;
					$this->count = &$this->table->count;
					$this->empty_result = &$this->table->empty_result;
			    }

/* USED TO OPEN A SECOND CONNECTION TO ANOTHER DB
			    // Check if coredb is the same as project_db (in the same host for the same db)
			    if ((!strcmp($this->core_module_parameters[TABLE_MODULE]->dbtype,$this->project_module_parameters[TABLE_MODULE]->dbtype))
			    		&&(!strcmp($this->core_module_parameters[TABLE_MODULE]->dbname,$this->project_module_parameters[TABLE_MODULE]->dbname))
			    			&&(!strcmp($this->core_module_parameters[TABLE_MODULE]->host,$this->project_module_parameters[TABLE_MODULE]->host)))
			    	// Only one connection to DB
			    	$this->table_core =& $this->table;
			    elseif (!$this->table_core = new table($this->core_module_parameters[TABLE_MODULE]))
			    	{
			    		$this->core_error = TRUE;
						return DB_INIT_ERROR;
			    	}
			    	else
			    	{
						$this->_results = &$this->table_core->results;
						$this->_count = &$this->table_core->count;
						$this->_empty_result = &$this->table_core->empty_result;
			    	}
*/
			}

			// Retrieve actual script_id value and set the correct core database
			if ($this->script_type = $this->get_script_options())
			{
				// Always retrieve non core parameters then (eventually) core parameters
				$this->bring_me_to_life(LYBRA_NON_CORE_MODE);
				// Common parameters will be overwritten with core version
				$this->bring_me_to_life(LYBRA_CORE_MODE);
			}
			else
				// Always retrieve non core parameters then (eventually) core parameters
				$this->bring_me_to_life(LYBRA_NON_CORE_MODE);
			// Retrieve project parameters
			$this->retrieve_project_parameters();
			
			/***************************************************************************************
			 *						 SPECIAL INIT FOR DB_DataObject								   *
			 ***************************************************************************************/
			// this  the code used to load and store DataObjects Configuration. 
    		$options = &PEAR::getStaticProperty('DB_DataObject','options');

    		// the simple examples use parse_ini_file, which is fast and efficient.
    		// however you could as easily use wddx, xml or your own configuration array.
    		//$config = parse_ini_file('example.ini',TRUE); 
    		// no .ini used, implement table and keys in each extended class

    		// because PEAR::getstaticProperty was called with and & (get by reference)
    		// this will actually set the variable inside that method (a quasi static variable)
    		//$options = $config['DB_DataObject'];

    		$options = array(
    			'database'         => $this->table->dsn,
    			'schema_location'  => 'pear/DB/DataObjects',
    			'class_location'   => 'pear/DB/DataObjects',
    			'require_prefix'   => 'DataObjects/',
    			'class_prefix'     => 'DataObjects_');

			// Wake-up all active core-modules (except table)
			$active_modules = $this->activate_core_modules($this->script_id,$use_init_values,3);

			// Language after session
			// Base varname for language paths
			$varname = "par_language_file_";
			$help_varname = $this->par_language_get_varname;

			if ($this->init_values[LANGUAGE_MODULE])
			{
				$hlp = $this->par_language_session_varname;
			    // Look into GET variables for specific language request
			    if (isset($this->GET[$this->par_language_get_varname]))
			    {
					$this->$help_varname = $this->GET[$this->par_language_get_varname];
					// Compose varname that stores language file to include
					$varname .= $this->GET[$this->par_language_get_varname];
					// GET variable override session value
					// Save value into session or into this instance
					if ($this->init_values[SESSION_MODULE])
					// Override session variable
						$this->register($this->par_language_session_varname,$this->GET[$this->par_language_get_varname]);
					// Store current language value into this instance
					$this->$hlp = $this->GET[$this->par_language_get_varname];
			    }
			    // Check for session variables
			    elseif (strcmp($this->session_get($this->par_language_session_varname),""))
			    {
					$this->$help_varname = $this->session_get($this->par_language_session_varname);
					// Use session language value
					$varname .= $this->session_get($this->par_language_session_varname);
					// Store current language value into this instance
					$this->$hlp = $this->session_get($this->par_language_session_varname);
			    }
			    else
			    {
					// Use default language
					$varname .= $this->par_default_language;
					// Store current language value into this instance
					$this->$hlp = $this->par_default_language;
					if ($this->init_values[SESSION_MODULE])
					// Override session variable
						$this->register($this->par_language_session_varname,$this->par_default_language);
			    }
			    // Needed by SQL dynamic evaluation
			    $this->language_id =& $this->session_get($this->par_language_session_varname);
			}
			// Import language file if active
			if ($this->par_language_file_active)
			    @include_once($this->par_main_path.$this->$varname);

			// Script access tests (authorization_manager module) only if active
			if (($this->modules_istances[LYBRA_AUTHORIZATION_MANAGER_MODULE])&&(!$this->authorize(LYBRA_ACCESS_SCRIPT,LYBRA_OBJECT_TYPE_SCRIPT,$this->script_id)))
			{
				print "CANNOT ACCESS THIS SCRIPT";
				exit;
			}
			    
			// Auto template activation
			if ($this->par_tem_autorun)
				// Activate auto template
				$this->set_auto_template($this->script_id,STATIC_TEMPLATE,EVENTS_SCHELETON_INIT);
			if ($this->par_tem_autorun_connect)
				// Activate auto template for script connection
				$this->set_auto_template_connect($this->script_name,EVENTS_SCHELETON_INIT);
			// Execute event-driven methods
			$this->auto_submit_method_calls($this->script_id,EVENTS_SCHELETON_INIT);
			return LYBRA_CORE_INIT_OK;
		}
		
		// }}}
		// {{{ get_script_options
		/**
		 * Retrieve information about actual script
		 *
		 * @access private
		 *
		 * @return int	0 if project script, 1 if core script
		 **/
		function get_script_options()
		{
			if ($this->script_name == "")
				return ALL_SCRIPTS;
			$select = "SELECT ".LYBRA_SCRIPT_ID_FIELD.",".SCRIPT_PROTECTED_FIELD.",".LYBRA_SCRIPT_NON_CORE_FIELD.
								" FROM ".LYBRA_SCRIPTS_TABLE.
								" WHERE ".SCRIPT_NAME_FIELD."='".addslashes($this->script_name)."'";
			// Starts looking into core scripts
			print_("AM I CORE '$select'","SCRIPT_OPTIONS");
			$this->retrieve($select);
			if (!$this->empty_result)
			{
				$this->script_id = $this->results[0][0];
				$this->script_protected = $this->results[0][1];
				$this->core_script = !$this->results[0][2];
			}
			else
			{
				$this->script_id = ALL_SCRIPTS;
				$this->script_protected = FALSE;
				$this->core_script = 0;
			}
			// Return script type (if not found at all suppose to be an unspecified core script)
			return $this->core_script;
		}

		// }}}
		// {{{ activate_core_modules

		/**
		 * Activate all core modules
		 *
		 * @access private
		 *
		 * @script_id int this script id
		 * @use_init_values bool use $this->init_values to find modules to activate (instead of database flag)
		 *
		 * @return void
		 */
		function activate_core_modules($script_id,$use_init_values=FALSE)
		{
			print_("INIT VALUES '".($use_init_values?"TRUE":"FALSE")."'");
			// Retrieve all entries from module table
			$select = "SELECT ".LYBRA_MODULES_CLASS_NAME.",".LYBRA_PARAMETERS_MODULE_ID.",".LYBRA_MODULES_FACTORY_INIT.","
						.LYBRA_MODULES_ACTIVE_FIELD." FROM "
						.LYBRA_MODULES_TABLE." WHERE ".LYBRA_MODULES_AUTO_ISTANTIATE."=1 ". // AND ".LYBRA_MODULES_ACTIVE_FIELD."=1".
						" ORDER BY ".LYBRA_MODULES_ORDER_FIELD;
			print_("SELECT '$select'","LIFE");
			$this->retrieve($select);

			if (!$this->empty_result)
			    // Loop on all results
			    for ($i=0;$i<$this->count;$i++)
			    {
					$class_name = $this->results[$i][0];
					print_($i."|".$class_name,"CLASS_NAME");
					if (!strcmp($class_name,""))
						// Not a module to istantiate
						continue;
					// Do not activate by default
					$active = false;
					// If activate using init_values check the module ID
					if (($use_init_values)&&($this->init_values[$this->results[$i][1]]))
						$active = true;
					if ((!$use_init_values)&&($this->results[$i][3]))
					{
						$active = true;
						$this->init_values[$this->results[$i][1]] = ON;
					}
					else
						$this->init_values[$this->results[$i][1]] = OFF;
					if (!class_exists($class_name))
					{
						print_("NON CLASS '$class_name'");
						$this->core_error(LYBRA_ERROR_MODULE_ACTIVATION,$class_name);
					}
					// Checks if I can call directly the constructor or I have to call a interface from abstract factory
					if ($active)
					{
						//print_r($this->results[$i]);
						if ($this->results[$i][2])
						{	
							// Calls an init interface from abstract factory (usually for third party modules. Ex: PEAR::Auth)
							$init = $class_name."_init";
							$this->$init($class_name,(isset($this->core_module_parameters[$this->results[$i][1]])?$this->core_module_parameters[$this->results[$i][1]]:""));
						}
						else
						{
							$empty = "";
							// Istantiate the module passing to it parameters (retrieved during bring_me_to_life)
							if (isset($this->core_module_parameters[$this->results[$i][1]]))
								$this->$class_name = new $class_name($this->core_module_parameters[$this->results[$i][1]]);
							else
								$this->$class_name = new $class_name($empty);
							$this->modules_istances[$this->results[$i][1]] =& $this->$class_name;
				    		$this->modules_istance_names[$this->results[$i][1]] = $class_name;
						}
			    	}
					// Set the module as active
			    	$this->set_module_as_active($this->results[$i][1]);
			    }
		}

		// }}}
		// {{{ set_module_as_active

		/**
		 * Set module as active (unactive by default)
		 *
		 * @access private
		 *
		 * $module_id int id of the module to set as active
		 *
		 * @return void
		 */	
		function set_module_as_active($module_id)
		{
			$this->active_modules[$module_id] = 1;
		}

		// }}}
		// {{{ is_module_active

		/**
		 * Find out if a module is active
		 *
		 * @access private
		 *
		 * $module_id int is of the module to look for
		 *
		 * @return bool true if active false otherwise
		 */	
		function is_module_active($module_id)
		{
			return $this->active_modules[$module_id];
		}
		

		// }}}
		// {{{ core_error

		/**
		 * Signal a core_error, stores attributes
		 *
		 * @access private
		 *
		 * $active bool if true retrieve only active modules, otherwise all of them
		 *
		 * @return array names of the modules classes
		 */		
		function core_error($error_code,$error_datails,$warning=FALSE)
		{
			$this->core_error = $error_code;
			$this->core_error_details[$error_code] = $error_datails;
			if (TRUE) // ($this->fatal_errors[$error_code]) FIXME: Implement fatal_errors 
			{
				if ((!isset($this->lybra_output_error))||($this->lybra_output_error))
					if (!$warning)
					{
						print "<br><b>LYBRA CORE ERROR (".$this->core_error.") MESSAGGE (".$this->get_error_message($this->core_error).") DETAILS (".$error_datails.")</u><br>";
						exit;
					}
					else
						print_("CORE WARNING","LYBRA CORE WARNING (".$this->core_error.") MESSAGGE (".$this->get_error_message($this->core_error).") DETAILS (".$error_datails."))");
			}
		}
		
		// }}}
		// {{{ render()
		
		/**
		 * Render the requested template or output the print buffer
		 *
		 * @access public
		 *
		 * $page string identify the template to render
		 * $output_mode bool, if false output a template, otherwise output the print buffer
		 *
		 * @return bool true of success false otherwise
		 */
		function render($page,$output_mode=false)
		{
		    if ($this->par_tem_autorun)
				// Activate auto template
				$this->set_auto_template($this->script_id,STATIC_TEMPLATE,EVENTS_SCHELETON_RENDER);
		    // Verifica se e' richiesta l'assegnazione automatica dei tag-template dinamici
		    if ($this->par_tem_autorun_dynamic)
				// Activate dynamic auto template
				$this->set_auto_template($this->script_id,DYNAMIC_TEMPLATE,EVENTS_SCHELETON_RENDER);
		    // Verifica se e' richiesta l'assegnazione automatica dei tag-template dinamici di connessione
		    if ($this->par_tem_autorun_connect_dynamic)
				// Activate auto template for script connection
				$this->set_auto_template_connect($this->script_id,EVENTS_SCHELETON_RENDER);
			// Execute event-driven methods
			$this->auto_submit_method_calls($this->script_id,EVENTS_SCHELETON_RENDER);
			// Render subtemplates and associate them to main templates
			$this->set_auto_template_subtemplates($this->script_name);
			if (DEBUG_ON)
				print_("DEBUGGING ENDS HERE","DEBUGGING ENDS HERE","GREEN");
		    // Se il modulo template e' attivo
		    if ($this->init_values[TEMPLATE_MODULE])
		    {
				// Automatic sub-template render, loop on correct array
				//while (list($value,$key) = each($this->parse_into_array))
					// $this->parse($value,$key,true);
				if ($output_mode)
			    	return $this->pparse_return("final-page",$page);
				else
					// FIXME: old functionality, to remove (not subtemplating is controlled by single tag_template entries
			    	$this->pparse("final-page",$page);
		    }
		    elseif (strcmp($this->print_buffer,""))
			{
				print $this->print_buffer;
			}
			else
			{
				print "<!-- NOTHING TO SHOW, NO TEMPLATE SYSTEM ACTIVE, PRINTBUFFER EMPTY -->";
			}
		    return true;
		}

		// }}}
		// {{{ action()

		/**
		 * Business logic repository, do automatic business logic calls
		 *
		 * @access public
		 *
		 * @return bool true
		 */
		function action()
		{
			// Execute event-driven methods
			$this->auto_submit_method_calls($this->script_id,EVENTS_SCHELETON_ACTION);
			if ($this->par_tem_autorun)
				// Activate auto template
				$this->set_auto_template($this->script_id,STATIC_TEMPLATE,EVENTS_SCHELETON_ACTION);
			// Auto-assign tag-template associated to SQL queries relative to script connections
			if ($this->par_tem_sql_autorun)
				$this->set_auto_template_visual($this->script_id);
			return "mainpage";
		}

		// }}}
		// {{{ get_status()

		/**
		 * Return core status
		 *
		 * @access public
		 *
		 * @return bool true
		 */
		function get_status()
		{
			return $this->core_status;
		}

		// }}}
		// {{{ get_status_msg()

		/**
		 * Return string message associated to $status_code
		 *
		 * @access protected
		 *
		 * @return string messagge associated to specified status
		 */
		function get_status_msg($status_code="")
		{
			if ($status_code="")
				$status_code = $this->get_status();
			if (isset($this->core_messages[$status_code]))
				return $this->core_messages[$status_code][$this->language_varname];
			return $this->core_messages[UNDEFINED_STATUS_MSG][$this->language_varname];
		}

		// }}}
		// {{{ bring_me_to_life()

		/**
		 * Retrieve parameters from database (only about active modules)
		 *
		 * @access private
		 *
		 * @return bool true on success false otherwise
		 */
		function bring_me_to_life($mode)
		{
			// Select all parameters to retrieve
			$select = "SELECT P.".LYBRA_PARAMETERS_MODULE_ID.
							",P.".LYBRA_MODULE_PARAMETERS_PARAM_NAME_FIELD.
							",P.".LYBRA_MODULE_PARAMETERS_PARAM_VALUE.
							",P.".LYBRA_SEND_TO_MODULE_FIELD.
							",P.".LYBRA_PARAMETERS_SUFFIX_PARAMETER_ID.
							",P.".LYBRA_PARAMETERS_PREFIX_PARAMETER_ID.
							",P.".LYBRA_PARAMETERS_PARAMETER_ID.
							" FROM ".LYBRA_PARAMETERS_TABLE." P,".LYBRA_MODULES_TABLE." M ".
								" WHERE P.".LYBRA_PARAMETERS_MODULE_ID."=M.".LYBRA_PARAMETERS_MODULE_ID.
									" AND M.".LYBRA_MODULES_ACTIVE_FIELD."=1 and (".LYBRA_PARAMETERS_SCRIPT_ID."='".LYBRA_ALLSCRIPT_VALUE."' ".
									" OR ".LYBRA_PARAMETERS_SCRIPT_ID."='".$this->script_id."')".
									" AND ".LYBRA_PARAMETERS_CORE_FIELD."=$mode ";
			print_("$select","PARAMETERS");
			$this->retrieve($select);
			if (!$this->empty_result)
			{
				// Save parameter positions by parameter_id, usefull to build composed parameters
				for ($i=0;$i<$this->count;$i++)
					$this->_lybra_parameters_idx[$this->results[$i][6]] = $i;
			    // Loop again
			    for ($i=0;$i<$this->count;$i++)
			    {
			    	// Compose value
			    	$value = $this->results[$i][2];
			    	// Check prefix
			    	if ($this->results[$i][5]!=LYBRA_PARAMETER_PREFIX_NOT_PRESENT)
			    		$value = $this->results[$this->_lybra_parameters_idx[$this->results[$i][5]]][2].$value;
			    	// Check suffix
			    	if ($this->results[$i][4]!=LYBRA_PARAMETER_SUFFIX_NOT_PRESENT)
			    		$value .= $this->results[$this->_lybra_parameters_idx[$this->results[$i][4]]][2];
					// Retrieve parameter name
					$varname = $this->results[$i][1];
					// Check send_to_module directive (=0 only to core, =1 also to module, =2 only to module)
					if ($this->results[$i][3]!=LYBRA_SEND_TO_MODULE_ONLY_TO_MODULE)
						$this->$varname = $value;
					// Send to module if send_to_module != 0
					if ($this->results[$i][3]!=LYBRA_SEND_TO_MODULE_ONLY_CORE)
					{
						// Checks if this is the fist parameters for the parameter's module
						if (!isset($this->core_module_parameters[$this->results[$i][0]]))
							$this->core_module_parameters[$this->results[$i][0]] = new param_container();
						// If requested send the variable to module parameters
						$this->core_module_parameters[$this->results[$i][0]]->$varname = $value;
						print_("ADDED '".$this->results[$i][1]."' VALUE '".$value."' MODULE '".$this->results[$i][0]."'");
					}
				}
			}
			// FIXME: To move in pre-creation function for (smarty) template module
			// Retrieve data about templates to use (if not previously assigned)
			if (!isset($this->parameters["templateArray"]))
			{

			    $select = "SELECT ".LYBRA_SCRIPT_TEMPLATES_TEMPLATE_FILE_FIELD.",".
			    	LYBRA_SCRIPT_TEMPLATES_TEMPLATE_LABEL_FIELD.",".
					LYBRA_SCRIPT_TEMPLATES_SCRIPT_ID_FIELD.",".LYBRA_SCRIPT_TEMPLATES_PARSE_INTO_FIELD.
					" FROM ".LYBRA_SCRIPT_TEMPLATES_TABLE.
					" where ".LYBRA_SCRIPT_TEMPLATES_SCRIPT_ID_FIELD."='".$this->script_id."' or ".
					LYBRA_SCRIPT_TEMPLATES_SCRIPT_ID_FIELD."='".LYBRA_ALLSCRIPT_VALUE."' ".
					" ORDER BY ".LYBRA_SCRIPT_TEMPLATES_PRIORITY_FIELD;

				$this->retrieve($select);
				print_("TEMPLATE PARAMS '$select' found nr. '".$this->count."'<br>");
			    if (!$this->empty_result)
					// Loop on results
					for ($i=0;$i<$this->count;$i++)
					{
						print_("(".$this->results[$i][1].")='".$this->results[$i][0]."'","TEMPLATE");
						print_("(".$this->results[$i][1].",".$this->results[$i][0].")","ASSIGN TO TEMPLATE");
						$this->parameters["templateArray"][$this->results[$i][1]] = $this->results[$i][0];
						//  Store hidden template destination
						// FIXME: old functionality, to remove (not subtemplating is controlled by single tag_template entries
						if (strcmp($this->results[$i][3],""))
							$this->parse_into_array[$this->results[$i][3]] = $this->results[$i][1];
					}
			}
		}

		// }}}
		// {{{ layersmenu_add_istance_parameters()

		// }}}
		// {{{ retrieve_project_parameters()

		/**
		 * Retrieve parameters relative to projects and save them into the correct location
		 *
		 * @access private
		 *
		 * @return void
		 */		
		function retrieve_project_parameters()
		{
			// Select all parameters to retrieve
			$select = "SELECT ".LYBRA_PROJECT_PARAMETERS_PARAMETER_NAME_ARRAY.
						",".LYBRA_PROJECT_PARAMETERS_PARAMETER_NAME.
						",".LYBRA_PROJECT_PARAMETERS_PARAMETER_VALUE.
						" FROM ".LYBRA_PROJECT_PARAMETERS_TABLE.
						" WHERE (".LYBRA_PROJECT_PARAMETERS_SCRIPT_ID."=".LYBRA_ALLSCRIPT_VALUE.
						" OR ".LYBRA_PROJECT_PARAMETERS_SCRIPT_ID."=$this->script_id) ".
						" AND ".LYBRA_PROJECT_PARAMETERS_ACTIVE."=".ON;

			print_("$select","PROJECT_PARAMETERS");
			$this->retrieve($select);
			if (!$this->empty_result)
			    // Loop on results
			    for ($i=0;$i<$this->count;$i++)
			    {
			    	// Save param value into param name
			    	$this->project_parameters[$this->results[$i][0]."_".$this->results[$i][1]] = $this->results[$i][2];
			    }
		}

		// }}}
		// {{{ layersmenu_add_istance_parameters()
		
		// }}}
		// {{{ set_auto_template()
		
		/**
		 * Retrieve template tags to set before/after action method and assign them
		 *
		 * @access private
		 *
		 * $script_name string name of the actual script
		 * $mode int identify the type of auto template to apply
		 * $event_id int identify the actual istant of the calling code
		 *
		 * @return void
		 */
		function set_auto_template($script_id,$mode=STATIC_TEMPLATE,$event_id=EVENTS_SCHELETON_INIT)
		{
			// FIXME: priority not respected for different $entry_type! Make it globally respected
			// Retrieve phplayersmenu
			$entry_type = 9;
			if (($mode!=STATIC_TEMPLATE)&&($this->is_module_active(LYBRA_LAYERSMENU_MODULE)))
			{
				$select = "SELECT DISTINCT A.".LYBRA_AUTOTEMPLATE_VARNAME_FIELD.
									", I.".LYBRA_PHPLAYERSMENU_NAME_FIELD.
									", M.".LYBRA_PHPLAYERSMENU_CSS_FIELD.
									", M.".LYBRA_PHPLAYERSMENU_ARROWS_DOWN.
									", M.".LYBRA_PHPLAYERSMENU_ARROWS_FORWARD.
									", M.".LYBRA_PHPLAYERSMENU_LAYER_POSITION.
									", M.".LYBRA_PHPLAYERSMENU_TEMPLATE.
									", M.".LYBRA_PHPLAYERSMENU_SUB_TEMPLATE.
									", M.".LYBRA_PHPLAYERSMENU_VISIBILITY.
									", M.".LYBRA_PHPLAYERSMENU_ABSCISSA_STEP.
									", M.".LYBRA_PHPLAYERSMENU_MENU_FORMAT.
									", I.".LYBRA_PHPLAYERSMENU_TYPE_FIELD.
									", I.".LYBRA_PHPLAYERSMENU_REPOSITORY_FIELD.
									", I.".LYBRA_PHPLAYERSMENU_LABEL_FIELD.
							" FROM ".LYBRA_AUTOTEMPLATE_TABLE." A,".LYBRA_PHPLAYERSMENU_PARAMETERS_TABLE." M,".
										LYBRA_PHPLAYERSMENU_ISTANCE_TABLE." I,".
										LYBRA_AUTO_TEMPLATE_SCRIPT_ASSOC." SA,".
										LYBRA_AUTO_TEMPLATE_LANG_ASSOC." LA ".
							" WHERE  A.".LYBRA_AUTOTEMPLATE_TEMPLATE_ID."=SA.".LYBRA_AUTOTEMPLATE_TEMPLATE_ID.
							" AND (SA.".LYBRA_SCRIPT_ID_FIELD."=".$this->script_id.
							" OR SA.".LYBRA_SCRIPT_ID_FIELD."=".ALL_SCRIPTS.")".
							" AND (I.".LYBRA_SCRIPT_ID_FIELD."=".$this->script_id.
							" OR I.".LYBRA_SCRIPT_ID_FIELD."=".ALL_SCRIPTS.")".
							" AND A.".LYBRA_AUTOTEMPLATE_TEMPLATE_ID."=LA.".LYBRA_AUTOTEMPLATE_TEMPLATE_ID.
//							" AND (LA.".LYBRA_SCRIPT_ID_FIELD."=".$this->script_id.
//							" OR LA.".LYBRA_SCRIPT_ID_FIELD."=".ALL_SCRIPTS.")".
							" AND (LA.".LYBRA_AUTO_TEMPLATE_LANG_ASSOC_LANG_ID."=".LYBRA_ALL_LANGUAGE." ".
							" OR LA.".LYBRA_AUTO_TEMPLATE_LANG_ASSOC_LANG_ID."=".$this->language_id.")".
							" AND A.".LYBRA_AUTOTEMPLATE_EVENT_ID_FIELD."='$event_id' ".
							" AND ".LYBRA_AUTOTEMPLATE_ENTRY_TYPE_FIELD."=".$entry_type.
							" AND ".LYBRA_AUTOTEMPLATE_ACTIVE_FIELD."=1".
							" AND LA.".LYBRA_AUTOTEMPLATE_VARVALUE_FIELD."=I.".LYBRA_PHPLAYERSMENU_NAME_FIELD.
							" AND I.".LYBRA_PHPLAYERSMENU_PARAMETER_ID_FIELD."=M.".LYBRA_PHPLAYERSMENU_PARAMETER_ID_FIELD;

				$this->retrieve($select);
				print_("SEL MENU '$select'","SEL MENU");
				$one = false;
				//print_r($this->layersmenu);
				for ($i=0;$i<$this->count;$i++)
				{
					$one = true;
					print_("FOUND '".$this->results[$i][1]."'","PHPLAYERSMENU");
					// Save phplayersmenu parameters specific for this menu istance
					$this->layersmenu->layersMenu_add_istance_parameters($this->results[$i][1],$this->results[$i][2],$this->results[$i][3],$this->results[$i][4],$this->results[$i][5],$this->results[$i][6],$this->results[$i][7],$this->results[$i][8],$this->results[$i][9]);
					// Calls menu creation, internally assigns relative tag-templates
					$this->layersmenu_makemenu($this->results[$i][1],$this->results[$i][0],$this->results[$i][10],$this->results[$i][11],$this->results[$i][12],$this->results[$i][13]);
				}
				// Header and Footer
				if ($one)
					$this->layersmenu_header_footer();

				// Retrieve html strings
				$entry_type = 8;
				$varnameHlp = $this->par_language_session_varname;
				$select = "SELECT A.".LYBRA_AUTOTEMPLATE_VARNAME_FIELD.", H.".LYBRA_HTML_STRING_FIELD.
							", LA.".LYBRA_AUTO_TEMPLATE_LANG_ASSOC_LANG_ID.
							", A.".LYBRA_AUTOTEMPLATE_INTERNAL_TYPE_FIELD.
							" FROM ".LYBRA_AUTOTEMPLATE_TABLE." A,".LYBRA_HTML_STRING." H,".
									LYBRA_AUTO_TEMPLATE_SCRIPT_ASSOC." SA,".
									LYBRA_AUTO_TEMPLATE_LANG_ASSOC." LA ".
							" WHERE SA.".LYBRA_AUTOTEMPLATE_TEMPLATE_ID."=A.".LYBRA_AUTOTEMPLATE_TEMPLATE_ID.
							" AND (SA.".LYBRA_SCRIPT_ID_FIELD."=".$this->script_id.
							" OR SA.".LYBRA_SCRIPT_ID_FIELD."=".ALL_SCRIPTS.")".
							" AND A.".LYBRA_AUTOTEMPLATE_TEMPLATE_ID."=LA.".LYBRA_AUTOTEMPLATE_TEMPLATE_ID.
							" AND (LA.".LYBRA_AUTO_TEMPLATE_LANG_ASSOC_LANG_ID."=".LYBRA_ALL_LANGUAGE." ".
							" OR LA.".LYBRA_AUTO_TEMPLATE_LANG_ASSOC_LANG_ID."=".$this->language_id.")".							
							" AND LA.".LYBRA_AUTOTEMPLATE_VARVALUE_FIELD."=H.".LYBRA_HTML_STRING_ID_FIELD.
							" AND ".LYBRA_AUTOTEMPLATE_ENTRY_TYPE_FIELD."=".$entry_type.
							" AND A.".LYBRA_AUTOTEMPLATE_EVENT_ID_FIELD."='$event_id' ".
							" AND ".LYBRA_AUTOTEMPLATE_ACTIVE_FIELD."=1".
							" AND (H.".LYBRA_HTML_STRING_LANGUAGE_FIELD."=".NO_LANGUAGE.
							" OR H.".LYBRA_HTML_STRING_LANGUAGE_FIELD."=".$this->$varnameHlp.")";
				print_("$select","SELECT_HTML_STRING");
				$this->retrieve($select);
				$this->save_result("main");
				for ($i=0;$i<$this->count_main;$i++)
				{
					print_("ASSIGN '".$this->results_main[$i][0]."' VAL '".$this->results_main[$i][1]."'","HTML_STRINGS");
				    // Check language, if this parameters if not associated to a language (NO_LANGUAGE)
				    // of is associated to the current language, assign it to template
				    if (($this->results[$i][2] == NO_LANGUAGE) || ($this->results[$i][2] == $this->$varnameHlp))
						$this->set_var($this->results_main[$i][0],$this->results_main[$i][1]);
				}
			}

			// FIXME: OTTIMIZZA - una sola query alla prima chiamata, poi le chiamate successive scorrono il vettore dei risultati
		    $select = "SELECT DISTINCT A.".LYBRA_AUTOTEMPLATE_ENTRY_TYPE_FIELD.",A.".LYBRA_AUTOTEMPLATE_VARNAME_FIELD.",LA.".LYBRA_AUTOTEMPLATE_VARVALUE_FIELD.",LA.".LYBRA_AUTO_TEMPLATE_LANG_ASSOC_LANG_ID.
					" FROM ".LYBRA_AUTOTEMPLATE_TABLE." A,".
							LYBRA_SCRIPTS_TABLE." S,".
							LYBRA_AUTO_TEMPLATE_SCRIPT_ASSOC." SA,".
							LYBRA_AUTO_TEMPLATE_LANG_ASSOC." LA ".
					" WHERE  SA.".LYBRA_AUTOTEMPLATE_TEMPLATE_ID."=A.".LYBRA_AUTOTEMPLATE_TEMPLATE_ID.
					" AND (SA.".LYBRA_SCRIPT_ID_FIELD."=".$this->script_id.
					" OR SA.".LYBRA_SCRIPT_ID_FIELD."=".ALL_SCRIPTS.")".
					" AND A.".LYBRA_AUTOTEMPLATE_TEMPLATE_ID."=LA.".LYBRA_AUTOTEMPLATE_TEMPLATE_ID.
					" AND (LA.".LYBRA_AUTO_TEMPLATE_LANG_ASSOC_LANG_ID."=".LYBRA_ALL_LANGUAGE." ".
					" OR LA.".LYBRA_AUTO_TEMPLATE_LANG_ASSOC_LANG_ID."=".$this->language_id.")".
					" AND ".LYBRA_AUTOTEMPLATE_ENTRY_TYPE_FIELD."=$mode".
					" AND A.".LYBRA_AUTOTEMPLATE_EVENT_ID_FIELD."='$event_id' ".
					" AND A.".LYBRA_AUTOTEMPLATE_ACTIVE_FIELD."=1 ".
					" ORDER BY A.".LYBRA_AUTOTEMPLATE_PRIORITY_FIELD." asc ";

		    // Retrieve entries about $script_name
		    $this->retrieve($select);
		    print_($select,"SELECT STAND");
		    if (!$this->empty_result)
			// Loop on results
			for ($i=0;$i<$this->count;$i++)
			{
			    // Retrieve instance actual language varname (needed to use $this->$... statement)
			    $varnameHlp = $this->par_language_session_varname;
			    // Check language, if this parameters if not associated to a language (NO_LANGUAGE)
			    // of is associated to the current language, assign it to template
			    if (($this->results[$i][3] == NO_LANGUAGE) || ($this->results[$i][3] == $this->$varnameHlp))
			    {
					// Retrieve parameter name
			        $varname = $this->results[$i][2];
			        // If mode dynamic and class variable name is not null
			        if ($mode==DYNAMIC_TEMPLATE)
			        	if (strcmp($this->results[$i][2],""))
						{
				    		// Use class variable value
				    		$value = $this->$varname;
						}
						else
							$value = "";
					// If mode is static and varvalue is not null
					if ($mode == STATIC_TEMPLATE)
						if (strcmp($this->results[$i][2],""))
						{
				    		// Use table value (mode STATIC)
				    		$value = $this->results[$i][2];
						}
						else
							$value = "";
					// Assign to the template
					$this->set_var($this->results[$i][1],$value);
				}
			}
		}

		// }}}
		// {{{ set_auto_template_subtemplates()

		/**
		 * Render subtemplates
		 *
		 * @access private
		 *
		 * @return void
		 */		
		function set_auto_template_subtemplates($script_name)
		{
			$select = "SELECT DISTINCT A.".LYBRA_AUTOTEMPLATE_VARNAME_FIELD.",LA.".LYBRA_AUTOTEMPLATE_VARVALUE_FIELD.",LA.".LYBRA_AUTO_TEMPLATE_LANG_ASSOC_LANG_ID.
						" FROM ".LYBRA_AUTOTEMPLATE_TABLE." A,".
							LYBRA_SCRIPTS_TABLE." S,".
							LYBRA_AUTO_TEMPLATE_SCRIPT_ASSOC." SA,".
							LYBRA_AUTO_TEMPLATE_LANG_ASSOC." LA ".
						" WHERE SA.".LYBRA_AUTOTEMPLATE_TEMPLATE_ID."=A.".LYBRA_AUTOTEMPLATE_TEMPLATE_ID.
						" AND (SA.".LYBRA_SCRIPT_ID_FIELD."=".$this->script_id.
						" OR SA.".LYBRA_SCRIPT_ID_FIELD."=".ALL_SCRIPTS.")".
						" AND A.".LYBRA_AUTOTEMPLATE_TEMPLATE_ID."=LA.".LYBRA_AUTOTEMPLATE_TEMPLATE_ID.
						" AND (LA.".LYBRA_AUTO_TEMPLATE_LANG_ASSOC_LANG_ID."=".LYBRA_ALL_LANGUAGE." ".
						" OR LA.".LYBRA_AUTO_TEMPLATE_LANG_ASSOC_LANG_ID."=".$this->language_id.")".
//						" ((S.".SCRIPT_NAME_FIELD."='$script_name' and S.".LYBRA_SCRIPT_ID_FIELD."=A.".LYBRA_SCRIPT_ID_FIELD.")
//	 					 OR (A.".LYBRA_SCRIPT_ID_FIELD."='".LYBRA_ALLSCRIPT_VALUE."')) ".
						" AND ".LYBRA_AUTOTEMPLATE_ENTRY_TYPE_FIELD."=".SMARTY_SUBTEMPLATE.
						" AND ".LYBRA_AUTOTEMPLATE_ACTIVE_FIELD."=1".
						" ORDER BY A.".LYBRA_AUTOTEMPLATE_PRIORITY_FIELD." asc ";
						
			print_("AUTO_SUBTEMPLATE: '$select'<br>");
		    // Retrieve entries about $script_name
		    $this->retrieve($select);
		    if (!$this->empty_result)
				// Loop on results
				for ($i=0;$i<$this->count;$i++)
				{
					$this->render_sub_template($this->results[$i][0],$this->par_main_path.$this->par_tem_path."/".$this->results[$i][1]);
				}
		}

		// }}}
		// {{{ set_auto_template_visual()

		/**
		 * First retrieve auto tag-template associated to smarty-sql tags.
		 * After that retrieve all auto tag-template associated to visual instances,
		 * retrieve parameters and eventually execute sql queries associated to those parameters.
		 * Call the associated method and put the returned string to the tag-template
		 *
		 * @access private
		 *
		 * $script_id id of the actual script
		 *
		 * @return void
		 */
		function set_auto_template_visual($script_id)
		{
			// Retrieve smarty sql tag-template
			$entry_type = 7;
			$select = "SELECT A.".LYBRA_AUTOTEMPLATE_VARNAME_FIELD.",LA.".LYBRA_AUTOTEMPLATE_VARVALUE_FIELD.",".
						"A.".LYBRA_AUTOTEMPLATE_CARDINALITY_FIELD.",A.".LYBRA_AUTOTEMPLATE_INTERNAL_TYPE_FIELD.
						" FROM ".LYBRA_AUTOTEMPLATE_TABLE." A,".
								LYBRA_AUTO_TEMPLATE_SCRIPT_ASSOC." SA,".
								LYBRA_AUTO_TEMPLATE_LANG_ASSOC." LA ".
						" WHERE SA.".LYBRA_AUTOTEMPLATE_TEMPLATE_ID."=A.".LYBRA_AUTOTEMPLATE_TEMPLATE_ID.
						" AND (SA.".LYBRA_SCRIPT_ID_FIELD."=".$this->script_id.
						" OR SA.".LYBRA_SCRIPT_ID_FIELD."=".ALL_SCRIPTS.")".
						" AND A.".LYBRA_AUTOTEMPLATE_TEMPLATE_ID."=LA.".LYBRA_AUTOTEMPLATE_TEMPLATE_ID.
						" AND (LA.".LYBRA_AUTO_TEMPLATE_LANG_ASSOC_LANG_ID."=".LYBRA_ALL_LANGUAGE." ".
						" OR LA.".LYBRA_AUTO_TEMPLATE_LANG_ASSOC_LANG_ID."=".$this->language_id.")".
//						" AND (".LYBRA_SCRIPT_ID_FIELD."=".$script_id.
//						" OR ".LYBRA_SCRIPT_ID_FIELD."=".ALL_SCRIPTS.")".
						" AND ".LYBRA_AUTOTEMPLATE_ENTRY_TYPE_FIELD."=".$entry_type.
						" AND ".LYBRA_AUTOTEMPLATE_ACTIVE_FIELD."=1";
			$this->retrieve($select);
			$this->save_result("main");
			print_("$select","SMARTY_SQL");
			for ($i=0;$i<$this->count_main;$i++)
			{
				// Assegna ai tag di tipo SMARTY_SQL_TEMPLATE
				// Do the query only if not jet done or if done but with another mode
				if (!$this->sql_done($this->results_main[$i][1],$this->results_main[$i][3]))
				//||($this->sql_done_mode($this->results_main[$i][1])!=$this->results_main[$i][3]))
				{
					print_("FAI QUERY '".$this->results_main[$i][1]."' mode '".$this->results_main[$i][3]."'");
					// La query non e' stata ancora eseguita (o eseguita con mode diverso), va quindi recuperata, eseguita e salvata prima di procedere
					$this->execute_sql($this->results_main[$i][1],$this->results_main[$i][3]);
					// Make another reference to the same sql cache
					$this->{LYBRA_SQL_CACHE_PREFIX."_".$this->results_main[$i][0]} =& $this->{"results_".LYBRA_SQL_CACHE_PREFIX.$this->results_main[$i][1]};
				}
				$hlp = "results_".LYBRA_SQL_CACHE_PREFIX.$this->results_main[$i][1];
				// FIXME: max_cardinality not used jet. Find a way to use it to dinamically limit the max amount of elements
				//		exploded by smarty section tag
				// Set the max field into the smarty section
				$this->set_var($this->results_main[$i][0]."_max",$this->results_main[$i][2]);
				// Send also the amount of records
				$hlp2 = "count_".LYBRA_SQL_CACHE_PREFIX.$this->results_main[$i][1];
				$this->set_var($this->results_main[$i][0]."_count",$this->$hlp2);
				// Substitute values inside section
				$this->set_var($this->results_main[$i][0],$this->$hlp);
			}
			$entry_type = 2;
		    // Needed to retrieve all automatic template entries connected to sql queries 
		    // (visual istances)
		    $select = "SELECT V.".VISUAL_ISTANCE_ID_FIELD.
					" ,M.".LYBRA_METHOD_ID_FIELD.
					" ,M.".LYBRA_MODULE_ID_FIELD.
					" ,M.".LYBRA_METHOD_NAME_FIELD.
					" ,A.".LYBRA_AUTOTEMPLATE_ENTRY_TYPE_FIELD.
					" ,A.".LYBRA_AUTOTEMPLATE_VARNAME_FIELD.
					" FROM ".LYBRA_AUTOTEMPLATE_TABLE." A,".
							VISUAL_ISTANCES_TABLE." V,".
							LYBRA_METHODS_TABLE." M,".
							LYBRA_AUTO_TEMPLATE_SCRIPT_ASSOC." SA,".
							LYBRA_AUTO_TEMPLATE_LANG_ASSOC." LA ".
					" WHERE SA.".LYBRA_AUTOTEMPLATE_TEMPLATE_ID."=A.".LYBRA_AUTOTEMPLATE_TEMPLATE_ID.
						" AND (SA.".LYBRA_SCRIPT_ID_FIELD."=".$this->script_id.
						" OR SA.".LYBRA_SCRIPT_ID_FIELD."=".ALL_SCRIPTS.")".
						" AND A.".LYBRA_AUTOTEMPLATE_TEMPLATE_ID."=LA.".LYBRA_AUTOTEMPLATE_TEMPLATE_ID.
						" AND (LA.".LYBRA_AUTO_TEMPLATE_LANG_ASSOC_LANG_ID."=".LYBRA_ALL_LANGUAGE." ".
						" OR LA.".LYBRA_AUTO_TEMPLATE_LANG_ASSOC_LANG_ID."=".$this->language_id.")".
						" AND A.".LYBRA_AUTOTEMPLATE_ENTRY_TYPE_FIELD."=".VISUAL_ISTANCE_TEMPLATE.
						" AND LA.".LYBRA_AUTOTEMPLATE_VARVALUE_FIELD."=V.".VISUAL_ISTANCE_ID_FIELD.
						" AND V.".LYBRA_METHOD_ID_FIELD."=M.".LYBRA_METHOD_ID_FIELD.
						//" AND (A.".LYBRA_SCRIPT_ID_FIELD."=".$script_id.
						//" OR A.".LYBRA_SCRIPT_ID_FIELD."=".ALL_SCRIPTS.")".
						" AND A.".LYBRA_AUTOTEMPLATE_ACTIVE_FIELD."=1";
		    $this->retrieve($select);
			print_("SELECT AUTO_TEMPLATE_SQL_VISUAL: '$select'<br>FOUND '".$this->count."'ELEMENTS<br>","VISUAL ISTANCE RETRIEVE");
			// Save resulting query cause other queries could be executed inside loops
		    $this->save_result("main");
		    if (!$this->empty_result_main)
		    {
		    	//******************************************* FOR TEMPLATE ISTANCES
				// Loop all over visual istances to create
				for ($i=0;$i<$this->count_main;$i++)
				{
					if ($this->results_main[$i][4]==SMARTY_SQL_TEMPLATE)
					{
						// Assegna ai tag di tipo SMARTY_SQL_TEMPLATE
						if (!$this->sql_done($this->results_main[$i][2]))
							// La query non � stata ancora eseguita, va quindi recuperata, eseguita e salvata prima di procedere
							$this->execute_sql($this->results_main[$i][2]);
						$hlp = "results_".LYBRA_SQL_CACHE_PREFIX.$sql_id;
						$this->set_var($this->results_main[$i][5],$this->$hlp);
						$this->sql_template[$i] = &$this->$hlp;
					}
					else
					{
				    	// Recupera dal quarto elemento della query con risultato result_main il valore dopo la 
				    	// stringa $this->ce__param_template_autoset_templatevarvalue_istance
						// la stringa recuperata costituisce la variabile di istanza a cui assegnare l'html costruito
				    	$istance_variable = "out_string".$this->results_main[$i][0];
				    	// Recupera tutti i parametri associati alla visual istance in questione
						$select = "SELECT ".VISUAL_ISTANCE_PARAMETERS_POSITION_FIELD.
							", ".VISUAL_ISTANCE_PARAMETERS_OPTIONAL_FIELD.
							", ".VISUAL_ISTANCE_PARAMETERS_VALUE_FIELD.
							", ".VISUAL_ISTANCE_PARAMETERS_PARAMETER_TYPE_ID_FIELD.
							", ".SQL_ID_FIELD.
							", ".VISUAL_ISTANCE_PARAMETERS_SQL_FIELDS_FIELD.
							", ".VISUAL_ISTANCE_PARAMETERS_VARIABLE_NAME_FIELD.
							", ".VISUAL_ISTANCE_PARAMETERS_PARAMETER_SET_ID_FIELD.
							" FROM ".VISUAL_ISTANCE_PARAMETERS_TABLE.
					    	" WHERE ".VISUAL_ISTANCE_ID_FIELD."='".$this->results_main[$i][0]."' ".
					    	" ORDER BY ".VISUAL_ISTANCE_PARAMETERS_POSITION_FIELD;
				    	
					    $this->retrieve($select);
						$this->save_result("params");
						print_("RECUPERA VISUAL ISTANCE PARAMETRI '$select'<br>");
						// Prepara la chiamata al metodo associato al visual object 
						// (necessario per realizzare la visual istance associata alla query sql)
						// SOSTITUIRE ->html con il nome del metodo con id results_mail[$i][2]
						// Recupera il nome della variabile che contiene l'istanza del modulo a cui appartiene il metodo da invocare
						$tmp = $this->modules_istance_names[$this->results_main[$i][2]];
						print_("METHOD_NAME '".$this->results_main[$i][3]."'<br>");
						$call = "\$this->".$tmp."->".$this->results_main[$i][3]."(";
						if (!$this->empty_result_params)
						{
							// By default don't add the array with field numbers to the method calls
							// (needed by called methods to find the correct field number inside
							// query results passed by reference
							$this->add_sql_fields_array = false;
							$this->sql_fields_array = array();
							$sep = "";
							// used to save help arrays
							$help_index = 0;
							//************************************************* FOR PARAMETRI
							// Scorre tutti i parametri recurati per la visual
							// istance in questione (indice $i è la variabile)
				    		for ($j=0;$j<$this->count_params;$j++)
			    			{
					    			// Controlla se questo parametro è legato ad una query
									if ($this->results_params[$j][7]==VARSET_SQL_FIELD)
									{
										//********************************** PARAMETER IS A FIELD OF A QUERY
										// PARAMETRO LEGATO AD UNA QUERY SQL
										// sql fields index must be passed to method
										$this->add_sql_fields_array = true;
										// Aggiungi nel vettore degli indici (che potrebbe esser utilizzato o meno) le posizioni (all'interno delle rispettive query) dei parametri associati all'indice del vettore
										$this->sql_fields_array[$j] = $this->results_params[$j][5];
										$sql_id = $this->results_params[$j][4];
										$saved_cache = LYBRA_SQL_CACHE_PREFIX.$sql_id;
										$sql_field = $this->results_params[$j][5];
										// Controlla se la query con id $this->results_params[0][4] � gi� stata fatta o meno
										if (!$this->sql_done($sql_id))
											// La query non è stata ancora eseguita, va quindi recuperata, eseguita e salvata prima di procedere
											$this->execute_sql($this->results_params[$j][4]);
										// Extract row at position $sql_id (from 0) from related query
										$help_index += 1;
										$help_array = "help_ar_$help_index";
										print_("($j) PARAMETER_ID '".$this->results_params[$j][3]."'<br>");
										// Controlla il tipo di parametro per costruire correttamente la variabile da passare al metodo
									    if (($this->results_params[$j][3]==ARRAY_PARAM)||($this->results_params[$j][3]==HASH_PARAM))
									    {
											// Il parametro da passare è un HASH on un ARRAY
											unset($base_help_array);
											// FIXME: i risultati dalla query escono in matrice riga per colonna, qui viene estratta
											// la colonna con il campo di interesse (bisognerebbe recuperare i dati dal database direttamente)
											// ATTENZIONE: se le funzioni però sono fatte per ricevere il risultato della query allora non ci sono problemi!
											// colonna per colonna
											// Variabili di aiuto per accedere al risultato corretto
											$count_hlp = "count_".$saved_cache;
											$result_help = "results_".$saved_cache;
											print_("ELEMENTO TROVATI NELLA QUERY ($sql_id) SONO (".$this->$count_hlp.")");
											$call .= $sep ."\$this->$result_help";
										}
										else // Tipo NON HASH E NON ARRAY (parametro legato a query sql)
										{
											// Parametro di tipo: INT o FLOAT o STRING o FLAG (???)
											$hlp = "results_".LYBRA_SQL_CACHE_PREFIX.$sql_id;
											print_("PARAMETRO \"STRINGA\" LEGATO AD SQL FIELD '".$this->results_sql_cache_2[0][0]."'<br>");
											$call .= "$sep\$this->".$hlp."[0][".$this->results_params[$j][5]."]";
										}
									}
									//************************************************* PARAMETRI LEGATI AD UNA VARIABILE DI CLASSE
									elseif ($this->results_params[$j][7]==VARSET_CLASS)
									{
										// Il parametro è una variabile di istanza
										$variable_name = $this->results_params[$j][6];
										// Add parameter to string
										$call .= $sep."\$this->$variable_name";
									}
									else
									{ 
										print_("PARAMETRO ESPLICITO TYPE '".$this->results_params[$j][3]."'<br>");
										// FIXME: MANCANO I CASI PER VARIABILI GET, POST E DI SESSIONE
										//*****************************	****************************** PARAMETER IS AN EXPLICIT VALUE
								    	// Il parametro è un valore esplicito
								    	if (($this->results_params[$j][3]==ARRAY_PARAM)||($this->results_params[$j][3]==HASH_PARAM))
								    	{
											// Crea un array con un solo valore non essendo collegato questo parametro ad una query sql
											$help_index+=1;
											unset($base_help_array);
											$help_array = "help_ar_$help_index";
											$base_help_array[0] = $this->results_params[$j][2];
											$$help_array =& $base_help_array;
											$call .= $sep."\$help_ar_$help_index";
								    	}
								    	else
								    	{
								    		print_("EXPLICIT STRING '".$this->results_params[$j][2]."'");
											// Add as simple value
											$call .= $sep."\$this->results_params[$j][2]";
								    	}
									}
								$sep = ",";
			    			}
			    			// Add sql field array if needed
			    			if ($this->add_sql_fields_array)
								$call .= $sep."\$this->sql_fields_array";
			    			$call .= ");";
							// Expression to evaluate
							print_("EVALUATING: '\$this->$istance_variable = $call'<br>");
							// eval("\$this->$istance_variable = $call");
							eval("\$hlp = $call");
							print_("HELP '$hlp'","HELP");
						} // end if parametri trovati
						print_("ASSEGNA A '".$this->results_main[$i][4]."' VALORE '$hlp'<br>");
						$this->set_var($this->results_main[$i][5],$hlp);
					}
				} // End del for tag-template collegati a istanze visuali
			} // end if istanze trovate
			return true;
		} // end funzione

		// }}}
		// {{{ set_auto_template_connect()
		
		/**
		 * Retrieve template tags to set before/after action method and assign them (relative to script_connect)
		 *
		 * @access private
		 *
		 * $script_name string name of the actual script
		 * $event_id int identify the actual istant of the calling code
		 *
		 * @return void
		 */
		function set_auto_template_connect($script_name,$event_id=EVENTS_SCHELETON_ACTION)
		{
		    $select = "SELECT S2.".SCRIPT_NAME_FIELD.",C.".SCRIPT_CONNECT_LANGUAGE_FIELD.
						",T.".LYBRA_AUTOTEMPLATE_VARNAME_FIELD.",C.".LYBRA_CONNECT_ID_FIELD.
						", C.".LYBRA_CONNECT_MODE_FIELD.
						" FROM ".LYBRA_AUTOTEMPLATE_TABLE." T,".LYBRA_SCRIPTS_TABLE." S1,".
						LYBRA_SCRIPTS_TABLE." S2,".LYBRA_SCRIPT_CONNECT_TABLE." C".
				" WHERE T.".LYBRA_AUTOTEMPLATE_ENTRY_TYPE_FIELD."=".CONNECT_TEMPLATE.
				"   AND C.".LYBRA_SOURCE_ID_FIELD."=S1.".LYBRA_SCRIPT_ID_FIELD.
				"   AND C.".LYBRA_TARGET_ID_FIELD."=S2.".LYBRA_SCRIPT_ID_FIELD.
				"   AND T.".LYBRA_SCRIPT_ID_FIELD."=".$this->script_id.
				"   AND T.".LYBRA_AUTOTEMPLATE_VARVALUE_FIELD."=C.".LYBRA_CONNECT_ID_FIELD.
				"   AND T.".LYBRA_AUTOTEMPLATE_EVENT_ID_FIELD."=$event_id".
				"   ORDER BY T.".LYBRA_AUTOTEMPLATE_PRIORITY_FIELD;
				
			print_("SELECT CONNECT '$select'","CONNECT");
		    $this->retrieve($select);
		    $this->save_result("main");

		    if (!$this->empty_result_main)
			// Loop on results
			for ($i=0;$i<$this->count_main;$i++)
			{
			    // Retrieve instance actual language varname (needed to use $this->$... statement)
			    $varname_hlp = $this->par_language_session_varname;
			    // Check language, if this parameters is not associated to a language (NO_LANGUAGE)
			    // of is associated to the current language, assign it to template
			    if (($this->results_main[$i][1] == NO_LANGUAGE) || ($this->results_main[$i][1] == $this->$varname_hlp))
			    {
/*
					// Retrieve parameter name
			        $varname = $this->results_main[$i][0];
			        // If mode dynamic and class variable name is not null
			        if (($mode==DYNAMIC_CONNECT_TEMPLATE)&&(strcmp($this->results_main[$i][0],"")))
						// Use class variable value
						$value = $this->$varname;
					// If mode is static and varvalue is not null
					if (($mode == STATIC_CONNECT_TEMPLATE)&&(strcmp($this->results_main[$i][0],"")))
				    	// Use table value (mode STATIC)
				    	$value = $this->results_main[$i][0];
*/				
				    $select = "SELECT ".CONNECT_PARAM_PARAM_NAME_FIELD.",".CONNECT_PARAM_PARAM_VALUE_FIELD.
							    ",".CONNECT_PARAMETERS_POSTGET_FIELD_NAME.",".CONNECT_PARAM_VARIABLE_SET_ID.
							    ",".CONNECT_PARAM_VARIABLE_NAME_FIELD.
						 		" FROM ".CONNECT_PARAMETERS_TABLE_NAME.
						    	" WHERE ".LYBRA_CONNECT_ID_FIELD."=".$this->results_main[$i][3];
						    	
					print_("SELECT POSTGET PARAM '$select'","POSTGET");

					// Check for parameters (GET) to construct correct link
					$this->retrieve($select);
					$param_string = "";
					$post_string = "";
					$get_string = "";
					$hidden_post_string = "";
					if (!$this->empty_result)
				    	// Loop on results
				    	$value_par = "";
				    	$sep = "";
				    	for ($j=0;$j<$this->count;$j++)
				    	{	
				    		// Verifica il tipo di variabile
				    		switch ($this->results[$j][3])
				    		{
				    			case VARSET_EXPLICIT:
				    								{
				    									// Recupera direttamente il valore dal record
				    									//$value_par .= $sep.$this->results[$j][0]."=".$this->results[$j][1];
				    									$param_value = $this->results[$j][1];
				    									$param_name = $this->results[$j][0];
				    								}break;
				    			case VARSET_CLASS:
				    								{
				    									// Nome della variabile di classe da prelevare
				    									$hlp = $this->results[$j][4];
				    									// Recupera il valore stesso accedendo direttamente alla variabile in questione
				    									//$value_par .= $sep.$this->results[$j][0]."=".$this->$hlp;
				    									$param_value = $this->$hlp;
				    									$param_name = $this->results[$j][0];
				    								}break;
				    			case VARSET_GET:
				    								{
				    									// Recupera il valore dal vettore dei GET
				    									//$value_par .= $sep.$this->results[$j][0]."=".$this->GET[$this->results[$j][4]];
				    									$param_value = $this->GET[$this->results[$j][4]];
				    									$param_name = $this->results[$j][0];
				    								}break;
				    			case VARSET_POST:
				    								{
				    									// Recupera il valore dal vettore dei POST
				    									//$value_par .= $sep.$this->results[$j][0]."=".$this->POST[$this->results[$j][4]];
				    									$param_value = $this->POST[$this->results[$j][4]];
				    									$param_name = $this->results[$j][0];
				    								}break;
				    			case VARSET_SQL_FIELD:
				    								{
														// FIXME: DA IMPLEMENTARE!
				    								}break;				    			
				    			default:break;
				    		}
				    		print_("VALUE '$param_value' NAME '$param_name'","CON VAR");
							// Do correct task on collected value & param
							switch ($this->results_main[$i][4])
							{
								case LYBRA_CONNECT_GET_MODE:
													{
														// ADD GET ENTRY TO get_string
														$get_string .= $sep.$param_name."=".$param_value;
														$sep = "&";
				    								}break;
								case LYBRA_CONNECT_POST_MODE:
												    {
												    	// ADD POST ENTRY (an input type hidden HTML tag) 
												    	$hidden_post_string .= "<a input type=hidden name='$param_name' value=\"$param_value\">";
				    								}break;
							}
						}
						// Build destination string for post mode (usually tag-template added into FORM html tag)
						// the tag-template stored in auto template table is the one inside FORM html tag,
						// the tag-template to store hidden entries (for post params) is the same as tag-template
						// with a fixed suffix (LYBRA_CONNECT_HIDDENPARAM_TAGTEMPLATE_SUFFIX)
						if ($this->results_main[$i][4]==LYBRA_CONNECT_POST_MODE)
						{
							print_("","POST MODE");
							$this->set_var($this->results_main[$i][2],$this->results_main[$i][0]);
							$this->set_var($this->results_main[$i][2].LYBRA_CONNECT_HIDDENPARAM_TAGTEMPLATE_SUFFIX,$hidden_post_string);
						}
						elseif ($this->results_main[$i][4]==LYBRA_CONNECT_GET_MODE)
						{
							print_("","GET MODE");
							// Assegna al tag-template la stringa in get
							$this->set_var($this->results_main[$i][2],$this->results_main[$i][0]."?".$get_string); //$value.$param_string);					
						}
				}
			}
		}
		
		// }}}
		// {{{ auto_submit_method_calls()
		/**
		 * Call method associated to GET/POST/SESSION values
		 * Implements EVENT-DRIVEN features
		 * 
		 * @access private
		 *
		 * @script_id int script's id
		 * @event_id int individuate the event. Specify the actual istant of the calling code
		 *
		 * @return void
		 */	
		function auto_submit_method_calls($script_id=0,$event_id=EVENTS_SCHELETON_ACTION)
		{
		    // Test if active first call method flag
		    if ($this->par_first_execute_active)
			// Test if is first call for this script
			if ($this->session_get($this->par_first_execute_variable)<2)
			{
			    // Is first call
			    $method_name = $this->par_first_execute_method_name;
			    $this->$method_name();
			}

			$select = "SELECT DISTINCT ".
						" C.".LYBRA_CONDITION_ID_FIELD.",".
						" LSA.".SUBMIT_ACTIONS_EXECUTE_METHOD_ID_FIELD.",".
						" M.".LYBRA_MODULE_ID_FIELD.",".
						" M.".LYBRA_METHOD_NAME_FIELD.
						" FROM ".LYBRA_CONDITIONS_TABLE." C,".
								SUBMIT_ACTIONS_TABLE." LSA,".
								LYBRA_METHODS_TABLE." M".
						" WHERE ((LSA.".LYBRA_SCRIPT_ID_FIELD."=$script_id) OR (LSA.".LYBRA_SCRIPT_ID_FIELD."=".LYBRA_ALLSCRIPT_VALUE.")) ".
								" AND LSA.".SUBMIT_ACTIVE_FIELD."=1 ".
								" AND M.".LYBRA_METHOD_ID_FIELD."=LSA.".SUBMIT_ACTIONS_EXECUTE_METHOD_ID_FIELD.
								" AND LSA.".SUBMIT_ACTIONS_EVENT_ID_FIELD."=$event_id ".
								" AND LSA.".SUBMIT_ACTION_CONDITION_ID_FIELD."=C.".LYBRA_CONDITION_ID_FIELD.
								" ORDER BY LSA.".SUBMIT_ACTIONS_PRIORITY_FIELD;

			print_("METHOD CALLS, SELECT: '$select'<br>","EVENT-DRIVEN");
		    $this->retrieve($select);
		    $this->save_result("event_driven");
		    if (!$this->empty_result_event_driven)
		    {
				// Usefull to test variable value
				$test[POST] =& $this->POST;
				$test[GET] =& $this->GET;
				$test[SESSION] =& $this->SESSION;
				// Loop all over method calls
				for ($i=0;$i<$this->count_event_driven;$i++)
				{
					if ($this->execute_condition_chain($this->results_event_driven[$i][0]))
			    	{
			    		print_("TEST OK <br>");
			    		$module_istance =& $this->modules_istances[$this->results_event_driven[$i][2]];
			    		$method_name = $this->results_event_driven[$i][3];
						if ($this->results_event_driven[$i][2]==FAKE_MODULE)
						{
							if (method_exists($this,$method_name))
				    			$this->$method_name();
				    		else
				    			$this->core_error(LYBRA_ERROR_AUTOMATIC_METHOD_CALL,$class_name);
						}
				    	else
				    	{
				    		print_("MODULE '$module_istance' method '$method_name'");
				    		if (method_exists($module_istance,$method_name))
				    			$module_istance->$method_name();
				    		else
				    			$this->core_error(LYBRA_ERROR_AUTOMATIC_METHOD_CALL,"CALLING METHOD '".$this->results_event_driven[$i][2]."' IN MODULE WITH ID '".$this->results_event_driven[$i][1]."'");
						}
			    	}
				}
		    }
		}
		

		
		// }}}
		// {{{ get_variable()
		/**
		 * Retrieve correct variable value depending of it's set
		 * 
		 * @access private
		 *
		 * @variable_name string name of the variable
		 * @variable_set int id of the variable set
		 *
		 * @return string variable value
		 */
		 function get_variable($variable_name,$variable_set_id)
		 {
		 	//print_("GET VAR '$variable_name' '$variable_set_id'");
			switch ($variable_set_id)
			{
				case LYBRA_VARIABLE_SET_EXPLICIT_VALUE:$var_value = $variable_name;break;
				case LYBRA_VARIABLE_SET_CLASS_VAR:$var_value = $this->$variable_name;break;
				case LYBRA_VARIABLE_SET_SESSION_VAR:$var_value = $_SESSION[$variable_name];break;//$this->session_get($var_name);break;
				case LYBRA_VARIABLE_SET_GET_VAR:$var_value = (isset($_GET[$variable_name])?$_GET[$variable_name]:"");break;
				case LYBRA_VARIABLE_SET_POST_VAR:$var_value = (isset($_POST[$variable_name])?$_POST[$variable_name]:"");break;
				case LYBRA_VARIABLE_SET_SQL_FIELD:$var_value = "";break; // FIXME: Not implemented jet
				default:$var_value="";break;
			}
			// print_("GET VAR RET '$var_value' ");
			return $var_value;
		 }

		// }}}
		// {{{ execute_condition_chain()
		/**
		 * Follow a chain of test and execute them all following the chain
		 * 
		 * @access private
		 *
		 * @test_type int identify the test to execute
		 * @var_name string name of the variable to test
		 * @var_type int indetify the type of this variable (POST,GET ...)
		 * @var_value1 string first value to use for the test
		 * @var_value2 string second value to use for the test
		 *
		 * @return bool last condition return value
		 */	 
		function execute_condition_chain($condition_id,$start=0)
		{
			$start++;
			if ($start>200)
				return FALSE;
			$select = "SELECT ".LYBRA_CONDITIONS_TEST_ID_FIELD.",".
								LYBRA_CONDITIONS_GOTO_IF_TRUE.",".
								LYBRA_CONDITIONS_GOTO_IF_FALSE.",".
								LYBRA_CONDITIONS_VARIABLE_NAME1_FIELD.",".
								LYBRA_CONDITIONS_VARIABLE1_SET_ID_FIELD.",".
								LYBRA_CONDITIONS_VARIABLE_NAME2_FIELD.",".
								LYBRA_CONDITIONS_VARIABLE2_SET_ID_FIELD.",".
								LYBRA_CONDITIONS_VARIABLE_NAME3_FIELD.",".
								LYBRA_CONDITIONS_VARIABLE3_SET_ID_FIELD.",".
								LYBRA_CONDITIONS_PERSONAL_METHOD_ID_FIELD.
								" FROM ".LYBRA_CONDITIONS_TABLE.
								" WHERE ".LYBRA_CONDITION_ID_FIELD."=$condition_id";
			$this->retrieve($select);
			print_("EXECUTE CONDITION '$select' '".$this->results[0][3]."' '$start'","CONDITION");
			// $this->save_result("event_$start");
		    if (!$this->empty_result) //{"empty_result_event_".$start})
		    {
		    	$hlp = "results_event_$start";
		    	$goto_if_true = $this->results[0][1];
		    	$goto_if_false = $this->results[0][2];
		    	// Execute this condition
		    	if ($ret_value = $this->event_driven_test($this->results[0][0],$this->results[0][3],$this->results[0][4],$this->results[0][5],$this->results[0][6],$this->results[0][7],$this->results[0][8],$this->results[0][9]))	    	
		    	{
		    		if ($goto_if_true)
		    			// Another condition follows the current one for TRUE result
		    			return $this->execute_condition_chain($goto_if_true,$start);
		    		// Condition true, return it
		    		return true;
		    	}
		    	else
		    	{
		    		if ($goto_if_false)
		    			// Another condition follows the current one for FALSE result
		    			return $this->execute_condition_chain($goto_if_false,$start);
		    		// Condition false, return it
		    		return false;
		    	}
		    }
		}
		 
		 
		// }}}
		// {{{ event_driven_test()
		/**
		 * Test if an event must be executed or not
		 * 
		 * @access private
		 *
		 * @test_type int identify the test to execute
		 * @var_name1,2,3 string name of the variable to test
		 * @var_type1,2,3 int indetify the type of this variable (POST,GET ...)
		 * @test_method_id int id of the method to execute as a test
		 *
		 * @return bool true if the test succeeded, false otherwise
		 */	
		function event_driven_test($test_type,$var_name1,$var_type1,$var_name2,$var_type2,$var_name3,$var_type3,$test_method_id=0)
		{
			//print_("TEST_FUNC CALLED '$test_type,$var_name,$var_type,$var_value1,$var_value2'<br>","TEST FUNC");
			// Preleva il valore della variabile dipendentemente dal suo tipo e dal nome della variabile stessa
			$var_value1 = $this->get_variable($var_name1,$var_type1);
			$var_value2 = $this->get_variable($var_name2,$var_type2);
			$var_value3 = $this->get_variable($var_name3,$var_type3); 
			print_("TEST_FUNC VALUES '$test_type' '$var_name1' '$var_type1' '$var_name2' '$var_type2' '$var_name3' '$var_type3' '$test_method_id'");
			print_("VAR_VALUES '$var_value1' '$var_value2' '$var_value3'");

			// Esegue il test richiesto
			switch ($test_type)
			{
				case EVENTDRIVEN_TEST_EQUAL_VALUE1:
					{
						if (!strcmp($var_value1,$var_value2))
							return true;
					}break;
				case EVENTDRIVEN_VARTYPE_POST:
					{
						if ((!strcmp($var_value1,$var_value2)) || (!strcmp($var_value1,$var_value3)))
							return true;
					}break;
				case EVENTDRIVEN_TEST_EQUAL_VALUE2:
					{
						if (!strcmp($var_value1,$var_value3))
							return true;
					}break;
				case EVENTDRIVEN_TEST_NOT_EQUAL_VALUE1:
					{
						if (strcmp($var_value1,$var_value2))
							return true;
					}break;
				case EVENTDRIVEN_TEST_NOT_EQUAL_VALUE2:
					{
						if (strcmp($var_value1,$var_value3))
							return true;
					}break;
				case EVENTDRIVEN_TEST_NOT_EQUAL_BOTH:
					{
						if ((strcmp($var_value1,$var_value2)) && (strcmp($var_value1,$var_value3)))
							return true;
					}break;
				case EVENTDRIVEN_TEST_GT_VALUE1:
					{
						if ($var_value1 > $var_value2)
							return true;
					}break;
				case EVENTDRIVEN_TEST_LT_VALUE1:
					{
						if ($var_value1 < $var_value2)
							return true;
					}break;
				case EVENTDRIVEN_TEST_GE_VALUE1:
					{
						if ($var_value1 >= $var_value2)
							return true;
					}break;
				case EVENTDRIVEN_TEST_LE_VALUE1:
					{
						if ($var_value1 <= $var_value2)
							return true;
					}break;
				case EVENTDRIVEN_TEST_GT_VALUE2:
					{
						if ($var_value1 > $var_value3)
							return true;
					}break;
				case EVENTDRIVEN_TEST_LT_VALUE2:
					{
						if ($var_value1 < $var_value3)
							return true;
					}break;
				case EVENTDRIVEN_TEST_GE_VALUE2:
					{
						if ($var_value1 >= $var_value3)
							return true;
					}break;
				case EVENTDRIVEN_TEST_LE_VALUE2:
					{
						if ($var_value1 <= $var_value3)
							return true;
					}break;
				case EVENTDRIVEN_TEST_BETWEEN_1YES_2NO:
					{
						if (($var_value1 >= $var_value2) && ($var_value1 < $var_value3))
							return true;
					}break;
				case EVENTDRIVEN_TEST_BETWEEN_1NO_2YES:
					{
						if (($var_value1 > $var_value2) && ($var_value1 <= $var_value3))
							return true;
					}break;
				case EVENTDRIVEN_TEST_BETWEEN_1YES_2YES:
					{
						if (($var_value1 >= $var_value2) && ($var_value1 <= $var_value3))
							return true;
					}break;
				case EVENTDRIVEN_TEST_BETWEEN_1NO_2NO:
					{
						if (($var_value1 > $var_value2) && ($var_value1 < $var_value3))
							return true;
					}break;
				case EVENTDRIVEN_TEST_EQUAL_STRING_VALUE1:
					{
						if (!strcmp($var_value1,$var_value2))
							return true;
					}break;
				case EVENTDRIVEN_TEST_EQUAL_STRING_VALUE2:
					{
						if (!strcmp($var_value1,$var_value3))
							return true;
					}break;
				case EVENTDRIVEN_TEST_SUBSTRING_VALUE1:
					{
						if (ereg($var_value1,$var_value2))
							return true;
					}break;
				case EVENTDRIVEN_TEST_SUBSTRING_VALUE2:
					{
						if (ereg($var_value1,$var_value3))
							return true;
					}break;
				case EVENTDRIVEN_USER_DEFINED_TEST:
					{
						// Execute method
						$this->retrieve("SELECT ".LYBRA_METHOD_NAME_FIELD.",".
													LYBRA_MODULE_ID_FIELD.
												" FROM ".LYBRA_METHODS_TABLE.
												" WHERE ".LYBRA_METHOD_ID_FIELD."=$test_method_id");
						if (!$this->empty_result)
						{					
							return $this->call_method($this->results[0][0],$this->results[0][1],$var_name1,$var_type1,$var_value2,$var_type2,$var_value3,$var_type3);
						}
						return false;
					}break;				
				default:return false;
			}

/*
	- 99 user-defined, value2 is the id of the method to call, the variable value and value1 are passed to the
		method. If return true the method is executed otherwise not
*/
		}

		// }}}
		// {{{ call_method()
		/**
		 * Just call a method into a module passing some parameters
		 * 
		 * @access private
		 *
		 * @module_id int module's id
		 *
		 * @return the return value of the called method
		 */		
		 function call_method($method_name,$module_id,$var_name1,$var_type1,$var_name2,$var_type2,$var_name3,$var_type3)
		 {
		 	$exists = false;
		 	if ($module_id==FAKE_MODULE)
		 	{
				$tmp = "\$this";
				if (function_exists($method_name))
					$exists = true;
		 	}
			else
			{
				$tmp = $this->modules_istance_names[$module_id];
				if (method_exists($tmp,$method_name))
					$exists = true;
			}
			if (!$exists)
				$this->core_error(LYBRA_METHOD_NOT_FOUND,"Impossible to call method $method_name",TRUE);
			$call = $tmp."->".$method_name."(1,1,1,1,1,1)";// "($var_name1,$var_type1,$var_name2,$var_type2,$var_name3,$var_type3)";
			print_("EVAL METHOD '\$retval=$call'","CALL_METHOD");
			$retval = "";
			eval("\$retval=$call");
			return $retval;
		 }

		// }}}
		// {{{ module_active()
		/**
		 * Find out if a module is active or not
		 * 
		 * @access private
		 *
		 * @module_id int module's id
		 *
		 * @return bool true if the module with id module_id is active, false otherwise
		 */	
		function module_active($module_id)
		{
			if ($this->core_module_active[$module_id]==ON)
				return true;
			return false;
		}

		// }}}
		// {{{ execute_sql()
		/**
		 * Retrieve and execute a query with and save the result into a cache
		 * 
		 * @access private
		 *
		 * @sql_id int identify the sql query to execute
		 *
		 * @return bool true on success, false otherwise
		 */	
		function execute_sql($sql_id,$mode=LYBRA_DB_FETCHMODE_DEFAULT)
	    {
	    	// Costruct query
	    	$select = "SELECT ".SQL_FIELD.",".SQL_EVALUATE_FIELD." FROM ".LYBRA_SQL_TABLE." WHERE ".SQL_ID_FIELD."=".addslashes($sql_id);
	    	print_("FIND SQL QUERY '$select' '$sql_id' '$mode'<br>");
			$this->retrieve($select);
			if (!$this->empty_result)
	    	{
	    		if ($this->results[0][1])
			    	// Evaluate string, allows all dynamic value to be substituted with actual values ($this->...)
			    	eval("\$sql = \"".$this->results[0][0]."\";");
			    else
			    	$sql = $this->results[0][0];
			    // Execute retrieved sql
			    // IMPROVEME: retrieve by column and not row, usefull to call methods with an array for each column
			    $this->retrieve($sql,$mode);
			    // Save query by sql id
			    $this->save_result(LYBRA_SQL_CACHE_PREFIX.$sql_id,$mode);
			    //print_("QUERY RES '".print_r($this->{"results_".LYBRA_SQL_CACHE_PREFIX.$sql_id})."'");
			    return SQL_DONE_AND_CACHED;
			}
			else
			{
				return LYBRA_ERROR_SQL_ID_NOT_FOUND;
			}
	    }

		// }}}
		// {{{ sql_done()
		/**
		 * Test if an sql query result is into the cache or not
		 * 
		 * @access private
		 *
		 * @sql_id int identify the sql query result to tes
		 *
		 * @return bool true if requested sql query result is jet into cache
		 */	
	    function sql_done($sql_id,$mode="")
	    {
	    	//print_("QUERY DOME '$sql_id'","QUERY_DONE");
	    	if (isset($this->sql_cache[LYBRA_SQL_CACHE_PREFIX.$sql_id]))
	    	{
	    		if (!strcmp($mode,""))
	    			return TRUE;
	    		elseif ($this->sql_cache_mode[LYBRA_SQL_CACHE_PREFIX.$sql_id])
	    				return TRUE;
	    			else
	    				return FALSE;
	    	}
	    	else
	    		return FALSE;
	    	//return (isset($this->sql_cache[$sql_id])?$this->sql_cache[$sql_id]:FALSE);
	    }

		// }}}
		// {{{ init_user_manager()
		/**
		 * Activate user managment
		 * 
		 * @access private
		 *
		 * @return bool true on success false otherwise
		 */
		function init_user_manager()
		{
// FIXME: Implementare un meccanismo che permetta di indicare una lista di moduli che devono essere presenti
// affinche' una determinata funzionalita' possa essere abilitata (o una lista di moduli, uno dei quali deve essere attivo)
		    if (!$this->init_values[USERSESSION_MODULE])
				// User manager Not active
				return true;
		    if (!$this->init_user())
				return ERROR_CANT_INIT_USER;
		    return true;
		}

		// }}}
		// {{{ _print()
		/**
		 * Print out print buffer
		 * 
		 * @access private
		 *
		 * @return void
		 */		
		function _print(&$string)
		{
		    $this->print_buffer .= $string;
		}
		
		// }}}
		// {{{ send_to_script()
		/**
		 * Send an header to the specific location
		 * 
		 * @access protected
		 *
		 * @location string destionation script URL
		 *
		 * @return void
		 */
		function send_to_script($location)
		{
		    Header("Location: $location");
		    exit;
		}

		// To move somewhere in the db or in a included file
		// }}}
		// {{{ get_error_message()
		/**
		 * Return string message related to errors (lybra core)
		 * 
		 * @access protected
		 *
		 * @return string error description
		 */		
		function get_error_message($error_code=0)
		{
			return $this->core_messages[$error_code];
		}

		// To move somewhere in the db or in a included file
		// }}}
		// {{{ boring_init()
		/**
		 * FIXME: To move somewhere in the db or in a included file
		 * 
		 * @access private
		 *
		 * @return void
		 */
		function boring_init()
		{
			// Register active modules (core and non-core modules)
			foreach($this->init_values as $key => $value) 
				if ($value==ON)
					$this->core_module_active[$key] = NO;
			$this->core_messages[UNDEFINED_STATUS_MSG] = "Status undefined!?!?";
			$this->core_messages[LYBRA_NO_ERROR] = "No Error jet";
			$this->core_messages[LYBRA_ERROR] = "Some Error";
			$this->core_messages[LYBRA_CORE_INIT_OK] = "Core-Init OK";
			$this->core_messages[DB_INIT_ERROR] = "Database Init Error";
			$this->core_messages[TEMPLATE_INIT_ERROR] = "Template Init Error";
			$this->core_messages[TEMPLATE_INIT_ERROR] = "Template Init Error";
			$this->core_messages[LOG_INIT_ERROR] = "Log Init Error";
			$this->core_messages[SESSION_INIT_ERROR] = "Session Init Error";
			$this->core_messages[LYBRA_MODULE_ACTIVATION_ERROR] = "Error activating module";
			$this->core_messages[LYBRA_ERROR_AUTOMATIC_METHOD_CALL] = "Error calling method automatically";

			$this->core_messages[LYBRA_ERROR_SQL_ID_NOT_INT] = "sql_id is not INT";
			$this->core_messages[LYBRA_ERROR_SQL_ID_NOT_FOUND] = "sql_id is not INT";
			$this->core_messages[VALUE2_NOT_INT] = "var_value2 is not INT, cannot be a method id";
			$this->core_messages[ERROR_CALLING_CUSTOM_TEST_METHOD] = "Error calling method for eventdriven test method";
		}
	}
	
	// Just a variable container
	class param_container
	{
	}
?>