<?
 /**********************************************************************************************
 		Lybra: A general purpose framework for fast web development
		Copyright (C) 2003-2004 Simone Grassi (Ci S.B.i.C. snc di Giorgini, Grassi e Muratori)

	    config_scheleton_script.php
	    ---------------------------
		begin:  	9/2002 Simone Grassi (Ci S.B.i.C. snc)
		copyright:	(C) 2002 Ci S.B.i.C. snc
					viale Marconi 438, 47023 Cesena (FC), Italy.
		email:		simone@cisbic.com,andrea@cisbic.com,vico@cisbic.com

	    This program is free software; you can redistribute it and/or modify
	    it under the terms of the GNU General Public License as published by
	    the Free Software Foundation; either version 2 of the License, or
	    (at your option) any later version.

	    This program is distributed in the hope that it will be useful,
	    but WITHOUT ANY WARRANTY; without even the implied warranty of
	    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	    GNU General Public License for more details.

	    You should have received a copy of the GNU General Public License
	    along with this program; if not, write to the Free Software
	    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************************************/
	// Store information about scheleton_script modules and defines

	// Database: table names and field names
	define("LYBRA_PARAMETERS_TABLE","lybra_parameters");
	define("LYBRA_PARAMETERS_PARAMETER_ID","lybra_parameter_id");
	define("LYBRA_PARAMETERS_SUFFIX_PARAMETER_ID","lybra_parameter_id_suffix");
	define("LYBRA_PARAMETERS_PREFIX_PARAMETER_ID","lybra_parameter_id_prefix");
	define("LYBRA_PARAMETERS_MODULE_ID","module_id");
	define("LYBRA_PARAMETERS_PARAMETER_NAME","parameter_name");
	define("LYBRA_PARAMETERS_PARAMETER_VALUE","parameter_value");
	define("LYBRA_PARAMETERS_SCRIPT_ID","script_id");
	define("LYBRA_PARAMETERS_CORE_FIELD","core");
	define("LYBRA_PARAMETERS_SEND_TO_MODULE_FIELD","send_to_module");

	define("LYBRA_AUTH_TABLE","lybra_auth");
	define("LYBRA_AUTH_USERNAME","username");
	define("LYBRA_AUTH_PASSWORD","password");
    define("LYBRA_AUTH_CRYPT_TYPE","md5");
    
    define("LYBRA_AUTH_GROUP_TABLE","lybra_auth_group");
    define("LYBRA_AUTH_GROUP_ID","group_id");
    define("LYBRA_AUTH_GROUP_DESCRIPTION","group_description");
    
    define("LYBRA_AUTH_ROLE_TABLE","lybra_auth_role");
    define("LYBRA_AUTH_ROLE_ID","role_id");
    define("LYBRA_AUTH_ROLE_DESCRIPTION","role_description");
	
	define("LYBRA_MODULE_PARAMETERS_TABLE","lybra_module_parameters");
	define("LYBRA_MODULE_PARAMETERS_PARAM_NAME_FIELD","parameter_name");
	define("LYBRA_MODULE_PARAMETERS_PARAM_VALUE","parameter_value");
	define("LYBRA_SEND_TO_MODULE_FIELD","send_to_module");
	
	define("LYBRA_PROJECT_PARAMETERS_TABLE","lybra_project_parameters");
	define("LYBRA_PROJECT_PARAMETERS_SCRIPT_ID","script_id");
	define("LYBRA_PROJECT_PARAMETERS_PARAMETER_ID","parameter_id");
	define("LYBRA_PROJECT_PARAMETERS_ACTIVE","active");
	define("LYBRA_PROJECT_PARAMETERS_PARAMETER_NAME","parameter_name");
	define("LYBRA_PROJECT_PARAMETERS_PARAMETER_VALUE","parameter_value");
	define("LYBRA_PROJECT_PARAMETERS_PARAMETER_NAME_ARRAY","parameter_name_array");

	define("LYBRA_MODULES_TABLE","lybra_modules");
	define("LYBRA_MODULES_ACTIVE_FIELD","active");
	define("LYBRA_MODULES_CLASS_NAME","class_name");
	define("LYBRA_MODULES_AUTO_ISTANTIATE","auto_instantiate");
	define("LYBRA_MODULES_FACTORY_INIT","factory_init");
	define("LYBRA_MODULES_ORDER_FIELD","init_order");
 	
	define("LYBRA_PHPLAYERSMENU_PARAMETER_ID_FIELD","layersmenu_parameter_id");
	define("LYBRA_PHPLAYERSMENU_ISTANCE_TABLE","lybra_phplayersmenu_istance");
	define("LYBRA_PHPLAYERSMENU_PARAMETERS_TABLE","lybra_phplayersmenu_parameters");
	define("LYBRA_PHPLAYERSMENU_TYPE_FIELD","type");
	define("LYBRA_PHPLAYERSMENU_REPOSITORY_FIELD","repository");
	define("LYBRA_PHPLAYERSMENU_ISTANCE_ID_FIELD","istance_id");
	define("LYBRA_PHPLAYERSMENU_LAYOUTE_ID_FIELD","layout_id");
	define("LYBRA_PHPLAYERSMENU_NAME_FIELD","name");
	define("LYBRA_PHPLAYERSMENU_CSS_FIELD","css");
	define("LYBRA_PHPLAYERSMENU_ARROWS_DOWN","arrows_down");
	define("LYBRA_PHPLAYERSMENU_ARROWS_FORWARD","arrows_forward");
	define("LYBRA_PHPLAYERSMENU_LAYER_POSITION","layer_position");
	define("LYBRA_PHPLAYERSMENU_TEMPLATE","template");
	define("LYBRA_PHPLAYERSMENU_SUB_TEMPLATE","sub_template");
	define("LYBRA_PHPLAYERSMENU_VISIBILITY","visibility");
	define("LYBRA_PHPLAYERSMENU_ABSCISSA_STEP","abscissa_step");
	define("LYBRA_PHPLAYERSMENU_MENU_FORMAT","menu_format");
	define("LYBRA_PHPLAYERSMENU_LABEL_FIELD","label");

	define("LYBRA_ALLSCRIPT_VALUE",0);
	define("LYBRA_AUTOTEMPLATE_TABLE","lybra_auto_template");
	define("LYBRA_AUTOTEMPLATE_TEMPLATE_ID","lybra_auto_template_id");
	define("LYBRA_SCRIPT_ID_FIELD","script_id");
	define("LYBRA_AUTOTEMPLATE_ENTRY_TYPE_FIELD","entry_type");
	define("LYBRA_AUTOTEMPLATE_VARNAME_FIELD","template_varname");
	define("LYBRA_AUTOTEMPLATE_VARVALUE_FIELD","value");
	define("LYBRA_AUTOTEMPLATE_LANGUAGE_FIELD","language");
	define("LYBRA_AUTOTEMPLATE_PRIORITY_FIELD","priority");
	define("LYBRA_AUTOTEMPLATE_EVENT_ID_FIELD","lybra_event_id");
	define("LYBRA_AUTOTEMPLATE_ACTIVE_FIELD","active");
	define("LYBRA_AUTOTEMPLATE_CARDINALITY_FIELD","max_cardinality");
	define("LYBRA_AUTOTEMPLATE_INTERNAL_TYPE_FIELD","internal_type");

	define("LYBRA_AUTO_TEMPLATE_LANG_ASSOC","lybra_auto_template_language_association");
	define("LYBRA_AUTO_TEMPLATE_LANG_ASSOC_LANG_ID","language_id");
	define("LYBRA_AUTO_TEMPLATE_SCRIPT_ASSOC","lybra_auto_template_script_association");

	define("LYBRA_SCRIPT_TEMPLATES_TABLE","lybra_script_templates");
	define("LYBRA_SCRIPT_TEMPLATES_SCRIPT_ID_FIELD","script_id");
	define("LYBRA_SCRIPT_TEMPLATES_TEMPLATE_LABEL_FIELD","template_label");
	define("LYBRA_SCRIPT_TEMPLATES_TEMPLATE_FILE_FIELD","template_file");
	define("LYBRA_SCRIPT_TEMPLATES_PARSE_INTO_FIELD","parse_into");
	define("LYBRA_SCRIPT_TEMPLATES_PRIORITY_FIELD","priority");	

	define("LYBRA_SCRIPT_CONNECT_TABLE","lybra_script_connect");
	define("LYBRA_CONNECT_ID_FIELD","connect_id");
	define("LYBRA_SOURCE_ID_FIELD","source_id");
	define("LYBRA_TARGET_ID_FIELD","target_id");
	define("SCRIPT_CONNECT_LANGUAGE_FIELD","language");
	define("LYBRA_CONNECT_MODE_FIELD","mode_id");

	define("LYBRA_SCRIPTS_TABLE","lybra_scripts");
	define("SCRIPT_NAME_FIELD","script_name");
	define("SCRIPT_PROTECTED_FIELD","protected");
	define("LYBRA_SCRIPT_NON_CORE_FIELD","non_core");

	define("CONNECT_PARAMETERS_TABLE_NAME","lybra_connect_parameters");
	define("CONNECT_PARAMETERS_POSTGET_FIELD_NAME","post_get");
	define("CONNECT_PARAM_PARAM_NAME_FIELD","param_name");
	define("CONNECT_PARAM_PARAM_VALUE_FIELD","param_value");
	define("CONNECT_PARAM_VARIABLE_SET_ID","variable_set_id");
	define("CONNECT_PARAM_VARIABLE_NAME_FIELD","variable_name");
	define("LYBRA_CONNECT_HIDDENPARAM_TAGTEMPLATE_SUFFIX","_dst");
	
	define("LYBRA_ISTANCE_SQL_RELATION_TABLE","lybra_visual_istance_sql_relation");
	define("LYBRA_ISTANCE_SQL_RELATION_POSITION_FIELD","position");

	define("LYBRA_SQL_TABLE","lybra_sql");
	define("SQL_ID_FIELD","sql_id");
	define("SQL_FIELD","sql");
	define("LYBRA_SQL_CACHE_PREFIX","sql__");
	define("SQL_EVALUATE_FIELD","evaluate");

	define("VISUAL_ISTANCES_TABLE","lybra_visual_istances");
	define("VISUAL_ISTANCE_ID_FIELD","visual_istance_id");
	define("VISUAL_ISTANCE_PARAMETERS_TABLE","lybra_visual_istance_parameters");
	define("VISUAL_ISTANCE_PARAMETERS_VALUE_FIELD","value");
	define("VISUAL_ISTANCE_PARAMETERS_VARIABLE_NAME_FIELD","variable_name");
	define("VISUAL_ISTANCE_PARAMETERS_OPTIONAL_FIELD","optional");
	define("VISUAL_ISTANCE_PARAMETERS_SQL_FIELDS_FIELD","sql_field");
	define("VISUAL_ISTANCE_PARAMETERS_POSITION_FIELD","position");
	define("VISUAL_ISTANCE_PARAMETERS_PARAMETER_TYPE_ID_FIELD","parameter_type_id");
	define("VISUAL_ISTANCE_PARAMETERS_PARAMETER_SET_ID_FIELD","parameter_set_id");

	define("SUBMIT_ACTIONS_TABLE","lybra_submit_actions");
	define("SUBMIT_ACTION_ID_FIELD","submit_action_id");
	define("SUBMIT_ACTION_SCRIPT_ID_FIELD","script_id");
	define("SUBMIT_ACTION_CONDITION_ID_FIELD","lybra_condition_id");
	//define("SUBMIT_ACTIONS_METHOD_ID_FIELD","method_id");
	define("SUBMIT_ACTIONS_EVENT_ID_FIELD","event_id");
	define("SUBMIT_ACTIONS_PRIORITY_FIELD","priority");
	define("SUBMIT_ACTIVE_FIELD","active");
	define("SUBMIT_ACTIONS_EXECUTE_METHOD_ID_FIELD","execute_method_id");

	define("LYBRA_CONDITIONS_TABLE","lybra_conditions");
	define("LYBRA_CONDITION_ID_FIELD","lybra_condition_id");
	define("LYBRA_CONDITIONS_VARIABLE_NAME1_FIELD","variable1_name");
	define("LYBRA_CONDITIONS_VARIABLE_NAME2_FIELD","variable2_name");
	define("LYBRA_CONDITIONS_VARIABLE_NAME3_FIELD","variable3_name");
	define("LYBRA_CONDITIONS_VARIABLE1_SET_ID_FIELD","variable1_set_id");
	define("LYBRA_CONDITIONS_VARIABLE2_SET_ID_FIELD","variable2_set_id");
	define("LYBRA_CONDITIONS_VARIABLE3_SET_ID_FIELD","variable3_set_id");
	define("LYBRA_CONDITIONS_TEST_ID_FIELD","test_id");
	
	define("LYBRA_CONDITIONS_PERSONAL_METHOD_ID_FIELD","personal_method_id");
	
	define("LYBRA_CONDITION_TESTS","lybra_condition_test");
	define("LYBRA_CONDITION_USER_DEFINED_TEST",99);
	
	define("LYBRA_CONDITIONS_GOTO_IF_TRUE","goto_if_true");
	define("LYBRA_CONDITIONS_GOTO_IF_FALSE","goto_if_false");

	define("LYBRA_METHODS_TABLE","lybra_methods");
	define("LYBRA_METHOD_ID_FIELD","method_id");
	define("LYBRA_MODULE_ID_FIELD","module_id");
	define("LYBRA_METHOD_NAME_FIELD","method_name");
	
	define("LYBRA_HTML_STRING","lybra_html_strings");
	define("LYBRA_HTML_STRING_FIELD","html_string");
	define("LYBRA_HTML_STRING_ID_FIELD","html_string_id");
	define("LYBRA_HTML_DESCRIPTION_FIELD","description");
	define("LYBRA_HTML_STRING_LANGUAGE_FIELD","language");
	
	
	// SEND_TO_MODULE INTERPRETATION
	define("LYBRA_SEND_TO_MODULE_ONLY_CORE",0);
	define("LYBRA_SEND_TO_MODULE_CORE_AND_MODULE",1);
	define("LYBRA_SEND_TO_MODULE_ONLY_TO_MODULE",2);
	// PREFIX AND SUFFIX EXISTENCE
	define("LYBRA_PARAMETER_SUFFIX_NOT_PRESENT",0);
	define("LYBRA_PARAMETER_PREFIX_NOT_PRESENT",0);
	
	define("AND",0);
	define("OR",1);

	define("GET",0);
	define("POST",1);
	define("SESSION",2);
	define("CLASS",3);
	
	//OK MSG
	define("SQL_DONE_AND_CACHED",1);
 
	define("TEST",10);
	define( "ON", 1 );
	define( "OFF", 0 );

	// Tenere sincronizzato con tabella lybra_auto_template_variable_types
	define("STATIC_TEMPLATE",0); // Explicit values
	define("DYNAMIC_TEMPLATE",1); // Instance variables
	define("VISUAL_ISTANCE_TEMPLATE",2); // Visual istance
	define("CONNECT_TEMPLATE",3); // script connect
	define("SESSION_TEMPLATE",4); // Session
	define("GET_TEMPLATE",5); // get variable
	define("POST_TEMPLATE",6); // post variable
	define("SMARTY_SQL_TEMPLATE",7); // smarty sql to template tag
	define("HTML_STRING",8); // html strings
	define("PHPLAYERSMENU_TEMPLATE",9); // phplayersmenu menu
	define("SMARTY_SUBTEMPLATE",10); // subtemplate tag

	// Modes for lybra auto template relative to script connections
	define("LYBRA_CONNECT_GET_MODE",0);
	define("LYBRA_CONNECT_POST_MODE",1);

	// Supported modules
	define("TABLE_MODULE",0);
	define("TEMPLATE_MODULE",1);
	define("LOG_MODULE",2);
	define("SESSION_MODULE",3);
	define("ECOMMERCE_MODULE",4);
	define("LANGUAGE_MODULE",5);
	define("FAKE_MODULE",6);
	define("USERSESSION_MODULE",7);
	define("HTML_MODULE",8);
	define("XHTML_MODULE",9);
	define("AUTHENTICATION_MODULE",10);
	define("HTMLCDSAGENDA_MODULE",11);
	define("LYBRA_LAYERSMENU_MODULE",12);
	define("LYBRA_LIVEUSER_MODULE",13);
	define("LYBRA_DB_DATAOBJECT_MODULE",14);
	define("LYBRA_DOCUMENT_MANAGER_MODULE",15);
	define("LYBRA_FILE_MANAGER_MODULE",16);
	define("LYBRA_AUTHORIZATION_MANAGER_MODULE",17);
	

	define("NO_LANGUAGE",0);
	define("LYBRA_ALL_LANGUAGE",0);
	define("ITALIANO",1);
	define("INGLESE",2);
	define("SPAGNOLO",3);
	define("TEDESCO",4);
	define("FRANCESE",5);

	// Meaning of the field $this->ce__param_tempalte_autoset_lybra_event_id_field
	// Default event is like at scheleton init
	define("EVENTS_DEFAULT",1);
	// Done at scheleton init time
	define("EVENTS_SCHELETON_INIT",1);
	// Done at scheleton action time
	define("EVENTS_SCHELETON_ACTION",2);
	// Done at scheleton render time
	define("EVENTS_SCHELETON_RENDER",3);

	// Meaning of the field $this->ce__param_tempalte_autoset_lybra_event_id_field
	// Single value (string)
	define("SCALAR",0);
	// Array
	define("ARRAY",1);

	// Common parameters name
	// Template absolute path
	define("TEMPLATE_PATH","par_tem_path");
	// Template mainpage file
	define("TEMPLATE_MAINPAGE","par_tem_file_mainpage");
	// Template error file
	define("TEMPLATE_ERROR","par_tem_file_error");

	// common settings variables
	define( "LOG_FILE", "logFile" );
	define( "TEMPLATE", "template" );
	define( "TEMPLATE_ARRAY", "templateArray" );
	define( "TABLE", "table" );
	define( "TABLE_DBNAME", "table_dbname" );

	// Ecommerce defines
	define("DEFAULT_CART_STYLE", 1 );
	define("CISBIC_STYLE1", 1 );
	define("CISBIC_STYLE2", 2 );
	define("CISBIC_STYLE3", 3 );
	define("CISBIC_STYLE4", 4 );

	// Possible return values (errors & OK)
	define("UNDEFINED_STATUS_MSG",2);
	define("LYBRA_NO_ERROR",1);
	define("LYBRA_ERROR",0);
	define("LYBRA_CORE_INIT_OK",1);
	define("DB_INIT_ERROR",-1);
	define("TEMPLATE_INIT_ERROR",-2);
	define("LOG_INIT_ERROR",-3);
	define("SESSION_INIT_ERROR",-4);
	define("LYBRA_ERROR_MODULE_ACTIVATION",-5);
	define("LYBRA_ERROR_AUTOMATIC_METHOD_CALL",-6);
	define("LYBRA_METHOD_NOT_FOUND",-7);

	// Event-driven errors
	define("LYBRA_ERROR_SQL_ID_NOT_INT",-20);
	define("LYBRA_ERROR_SQL_ID_NOT_FOUND",-21);
	define("VALUE2_NOT_INT",-22);
	define("ERROR_CALLING_CUSTOM_TEST_METHOD",-23);

	// Lenght of the string used to store the prefix of all session registered variables
	define("RANDOMIZER_VARNAME_LENGHT",12);
	define("RANDOMIZER_COMMON_PREFIX","csb");

	// Messages
	define("PROJECT_SCRIPT_INIT_OK", 100);

	// Parameters type
	define("FLAG_PARAM",1);
	define("INT_PARAM",2);
	define("STRING_PARAM",3);
	define("ARRAY_PARAM",4);
	define("HASH_PARAM",5);
	define("FLOAT_PARAM",6);

	// Parameters sets
	define("VARSET_EXPLICIT",1);
	define("VARSET_SESSION",2);
	define("VARSET_CLASS",3);
	define("VARSET_GET",4);
	define("VARSET_POST",5);
	define("VARSET_SQL_FIELD",6);
	// FIXME: Same with other names (use only below defs, remove above VARSET_...)
	define("LYBRA_VARIABLE_SET_EXPLICIT_VALUE",1);
	define("LYBRA_VARIABLE_SET_SESSION_VAR",2);
	define("LYBRA_VARIABLE_SET_CLASS_VAR",3);
	define("LYBRA_VARIABLE_SET_GET_VAR",4);
	define("LYBRA_VARIABLE_SET_POST_VAR",5);
	define("LYBRA_VARIABLE_SET_SQL_FIELD",6);

	// scripts_id
	define("ALL_SCRIPTS",0);
	define("SQL_ADD_FIELDS_ARRAY_AS_PARAM",-1);
	// eventdriven defines
	define("EVENTDRIVEN_VARTYPE_GET",0);
	define("EVENTDRIVEN_VARTYPE_POST",1);
	
	define("EVENTDRIVEN_TEST_EQUAL_VALUE1",0);
	define("EVENTDRIVEN_TEST_EQUAL_BOTH",1);
	define("EVENTDRIVEN_TEST_EQUAL_VALUE2",2);
	define("EVENTDRIVEN_TEST_NOT_EQUAL_VALUE1",3);
	define("EVENTDRIVEN_TEST_NOT_EQUAL_VALUE2",4);
	define("EVENTDRIVEN_TEST_NOT_EQUAL_BOTH",5);
	define("EVENTDRIVEN_TEST_GT_VALUE1",6);
	define("EVENTDRIVEN_TEST_LT_VALUE1",7);
	define("EVENTDRIVEN_TEST_GE_VALUE1",8);
	define("EVENTDRIVEN_TEST_LE_VALUE1",9);
	define("EVENTDRIVEN_TEST_GT_VALUE2",10);
	define("EVENTDRIVEN_TEST_LT_VALUE2",11);
	define("EVENTDRIVEN_TEST_GE_VALUE2",12);
	define("EVENTDRIVEN_TEST_LE_VALUE2",13);
	define("EVENTDRIVEN_TEST_BETWEEN_1YES_2NO",14);
	define("EVENTDRIVEN_TEST_BETWEEN_1NO_2YES",15);
	define("EVENTDRIVEN_TEST_BETWEEN_1YES_2YES",16);
	define("EVENTDRIVEN_TEST_BETWEEN_1NO_2NO",17);
	define("EVENTDRIVEN_TEST_EQUAL_STRING_VALUE1",18);
	define("EVENTDRIVEN_TEST_EQUAL_STRING_VALUE2",19);
	define("EVENTDRIVEN_TEST_SUBSTRING_VALUE1",20);
	define("EVENTDRIVEN_TEST_SUBSTRING_VALUE2",21);
	define("EVENTDRIVEN_USER_DEFINED_TEST",99);
	// Lybra modes
	define("LYBRA_CORE_MODE",1);
	define("LYBRA_NON_CORE_MODE",0);
	
	// PHPLayermenu defines (menu types)
	define("LYBRA_PHPLAYERMENU_TYPE_DB",0);
	define("LYBRA_PHPLAYERMENU_TYPE_FILE",1);
	define("LYBRA_PHPLAYERMENU_TYPE_ARRAY",2);
	define("LYBRA_PHPLAYERMENU_TYPE_ARRAY_QUERY",3);
	
	// DB retrieve modes (from pear)
	define('LYBRA_DB_FETCHMODE_DEFAULT',0);
	define('LYBRA_DB_FETCHMODE_ORDERED',1);
	define('LYBRA_DB_FETCHMODE_ASSOC',2);
	define('LYBRA_DB_FETCHMODE_OBJECT',3);
	define('LYBRA_DB_FETCHMODE_FLIPPED',4);
	
	// Permission defines
	// Lybra groups and roles
	define("LYBRA_ROOT",4);
	define("LYBRA_PROJECT_ROOT",5);
	// users
	define("LYBRA_ROOT_USER","lybraroot");
	define("LYBRA_ROOT_PROJECT_USER","lybraprojectroot");
	define("LYBRA_PANEL_ADMIN","lybrapaneladmin");
	define("LYBRA_ROOT_ADMIN","lybraadmin");
	//define("LYBRA_ROOT_USER_ID",);
	//define("LYBRA_ROOT_PROJECT_USER_ID",);
	//define("LYBRA_PANEL_ADMIN_ID",);
	//define("LYBRA_ROOT_ADMIN_ID",);
	// LiveUser AREAS
	define("LYBRA_LIVERUSER_AREA",2);
	
?>