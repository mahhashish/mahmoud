<?
	require_once("lybra/core/modules/DataObject.php");
	
	class Lybra_DB_DataObject extends DB_DataObject
	{
		// Generic id field
		var $id;
		// Id field name
		var $id_fieldname;
		// Store retrieved objects
		var $objects;

		function Lybra_DB_DataObject($field="",$value="")
		{
			$class_name = $this->class_name = get_class($this);
			print_(" CLASS '$class_name' ","Lybra_DB_DataObject");
			$object = new $class_name();
			if ((is_array($field)&&!is_array($value))||
				(!is_array($field)&&is_array($value)))
				// Cant work with an array and a single value
				return false;
			if (count($field)>count($value))
				// Cant work with less values than fields
				return false;
			if (!is_array($field))
			{
				if (!strcmp($value,""))
				{
					if (strcmp($field,""))
						// Only field has a value, use it as ID
						$this->id = $field;
					else
						// Both values empty, nothing to do
						return FALSE;
				}
				else
				{
					// Both parameteres with value
					$object->$field = $value;
				}
			}
			else
			{
				$one_ok = false;
				// Assign all values
				for ($i=0;$i<count($field);$i++)
				{
					if (strcmp($value[$i],""))
					{
						$one_ok = true;
						$object->$field[$i] = $value[$i];
					}
				}
			}
			$object->find();
			$array = array();
			while ($object->fetch())
			{
				$array[] = $object->__clone();
			}
			// Return the result(s)
			return $array;
		}
		
		/* Static get */
		function staticGet($k,$v=NULL) { return DB_DataObject::staticGet($this->class_name,$k,$v); }
		
		// Common way to set the field used to retrieve one or more records
		// To set-up more than one field use field and value as arrays
		function common_init($field="",$value="")
		{
			if ((!strcmp($field,""))&&(!strcmp($value,"")))
				return TRUE;
			else
				return $this->factory($field,$value);
		}
		
		function factory($field="",$value="")
		{
			if ($this->objects = Lybra_DB_DataObject::Lybra_DB_DataObject($field,$value))
				return TRUE;
			return FALSE;
		}
		
		// now define the keys, by default id
	    function keys()
	    {
	        return array('id');
	    }

		// Update a field and execute the relative method on success
		function update_and_call($method)
		{
			foreach ($this->objects as $key => $value)
			{
				if (method_exists($this->objects,$method))
				{
					if (!$this->objects[$key]->update())
						$this->objects[$key]->last_error = "error updating";
				}
				else
					$this->objects[$key]->last_error = "method $method does not exists";
			}
		}

		function delete_all() // MOVE TO Lybra_DB_DataObject
		{
			foreach ($this->objects as $key => $value)
				$this->objects[$key]->delete();				
		}

		/* ZE2 compatibility trick */
		function __clone() { return $this;}
		
	    // now define your table structure.
	    // key is column name, value is type (to implement extending Lybra_DB_DataObject
	    /*
	    function table() {
	        return array(
	            'id'     => DB_DATAOBJECT_INT,
	            'name'   => DB_DATAOBJECT_STR,
	            'bday'   => DB_DATAOBJECT_STR + DB_DATAOBJECT_DATE,
	            'last'   => DB_DATAOBJECT_STR + DB_DATAOBJECT_DATE + DB_DATAOBJECT_TIME,
	            'active' => DB_DATAOBJECT_INT + DB_DATAOBJECT_BOOL,
	            'desc'   => DB_DATAOBJECT_STR + DB_DATAOBJECT_TXT,
	            'photo'  => DB_DATAOBJECT_STR + DB_DATAOBJECT_BLOB,
	        ));
	    }
		*/
	}
?>