<?
  /**********************************************************************************************
 		Lybra: A general purpose framework for fast web development
		Copyright (C) 2002-2004 Simone Grassi, Andrea Giorgini
		
	    abstract_factory.php
	    --------------------
		begin:  	9/2002 Simone Grassi (Ci S.B.i.C. snc)
		copyright:	(C) 2002, Simone Grassi, Andrea Giorgini
					viale Marconi 438, 47023 Cesena (FC), Italy.
		email:		lybra@cisbic.com
	
	    This program is free software; you can redistribute it and/or modify
	    it under the terms of the GNU General Public License as published by
	    the Free Software Foundation; either version 2 of the License, or
	    (at your option) any later version.

	    This program is distributed in the hope that it will be useful,
	    but WITHOUT ANY WARRANTY; without even the implied warranty of
	    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	    GNU General Public License for more details.

	    You should have received a copy of the GNU General Public License
	    along with this program; if not, write to the Free Software
	    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************************************/

	define("NO_DB_ERROR_MESSAGE", -253);
	define("LYBRA_DEBUG",1);
	
	// FIXME: include only if activated
	// Template implementation
	//require_once("lybra/core/modules/template.php");
	require_once("lybra/core/modules/smarty/libs/Smarty.class.php");
	// Log implementation
	//require_once("lybra/core/modules/multi_log.php");
	// database access implementation
	require_once("lybra/core/modules/table.php");
	// session implementation
	require_once("lybra/core/modules/session.php");
	// html builder
	require_once("lybra/core/modules/html.php");
	require_once("lybra/core/modules/html_cdsagenda.php");
	// ecommerce implementation
	// require_once("lybra/core/modules/ecommerce.php");
	// xhtml module
	require_once("lybra/core/modules/modulo_xhtml.php");
	// Authentication module
	require_once("lybra/core/modules/Auth/Auth.php");
	// Layersmenu module
	require_once("lybra/core/modules/layersmenucomplete.inc.php");
	//Multi Log Module
	require_once("lybra/core/modules/multi_log.php");
	// DB_Dataobject
	require_once("lybra/core/api/Lybra_DB_DataObject.php");
	// Document Manager
	require_once("lybra/core/modules/document_manager.php");
	// File Manager
	require_once("lybra/core/modules/file_manager.php");		
	// File Manager
	require_once("lybra/core/modules/authorization_manager.php");
	
	class abstract_factory
	{
		// Output buffer
		var $printBuffer;
		// Logger class
		var $logger;
		// database access
		var $table;
		// template
		var $template;
		// ecommerce
		var $ecommerce;
		// TABLE variables
		// last signel result
		var $lastRow;
		// Authorization manager
		var $authorization_manager;
		// last multiple result
		var $results = array();		
		// No constructor


		function abstract_factory()
		{
		    // Abstract
		}

		/*********************************************************
			CORE-MODULES INIT INTERFACES
		 *********************************************************/
		function authorization_manager_init($class_name,$parameters)
		{
			if ($this->$class_name = new $class_name($this->lybra_auth->getUsername(),$parameters))
				return true;
			return false;
		}
		 
		 
		// NOTE: Use the same db connection
		function liveuser_init($class_name,$parameters=array())
		{
			if ($this->script_protected)
			{
				$LUOptions =
							    array(
							        'autoInit' => true,
							        'session'  => array(
							            'name'     => 'PHPSESSION',
							            'varname'  => 'ludata'
							        ),
							        'login' => array(
							            'method'   => 'post',
							            'username' => 'username',
							            'password' => 'password',
							            'force'    => true,
							            'function' => 'showLoginForm',
							            'remember' => 'rememberMe'
							        ),
							        'logout' => array(
							            'trigger'  => 'logout',
							            'redirect' => 'index.php',
							            'destroy'  => true,
							            'function' => ''
							        ),
							        'authContainers' => array(
							            array(
							                'type'          => 'DB',
							                'name'          => 'DB_Local',
							                'loginTimeout'  => 0,
							                'expireTime'    => 3600,
							                'idleTime'      => 1800,
							                'connection' => $this->table->connection,
							                //'dsn'           => $this->table->dsn,
							                'allowDuplicateHandles' => 0,
							                'authTable'     => 'liveuser_users',
							                'authTableCols' => array(
							                    'user_id'    => 'auth_user_id',
							                    'handle'     => 'handle',
							                    'passwd'     => 'passwd',
							                    'lastlogin'  => 'lastlogin',
							                    'is_active'  => 'is_active'
							                )
							            )
							        ),
							        'permContainer' => array(
							        	'connection' => $this->table->connection,
							            //'dsn'        => $this->table->dsn,
							            'type'       => 'DB_Complex',
							            'prefix'     => 'liveuser_'
							        )
							    );
				
/*		
				$LUOptions = array('autoInit'       => true,
	                     'login'          => array('function' => 'showLoginForm',
	                                               'force'    => true),
	                     'authContainers' => array(array('type'          => 'DB',
	                                                     'connection'    => $this->table->connection,
	                                                     'loginTimeout'  => 0,
	                                                     'expireTime'    => 3600,
	                                                     'idleTime'      => 1800,
	                                                     'allowDuplicateHandles' => 0,
	                                                     'authTable'     => 'liveuser_users',
	                                                     'authTableCols' => array('user_id'       => 'auth_user_id',
	                                                                              'handle'       => 'handle',
	                                                                              'passwd'     => 'passwd',
	                                                                              'lastlogin'    => 'lastlogin'
	                                                                             )
	                                                    )
	                                              ),
	                     'permContainer'  => array('type'       => 'DB_Complex',
	                                               'connection' => $this->table->connection,
	                                               'prefix'     => 'liveuser_')
	                    ); 
*/

	  			if (!$this->$class_name = LiveUser::factory($LUOptions))
					return false;
	  			if ($this->$class_name->isLoggedIn())
	  			{
	  				return true;
	  			}
	  			else
	  			{
				    // The user couldn't login, so let's check if the reason was that
				    // he's not yet been declared "valid" by an administrator.
				    if (FALSE) //if ($this->$class_name->userNotValidated()) 
				    {
				        echo "Sorry kid, but one of our admins has yet to approve ";
				        echo "your user status. Please be patient. Don't call us - ";
				        echo "we'll call you.";
				    }
				    else 
				    {
				        echo "Sorry, we can't let you in. Check if the spelling of ";
				        echo "your handle and password is correct.";
				        $this->liveuser_show_login_form(&$this->$class_name,$parameters);
				    }
				    exit;
				}
			}
			return true;
		}
		/***********************************************
			INTERMEDIATE INIT FOR document_manager
		************************************************/
		function document_manager_init($class_name,$parameters)
		{
			// Init document without specific fields to retrieve
			if ($this->$class_name = new document_manager($parameters))
				return true;
			return false;
		}
		
		/***************************************
			FUNCTION RELATED TO PEAR::LiveUser
		****************************************/
		function liveuser_show_login_form($liveUserObj = false,$parameters=array())
		{
			// With lybra template engine
			$this->template->display($this->par_main_path.$this->par_tem_path."/"."loginform.tpl.php");
			return TRUE;
			
			include_once 'LiveUser/IT.php';
			$tpl = new HTML_Template_IT();
			//if (isset($parameters["loginform"]))
				$tpl->loadTemplatefile('lybra/core/modules/LiveUser/loginform.tpl.php');
			//else
				//$tpl->loadTemplatefile($parameters["loginform"]);

			$tpl->setVariable('form_action', $_SERVER['PHP_SELF']);
			
			if (is_object($liveUserObj)) 
			{
				print_("IS '".(!$liveUserObj->status?"FALSE":"TRUE")."'");
				if ($liveUserObj->status) 
				{
					switch ($liveUserObj->status) 
					{
						case LIVEUSER_AUTH_ISINACTIVE:
						$tpl->touchBlock('inactive');
						break;
						case LIVEUSER_AUTH_IDLED:
						$tpl->touchBlock('idled');
						break;
						case LIVEUSER_AUTH_EXPIRED:
						$tpl->touchBlock('expired');
						break;
						default:
						$tpl->touchBlock('failure');
						break;
					}
				}
			}
			$tpl->show();
			exit();
		}

		// }}}
		// {{{ liveruser_retrieve_role_permission

		/**
		 * liveruser_retrieve_role_permission constructor
		 *
		 * @access protected
		 *
		 * @object_type	role is relative to this object_type
		 * @object_id 	role is relative to this object_id
		 *
		 * @return bool true on success false otherwise
		 */
		function liveruser_retrieve_role_permission($object_type,$object_id)
		{
			// tests if liveuser is active
			if ($this->init_values[LYBRA_LIVEUSER_MODULE])
				$this->liveuser->readRoleRights($object_type,$object_id);
		}
		/***************************************
			FUNCTION RELATED TO PEAR::Auth
		****************************************/
		function Auth_init($class_name,$parameters="")
		{
			print_("TEST_AUTH '$class_name'","TEST_AUTH");
			// function Auth($storageDriver, $options = "", $loginFunction = "", $showLogin = true)
			//$this->$class_name = new Auth("DB", $this->table->dsn, "loginFunction");
			$this->auth = $this->lybra_auth = new Auth("DB", $this->table->dsn, "loginFunction");
			if ($this->script_protected)
            {
                // Start module
                if ((isset($this->GET['action']))&&($this->GET['action'] == "logout"))
                {
	                $this->lybra_auth->logout();
	                $this->lybra_auth->start();
                }
                else
					$this->lybra_auth->start();
                if (($this->script_protected)&&(!$this->lybra_auth->getAuth()))
					exit;
            }
		}
		/**********************************
		  AUTHORIZATION FUNCTION
		 **********************************/
		function authorize($permission,$object_id="",$object_type="")
		{
			print_("CALLED PERM: '$permission' OBJ_ID: '$object_id' OBJ_TPYE: '$object_type' ","AUTHORIZE");
			return $this->authorization_manager->authorize($permission,$object_id,$object_type);
		}
		/***************************************
			FUNCTION RELATED TO Smarty
		****************************************/
		function smarty_init($class_name,$parameters="")
		{
			$this->$class_name = new Smarty;
			$this->template =& $this->$class_name;
		}
		function session_init($class_name,$parameters="")
		{
			if (!($this->$class_name = new session()))
				$this->core_error(LYBRA_MODULE_ACTIVATION_ERROR,"SESSION");
			// Test if active first call method flag
			if ($this->par_first_execute_active)
			{
				// Flag active check the session variable
				if ($this->is_set($this->par_first_execute_variable))
				{
					$this->session_update($this->par_first_execute_variable,$this->session_get($this->par_first_execute_variable)+1);
				}
				else
				{
					$this->register($this->par_first_execute_variable,1);
				}
			}
		}
		/*********************************************************
		 	LAYERSMENU FUNCTIONS	
		 *********************************************************/	
		function layersmenu_init($class_name,$parameters="")
		{
			$this->$class_name = new LayersMenuComplete($this->table->dsn,$parameters);
		}
		function layersmenu_makemenu($menu,$tag_template,$menu_format,$menu_type,$resource,$label_string)
		{	
			if ($label_string != "")
				$label_string = explode(" ",$label_string);
		
			$call_menu = "make_".$menu_format."_menu";
			print_("$call_menu","DO MENU");
			// Fix resource depending on menu_type
			if ($menu_type==LYBRA_PHPLAYERMENU_TYPE_DB)
				$hlp = "";
			elseif ($menu_type==LYBRA_PHPLAYERMENU_TYPE_ARRAY)
				$hlp =& $this->$resource;
			elseif ($menu_type==LYBRA_PHPLAYERMENU_TYPE_FILE)
				$hlp = $resource;
			elseif ($menu_type==LYBRA_PHPLAYERMENU_TYPE_ARRAY_QUERY)
			{
				// Checks if the query has been executed
				if (!$this->sql_done($this->results_main[$resource][1]))
				// La query non è stata ancora eseguita, va quindi recuperata, eseguita e salvata prima di procedere
				$this->execute_sql($this->results_main[$resource][1]);
				// FIXME: cosi non è corretto, va fatto un metodo intermedio che sistemi il risultato della query
				// creando un array accetta da phplayersmenu
				$hlp1 = "results_".SQL_CACHE_PREFIX.$resource;
				$hlp = &$this->$hlp1;
			}
			// For su tutto (DB, FILE, ARRAY_QUERY)
			$this->layersmenu->$call_menu($menu,$menu_type,$hlp,$label_string);
			
			//Create MainMenu
			$this->set_var($tag_template,$this->layersmenu->get_menu($menu));
		}
		function layersmenu_header_footer()
		{
			//Create Menu Header JS & Css
			$this->set_var("layermenu_menuheader",$this->layersmenu->get_header());
			//Create Menu Footer JS
			$this->set_var("layermenu_menufooter",$this->layersmenu->get_footer());
		}
		function multi_log_init($class_name,$parameters="")
		{
			//print_r($parameters);
			/*foreach($parameters as $value)
			{
				$constructor_name = "log_".$value["log_extension"];
				$this->$class_name->$value["id"] = new $constructor_name($value,$value["log_arg_list"]);
			}*/
		}
		function multi_log_istance($parameters)
		{
		}
		/*********************************************************
		 	SESSION ABSTRACT FUNCTIONS	
		 *********************************************************/		
		function register($name,$val="")
		{
			return $this->session->register($name,$val);
		}
		function session_put($name,$val="")
		{
			$this->register($name,$val);
		}
		function session_get($name)
		{
			return $this->session->get($name);
		}
		function remove($name)
		{
			return $this->session->remove($name);
		}
		function session_id()
		{
			return $this->session->session_id;
		}
		function is_set($var_name)
		{
			return $this->session->is_set($var_name);
		}
		function session_update($var_name,$new_value)
		{
			$this->session->session_update($var_name,$new_value);
		}		
		/*********************************************************
		 	TEMPLATE ABSTRACT FUNCTIONS
		 *********************************************************/
		// Interface to set_var function
		function set_var($name,$value)
		{
			// return $this->template->set_var($name,$value); // NON SMARTY
			return $this->template->assign($name,$value);
		}
		// Parse and create html
		function pparse($page1,$page2)
		{
			// return $this->template->pparse($page1,$page2); // NON SMARTY
			$this->template->display($this->par_main_path.$this->par_tem_path."/".$this->parameters["templateArray"][$page2]);
		}
		function parse($page1,$page2,$flag)
		{
			//return $this->template->parse($page1,$page2,$flag);
		}
		// Put hidden template into a variable of another template
		function render_sub_template($name,$sub_template,$flag = true)
		{
			$this->template->assign($name, $this->template->fetch($sub_template));
			//return $this->parse($name,$hidden_page,$flag); // NON SMARTY
		}
		/*********************************************************
		 	DATABASE ABSTRACT FUNCTIONS
		 *********************************************************/
		 
		 // DB_DataObject init
		 function DB_DataObject_init($class_name,$parameters="")
		 {
		 	if (!$options = &PEAR::getStaticProperty('DB_DataObject','options'))
		 		return FALSE;
		 	// Now every class set-up it's tables
		 	// Configuration with .ini file
		 	// $config = parse_ini_file('lybra_dataobject.ini',TRUE);
		 	// $options = $config['DB_DataObject'];
		 }
		 
		 // Do query $select and retrieve all records
		function retrieve($select,$mode=DB_FETCHMODE_DEFAULT,$param="")
		{	
		    $this->table->retrieve($select,$mode,$param);
		}		
		/**
		 * Save last results and counter with $id
		 * if $free=true free actual result
		 *
		 * @param $id id to use to save result and counters
		 *
		 * retval true on success
		 *	  false otherwise
		 **/
		function save_result($id,$mode=LYBRA_DB_FETCHMODE_DEFAULT)
		{
		    // Save last result and counters
		    $this->sql_cache[$id] = true;
		    $this->sql_cache_mode[$id] = $mode;
		    $help = "results_$id";
		    $this->$help = $this->table->results;
		    $help = "count_$id";
		    $this->$help = $this->table->count;
		    $help = "empty_result_$id";
		    $this->$help = &$this->table->empty_result;
		    $help = "empty_query_$id";
		    $this->$help = $this->table->empty_query;

		    //if ($free)
				//$this->table->free();
		    return true;
		}

		// Return true if last query result is empty, otherwise false
		function empty_query()
		{
			if ((is_array($this->results))&&(count($this->results)>0))
			    return false;
			return true;	
		}
		
		function count()
		{
		    return $this->table->count;
		}
		
		// Do the query
		function query($query)
		{
			return $this->table->query($query);
		}
		
		function get_db_error()
		{
			return $this->connection->getError();
		}
		
		// Test if is a valid result (rows)
		function rows_ok()
		{
			return !($this->empty_query());
		}
		// Return true if lastRes is an error
		// false otherwise
		function get_error()
		{
			// Check for errors
			if ($this->table->isError($this->table->last_res))
				return true;
			return false;	
		}
		// Return the error message
		function get_message()
		{
			if (is_object($this->table->lastRes))
				return $this->table->lastRes->get_message();
			return NO_DB_ERROR_MESSAGE;
		}
		function get_error_message()
		{
			return $this->get_message();
		}
		function query_and_retrieve($query,$mode="")
		{
			return $this->table->retrieve($query,$mode);
		}
		function pop($mode="")
		{
			return $this->table->pop($mode);
		}
		function get_all($select,$param="",$mode="")
		{
			return $this->table->get_all($select,$param,$mode);
		}	
		/*********************************************************
		 	REPORT/LOG ABSTRACT FUNCTIONS
		 *********************************************************/	
		 // First parameter: reportID
		 // other parameters: fields for the report
		function log()
		{
			$vect = func_get_args();
			if ($this->par_log_active[$vect[0]])
			    // Log active, do it
			    return $this->logger->log($vect);
			// Log not active
			return true;
		}
		
		/*********************************************************
			ECOMMERCE ABSTRACT FUNCTIONS
		 *********************************************************/
//		require("cisbicFrame/patterns/ecommerce_interfaces.php");
		function init_user()
		{
		    return $this->ecommerce->inizializza_utente();
		}
		function create_guest()
		{
		    return $this->ecommerce->crea_visitatore();
		}
		function create_cart($id)
		{
			return $this->ecommerce->setta_id_utente($id);
		}
		function retrieve_cart($id)
		{
			return $this->create_cart($id);
		}
		
		function empty_cart()
		{
			return $this->ecommerce->empty_cart();
		}
		function pay_cart()
		{
			return $this->ecommerce->pay_cart();
		}
		function retrieve_html_cart($style="",$parameters="")
		{
			return $this->ecommerce->recupera_carrello_html($style,$parameters);
		}
				
		/*********************************************************
			HTML ABSTRACT FUNCTIONS
		 *********************************************************/	
		function anchors(&$locations,&$params_name,&$params_value,&$strings)
		{
		    return $this->html->anchors($locations,$params_name,$params_value,$strings);
		}
	}
?>