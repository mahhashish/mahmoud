<?
 /**********************************************************************************************
 		Lybra: A general purpose framework for fast web development
		Copyright (C) 2002-2004 Simone Grassi, Andrea Giorgini

	    document_manager.php
	    --------------------
		begin:  	2/2004 Simone Grassi (Ci S.B.i.C. snc)
		copyright:	(C) 2004, Simone Grassi,  Andrea Giorgini
					viale Marconi 438, 47023 Cesena (FC), Italy.
		email:		lybra@cisbic.com

	    This program is free software; you can redistribute it and/or modify
	    it under the terms of the GNU General Public License as published by
	    the Free Software Foundation; either version 2 of the License, or
	    (at your option) any later version.

	    This program is distributed in the hope that it will be useful,
	    but WITHOUT ANY WARRANTY; without even the implied warranty of
	    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	    GNU General Public License for more details.

	    You should have received a copy of the GNU General Public License
	    along with this program; if not, write to the Free Software
	    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************************************/

		define("LYBRA_DOCUMENT_TABLE_NAME","lybra_documents");
		define("LYBRA_DOCUMENT_DOCUMENT_ID_FIELD","document_id");
		define("LYBRA_DOCUMENT_DOCUMENT_NAME_FIELD","document_name");
		define("LYBRA_DOCUMENT_DOCUMENT_DESCRIPTION_FIELD","document_description");

		class document_manager extends Lybra_DB_DataObject
		{
			var $__table = LYBRA_DOCUMENT_TABLE_NAME;
			// Array of returned objects
			var $objects;
			// Array of component files
			var $file_objects;

			function document_manager($parameters,$field="",$value="")
			{
				$this->parameters = $parameters;
				$this->common_init($field,$value);
			}
			
			function factory($field="",$value="")
			{
				if ($this->objects = Lybra_DB_DataObject::Lybra_DB_DataObject($field,$value))
				{
					// Do special tasks
					$this->retrieve_all_files();
				}
			}
			
			// Retrieve the list of categories accessible by this user
			function retrieve_document_categories()
			{	
			}
			// Retrieve the list of documents accessible by the user
			function retrieve_documents()
			{	
			}
			
			/* Static get */
			function staticGet($k,$v=NULL) { return DB_DataObject::staticGet('document_manager',$k,$v); }
			
			/*
			 * Define table to work on
			 */
			function table()
			{
		        return array(
		            LYBRA_DOCUMENT_DOCUMENT_ID_FIELD			=> DB_DATAOBJECT_INT,
		            LYBRA_DOCUMENT_DOCUMENT_NAME_FIELD			=> DB_DATAOBJECT_STR,
		            LYBRA_DOCUMENT_DOCUMENT_DESCRIPTION_FIELD	=> DB_DATAOBJECT_STR
		        );
			}
			
			// Override default key
			function keys() 
	    	{
	        	return array(LYBRA_DOCUMENT_DOCUMENT_ID_FIELD);
	    	}

			// Retrieve all files belonging to this document
			function retrieve_all_files()
			{
				$this->file_objects = new file_manager("document_id",$this->document_id);
				print_r($this->file_objects);
			}
		}
?>