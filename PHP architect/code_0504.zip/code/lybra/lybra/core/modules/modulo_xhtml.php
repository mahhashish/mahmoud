<?
 /**********************************************************************************************
 		Lybra: A general purpose framework for fast web development
		Copyright (C) 2002-2004 Simone Grassi, Andrea Giorgini

	    modulo_xhtml.php
	    ----------------
		begin:  	5/2003 Andrea Giorgini (Ci S.B.i.C. snc)
		copyright:	(C) 2003, Simone Grassi,  Andrea Giorgini
					viale Marconi 438, 47023 Cesena (FC), Italy.
		email:		lybra@cisbic.com

	    This program is free software; you can redistribute it and/or modify
	    it under the terms of the GNU General Public License as published by
	    the Free Software Foundation; either version 2 of the License, or
	    (at your option) any later version.

	    This program is distributed in the hope that it will be useful,
	    but WITHOUT ANY WARRANTY; without even the implied warranty of
	    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	    GNU General Public License for more details.

	    You should have received a copy of the GNU General Public License
	    along with this program; if not, write to the Free Software
	    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************************************/

/*	WISH LIST
	1 - ??!?
	2 - boh...
*/

	// Da capire come mettere la dimensione screen.width e screen.height
	define ("CALENDAR_OPT",",'scrollbars=no,resizable=no,status=no,left='+((screen.width/2)-200)+',top=250");

	class modulo_xhtml
	{
		// Constructor
		// The parameter cal_path define where the file calendar.php is located (RELATIVE PATH e.g core/calendar.php)
		// The parameter default_cal_img must contain the complete path that contain the image for the button
		// The parameter img_path contain the complete path to the images folder
		// The parameter cal_style can be specified for a different style for the calendar
		function modulo_xhtml(&$script,&$parameters)
		{
			$this->parameters = $parameters;
			$this->script = $script;
		}

		// Function to generate the calendar that will be (maybe) loaded into the gen_data_cal object
		// If ny=0 the year will not displayed
		function gen_calendar($style,$fsm,$fwm,$fsd,$fwd,$fsn,$fwn,$tw,$th,$cs,$cp,$mbgcolor,$dbgcolor,$ntc,$nbc,$mbc,$tfc,$ny)
		{
			// $style contains the index of the stylesheet to be applied; 0 is the default
			// $dnbc Day name background color
			// $tw Table width
			// $th Table Heigth

			if ($style > 0)
			{
				$conf = explode("&",$this->parameters->style . $style);
				foreach ($conf as $values)
				{
					$config = explode ("=",$values);
					$$config[0] = $config[1];
				}
			}

			if (!$al) $al="0";
			if (!$ot) $ot="-0";
			if (!$ny) $ny=1;
			if (!$ds) $ds=0;
			if (!$nt) $nt=0;

			// Cell alignment
			if ($al == 1)
				$al = "align=\'right\' valign=\'top\'";
			elseif ($al == 2)
				$al = "align=\'left\' valign=\'top\'";
			else
				$al = "align=\'center\' valign=\'middle\'";

			// Todays day number
			$ot = $ot*3600;
			$tmo = date("m", time()+$ot);	// Current month
			$tda = date("j", time()+$ot);	// Current day
			$tyr = date("Y", time()+$ot);	// Current year
			$tnum = (intval((date ("U", mktime(20,0,0,$tmo,$tda,$tyr))/86400)));

			if (!$mo) $mo=$tmo;
			if (!$yr) $yr=$tyr;

			// First of the month day number
			$daycount = (intval((date ("U", mktime(20,0,0,$mo,1,$yr))/86400)));

			$mo = intval($mo);

			$this->script->set_var("mese_idx",$mo); // Display month

			if ($ny!=0)
				$this->script->set_var("anno",$yr); // Display year

			// On what day does the first fall
			$sd = date ("w", mktime(0,0,0,$mo,1-$ds,$yr));
			$cd = 1-$sd;

			// Number of days in month
			$nd = mktime (0,0,0,$mo+1,0,$yr);
			$nd = (strftime ("%d",$nd))+1;

			// Process the day marking
			if ($es)
			{
				$es = explode ("x",$es);
				$smc = count ($es);
				$ee = explode ("x",$ee);
				$emc = count ($ee);

				if ($smc==1)
				{
					$es[1]="3000-01-01";
					$ee[1]="3000-01-01";
				}
			}

			$i=0;
			while ($i < $smc)
			{
				$es[$i] = ereg_replace('-','/', $es[$i]);
				$ee[$i] = ereg_replace('-','/', $ee[$i]);
				$start = intval(strtotime ($es[$i])/86400)+1;
				$end = intval(strtotime ($ee[$i])/86400)+1;

				if (!$ee[$i])
					$end=$start; // MARK SINGLE DAY WITH ONLY ES VARIABLE

				if (!$bgc[$start])
					$bgc[$start]=1;
				else 
					$bgc[$start]=4;

				$bgc[$end]=3;
				for ($n = ($start+1); $n < $end; $n++)
					$bgc[$n] = 2;
				$i++;
			}

			//////////////////////
			// DISPLAY CALENDAR //
			//////////////////////

			// Adjust table height for 5 rows months
			$checksize=$fsd+$cs+$cp;
			$checkrows=$ds+$nd-$cd;
			if ($checkrows<36)
				$th=$th-intval(($th-$checksize)/6);

			// If a month table background color is set
			if ($mbgcolor)
				$this->script->set_var("mbgcolor","BGCOLOR=\"#$mbgcolor\"");
			else
				$this->script->set_var("mbgcolor","");

			$this->script->set_var("checksize",$checksize);

			// If a day table background color is set
			if ($dbgcolor)
				$this->script->set_var("dbgcolor","BGCOLOR=\"#$dbgcolor\"");
			else
				$this->script->set_var("dbgcolor","");

			// Print days digit row
			$righe = "";
			for ($i=0;$i<7;$i++)
			{
				$dayprint=$ds+$i;
				if ($dayprint>6)
					$dayprint=$dayprint-7;
				$righe .= "  <td>{xhtml_calendar_giorno" . $dayprint . "}</td>";
			}
			$this->script->set_var("righe",$righe);

			// Display calendar
			$q1 = "";

			for ($i = 1; $i<7; $i++)
			{
				// This tr tag for the lines of the days
				if ($cd >= $nd)
						break;
				$q1 .= "'<tr $al class=\'dates{style}\'";
				if ($ntc)
					$q1 .= " bgcolor=\'#$ntc\'";
				$q1 .= ">'+\n";
				for ($prow = 1; $prow<8; $prow++)
				{
					if ($daycount == $tnum && $nt != "1" && $cd>0 && $cd<$nd)
					{
						$q1 .= "'<td bgcolor=\'#";
						if ($bgc[$daycount])
							$q1 .= $mbc;
						else
							$q1 .= $nbc;
						$q1 .= "\'><font color=\'#$tfc\'><a class=\'today\'href=\'#\' onClick=set_date(\'$cd\');>$cd</a></font></td>'+\n";
						$daycount++;
						$cd++;
					}
					else
					{
						$q1 .= "'<td";
						if ($cd > 0 && $cd < $nd)
						{
							$q1 .= " bgcolor=\'#";
							if ($bgc[$daycount])
								$q1 .= $mbc;
							else
								$q1 .= $nbc;
							$q1 .= "\'><a href=\'#\' onClick=set_date(\'$cd\');>$cd</a>";
							$daycount++;
						}
						else
							$q1 .= ">";
						$cd++;
						$q1 .= "</td>'+\n";
					}
				}
				$q1 .= "'</tr>'+\n";
			}
			// End displaying calendar

			// Setting default values
			$this->script->set_var("fsm",$fsm);
			$this->script->set_var("fwm",$fwm);
			$this->script->set_var("fsd",$fsd);
			$this->script->set_var("fwd",$fwd);
			$this->script->set_var("fsn",$fsn);
			$this->script->set_var("fwn",$fwn);
			$this->script->set_var("tw",$tw);
			$this->script->set_var("th",$th);
			$this->script->set_var("cs",$cs);
			$this->script->set_var("cp",$cp);
			$this->script->set_var("al",$al);
			$this->script->set_var("ntc",$ntc);
			$this->script->set_var("q1",$q1);
			$this->script->set_var("style",$style);
			$this->script->set_var("mn",$mn);
			$this->script->set_var("nbc",$nbc);
			$this->script->set_var("mbc",$mbc);
			$this->script->set_var("tfc",$tfc);

			$mesi = "";
			for ($i=1; $i<13; $i++)
				if ($i == $mo)
					$mesi .= "<option value=$i selected>{xhtml_calendar_mese$i}</option>";
				else
					$mesi .= "<option value=$i>{xhtml_calendar_mese$i}</option>";

			$anni= "";
			$start_year = $tyr - 5;

			for ($i=1; $i<12; $i++)
			{
				if ($start_year == $tyr)
					$anni .= "<option value=$start_year selected>$start_year</option>";
				else
					$anni .= "<option value=$start_year>$start_year</option>";
				$start_year++;
			}

			$this->script->set_var("selmesi",$mesi);
			$this->script->set_var("selanni",$anni);
		}

		// Function to generate an object composite by a text input with an (optional)
		// button to call a little window containing a calendar inside; clicking over
		// the link of each day, the date will be returned inside the text box
		function gen_data_cal($name,$with_button=1,$style=0,$fsm="18",$fwm="bold",$fsd="11",$fwd="normal",$fsn="11",$fwn="normal",$tw="175",
							$th="140",$cs=1,$cp=0,$mbgcolor="",$dbgcolor="",$ntc="",$nbc="EEEEEE",$mbc="EEBBBB",$tfc="CF0000",$ny="1")
		{
			$data_cal = "<input type=\"text\" name=\"";
			if (!isset($name))
				return false;
			// Set the name; the size is fixed to 10 characters
			$data_cal .= "$name\" size=\"10\" maxlength=\"10\">";
			$this->script->set_var("input_name",$name);

			// Have to add the button
			if ($with_button == 1)
			{
				// Generate the page with the calendar
				$calendar = '{xhtml_calendar_tagtemp}';

				switch ($style)
				{
					default: $w=192; $h=190; break;
				}

				$data_cal .= " <a href=\"#\" onClick=\"var cal=document.open('thecal.php?n=$name',''" . CALENDAR_OPT . ",width=$w,height=$h');";
//				$data_cal .= " cal.document.writeln($calendar); if (document.all) cal.document.location.reload();";
				$data_cal .= "\"><img src=\"";
				$data_cal .= $this->parameters->img_path . "/" . $this->parameters->cal_default_img . "\"";
				$data_cal .= " border=\"0\"></a>";
				
				$this->gen_calendar($style,$fsm,$fwm,$fsd,$fwd,$fsn,$fwn,$tw,$th,$cs,$cp,$mbgcolor,$dbgcolor,$ntc,$nbc,$mbc,$tfc,$ny);
			}

			return $data_cal;
		}
	}
?>