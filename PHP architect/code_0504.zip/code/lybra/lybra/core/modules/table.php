<?
 /**********************************************************************************************
 		Lybra: A general purpose framework for fast web development
		Copyright (C) 2002-2004 Simone Grassi, Andrea Giorgini

	    table.php
	    ---------
		begin:  	2001 Simone Grassi (Ci S.B.i.C. snc)
		copyright:	(C) 2001, Simone Grassi,  Andrea Giorgini
					viale Marconi 438, 47023 Cesena (FC), Italy.
		email:		lybra@cisbic.com

	    This program is free software; you can redistribute it and/or modify
	    it under the terms of the GNU General Public License as published by
	    the Free Software Foundation; either version 2 of the License, or
	    (at your option) any later version.

	    This program is distributed in the hope that it will be useful,
	    but WITHOUT ANY WARRANTY; without even the implied warranty of
	    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	    GNU General Public License for more details.

	    You should have received a copy of the GNU General Public License
	    along with this program; if not, write to the Free Software
	    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************************************/

	define("SOME_ERROR", -254);
	require_once("pear/DB.php");

	class table extends DB
	{
		// last query result
		var $last_res;

		/**
		 * Connect to database
		 * 
		 * @param $dbtype
		 * @param $dbname
		 * @param $host
		 * @param $port
		 * @param $user
		 * @param $password
		 *
		 * retval true on success false otherwise
		 **/
		 
		// function table($dbtype,$dbname,$host,$port,$user,$password)
		function table($parameters)
		{
			$this->dsn = $parameters->dbtype."://".($parameters->user!=""?$parameters->user.($parameters->password!=""?":".$parameters->password:"")."@":"").
								($parameters->host!=""?$parameters->host.($parameters->port!=""?":".$parameters->port:""):"")."/".($parameters->dbname!=""?$parameters->dbname:"");
			$this->connection = DB::connect($this->dsn);
			if (DB::isError($this->connection))
				return false;
			return true;
		}

		/**
		 * Disconnect from database
		 * 
		 * @param $select string with SQL select syntax
		 *
		 * retval true on success false otherwise
		 **/
		function destruct($connection_id="")
		{
		    $this->connection->disconnect();
		}

		/**
		 * Retrieve data about actual database and personalize this instance to it
		 * 
		 * retval true on success false otherwise
		 **/
		function automap()
		{
		    // TO implement, use db specific select to retrieve tables and fields properties
		}

		/**
		 * Start a new transaction
		 * 
		 * retval true on success false otherwise
		 **/
		function start_transaction()
		{
			return false;
		}
		/**
		 * Commit actual transaction
		 * 
		 * retval true on success false otherwise
		 **/
		function commit_transaction()
		{
			return false;
		}
		
		/**
		 * Rollback actual transaction
		 * 
		 * retval true on success false otherwise
		 **/
		function rollback_transaction()
		{
			return false;
		}

		/**
		 * Retrieve records doing a query
		 * 
		 * @param $select string with SQL select syntax
		 * @param $mode mode of execution
		 * @param $param additional parameters
		 *
		 * retval true on success false otherwise
		 **/
		function retrieve($select,$mode,$param = "")
		{
		    $this->free();
		    $i = 0;
		    $this->lastRows = array();
		    $this->results = array();
		    if ($this->query($select))
			while ($this->results[$i] = $this->last_res->fetchRow($mode))
			{
			    $i++;
			}
			unset($this->results[$i]);
			$this->count = count($this->results);
		    $this->empty_result = $this->empty_query = !($this->count);
		    return (!$this->isError($this->last_res));
		}

		/**
		 * Execute $select
		 *
		 * @param $select string with SQL select syntax
		 *
		 * retval true on success false otherwise
		 **/
		function query($select)
		{
			//print_r($this->connection);
			return !(DB::isError($this->last_res = $this->connection->query($select)));
		}

		/**
		 * Execute $select
		 *
		 * @param $select string with SQL select syntax
		 *
		 * retval a PEAR DB object result
		 **/
		function retrieve_pear_db_result($select)
		{

   			if(DB::isError($this->last_res = $this->connection->query($select)))
				return DB::errorMessage($this->last_res);

			return $this->last_res;
		}

		/**
		 * Free last result
		 *
		 * retval true
		 **/
		function free()
		{
			if (is_object($this->last_res))
			    $this->last_res="";
			return true;
		}
		
		/**
		 * Fetch next found row
		 * 
		 * @param $mode active retrieve mode
		 *
		 * retval return fetched record
		 **/		
		function pop($mode=DB_FETCHMODE_DEFAULT)
		{
			$record = $this->last_res->fetchRow($mode);
			if ($error=$this->catchError($record))
				return !$error;
			return $record;		
		}
		
		/**
		 * Execute generic SQL statement
		 * 
		 * @param $sql active retrieve mode
		 *
		 * retval return fetched record
		 **/		
		function execute_statment($sql)
		{
		    return $this->query($sql);
		}
		function execute_statement($sql)
		{
		    return $this->query($sql);
		}

		// FIXME: to rewrite!
		/**
		 * Construct the INSERT with the variables values. Automatically retrieve sequence number next value.
		 * 
		 * retval true on success false otherwise
		 **/
		function insert()
		{
			$sep = "";
			$list = "(";
			$value = "(";
		
			// Scans all the fields in the table
			for ( $i = 0; $i < count( $this->fNames ); $i++ )
			{
				$help = $this->fNames[ $i ];
				// Check if this field have a sequence_number associated
				// FIXME: Se il campo con numero di sequenza e' gia' settato
				// va usato il valore presente e non va fatta la query sulla sequenza
				if ( ( $this->sNames[ $i ] ) && ( $this->sNames[ $i ] != "" ))
				{
					// If the field $this->fNames[ $i ] is not empty we suppose that
					// the next sequence number must be retrieved just to do the insert
					// and then to know all the fields of the record.
					// The insert can be made without some sequence number, the database
					// automatically use the next sequence val, but then there is no way to be sure
					// of the number used for the sequence numbers.
		
					// Do this select to retrieve the nextVal of the sequence
					$this->dbHandler->setSelect("SELECT nextval('" . $this->sNames[ $i ] . "') ");
					$this->dbHandler->executeQuery();
					$this->$help = $this->dbHandler->getSequenceNumber();
				}
				// Create the select
				$list .= $sep . $help;
				// Add the field $help, with 'field' if the type is 1, without if the type is 0
				if ( $this->fType[ $i ] == 0 )
					$value .= $sep . $this->$help;
				elseif ( $this->fType[ $i ] == 3 )
					$value .= $sep . ( $this->$help == "" ? "'now'" : "'" . $this->$help . "'" );
				else
					$value .= $sep . "'" . $this->$help . "'";
				$sep = ",";
			}
			$list .= ")";
			$value .= ")";
			$insert = " INSERT INTO " . $this->TABLE_NAME . " " . $list . " VALUES " . $value . " ";
			// print "<br> INSERT: |" . $insert . "|<br>";
			$this->dbHandler->setSelect( $insert );
			return $this->dbHandler->executeQuery();
		}
	
	
		// FIXME:to rewrite!
		// Effettua la update di questo record, inserendo tutti i campi con isset(campo)==true
		// scarta dalla lista il parametro $keyName essendo una eventuale chiave primaria
		// FIXME: i parametri da scartare nell'update non devono essere passati alla update ma
		// dovrebbero essere specificati nella init passandogli un vettore aggiuntivo che specifica
		// quali parametri sono chiave, per ora si specifica a mano (ed uno solo), il meglio sarebbe
		// quello di ottenere il campo chiave dal database stesso o memorizzare questa informazione
		// nella tabella che ha lo stesso nome del database
		
		// BUG: now it works with the retrieved key value, it should work also not specifing the key
		//      simply as an update of n-rows. Use executeStatment instead of this.
		/**
		 * Construct the UPDATE with the variables values.
		 * 
		 * retval true on success false otherwise
		 **/
		function update( $keyName )
		{
			$selectStr = " UPDATE " . $this->TABLE_NAME . " SET ";
	
			// Flag that is true if no fields are currently into the SET statment
			$noSet = true;
			// Scans all the fields of the table to build the SET statment
			for ( $i = 0; $i < count( $this->fNames ); $i++ )
		            	// Do not consider a key field
		            	if ( $this->fNames[ $i ] != $keyName )
		            	{
					// Construct the statment
					$help = $this->fNames[ $i ];
					if ( isset( $this->$help ))
					{
						if ( $noSet == true )
						{
							$selectStr .= " " . $help . "=";
							$noSet = false;
						} else
							$selectStr .= ", " . $help . "=";
					// Depending on the type of field add the correct syntax into the select
					switch ( $this->fType[ $i ] )
					{
						case 0: // INTEGER
							$selectStr .= $this->$help;
							break;
						case 1: // TEXT, VARCHAR
							$selectStr .= "'" . $this->$help . "'";
							break;
						case 2: // BOOLEAN
							$selectStr .= ( $this->$help == true ? 'true' : 'false' );
							break;
						case 4: // DATA (se il campo e' settato ma uguale a "" allore viene posto a 'now'
							$selectStr .= ( $this->$help == "" ? "'now'" : "'" . $this->$help . "'" );
							break;
					}
		                    }
		            } else
			// Memorizza la posizione della chiave nel vettore dei nomi dei campi
			$keyPos = $i;
			
			$help = $this->fNames[ $keyPos ];
			// FIXME: funziona solo se la chiave utilizzata e' integer o text (0 o 1) non 2 o 3 (come tipo)
			$selectStr .= " WHERE " . $this->fNames[ $keyPos ] . "=" . ( $this->fTypes[ $keyPos ]==0 ? $this->$help . " " : "'" . $this->$help . "' ");
		
			$this->dbHandler->setSelect( $selectStr );
			return $this->dbHandler->executeQuery();
		}
		/**
		 * Return the value of the field with name $field_name
		 * 
		 * @param $field_name
		 * retval true on success false otherwise
		 **/
		function get_field($field_name)
		{
		    return $this->fNames[$field_name];
		}

		/**
		 * Assign all the field from the istance $object to the current class
		 * is used when retrieve mode is by object
		 * 
		 * @param $object contains field of a record
		 *
		 * retval true on success false otherwise
		 **/
		function setAll($object)
		{
		    if (!is_object($object))
			return false;
		    // Scans all the fields
		    for ($i = 0; $i<count($this->fNames); $i++)
		    {
			$help = $this->fNames[$i];
			if (isset( $object->$help))
			    // If the field has a value assign it to the current class
			    $this->$help = $object->$help;
		    }
		    return true;
		}

		/**
		 * Return a string representation  of a record
		 * 
		 * @param $object contains field of a record
		 *
		 * retval true on success false otherwise
		 **/
		function to_string()
		{
			$retStr = " -------------------------------<br>";
			for ($i = 0; $i<count($this->fNames); $i++)
			{
				$help = $this->fNames[$i];
				$retStr .= " " . $this->fNames[$i] . " : ". (isset($this->$help)?$this->$help:" null ");
				$retStr .= "<br>";
			}
			$retStr .= " -------------------------------<br>";
		
			return $retStr;
		}
	
		/**
		 * Lock a table
		 * 
		 * @param $table_name table to lock
		 *
		 * retval true on success false otherwise
		 **/
		function lock($table_name)
		{
			return $this->dbHandler->lock( $table_name );
		}
		
		/**
		 * Unlock a table
		 * 
		 * @param $table_name table to lock
		 *
		 * retval true on success false otherwise
		 **/
		function unlock($table_name)
		{
			return $this->dbHandler->unLock( $table_name );
		}
	}
?>
