<?
 /**********************************************************************************************
 		Lybra: A general purpose framework for fast web development
		Copyright (C) 2002-2004 Simone Grassi, Andrea Giorgini

	    auth.php
	    --------
		begin:  	9/2003 Simone Grassi (Ci S.B.i.C. snc)
		copyright:	(C) 2003, Simone Grassi,  Andrea Giorgini
					viale Marconi 438, 47023 Cesena (FC), Italy.
		email:		simone@cisbic.com,andrea@cisbic.com,vico@cisbic.com

	    This program is free software; you can redistribute it and/or modify
	    it under the terms of the GNU General Public License as published by
	    the Free Software Foundation; either version 2 of the License, or
	    (at your option) any later version.

	    This program is distributed in the hope that it will be useful,
	    but WITHOUT ANY WARRANTY; without even the implied warranty of
	    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	    GNU General Public License for more details.

	    You should have received a copy of the GNU General Public License
	    along with this program; if not, write to the Free Software
	    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************************************/

    /**
     * Manage generic authorization issues
     * works on objects, actors and actions
     * Single kind of permission can be activated or not
     * depending on the need of the project
     **/
    class auth
    {
    	// Tables
    	define("AUTH_OBJECTS",1);
    	define("AUTH_ACTORS",2);
    	define("AUTH_ACTIONS",3);
    	define("AUTH_OBJECT_RELATIONS",4);
    	define("AUTH_OBJECT_CATEGORIES",5);
    	define("AUTH_OBJECT_PART_OF_CATEGORY",6);
    	define("AUTH_OBJECT_IN_RELATION_TO_OBJECT",7);
    	define("AUTH_HAS_DIRECT_PERMISSION_TO",8);
    	define("AUTH_ROLES",9);
    	define("AUTH_HAS_ROLE_OBJECT",10);
    	define("AUTH_HAS_ROLE_CATEGORIES",11);
    	define("AUTH_POLICY",12);
    	define("AUTH_POLICY_ON_OBJECT_CAN",13);
    	define("AUTH_POLICY_ON_CATEGORIES_CAN",14);
    	
    	// Fields
    	define("AUTH_ACTOR_ID",1);
    	define("AUTH_OBJECT_ID",2);
    	define("AUTH_ACTION_ID",3);
    	define("AUTH_ACTIVE_PERMISSION",4);
    	
    	// Generic DB Structure
    	/* TABLE BY TABLE, FIELDS NEEDED BY THIS MODULE
    	
    		OBJECTS:						object_id*,object_type
    		ACTORS:							actor_id*,actor_type
    		ACTIONS:						action_id*,action_type
    		OBJECT_RELATIONS:				object_relation_id*
       		OBJECT_CATEGORIES:				object_category_id*,category_type
       		FATHER_CATEGORY:				object_category_id*,father_category_id
    		OBJECT_PART_OF_CATEGORY:		object_id*,object_category_id*,from_date,to_date
    		OBJECT_IN_RELATION_TO_OBJECT:	src_object_id*,object_relation_id*,dst_object_id*,from_date,to_date
    		HAS_DIRECT_PERMISSION_TO:		actor_id*,object_id*,action_id*
    		ROLES:							role_id*
    		HAS_ROLE_OBJECT:				actor_id*,role_id*,object_id*
    		HAS_ROLE_CATEGORIES:			actor_id*,role_id*,object_category_id*
    		POLICY:							policy_id*
    		POLICY_ON_OBJECT_CAN:			policy_id*,action_id*,allowed,option
    		POLICY_ON_CATEGORIES_CAN:		policy_id*,
    	*/

    	// OBJECT TYPES
    	define("AGENDA",1);
    	define("SESSION",2);
    	define("TALK",3);
    	define("SUBTALK",4);
    	
    	define("NO_PERMISSIONS",0);
    	//define("",);
    	
		function auth()
		{
			return true;
		}
		
		function db_init()
		{
			// SOLUTION FOR CDSAGENDA 5.0 (FIXME: store into database)
			// Associate object_types to tables storing objects of that type
			$this->object_tables = array(AGENDA=>"AGENDA",SESSION=>"SESSION",TALK=>"TALK",SUBTALK=>"TALK");
			// Associate actor_type to tables storing actors of that type
			$this->actors_type = array(USERS=>"USERS");
			// Associate action_type to tables storing actions of that type
			$this->actions_type = array(ACTIONS=>"ACTIONS");
			
			$this->auth_tb[HAS_DIRECT_PERMISSION_TO][0] = "DIRECT_PERMISSION_TO";
			$this->auth_tb[HAS_DIRECT_PERMISSION_TO][ACTOR_ID] = "user_id";
		}
		
		/**
		 * Main function, every single permission can be retrieved from here
		 * @params:
		 *		objectID: the action will be done on the object with this id
		 *		actorID: id of the actor that will do the action on this object
		 *		actionID: id of the action to do
		 **/
		function authorize($objectID,$actorID,$actionID)
		{
			// Check if the permission is already retrieved from DB
			if (is_set($this->auth_cache[$actorID][$objectID]))
			{
				// FIXME: Return the correct value, not already managed how to store inside cache
				return true;
			}
			// Retrieve all authorization relative to this user
			$this->auth_actor_retrieve($actorID);
			// Check for permissions about object_id
			if (is_set($this->auth_cache[$actorID][$objectID][$actionID])
				return $this->pauth_cache[$actorID][$objectID][$actionID];
			return AUTH_NO_PERMISSIONS;
		}
		
		
		/**
		 *
		 **/
		
		/**
		 * Retrieve all authorization about this user
		 **/
		 function auth_actor_retrieve()
		 {
			// Retrieve direct permissions on objects and categories
			$this->retrieve_direct_permissions($actorID);
			// Retrieve permission from group partnership on objects and categories
			$this->retrieve_
		 }
		 
		 function retrieve_direct_permissions($actorID)
		 {
			$select = "SELECT ".$this->auth_tb[AUTH_HAS_PERMISSION_TO][AUTH_ACTION_ID].",".$this->auth_tb[AUTH_HAS_PERMISSION_TO][AUTH_OBJECT_ID].
								.$this->auth_tb[AUTH_HAS_PERMISSION_TO][AUTH_ACTIVE_PERMISSION].
						" FROM ".$this->auth_tb[AUTH_ACTION_ID].
						" WHERE ".$this->auth_tb[AUTH_HAS_PERMISSION_TO][AUTH_ACTOR_ID]."='$actorID'";
			$this->query($select);
			if (!$this->empty_results)
				for ($i=0;$i<$this->count;$i++)
					$this->auth_cache[$this->results[$i][0]][$this->results[$i][1]][$actorID] = $this->resuls[$i][2];
		 }
    }
?>