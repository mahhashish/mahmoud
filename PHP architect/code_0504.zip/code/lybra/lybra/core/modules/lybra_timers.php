<?
 /**********************************************************************************************
 		Lybra: A general purpose framework for fast web development
		Copyright (C) 2002-2004 Simone Grassi, Andrea Giorgini

	    lybra_timers.php
	    ----------------
		begin:  	3/2004 Simone Grassi (Ci S.B.i.C. snc)
		copyright:	(C) 2004, Simone Grassi,  Andrea Giorgini
					viale Marconi 438, 47023 Cesena (FC), Italy.
		email:		lybra@cisbic.com

	    This program is free software; you can redistribute it and/or modify
	    it under the terms of the GNU General Public License as published by
	    the Free Software Foundation; either version 2 of the License, or
	    (at your option) any later version.

	    This program is distributed in the hope that it will be useful,
	    but WITHOUT ANY WARRANTY; without even the implied warranty of
	    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	    GNU General Public License for more details.

	    You should have received a copy of the GNU General Public License
	    along with this program; if not, write to the Free Software
	    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************************************/

		define("LYBRA_TIMERS_TABLE","lybra_timers");
		define("LYBRA_TIMERS_ID_FIELD","timer_id");
		define("LYBRA_TIMERS_START_TIME_FIELD","start_time");
		define("LYBRA_TIMERS_END_TIME_FIELD","end_time");
		define("LYBRA_TIMERS_RECURSIVE_BITMAP_FIELD","recursive_bitmap");
		define("LYBRA_TIMERS_WEEK_BITMAP_FIELD","week_bitmap");
		define("LYBRA_TIMERS_TIMER_CATEGORY","timer_category");
		define("LYBRA_TIMERS_DESCRIPTION","description");

		class lybra_timers extends Lybra_DB_DataObject
		{
			/**
		     * Test timers
		     *
		     * @param $field name of the field and $value it's value
		     * 			used to retrieve data from the DB
		     *
		     * @return mixed a newly created DB object, or a DB error code on
		     * error
		     *
		     * access private
		     */
		     
			// Table name
			var $__table = LYBRA_TIMERS_TABLE;

			function lybra_timers($field="",$value="")
			{
				$this->common_init($field,$value);
			}

			function factory($field="",$value="")
			{
				$recursive_bitmap_field = LYBRA_TIMERS_RECURSIVE_BITMAP_FIELD;
				$timer_id_field = LYBRA_TIMERS_ID_FIELD;
				
				if (Lybra_DB_DataObject::factory($field,$value))
				{
					for ($i=0;$i<count($this->objects);$i++)
					{
						// Check if is a daily recursive timer
						if ($this->objects[$i]->$recursive_bitmap_field == LYBRA_TIMER_DAILY)
						{
							// Retrieve day timers associated to this timer
							$this->objects[$i]->daily_timers = new lybra_daily_timers($this->objects[$i]->$timer_id_field);
						}
					}
				}
			}
			
			function is_timer_on()
			{
				$start = LYBRA_TIMERS_START_TIME_FIELD;
				$end = LYBRA_TIMERS_END_TIME_FIELD;
				$recursive = LYBRA_TIMERS_RECURSIVE_FIELD;
			}

			/*
			 * Define table to work on
			 */
			function table()
			{
		        return array(
		        	LYBRA_TIMERS_ID_FIELD			=>	DB_DATAOBJECT_INT,
		            LYBRA_TIMERS_START_TIME_FIELD	=>	DB_DATAOBJECT_INT,
		            LYBRA_TIMERS_END_TIME_FIELD		=>	DB_DATAOBJECT_INT,
		            LYBRA_TIMERS_RECURSIVE_FIELD	=>	DB_DATAOBJECT_INT,
		            LYBRA_TIMERS_TESTED_TIMES		=>	DB_DATAOBJECT_INT
		        );
			}

			// Override default key
			function keys() 
	    	{
	        	return array(LYBRA_TIMERS_ID_FIELD);
	    	}
		}

		define("LYBRA_TIMERS_DAY_TABLE","lybra_timers_day");
		define("LYBRA_TIMERS_DAY_TIMER_DAY_ID_FIELD","timer_day_id");
		define("LYBRA_TIMERS_DAY_START_TIME_FIELD","start_time");
		define("LYBRA_TIMERS_DAY_END_TIME_FIELD","end_time");
		define("LYBRA_TIMERS_DAY_DESCRIPTION","description");	
		
		//FIXME: UTILIZZARE JOIN PER RECUPERARE DIRETTAMENTE DA ENTRAMBE LE TABELLE!
		
		class lybra_daily_timers extends Lybra_DB_DataObject
		{
			/**
		     * Test timers
		     *
		     * @param $field name of the field and $value it's value
		     * 			used to retrieve data from the DB
		     *
		     * @return mixed a newly created DB object, or a DB error code on
		     * error
		     *
		     * access private
		     */
		     
			// Table name
			var $__table = LYBRA_TIMERS_DAY_TABLE;

			function lybra_timers($field="",$value="")
			{
				$this->common_init($field,$value);
			}

			function factory($field="",$value="")
			{
	
				if (Lybra_DB_DataObject::factory($field,$value))
				{
					// Do spacial tasks on retrieved entries
					//for ($i=0;$i<count($this->objects);$i++)
					//{
					//}
				}
			}
			
			function is_timer_on($time_to_check="")
			{
				$start = LYBRA_TIMERS_DAY_START_TIME_FIELD;
				$end = LYBRA_TIMERS_DAY_END_TIME_FIELD;
				
				if (strcmp($time_to_check,""))
					$time_to_check = date("H:i:s");
				// Timer is on if current time is between start and end time
				if (($actual_time>=$start) && ($actual_time<=$end))
					return TRUE;
				return FALSE;
			}

			/*
			 * Define table to work on
			 */
			function table()
			{
		        return array(
		        	LYBRA_TIMERS_DAY_ID_FIELD			=>	DB_DATAOBJECT_INT,
		            LYBRA_TIMERS_DAY_START_TIME_FIELD	=>	DB_DATAOBJECT_INT,
		            LYBRA_TIMERS_DAY_END_TIME_FIELD		=>	DB_DATAOBJECT_INT
		        );
			}

			// Override default key
			function keys() 
	    	{
	        	return array(LYBRA_TIMERS_DAY_ID_FIELD);
	    	}
		}
?>