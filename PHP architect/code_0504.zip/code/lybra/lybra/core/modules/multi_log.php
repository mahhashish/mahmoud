<?
require_once("multilog/classes/logXml.class.php");
require_once("multilog/classes/logTxt.class.php");
require_once("multilog/classes/logCsv.class.php");
?>