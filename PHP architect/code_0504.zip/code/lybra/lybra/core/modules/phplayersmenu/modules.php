<?
	require_once ("template.inc.php");
?>
