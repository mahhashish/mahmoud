<?php
define("DB",0);
define("FILE",1);

require_once("layersmenu.inc.php");
require_once("template.inc.php");


Class LayersMenuComplete extends LayersMenu{
	
	function LayersMenuComplete($dsn){
		include("includes/config.php");
		
		global $visibility;
		
		$this->visibility = &$visibility;
		
		parent::LayersMenu();
		
		$this->abscissaStep = &$abscissaStep;
		
		//Css Style
		$this->css = &$menu_css; //Array of css Style
		
		//Arrow images
		$this->arrow = &$arrows_images;
		
		//Some PhpLayersMenu Settings
		//$this->setDownArrowImg($arrows_images["down"]);
		//$this->setForwardArrowImg($arrows_images["forward"]);
		$this->setImgdir($dir_images);
		$this->setImgwww($www_dir_images);
		$this->setTpldir($dir_template);
		//$this->setSubMenuTpl($down_template);
		$this->setLibjswww($libjswww);
		$this->setLibjsdir($libjsdir);
		
		//Template Parameters
		$this->template = &$template; //Array di templates
		$this->sub_template = &$sub_template; //Array di subtemplates
		$this->layer_position = &$layer_position; //Array of layer_position
		
		//DB Parameters
		$this->dsn = $dsn;
		$this->tableName = $db_table_name;
		$this->tableFields = $db_table_fields;
		$this->tableName_i18n = $db_table_i18n;
		$this->tableFields_i18n = $db_table_i18n_fields;
		
		//File Parameters
		$this->structure_file = $menu_structure_file;
		
		//Javascript Include
		$this->menu_jscript = $menu_jscript;
		
	}
	
	/**
	* The method to set the value of abscissaStep
	* @access public
	* @return void
	*/
	function setAbscissaStep($abscissaStep,$name) {
		$this->abscissaStep[$name] = $abscissaStep;
	}
	
	/**
	* A method to set forwardArrow
	* @access public
	* @param string $forwardArrow the forward arrow HTML code
	* @return void
	*/
	function setForwardArrow($forwardArrow,$menu_name) {
		$this->forwardArrow[$menu_name] = $forwardArrow;
	}
	
	
	/**
	* The method to set an image to be used for the forward arrow
	* @access public
	* @param string $forwardArrowImg the forward arrow image filename
	* @return boolean
	*/
	function setForwardArrowImg($forwardArrowImg,$menu_name) {
		if (!file_exists($this->imgdir . $forwardArrowImg)) {
			$this->error("setForwardArrowImg: file " . $this->imgdir . $forwardArrowImg . " does not exist.");
			return false;
		}
		$foobar = getimagesize($this->imgdir . $forwardArrowImg);
		$this->forwardArrow[$menu_name] = " <img src=\"" . $this->imgwww . $forwardArrowImg . "\" width=\"" . $foobar[0] . "\" height=\"" . $foobar[1] . "\" border=\"0\" alt=\" >>\" />";
		return true;
	}
	
	/**
	* A method to set downArrow
	* @access public
	* @param string $downArrow the down arrow HTML code
	* @return void
	*/
	function setDownArrow($downArrow,$menu_name) {
		$this->downArrow[$menu_name] = $downArrow;
	}
	
	/**
	* The method to set an image to be used for the down arrow
	* @access public
	* @param string $downArrowImg the down arrow image filename
	* @return boolean
	*/
	function setDownArrowImg($downArrowImg,$menu_name) {
		
		if (!file_exists($this->imgdir . $downArrowImg)) {
			$this->error("setDownArrowImg: file " . $this->imgdir . $downArrowImg . " does not exist.");
			return false;
		}
		print_($this->core_module_parameters,"ARROW");
		$foobar = getimagesize($this->imgdir . $downArrowImg);
		$this->downArrow[$menu_name] = " <img src=\"" . $this->imgwww . $downArrowImg . "\" width=\"" . $foobar[0] . "\" height=\"" . $foobar[1] . "\" border=\"0\" alt=\" >>\" />";
		return true;
	}
	
	function setHorizontal($name){
		$this->forwardArrow[$name] = " --&gt;";
		$this->downArrow[$name] = " --&gt;";
		
		$this->setForwardArrowImg($this->arrow[$name][FORWARD],$name);
		$this->setDownArrowImg($this->arrow[$name][DOWN],$name);
		
		$this->setHorizontalMenuTpl($this->template[$name]);
		$this->setSubMenuTpl($this->sub_template[$name]);
		
		$this->newHorizontalMenu($name, $this->layer_position[$name]);
	}
	
	function setVertical($name){
		$this->forwardArrow[$name] = " --&gt;";
		$this->downArrow[$name] = " --&gt;";
		
		$this->setForwardArrowImg($this->arrow[$name][FORWARD],$name);
		$this->setDownArrowImg($this->arrow[$name][DOWN],$name);
		
		$this->setVerticalMenuTpl($this->template[$name]);
		$this->setSubMenuTpl($this->sub_template[$name]);
		$this->newVerticalMenu($name, $this->layer_position[$name]);
	}
	
	function setTree($name){
		$this->newTreeMenu($name);
	}
	
	function setDB($name){
		$this->setDBConnParms($this->dsn);
		$this->setTableName($this->tableName);
		$this->setTableFields($this->tableFields);
		
		$this->setTableName_i18n($this->tableName_i18n);
		$this->setTableFields_i18n($this->tableFields_i18n);
		$this->scanTableForMenu($name,$this->language);
	}
	
	
	function setFile($name){
		$this->setMenuStructureFile($this->structure_file[$name]);
		$this->parseStructureForMenu($name);
	}
	
	function setType($name,$type){
		$this->type[$name] = $type;
	}
	
	function getType($name){
		return $this->type[$name];
	}
	
	//Load Browser Detection javascript
	function loadBrowserDtJs(){
		return "<script language=\"JavaScript\" type=\"text/javascript\" src=\"".$this->menu_jscript[0]."\"></script>\n";
	}
	
	function loadLayersJs(){
		return "<script language=\"JavaScript\" type=\"text/javascript\" src=\"".$this->menu_jscript[1]."\"></script>
		<script language=\"JavaScript\" type=\"text/javascript\" src=\"".$this->menu_jscript[2]."\"></script>\n";
	}
	
	function loadTreeJs(){
		return "<script language=\"JavaScript\" type=\"text/javascript\" src=\"".$this->menu_jscript[3]."\"></script>\n";
	}
	
	function loadCss($name){
		return "<link rel=\"stylesheet\" href=\"".$this->css[$name]."\">\n";
	}
	
	
	function scanTableForMenu(
	$menu_name = "", // non consistent default...
	$language = ""
	) {
		$this->_maxLevel[$menu_name] = 0;
		$this->_firstLevelCnt[$menu_name] = 0;
		unset($this->tree[$this->_nodesCount+1]);
		$this->_firstItem[$menu_name] = $this->_nodesCount + 1;
		/* BEGIN BENCHMARK CODE
		$time_start = $this->_getmicrotime();
		/* END BENCHMARK CODE */
		$db = DB::connect($this->dsn, $this->persistent);
		if (DB::isError($db)) {
			$this->error("scanTableForMenu: " . $db->getMessage());
		}
		
		$query = "
		SELECT " .
		$this->tableFields["Name"] . " AS Name, " .
		$this->tableFields["id"] . " AS id, " .
		$this->tableFields["parent_id"] . " AS parent_id, " .
		$this->tableFields["text"] . " AS text, " .
		$this->tableFields["link"] . " AS link, " .
		$this->tableFields["title"] . " AS title, " .
		$this->tableFields["icon"] . " AS icon, " .
		$this->tableFields["target"] . " AS target, " .
		$this->tableFields["expanded"] . " AS expanded
		FROM " . $this->tableName . "
		WHERE " . $this->tableFields["id"] . " <> 1 and  Name = '$menu_name' ";
		
		if($this->label[$menu_name]){
			$i = 0;
			while(isset($this->label[$menu_name][$i])){
				if($i == 0){
					$query .= "and label = '".$this->label[$menu_name][$i]."' ";
				}else{
					$query .= "or label = '".$this->label[$menu_name][$i]."' ";
				}
				
				$i++;
			}
		}
		
		
		$query .= "ORDER BY " . $this->tableFields["orderfield"] . ", " . $this->tableFields["text"] . " ASC
	";
		
		$dbresult = $db->query($query);
		
		if(DB::isError($dbresult)){
			print($query);
		}
		
		$this->_tmpArray = array();
		while ($dbresult->fetchInto($row, DB_FETCHMODE_ASSOC)) {
			$this->_tmpArray[$row["id"]]["parent_id"] = $row["parent_id"];
			$this->_tmpArray[$row["id"]]["text"] = $row["text"];
			$this->_tmpArray[$row["id"]]["link"] = $row["link"];
			$this->_tmpArray[$row["id"]]["title"] = $row["title"];
			$this->_tmpArray[$row["id"]]["icon"] = $row["icon"];
			$this->_tmpArray[$row["id"]]["target"] = $row["target"];
			$this->_tmpArray[$row["id"]]["expanded"] = $row["expanded"];
		}
		if ($language != "") {
			$dbresult = $db->query("
			SELECT " .
			$this->tableFields_i18n["id"] . " AS id, " .
			$this->tableFields_i18n["text"] . " AS text, " .
			$this->tableFields_i18n["title"] . " AS title
			FROM " . $this->tableName_i18n . "
			WHERE " . $this->tableFields_i18n["id"] . " <> 1 and Name = $menu_name
			AND " . $this->tableFields_i18n["language"] . " = '$language'
		");
			while ($dbresult->fetchInto($row, DB_FETCHMODE_ASSOC)) {
				$this->_tmpArray[$row["id"]]["text"] = $row["text"];
				$this->_tmpArray[$row["id"]]["title"] = $row["title"];
			}
		}
		unset($dbresult);
		unset($row);
		$this->_depthFirstSearch($this->_tmpArray, $menu_name, 1, 1);
		//BEGIN BENCHMARK CODE
		//$time_end = $this->_getmicrotime();
		//$time = $time_end - $time_start;
		//print "TIME ELAPSED = " . $time . "\n<br>";
		//END BENCHMARK CODE */
		$this->_lastItem[$menu_name] = count($this->tree);
		$this->_nodesCount = $this->_lastItem[$menu_name];
		$this->tree[$this->_lastItem[$menu_name]+1]["level"] = 0;
		$this->_postParse($menu_name);
	}
	
	/**
	*
	*Array(ID,PARENT_ID,TEXT,LINK,TITLE,ICON,TARGET,ORDERFIELDS,EXPANDS)
	*
	*/
	function setMenuFromArray($menu_array,$menu_name){
		$this->_maxLevel[$menu_name] = 0;
		$this->_firstLevelCnt[$menu_name] = 0;
		unset($this->tree[$this->_nodesCount+1]);
		$this->_firstItem[$menu_name] = $this->_nodesCount + 1;
		$this->_tmpArray = $menu_array;
		$this->_depthFirstSearch($this->_tmpArray,$menu_name,1,1);
		//BEGIN BENCHMARK CODE
		//$time_end = $this->_getmicrotime();
		//$time = $time_end - $time_start;
		//print "TIME ELAPSED = " . $time . "\n<br>";
		//END BENCHMARK CODE */
		$this->_lastItem[$menu_name] = count($this->tree);
		$this->_nodesCount = $this->_lastItem[$menu_name];
		$this->tree[$this->_lastItem[$menu_name]+1]["level"] = 0;
		$this->_postParse($menu_name);
	}
	
	function setLabel($name,$label){
		$this->label[$name] = $label;
	}
	
	function setRepository($menu_name,$repository,$menu_array = ""){
		
		if ($repository == DB)
		$this->setDB($menu_name);
		else if($repository == ARRAY_QUERY)
		$this->setMenuFromArray($menu_array,$menu_name);
		else
		$this->setFile($menu_name);
	}
	
		function populateArray($menu_array, $menu_struct){
		
		foreach ($menu_array as $key => $value){
			if ($value == ON)
			$tmpArray[$key] = $menu_struct[$key]; 
		}
		
		return $tmpArray;
		
		
	}
	
	function _depthFirstSearch($tmpArray, $menu_name, $parent_id = 1, $level) {
		reset ($tmpArray);
		foreach ($tmpArray as $id => $foobar) {
			if ($foobar["parent_id"] == $parent_id) {
				unset($tmpArray[$id]);
				unset($this->_tmpArray[$id]);
				$cnt = count($this->tree) + 1;
				$this->tree[$cnt]["level"] = $level;
				
				foreach($foobar as $key => $value){
					$this->tree[$cnt][$key] = $foobar[$key];
				}

				unset($foobar);
				if ($id != $parent_id) {
					$this->_depthFirstSearch($this->_tmpArray, $menu_name, $id, $level+1);
				}
			}
		}
	}
	
	/**
	* Method to preparare a vertical menu.
	*
	* This method processes items of a menu to prepare the corresponding
	* vertical menu code updating many variables; it returns the code
	* of the corresponding _firstLevelMenu
	*
	* @access public
	* @param string $menu_name the name of the menu whose items have to be processed
	* @param integer $ordinateMargin margin (in pixels) to set the position
	*   of a layer a bit above the ordinate of the "father" link
	* @return string
	*/
	function newVerticalMenu(
	$menu_name = "",	// non consistent default...
	$ordinateMargin = 12
	) {
		global $menu_array;
		
		if (!isset($this->_firstItem[$menu_name]) || !isset($this->_lastItem[$menu_name])) {
			$this->error("newVerticalMenu: the first/last item of the menu '$menu_name' is not defined; please check if you have parsed its menu data.");
			return 0;
		}
		
		$this->parseCommon($menu_name);
		
		$t = new TemplateMenu();
		$t->setFile("tplfile", $this->verticalMenuTpl);
		$t->setBlock("tplfile", "template", "template_blck");
		$t->setBlock("template", "vertical_menu_table", "vertical_menu_table_blck");
		$t->setVar("vertical_menu_table_blck", "");
		$t->setBlock("vertical_menu_table", "vertical_menu_cell", "vertical_menu_cell_blck");
		$t->setVar("vertical_menu_cell_blck", "");
		$t->setVar("abscissaStep", $this->abscissaStep[$menu_name]);
		
		$t_sub = new TemplateMenu();
		$t_sub->setFile("tplfile", $this->subMenuTpl);
		$t_sub->setBlock("tplfile", "sub_menu_cell", "sub_menu_cell_blck");
		$t_sub->setVar("abscissaStep", $this->abscissaStep[$menu_name]);
		
		$this->_firstLevelMenu[$menu_name] = "";
		
		$this->moveLayers .= "\tvar " . $menu_name . "TOP = getOffsetTop('" . $menu_name . "');\n";
		$this->moveLayers .= "\tvar " . $menu_name . "LEFT = getOffsetLeft('" . $menu_name . "');\n";
		$this->moveLayers .= "\tvar " . $menu_name . "WIDTH = getOffsetWidth('" . $menu_name . "');\n";
		
		for ($cnt=$this->_firstItem[$menu_name]; $cnt<=$this->_lastItem[$menu_name]; $cnt++) {	// this counter scans all nodes of the new menu
		
		if ($this->tree[$cnt]["not_a_leaf"]) {
			// geometrical parameters are assigned to the new layer, related to the above mentioned children
			if ($this->tree[$cnt]["child_of_root_node"]) {
				$this->moveLayers .= "\tsetLeft('" . $this->tree[$cnt]["layer_label"] . "', " . $menu_name . "LEFT + " . $menu_name . "WIDTH);\n";
			}
			$this->tree[$cnt]["arrow"] = $this->forwardArrow[$menu_name];
			$this->moveLayers .= "\tif (IE4) setWidth('" . $this->tree[$cnt]["layer_label"] . "'," . $this->abscissaStep[$menu_name] . ");\n";
		} else {
			$this->tree[$cnt]["arrow"] = "";
		}
		$foobar = "";
		
		$t->setVar(array(
		"cellwidth"		=> $this->abscissaStep[$menu_name],
		"cell_link_blck"	=> $foobar
		));
		
		if ($this->tree[$cnt]["child_of_root_node"]) {
			if ($this->tree[$cnt]["not_a_leaf"]) {
				$this->tree[$cnt]["onmouseover"] = " onmouseover=\"moveLayerY('" . $this->tree[$cnt]["layer_label"] . "', " . $ordinateMargin . ") ; moveLayerX('" . $this->tree[$cnt]["layer_label"] . "') ; LMPopUp('" . $this->tree[$cnt]["layer_label"] . "', false);\"";
			} else {
				$this->tree[$cnt]["onmouseover"] = " onmouseover=\"shutdown();\"";
			}
			
			$template_array = array();
			
			foreach ($menu_array[$menu_name][TEMPLATE] as $key => $value){
					
					if($this->tree[$cnt]["parsed_".$key])
						$template_array[$key] = $this->tree[$cnt]["parsed_".$key];
					else
						$template_array[$key] = $this->tree[$cnt][$key];
			}	
			
			
			
			$t->setVar(array(
			"ordinateStep"	=> $this->ordinateStep,
			"icontag"	=> $this->tree[$cnt]["icontag"],
			"refid"		=> " id=\"ref" . $this->tree[$cnt]["layer_label"] . "\"",
			"onmouseover"	=> $this->tree[$cnt]["onmouseover"],
			"arrow"		=> $this->tree[$cnt]["arrow"]
			));
			
			$t->setVar($template_array);
			$this->_firstLevelMenu[$menu_name] .= $t->parse("vertical_menu_cell_blck", "vertical_menu_cell");
		} else {
			if ($this->tree[$cnt]["not_a_leaf"]) {
				$this->tree[$cnt]["onmouseover"] = " onmouseover=\"moveLayerY('" . $this->tree[$cnt]["layer_label"] . "', " . $ordinateMargin . ") ; moveLayerX('" . $this->tree[$cnt]["layer_label"] . "') ; LMPopUp('" . $this->tree[$cnt]["layer_label"] . "', false);\"";
			} else {
				$this->tree[$cnt]["onmouseover"] = " onmouseover=\"LMPopUp('" . $this->tree[$this->tree[$cnt]["father_node"]]["layer_label"] . "', true);\"";
			}
			
			foreach ($menu_array[$menu_name][SUB_TEMPLATE] as $key => $value){
					
					if($this->tree[$cnt]["parsed_".$key])
						$template_array[$key] = $this->tree[$cnt]["parsed_".$key];
					else
						$template_array[$key] = $this->tree[$cnt][$key];
						
			}	
			
			$t_sub->setVar(array(
			"cellwidth"	=> $this->abscissaStep[$menu_name],
			"ordinateStep"	=> $this->ordinateStep,
			"icontag"	=> $this->tree[$cnt]["icontag"],
			"refid"		=> " id=\"ref" . $this->tree[$cnt]["layer_label"] . "\"",
			"onmouseover"	=> $this->tree[$cnt]["onmouseover"],
			"arrow"		=> $this->tree[$cnt]["arrow"]
			));
			
			$t_sub->setVar($template_array);
			
			$this->tree[$this->tree[$cnt]["father_node"]]["layer_content"] .= $t_sub->parse("sub_menu_cell_blck", "sub_menu_cell");
		}
		}	// end of the "for" cycle scanning all nodes
		
		$t->setVar("vertical_menu_cell_blck", $this->_firstLevelMenu[$menu_name]);
		$this->_firstLevelMenu[$menu_name] = $t->parse("vertical_menu_table_blck", "vertical_menu_table");
		
		if($this->visibility[$menu_name] == OFF)
			$visibility = "visibility: hidden";
		else
			$visibility = "visibility: visible";
		
		$this->_firstLevelMenu[$menu_name] =
		"<div  id=\"$menu_name\" style=\"$visibility;\" onmouseover=\"clearLMTO();\" onmouseout=\"setLMTO();\">\n" .
		"<script language=\"JavaScript\" type=\"text/javascript\">\n" .
		"<!--\n" .
		"if (IE) fixieflm(\"" . $menu_name . "\");\n" .
		"// -->\n" .
		"</script>" .
		$this->_firstLevelMenu[$menu_name] . "\n" .
		"</div>";
		$t->setVar(array(
		"layer_label"			=> $menu_name,
		//"abscissaStep"	=> $this->abscissaStep[$menu_name],
		"vertical_menu_table_blck"	=> $this->_firstLevelMenu[$menu_name],
		"visibility"			=> $visibility
		));
		
		$this->_firstLevelMenu[$menu_name] = $t->parse("template_blck", "template");
		
		$this->_updateFooter($menu_name);
		
		return $this->_firstLevelMenu[$menu_name];
	}
	
	/**
	* Method to preparare a horizontal menu.
	*
	* This method processes items of a menu to prepare the corresponding
	* horizontal menu code updating many variables; it returns the code
	* of the corresponding _firstLevelMenu
	*
	* @access public
	* @param string $menu_name the name of the menu whose items have to be processed
	* @param integer $ordinateMargin margin (in pixels) to set the position
	*   of a layer a bit above the ordinate of the "father" link
	* @return string
	*/
	function newHorizontalMenu(
	$menu_name = "",	// non consistent default...
	$ordinateMargin = 12
	) {
	
	global $menu_array;
	
	if (!isset($this->_firstItem[$menu_name]) || !isset($this->_lastItem[$menu_name])) {
		$this->error("newHorizontalMenu: the first/last item of the menu '$menu_name' is not defined; please check if you have parsed its menu data.");
		return 0;
	}

	$this->parseCommon($menu_name);

	$t = new TemplateMenu();
	$t->setFile("tplfile", $this->horizontalMenuTpl);
	$t->setBlock("tplfile", "template", "template_blck");
	$t->setBlock("template", "horizontal_menu_cell", "horizontal_menu_cell_blck");
	$t->setVar("horizontal_menu_cell_blck", "");
	$t->setBlock("horizontal_menu_cell", "cell_link", "cell_link_blck");
	$t->setVar("cell_link_blck", "");
	$t->setVar("abscissaStep", $this->abscissaStep[$menu_name]);
	
	$t_sub = new TemplateMenu();
	$t_sub->setFile("tplfile", $this->subMenuTpl);
	$t_sub->setBlock("tplfile", "sub_menu_cell", "sub_menu_cell_blck");
	$t_sub->setVar("abscissaStep", $this->abscissaStep[$menu_name]);

	$this->_firstLevelMenu[$menu_name] = "";

	$foobar = $this->_firstItem[$menu_name];
	$this->moveLayers .= "\tvar " . $menu_name . "TOP = getOffsetTop('" . $menu_name . "L" . $foobar . "');\n";
	$this->moveLayers .= "\tvar " . $menu_name . "HEIGHT = getOffsetHeight('" . $menu_name . "L" . $foobar . "');\n";
	
	for ($cnt=$this->_firstItem[$menu_name]; $cnt<=$this->_lastItem[$menu_name]; $cnt++) {	// this counter scans all nodes of the new menu
		if ($this->tree[$cnt]["not_a_leaf"]) {
			// geometrical parameters are assigned to the new layer, related to the above mentioned children
			if ($this->tree[$cnt]["child_of_root_node"]) {
				$this->moveLayers .= "\tsetLeft('" . $this->tree[$cnt]["layer_label"] . "', getOffsetLeft('" . $menu_name . $this->tree[$cnt]["layer_label"] . "'));\n";
				$this->tree[$cnt]["arrow"] = $this->downArrow[$menu_name];
			} else {
				$this->tree[$cnt]["arrow"] = $this->forwardArrow[$menu_name];
			}
			if ($this->tree[$cnt]["child_of_root_node"]) {
				$this->moveLayers .= "\tsetTop('" . $this->tree[$cnt]["layer_label"] . "', "  . $menu_name . "TOP + " . $menu_name . "HEIGHT);\n";
			}
			$this->moveLayers .= "\tif (IE4) setWidth('" . $this->tree[$cnt]["layer_label"] . "'," . $this->abscissaStep[$menu_name] . ");\n";
		} else {
			$this->tree[$cnt]["arrow"] = "";
		}

		if ($this->tree[$cnt]["child_of_root_node"]) {
			if ($this->tree[$cnt]["not_a_leaf"]) {
				$this->tree[$cnt]["onmouseover"] = " onmouseover=\"LMPopUp('" . $this->tree[$cnt]["layer_label"] . "', false);\"";
			} else {
				$this->tree[$cnt]["onmouseover"] = " onmouseover=\"shutdown();\"";
			}
			
			foreach ($menu_array[$menu_name][TEMPLATE] as $key => $value){
					
					if($this->tree[$cnt]["parsed_".$key])
						$template_array[$key] = $this->tree[$cnt]["parsed_".$key];
					else
						$template_array[$key] = $this->tree[$cnt][$key];
						
			}	
			
			$t->setVar(array(
				"icontag"	=> $this->tree[$cnt]["icontag"],
				"onmouseover"	=> $this->tree[$cnt]["onmouseover"],
				"arrow"		=> $this->tree[$cnt]["arrow"]
			));
			
			$t->setVar($template_array);
			
			$foobar = $t->parse("cell_link_blck", "cell_link");
			
			if($this->visibility[$menu_name] == OFF)
				$visibility = "visibility: hidden";
			else
				$visibility = "visibility: visible";
			
			$foobar =
			"<div id=\"" . $menu_name . $this->tree[$cnt]["layer_label"] . "\" style=\"position: relative; $visibility;\" onmouseover=\"clearLMTO();\" onmouseout=\"setLMTO();\">\n" .
			"<script language=\"JavaScript\" type=\"text/javascript\">\n" .
			"<!--\n" .
			"if (IE) fixieflm(\"" . $menu_name . $this->tree[$cnt]["layer_label"] . "\");\n" .
			"// -->\n" .
			"</script>" .
			$foobar . "\n" .
			"</div>";
			
			$t->setVar(array(
				//"abscissaStep" => $this->abscissaStep[$menu_name],
				"cellwidth"		=> $this->abscissaStep[$menu_name],
				"cell_link_blck"	=> $foobar
			));
			
			$t->parse("horizontal_menu_cell_blck", "horizontal_menu_cell", true);
		} else {
			if ($this->tree[$cnt]["not_a_leaf"]) {
				$this->tree[$cnt]["onmouseover"] = " onmouseover=\"moveLayerY('" . $this->tree[$cnt]["layer_label"] . "', " . $ordinateMargin . ") ; moveLayerX('" . $this->tree[$cnt]["layer_label"] . "') ; LMPopUp('" . $this->tree[$cnt]["layer_label"] . "', false);\"";
			} else {
				$this->tree[$cnt]["onmouseover"] = " onmouseover=\"LMPopUp('" . $this->tree[$this->tree[$cnt]["father_node"]]["layer_label"] . "', true);\"";
			}
			
			foreach ($menu_array[$menu_name][SUB_TEMPLATE] as $key => $value){
					
					if($this->tree[$cnt]["parsed_".$key])
						$template_array[$key] = $this->tree[$cnt]["parsed_".$key];
					else
						$template_array[$key] = $this->tree[$cnt][$key];
						
			}	
			
			$t_sub->setVar(array(
				"ordinateStep"	=> $this->ordinateStep,
				"icontag"	=> $this->tree[$cnt]["icontag"],
				"refid"		=> " id=\"ref" . $this->tree[$cnt]["layer_label"] . "\"",
				"onmouseover"	=> $this->tree[$cnt]["onmouseover"],
				"arrow"		=> $this->tree[$cnt]["arrow"]
			));
			
			$t_sub->setVar($template_array);
			$this->tree[$this->tree[$cnt]["father_node"]]["layer_content"] .= $t_sub->parse("sub_menu_cell_blck", "sub_menu_cell");
		}
	}	// end of the "for" cycle scanning all nodes

	$foobar = $this->_firstLevelCnt[$menu_name] * $this->abscissaStep[$menu_name];
	$t->setVar("menuwidth", $foobar);
	$t->setVar(array(
		"layer_label"	=> $menu_name,
		//"abscissaStep" => $this->abscissaStep[$menu_name],
		"menubody"	=> $this->_firstLevelMenu[$menu_name]
	));
	$this->_firstLevelMenu[$menu_name] = $t->parse("template_blck", "template");

	$this->_updateFooter($menu_name);

	return $this->_firstLevelMenu[$menu_name];
}



	/**
	* @return void
	* @param String $menu_name
	* @param Array $arrayTemplate
	* @desc Method to add tag to template
	*/
	function addTagTemplate($menu_name,$array_template,$template){
		
		for ($cnt=$this->_firstItem[$menu_name]; $cnt<=$this->_lastItem[$menu_name]; $cnt++) {
			for ($i = 0; $i > count($array_template[TEMPLATE]); $i++)
			{
				$template->set_var($array_template[TEMPLATE][$i],$this->tree[$cnt]["parsed_target"]);
			}
		}
		
		
	}
	
}


?>
