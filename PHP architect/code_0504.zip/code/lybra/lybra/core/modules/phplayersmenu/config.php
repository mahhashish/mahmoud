<?
require_once("config_runtime.php");

//Configuro i paramatri del DB
 $this->parameters["tableDbtype"]="mysql";
 $this->parameters["tableDbname"]="lybra_development_db";
 $this->parameters["tableServer"]="localhost";
 $this->parameters["tablePort"]="";
 $this->parameters["tableUser"]="root";
 $this->parameters["tablePassword"]="stocazzo";

##############################
#   LAYER MENU PARAMETERS    #
#############################

//JS Libraries
$libjsdir = "/var/www/html/cdsagenda5/modules/phplayersmenu/libjs/";
$libjswww = "modules/phplayersmenu/libjs/";

$menu_jscript[0] = $libjswww."layersmenu-browser_detection_func.js";
$menu_jscript[1] = $libjswww."layersmenu-library.js";
$menu_jscript[2] = $libjswww."layersmenu.js";
//To use only with tree menu
$menu_jscript[3] = $libjswww."layerstreemenu-cookies.js";

//Images Directory
$dir_images = "/var/www/html/cdsagenda5/images/";
$www_dir_images = "images/";

//Templates Directory
$dir_template = "template/";

//Arrow Icons for Menu
$arrows_images["down"] = "down-nautilus.png";
$arrows_images["forward"] = "forward-nautilus.png";

//Css file for menu style
$menu_css["MainMenu"] = "css/layersmenucdsagenda.css";

//Position of SubMenu from Menu
$layer_position["MainMenu"] = "12";

//Template Configuration
$template["MainMenu"] = "BarMenu_MainMenu.ihtml";
$sub_template["MainMenu"] = "layersmenu-sub_cdsagenda.ihtml";

//Parameters DB
$db_table_name = "lybra_phplayersmenu";
$db_table_fields = array(
	"Name"		=> "Name",
	"id"		=> "id",
	"parent_id"	=> "parent_id",
	"text"		=> "text",
	"link"		=> "link",
	"title"		=> "title",
	"icon"		=> "icon",
	"target"	=> "target",
	"orderfield"	=> "orderfield",
	"expanded"	=> "expanded"
);

$db_table_i18n = "lybra_phplayersmenu_i18n";
$db_table_i18n_fields = array(
	"language"	=> "language",
	"Name"		=> "Name",
	"id"		=> "id",
	"text"		=> "text",
	"title"		=> "title"
);


 ?>
