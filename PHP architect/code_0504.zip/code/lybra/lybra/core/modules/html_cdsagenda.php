<?
/**********************************************************************************************
html_agenda.php
--------------------
begin:  	10/2003 Simone Grassi, Francesco Trucchia (Ci S.B.i.C. snc)
copyright:	(C) 2003 Ci S.B.i.C. snc
viale Marconi 438, 47023 Cesena (FC), Italy.
email:		simone@cisbic.com,ciccio@cisbic.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
***********************************************************************************************/
define("AGENDA_DATE_FORMAT","d F Y");

class html_cdsagenda
{
	function html_cdsagenda(&$parameters)
	{
		global $displayAgendas_SMR, $default_date_separator;
		
		$this->default_date_separator = $default_date_separator;
		
		$this->displayAgendas_SMR = $displayAgendas_SMR;
		
		$this->parameters = &$parameters;
		
	}
}
?>
