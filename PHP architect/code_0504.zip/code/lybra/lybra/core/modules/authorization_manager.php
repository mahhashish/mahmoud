<?
 /**********************************************************************************************
 		Lybra: A general purpose framework for fast web development
		Copyright (C) 2002-2004 Simone Grassi, Andrea Giorgini

	    authorization_manager.php
	    --------------------
		begin:  	2/2004 Simone Grassi (Ci S.B.i.C. snc)
		copyright:	(C) 2004, Simone Grassi,  Andrea Giorgini
					viale Marconi 438, 47023 Cesena (FC), Italy.
		email:		lybra@cisbic.com

	    This program is free software; you can redistribute it and/or modify
	    it under the terms of the GNU General Public License as published by
	    the Free Software Foundation; either version 2 of the License, or
	    (at your option) any later version.

	    This program is distributed in the hope that it will be useful,
	    but WITHOUT ANY WARRANTY; without even the implied warranty of
	    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	    GNU General Public License for more details.

	    You should have received a copy of the GNU General Public License
	    along with this program; if not, write to the Free Software
	    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************************************/


    	// Generic DB Structure (OLD)
    	/* TABLE BY TABLE, FIELDS NEEDED BY THIS MODULE
    	
    	// Memorizza username e password. Viene usata dal modulo Pear::Auth
   		// Authorization_manager utilizza Auth per individuare l'utente
   		// attualmente loggato
    	
			CREATE TABLE `lybra_auth` (
			  `user_id` int(12) unsigned NOT NULL auto_increment,
			  `username` varchar(50) NOT NULL default '',
			  `PASSWORD` varchar(32) NOT NULL default '',
			  PRIMARY KEY  (`user_id`),
			  UNIQUE KEY `username` (`username`),
			  KEY `PASSWORD` (`PASSWORD`)
			) TYPE=MyISAM COMMENT='store users' AUTO_INCREMENT=2 ;

		// Memorizza i permessi assegnati direttamente ad un gruppo.
		// Questi permessi saranno garantiti a tutti gli utenti facenti parte
		// del gruppo.
		// Mode definisce come viene gestito il permesso

			CREATE TABLE `lybra_auth_group_permission` (
			  `group_id` int(8) NOT NULL default '0',
			  `permission_id` bigint(20) NOT NULL default '0',
			  `active` tinyint(1) unsigned NOT NULL default '0',
			  `mode` int(6) unsigned NOT NULL default '1',
			  PRIMARY KEY  (`group_id`,`permission_id`)
			) TYPE=MyISAM COMMENT='stores group permission (wide, not relative to an object)';

		// Memorizza i permessi assegnati ad un gruppo relativamente
		// ad uno specifico oggetto (object_id+object_type).
		// Il mode definisce la modalit� di utilizzazione del permesso

			CREATE TABLE `lybra_auth_group_permission_on_object` (
			  `group_id` int(8) unsigned NOT NULL default '0',
			  `permission_id` bigint(20) unsigned NOT NULL default '0',
			  `object_id` int(12) unsigned NOT NULL default '0',
			  `object_type` int(8) unsigned NOT NULL default '0',
			  `active` tinyint(1) unsigned NOT NULL default '0',
			  `mode` int(6) unsigned NOT NULL default '1',
			  `description` varchar(255) NOT NULL default '',
			  PRIMARY KEY  (`group_id`,`permission_id`,`object_id`,`object_type`)
			) TYPE=MyISAM COMMENT='store group permission relative to an object';

		// Memorizza i permessi assegnati ad un gruppo relativamente
		// a tutti gli oggetti di un determinato tipo (object_type).
		// Mode memorizza il modo di gestione del permesso

			CREATE TABLE `lybra_auth_group_permission_on_object_type` (
			  `group_id` int(8) unsigned NOT NULL default '0',
			  `permission_id` bigint(20) unsigned NOT NULL default '0',
			  `object_type` int(8) unsigned NOT NULL default '0',
			  `active` tinyint(1) unsigned NOT NULL default '0',
			  `mode` int(6) unsigned NOT NULL default '1',
			  PRIMARY KEY  (`group_id`,`permission_id`,`object_type`)
			) TYPE=MyISAM COMMENT='stores group permissions on object types';

		// Memorizza i gruppi di utenti esistenti

			CREATE TABLE `lybra_auth_groups` (
			  `group_id` int(8) unsigned NOT NULL auto_increment,
			  `group_description` varchar(255) NOT NULL default '',
			  `description` varchar(255) NOT NULL default '',
			  PRIMARY KEY  (`group_id`)
			) TYPE=MyISAM COMMENT='group of users' AUTO_INCREMENT=9 ;

		// Memorizza la lista dei tipi di oggetti supportati.
		// In define viene memorizzata la stringa utilizzata
		// in php come DEFINE per richiamare quel tipo di oggetti.
		// Deve cio� esistere un file php incluso che contiene per ogni
		// record di questa tabella la define corrispondente.
		// define("define",object_type); ...
		
			CREATE TABLE `lybra_auth_object_types` (
			  `object_type` int(8) unsigned NOT NULL auto_increment,
			  `object_type_description` varchar(255) NOT NULL default '',
			  `define` varchar(120) NOT NULL default '',
			  PRIMARY KEY  (`object_type`),
			  UNIQUE KEY `define` (`define`)
			) TYPE=MyISAM COMMENT='stores object types' AUTO_INCREMENT=5 ;
		
		// Memorizza l'insieme delle policies legate ad i permessi.
		// Ogni policy � costituita da un gruppo di permessi che
		// vengono cosi legati insieme. Viene inoltre associata una
		// descrizione ed una define per poter specificare
		// facilmente la policies in fase di sviluppo
		
			CREATE TABLE `lybra_auth_permission_policies` (
			  `permission_policy_id` int(6) unsigned NOT NULL auto_increment,
			  `define` varchar(80) NOT NULL default '',
			  `description` varchar(80) NOT NULL default '',
			  PRIMARY KEY  (`permission_policy_id`)
			) TYPE=MyISAM COMMENT='Stores sets of permissions, used as policies' AUTO_INCREMENT=1 ;

		// Memorizza la lista dei possibili permessi.
		// Il campo define memorizza la stringa utilizzata
		// per la define dello specifico permesso.
		// Deve esistere un file php, incluso dal modulo
		// dei permessi, che per ogni record di questa tabella
		// contenga la corrispondente define
		// define("define",permission_id);

			CREATE TABLE `lybra_auth_permissions` (
			  `permission_id` bigint(20) NOT NULL auto_increment,
			  `define` varchar(120) NOT NULL default '',
			  `description` varchar(255) NOT NULL default '',
			  PRIMARY KEY  (`permission_id`)
			) TYPE=MyISAM COMMENT='stores single permission' AUTO_INCREMENT=7 ;
		
		// Memorizza l'associazione fra permessi e policies
		// associando piu permessi ad un policy ed un permesso
		// a piu policies
		
			CREATE TABLE `lybra_auth_permissions_in_policies` (
			  `permission_policy_id` int(6) unsigned NOT NULL default '0',
			  `permission_id` bigint(20) unsigned NOT NULL default '0',
			  PRIMARY KEY  (`permission_policy_id`,`permission_id`)
			) TYPE=MyISAM COMMENT='Associate permissions to permission policies';

		// Memorizza i permessi associati al ruolo specificato.
		// Active permette di attivare/disattivare questa corrispondenza
		// Mode definisce le modalit� di gestione del permesso

			CREATE TABLE `lybra_auth_role_permission` (
			  `role_id` int(8) unsigned NOT NULL default '0',
			  `permission_id` bigint(20) unsigned NOT NULL default '0',
			  `mode` int(6) unsigned NOT NULL default '1',
			  `active` tinyint(1) NOT NULL default '0',
			  PRIMARY KEY  (`role_id`,`permission_id`)
			) TYPE=MyISAM COMMENT='associate permissions to roles';

		// Memorizza la lista dei ruoli esistenti

			CREATE TABLE `lybra_auth_roles` (
			  `role_id` int(8) unsigned NOT NULL auto_increment,
			  `role_description` varchar(255) NOT NULL default '',
			  PRIMARY KEY  (`role_id`)
			) TYPE=MyISAM COMMENT='store roles for users' AUTO_INCREMENT=1 ;

		// Memorizza l'associazione fra gruppo e gruppo padre
		// nonch� in mode, la modalit� di interazione fra i due
		// gruppi

			CREATE TABLE `lybra_auth_subgroup` (
			  `group_id` int(8) unsigned NOT NULL default '0',
			  `father_group_id` int(8) unsigned NOT NULL default '0',
			  `active` tinyint(1) unsigned NOT NULL default '0',
			  `mode` smallint(6) unsigned NOT NULL default '1',
			  PRIMARY KEY  (`group_id`,`father_group_id`)
			) TYPE=MyISAM COMMENT='stores subgroups';

		// Memorizza l'associazione fra utenti e gruppi.
		// Active permette di disattivare/attivare questa
		// associazione, mentre mode definisce le modalit�
		// di gestione dei permessi conseguenti all'appartenenza
		// al gruppo
		
			CREATE TABLE `lybra_auth_user_group` (
			  `user_id` int(12) unsigned NOT NULL default '0',
			  `group_id` int(8) unsigned NOT NULL default '0',
			  `mode` smallint(6) unsigned NOT NULL default '1',
			  `active` tinyint(1) unsigned NOT NULL default '0',
			  PRIMARY KEY  (`user_id`,`group_id`)
			) TYPE=MyISAM COMMENT='stores association from user and groups';

		// Memorizza l'associazione di un ruolo ad un utente
		// relativamente ad uno specifico oggetto (object_id+object_type)
		// Active disattiva/attiva il ruolo e mode definisce le modalit�
		// di gestione dei permessi conseguenti al ruolo

			CREATE TABLE `lybra_auth_user_has_role` (
			  `user_id` int(12) unsigned NOT NULL default '0',
			  `role_id` int(8) unsigned NOT NULL default '0',
			  `object_id` int(12) unsigned NOT NULL default '0',
			  `object_type` int(8) unsigned NOT NULL default '0',
			  `mode` int(6) unsigned NOT NULL default '1',
			  `active` tinyint(1) unsigned NOT NULL default '0',
			  PRIMARY KEY  (`user_id`,`role_id`,`object_id`,`object_type`)
			) TYPE=MyISAM COMMENT='associate role to user for a specific object';

		// Memorizza l'associazione di un ruolo ad un utente
		// relativamente ad una categoria di oggetti (object_type)
		// Active disattiva/attiva il ruolo e mode definisce le modalit�
		// di gestione dei permessi conseguenti al ruolo
		
			CREATE TABLE `lybra_auth_user_has_role_on_object_type` (
			  `user_id` int(12) unsigned NOT NULL default '0',
			  `role_id` int(8) unsigned NOT NULL default '0',
			  `object_type` int(8) unsigned NOT NULL default '0',
			  `mode` int(6) unsigned NOT NULL default '1',
			  `ative` tinyint(1) unsigned NOT NULL default '0',
			  PRIMARY KEY  (`user_id`,`role_id`,`object_type`)
			) TYPE=MyISAM COMMENT=' associate role to user for a specific object_type';
		
		
		// Memorizza i permessi associati direttamente ad un utente.
		// Sono permessi trasversali a tutti gli oggetti di tutti i tipi.
		// Active permette di disattivare/attivare le associazioni
		// mode definisce i metodi di gestione dei permessi stessi

			CREATE TABLE `lybra_auth_user_permission` (
			  `user_id` int(12) unsigned NOT NULL default '0',
			  `permission_id` bigint(20) unsigned NOT NULL default '0',
			  `mode` int(6) unsigned NOT NULL default '1',
			  `active` tinyint(1) unsigned NOT NULL default '0',
			  PRIMARY KEY  (`user_id`,`permission_id`)
			) TYPE=MyISAM COMMENT='stores user permissions (wide, not relative to an object)';

		// Memorizza un permesso diretto ad un utente su di uno specifico
		// oggetto (object_id+object_type).
		// Active disattiva/attiva l'associazione mentre
		// mode definisce la modalit� di gestione del permesso

			CREATE TABLE `lybra_auth_user_permission_on_object` (
			  `user_id` int(12) unsigned NOT NULL default '0',
			  `permission_id` bigint(20) unsigned NOT NULL default '0',
			  `object_type` int(8) unsigned NOT NULL default '0',
			  `object_id` int(12) unsigned NOT NULL default '0',
			  `mode` int(6) NOT NULL default '1',
			  `active` tinyint(1) unsigned NOT NULL default '0',
			  PRIMARY KEY  (`user_id`,`permission_id`,`object_id`,`object_type`)
			) TYPE=MyISAM COMMENT='stores user permission relative to an object';

		// Memorizza un permesso diretto ad un utente su di una
		// intera categoria di oggetti (object_type)
		// Active disattiva/attiva l'associazione del permesso, mentre
		// mode definisce la modalit� di gestione del permesso

			CREATE TABLE `lybra_auth_user_permission_on_object_type` (
			  `user_id` int(12) unsigned NOT NULL default '0',
			  `permission_id` bigint(20) unsigned NOT NULL default '0',
			  `object_type` int(8) unsigned NOT NULL default '0',
			  `mode` int(6) unsigned NOT NULL default '1',
			  `active` tinyint(1) unsigned NOT NULL default '0',
			  PRIMARY KEY  (`user_id`,`permission_id`,`object_type`)
			) TYPE=MyISAM COMMENT='stores user permission on specific object id+type';
	    	*/
    	
    	
    	/******************************************
    	 * BETA TESTS                             *
    	 ******************************************/
/*
		Testare che funzionino le propriet� assegnate nei seguenti modi:
		
		1)	Utente con permesso specifico aperto a tutto
			- attivo
			- disattivo
		2)	Utente con permesso specifico aperto a tutti gli object_type
			- attivo
			- disattivo
		3)	Utente con permesso specifico aperto ad un solo oggetto, object_id + object_type
			- attivo
			- disattivo
		4)	Permesso a tutto assegnato ad un gruppo
			- appartenendo direttamente al gruppo
				- attivo
				- disattivo
			- appartenendo ad un sottogruppo
				- senza ereditare il permesso (mode=)
				- ereditando il permesso
					- attivo
					- disattivo
		5)	Permesso ad object_type assegnato al gruppo
			- appartenendo direttamente al gruppo
				- attivo
				- disattivo
				- attivo tramite permission policy
			- appartenendo ad un sottogruppo
				- senza ereditarlo (mode=)
				- ereditando il permesso
					- attivo
					- disattivo
					- attivo tramite permission policy
		6) Permesso su oggetto specifico, object_id + object_type tramite gruppo
			- appartenendo direttamente al gruppo
				- attivo
				- disattivo
				- attivo tramite permission policy
			- appartenendo ad un sottogruppo
				- senza ereditarlo
				- ereditando il permesso
					- attivo
					- disattivo
					- attivo tramite permission policy
		7) Permesso a tutto tramite ruolo
			- attivo
			- disattivo
			- attivo tramite permission policy
		8) Permesso ad oject_type tramite ruolo
			- attivo
			- disattivo
			- attivo tramite permission policy
		9) Permesso ad oggetto specifico, object_id + object_type tramite ruolo
			- attivo
			- disattivo
			- attivo tramite permission policy
		
*/
    	 
    	 
    	 
    	 
    	 
    	
    	require_once("authorization_defines.php");

  		define("LYBRA_USER_TABLE","lybra_auth");
		define("LYBRA_USER_ID_FIELD","user_id");
		define("LYBRA_USERNAME_FIELD","username");
		define("LYBRA_PASSWORD_FIELD","PASSWORD");
    	
		class authorization_manager
		{
			/**
		     * Retrieve all information about user permissions
		     *
		     * @param $username store the username of the actual user
		     *		  $parameters stores optional additional paramteres
		     *
		     * @return an authorization_manager object building inside all
		     *		connection to related objects (storing permissions)
		     *
		     * access public
		     */
			function authorization_manager($username,$paramters="")
			{
				$this->parameters = $parameters;
				$this->user = new auth_user(LYBRA_USERNAME_FIELD,$username);
			}

			// Ask for permission on object
			function authorize($permission,$object_id="",$object_type="")
			{
				return $this->user->permission($permission,$object_id,$object_type);
			}
		}

		class auth_user extends Lybra_DB_DataObject
		{
			/**
		     * Retrieve all information about one or more users
		     *
		     * @param $field name of the field and $value it's value
		     * 			used to retrieve data from the DB
		     *
		     * @return mixed a newly created DB object, or a DB error code on
		     * error
		     *
		     * access private
		     */
			// Table name
			var $__table = LYBRA_USER_TABLE;

			function auth_user($field="",$value="")
			{
				$this->common_init($field,$value);
			}

			function factory($field="",$value="")
			{
				if (Lybra_DB_DataObject::factory($field,$value))
				{
					// For each retrieved record do special tasks
					for ($i=0;$i<count($this->objects);$i++)
					{
						// Retrieve groups this user is part of
						$this->objects[$i]->user_group = new user_group(LYBRA_USER_ID_FIELD,$this->objects[$i]->user_id);
						// Retrieve roles associated to this user
						$this->objects[$i]->user_role = new user_role(LYBRA_USER_ID_FIELD,$this->objects[$i]->user_id);
						// Retrieve permissions associated to this user on all objects and object types
						$this->objects[$i]->user_wide_permission = new user_wide_permission(LYBRA_USER_ID_FIELD,$this->objects[$i]->user_id);
						// Retrieve permissions associated to this user on specific objects
						$this->objects[$i]->user_permission_on_object = new user_permission_on_object(LYBRA_USER_ID_FIELD,$this->objects[$i]->user_id);
						// Retrieve permissions associated to this user on a specific object_type
						$this->objects[$i]->user_permission_on_object_type = new user_permission_on_object_type(LYBRA_USER_ID_FIELD,$this->objects[$i]->user_id);
					}
				}
			}
			
			// }}}
			// {{{ permission
			/**
			 * Test if exists permission on a specific object
			 *
			 * @access public
			 *
			 * @permission permission to test
			 * @object_id  look for this permission on this object_id
			 * @object_type look for this permission on this object_type
			 * $i specify in witch repository to look for, by default the first entry
			 *
			 * @return int >0 if permission allowed 0 otherwise
			 **/
			function permission($permission,$object_id,$object_type,$i=0)
			{
				// Check if this permission is present in wide mode
				if ($this->wide_permission($permission,$i))
					return TRUE;
				// Not present in wide mode check if present on the specific object
				return $this->object_permission($permission,$object_id,$object_type,$i);
			}

			// }}}
			// {{{ wide_permission
			/**
			 * Test if exists permission in wide "mode" (on every object_id and object_type)
			 *
			 * @access public
			 *
			 * @permission permission to test
			 * $i specify in witch repository to look for, by default the first entry
			 *
			 * @return int >0 if permission allowed 0 otherwise
			 **/			
			function wide_permission($permission,$i=0)
			{
				// Check if the wide permission comes from group or direct user permission
				if ($this->objects[$i]->user_group->wide_permission($permission) ||
					($this->objects[$i]->user_wide_permission->wide_permission($permission)))
					return TRUE;
				return FALSE;
			}

			// }}}
			// {{{ object_permission
			/**
			 * Test if exists permission on a specific object (object_id+object_type)
			 *
			 * @access public
			 *
			 * @permission permission to test
			 * @object_id  look for this permission on this object_id
			 * @object_type look for this permission on this object_type
			 * $i specify in witch repository to look for, by default the first entry
			 *
			 * @return int >0 if permission allowed 0 otherwise
			 **/			
			function object_permission($permission,$object_id,$object_type,$i=0)
			{
				// Check permission via roles or groups or directly assigned to user
				if (($this->objects[$i]->user_role->permission($object_id,$object_type,$permission)) ||
					($this->objects[$i]->user_group->permission($object_id,$object_type,$permission)) ||
					($this->objects[$i]->user_permission_on_object->permission($object_id,$object_type,$permission)))
					return TRUE;
				return FALSE;				
			}
			
			// }}}
			// {{{ object_type_permission
			/**
			 * Test if exists permission on a specific category of objects (object_type)
			 *
			 * @access public
			 *
			 * @permission permission to test
			 * @object_type look for this permission on this object_type
			 * $i specify in witch repository to look for, by default the first entry
			 *
			 * @return int >0 if permission allowed 0 otherwise
			 **/
			function object_type_permission($permission,$object_type,$i=0)
			{
				// Check the permission via roles or direct permission to user
				if (($this->objects[$i]->user_role->permission($object_type,$permission)) ||
				    ($this->objects[$i]->user_group->permission($object_type,$permission)) ||
					($this->objects[$i]->user_permission_on_object_type->permission($object_id,$object_type,$permission)))
					return TRUE;
				return FALSE;				
			}

			/*
			 * Define table to work on
			 */
			function table()
			{
		        return array(
		        	LYBRA_USER_ID_FIELD		=>	DB_DATAOBJECT_INT,
		            LYBRA_USERNAME_FIELD	=>	DB_DATAOBJECT_STR,
		            LYBRA_PASSWORD_FIELD	=>	DB_DATAOBJECT_STR
		        );
			}

			// Override default key
			function keys() 
	    	{
	        	return array(LYBRA_USER_ID_FIELD);
	    	}
		}

		define("LYBRA_USER_PERM_TABLE","lybra_auth_user_permission");
		define("LYBRA_USER_PERM_USER_ID","user_id");
		define("LYBRA_USER_PERM_PERMISSION_ID","permission_id");
		define("LYBRA_USER_PERM_MODE","mode");
		define("LYBRA_USER_PERM_ACTIVE","active");

		class user_wide_permission extends Lybra_DB_DataObject
		{
			var $__table=LYBRA_USER_PERM_TABLE;

			function user_wide_permission($field="",$value="")
			{
				$this->common_init($field,$value);
			}

			function factory($field="",$value="")
			{
				$permission_id = LYBRA_USER_PERM_PERMISSION_ID;
				$mode = LYBRA_USER_PERM_MODE;
				
				if (Lybra_DB_DataObject::factory($field,$value))
				{
					for ($i=0;$i<count($this->objects);$i++)
					{
						$this->permissions[$this->objects[$i]->$permission_id] = $this->objects[$i]->$mode;
					}
					return true;
				}
				return false;
			}

			function wide_permission($permission)
			{
				$permission_id = LYBRA_USER_PERM_PERMISSION_ID;
				
				if ($this->permissions[$permission])
					return $this->permissions[$permission];
				return false;
			}
			/*
			 * Define table to work on
			 */
			function table()
			{
		        return array(
		            LYBRA_USER_PERM_USER_ID			=> DB_DATAOBJECT_INT,
		            LYBRA_USER_PERM_PERMISSION_ID	=> DB_DATAOBJECT_INT,
		            LYBRA_USER_PERM_MODE			=> DB_DATAOBJECT_INT,
		            LYBRA_USER_PERM_ACTIVE			=> DB_DATAOBJECT_INT
		        );
			}

			// Override default key
			function keys() 
	    	{
	        	return array(
	        					LYBRA_USER_PERM_USER_ID	=>	DB_DATAOBJECT_INT,
	        					LYBRA_USER_PERM_PERMISSION_ID	=> DB_DATAOBJECT_INT
	        				);
	    	}
	    	
	    	// No real sequenceKey present
	    	function sequence_key()
	    	{
	    		return array(false,false);
	    	}
		}

		define("LYBRA_USER_PERM_ON_OBJECT_TABLE","lybra_auth_user_permission_on_object");
		define("LYBRA_USER_PERM_ON_OBJECT_USER_ID","user_id");
		define("LYBRA_USER_PERM_ON_OBJECT_PERMISSION_ID","permission_id");
		define("LYBRA_USER_PERM_ON_OBJECT_OBJECT_TYPE","object_type");
		define("LYBRA_USER_PERM_ON_OBJECT_OBJECT_ID","object_id");
		define("LYBRA_USER_PERM_ON_OBJECT_MODE","mode");
		define("LYBRA_USER_PERM_ON_OBJECT_ACTIVE","active");

		class user_permission_on_object extends Lybra_DB_DataObject 
		{
			var $__table=LYBRA_USER_PERM_ON_OBJECT_TABLE;
			
			function user_permission_on_object($field="",$value="")
			{
				$this->common_init($field,$value);
			}
			
			function factory($field="",$value="")
			{
				if (Lybra_DB_DataObject::factory($field,$value))
				{
					// Permissions stored into $this->objects[]
					return true;
				}
				return false;
			}

			function permission($user_id,$object_id,$object_type)
			{
				$user_id_field = LYBRA_USER_PERM_ON_OBJECT_USER_ID;
				$object_id_field = LYBRA_USER_PERM_ON_OBJECT_OBJECT_ID;
				$object_type_field = LYBRA_USER_PERM_ON_OBJECT_OBJECT_TYPE;
				$active_field = LYBRA_USER_PERM_ON_OBJECT_TYPE_ACTIVE;
				$mode_field = LYBRA_USER_PERM_ON_OBJECT_MODE;
				
				for ($i=0;$i<count($this->objects);$i++)
					if (($this->objects[$i]->$user_id_field = $user_id) &&
						($this->objects[$i]->$object_id_field = $object_id) &&
						($this->objects[$i]->$object_type_field = $object_type) &&
						($this->objects[$i]->$active_field))
							return $this->objects[$i]->$mode_field;
				return false;
			}
			/*
			 * Define table to work on
			 */
			function table()
			{
		        return array(
		            LYBRA_USER_PERM_ON_OBJECT_USER_ID		=> DB_DATAOBJECT_INT,
		            LYBRA_USER_PERM_ON_OBJECT_PERMISSION_ID	=> DB_DATAOBJECT_INT,
		            LYBRA_USER_PERM_ON_OBJECT_OBJECT_ID		=> DB_DATAOBJECT_INT,
		            LYBRA_USER_PERM_ON_OBJECT_OBJECT_TYPE 	=> DB_DATAOBJECT_INT,
		            LYBRA_USER_PERM_ON_OBJECT_MODE 			=> DB_DATAOBJECT_INT,
		            LYBRA_USER_PERM_ON_OBJECT_ACTIVE 		=> DB_DATAOBJECT_INT
		        );
			}
			
			// Override default key
			function keys() 
	    	{
	        	return array(
	        					LYBRA_USER_PERM_ON_OBJECT_USER_ID	=>	DB_DATAOBJECT_INT,
	        					LYBRA_USER_PERM_ON_OBJECT_PERMISSION_ID => DB_DATAOBJECT_INT,
	        					LYBRA_USER_PERM_ON_OBJECT_OBJECT_TYPE => DB_DATAOBJECT_INT,
	        					LYBRA_USER_PERM_ON_OBJECT_OBJECT_ID	=>	DB_DATAOBJECT_INT
	        				);
	    	}
	    	// No real sequenceKey present
	    	function sequence_key()
	    	{
	    		return array(false,false);
	    	}
		}
		
		define("LYBRA_USER_PERM_ON_OBJECT_TYPE_TABLE","lybra_auth_user_permission_on_object_type");
		define("LYBRA_USER_PERM_ON_OBJECT_TYPE_USER_ID","user_id");
		define("LYBRA_USER_PERM_ON_OBJECT_TYPE_PERMISSION_ID","permission_id");
		define("LYBRA_USER_PERM_ON_OBJECT_TYPE_OBJECT_TYPE","object_type");
		define("LYBRA_USER_PERM_ON_OBJECT_TYPE_MODE","mode");
		define("LYBRA_USER_PERM_ON_OBJECT_TYPE_ACTIVE","active");

		class user_permission_on_object_type extends Lybra_DB_DataObject 
		{
			var $__table=LYBRA_USER_PERM_ON_OBJECT_TYPE_TABLE;
			
			function user_permission_on_object_type($field="",$value="")
			{
				$this->common_init($field,$value);
			}
			

			function factory($field="",$value="")
			{
				if (Lybra_DB_DataObject::factory($field,$value))
				{
					// Permissions stored into $this->objects[]
					return true;
				}
				return false;
			}

			function permission($user_id,$object_type)
			{
				$user_id_field = LYBRA_USER_PERM_ON_OBJECT_USER_ID;
				$object_type_field = LYBRA_USER_PERM_ON_OBJECT_OBJECT_TYPE;
				$active_field = LYBRA_USER_PERM_ON_OBJECT_TYPE_ACTIVE;
				$mode_field = LYBRA_USER_PERM_ON_OBJECT_MODE;
				
				for ($i=0;$i<count($this->objects);$i++)
					if (($this->objects[$i]->$user_id_field = $user_id) &&
						($this->objects[$i]->$object_type_field = $object_type) &&
						($this->objects[$i]->$active_field))
							return $this->objects[$i]->$mode_field;
				return false;
			}
			/*
			 * Define table to work on
			 */
			function table()
			{
		        return array(
		            LYBRA_USER_PERM_ON_OBJECT_TYPE_USER_ID			=> DB_DATAOBJECT_INT,
		            LYBRA_USER_PERM_ON_OBJECT_TYPE_PERMISSION_ID	=> DB_DATAOBJECT_INT,
		            LYBRA_USER_PERM_ON_OBJECT_TYPE_OBJECT_TYPE 		=> DB_DATAOBJECT_INT,
		            LYBRA_USER_PERM_ON_OBJECT_TYPE_MODE 			=> DB_DATAOBJECT_INT,
		            LYBRA_USER_PERM_ON_OBJECT_TYPE_ACTIVE 			=> DB_DATAOBJECT_INT
		        );
			}
			
			// Override default key
			function keys() 
	    	{
	        	return array(
	        					LYBRA_USER_PERM_ON_OBJECT_TYPE_USER_ID			=> DB_DATAOBJECT_INT,
	        					LYBRA_USER_PERM_ON_OBJECT_TYPE_PERMISSION_ID	=> DB_DATAOBJECT_INT,
	        					LYBRA_USER_PERM_ON_OBJECT_TYPE_OBJECT_TYPE		=> DB_DATAOBJECT_INT
	        				);
	    	}
	    	// No real sequenceKey present
	    	function sequence_key()
	    	{
	    		return array(false,false);
	    	}
		}

		define("LYBRA_GROUP_USER_TABLE","lybra_auth_user_group");
		define("LYBRA_GROUP_USER_GROUP_ID","group_id");
		define("LYBRA_GROUP_USER_USER_ID","user_id");
		define("LYBRA_GROUP_USER_MODE","mode");
		define("LYBRA_GROUP_USER_ACTIVE","active");

		class user_group extends Lybra_DB_DataObject 
		{
			var $__table=LYBRA_GROUP_USER_TABLE;

			function user_group($field="",$value="")
			{
				$this->common_init($field,$value);
			}

			function factory($field="",$value="")
			{
				$active = LYBRA_GROUP_USER_ACTIVE;
				
				if (Lybra_DB_DataObject::factory($field,$value))
				{
					for ($i=0;$i<count($this->objects);$i++)
					{
						// For each retrieved record do special tasks
						if ($this->objects[$i]->$active)
						{
							// 1
							$this->objects[$i]->group = new group(LYBRA_GROUP_USER_GROUP_ID,$this->objects[$i]->group_id);
							// 2
							$this->objects[$i]->wide_permission = new group_wide_permission(LYBRA_GROUP_USER_GROUP_ID,$this->objects[$i]->group_id);
							// 3
							$this->objects[$i]->permission_on_object = new permission_on_object(LYBRA_GROUP_USER_GROUP_ID,$this->objects[$i]->group_id);
							// 4
							$this->objects[$i]->permission_on_object_type = new group_permission_on_object_type(LYBRA_GROUP_USER_GROUP_ID,$this->objects[$i]->group_id);
						}
					}
				}
			}
			
			function wide_permission($permission,$i=0)
			{
				if (is_object($this->objects[$i]->wide_permission))
					return $this->objects[$i]->wide_permission->permission($permission);
				return false;
			}

			/*
			 * Define table to work on
			 */
			function table()
			{
		        return array(
		            LYBRA_GROUP_USER_GROUP_ID	=> DB_DATAOBJECT_INT,
		            LYBRA_GROUP_USER_USER_ID	=> DB_DATAOBJECT_INT,
		            LYBRA_GROUP_USER_MODE		=> DB_DATAOBJECT_INT,
		            LYBRA_GROUP_USER_ACTIVE		=> DB_DATAOBJECT_INT
		        );
			}

			// Override default key
			function keys() 
	    	{
	        	return array(
	        					LYBRA_GROUP_USER_GROUP_ID	=>	DB_DATAOBJECT_INT,
	        					LYBRA_GROUP_USER_USER_ID	=>	DB_DATAOBJECT_INT
	        				);
	    	}

	    	// No real sequenceKey present
	    	function sequence_key()
	    	{
	    		return array(false,false);
	    	}
		}

		define("LYBRA_ROLE_USER_TABLE","lybra_auth_user_has_role");
		define("LYBRA_ROLE_USER_ROLE_ID","role_id");
		define("LYBRA_ROLE_USER_USER_ID","user_id");
		define("LYBRA_ROLE_OBJECT_ID","object_id");
		define("LYBRA_ROLE_OBJECT_TYPE","object_type");
		define("LYBRA_ROLE_USER_MODE","mode");
		define("LYBRA_ROLE_USER_ACTIVE","active");
		
		class user_role extends Lybra_DB_DataObject 
		{
			var $__table=LYBRA_ROLE_USER_TABLE;
			
			function user_role($field="",$value="")
			{
				$this->common_init($field,$value);
			}
			
			function factory($field="",$value="")
			{
				if (Lybra_DB_DataObject::factory($field,$value))
				{
					for ($i=0;$i<count($this->objects);$i++)
					{
						// 1
						$this->objects[$i]->role = new role(LYBRA_ROLE_USER_ROLE_ID,$this->objects[$i]->role_id);
						// 2
						$this->objects[$i]->permission = new role_permission(LYBRA_ROLE_USER_ROLE_ID,$this->objects[$i]->role_id);
					}
				}
			}
			
			function permission($object_id,$object_type,$permission)
			{
				for ($i=0;$i<count($this->objects);$i++)
				{
					if ($this->objects[$i]->permission->permission($object_id,$object_type,$permission))
						return true;
				}
			}

			/*
			 * Define table to work on
			 */
			function table()
			{
		        return array(
		            LYBRA_ROLE_USER_ROLE_ID	=>	DB_DATAOBJECT_INT,
		            LYBRA_ROLE_USER_USER_ID	=>	DB_DATAOBJECT_INT,
		            LYBRA_ROLE_OBJECT_ID	=>	DB_DATAOBJECT_INT,
		            LYBRA_ROLE_OBJECT_TYPE	=>	DB_DATAOBJECT_INT,
		            LYBRA_ROLE_USER_MODE	=>	DB_DATAOBJECT_INT,
		            LYBRA_ROLE_USER_ACTIVE	=>	DB_DATAOBJECT_INT
		        );
			}
			
			// Override default key
			function keys() 
	    	{
	        	return array(
	        		LYBRA_ROLE_USER_ROLE_ID	=>	DB_DATAOBJECT_INT,
	        		LYBRA_ROLE_USER_USER_ID	=>	DB_DATAOBJECT_INT,
	        		LYBRA_ROLE_OBJECT_ID	=>	DB_DATAOBJECT_INT,
		            LYBRA_ROLE_OBJECT_TYPE	=>	DB_DATAOBJECT_INT
	        	);
	    	}
	    	
	    	// No real sequenceKey present
	    	function sequence_key()
	    	{
	    		return array(false,false);
	    	}
		}
		
		define("LYBRA_ROLE_PERMISSION_TABLE","lybra_auth_role_permission");
		define("LYBRA_ROLE_PERMISSION_ROLE_ID","role_id");
		define("LYBRA_ROLE_PERMISSION_PERMISSION_ID","permission_id");
		define("LYBRA_ROLE_PERMISSION_MODE","mode");
		define("LYBRA_ROLE_PERMISSION_ACTIVE","active");
		
		class role_permission extends Lybra_DB_DataObject 
		{
			var $__table=LYBRA_ROLE_PERMISSION_TABLE;

			function user_role($field="",$value="")
			{
				$this->common_init($field,$value);
			}

			function factory($field="",$value="")
			{
				$permission_id = LYBRA_ROLE_PERMISSION_PERMISSION_ID;
				$mode = LYBRA_ROLE_PERMISSION_MODE;
				$active = LYBRA_ROLE_PERMISSION_ACTIVE;
				
				if (Lybra_DB_DataObject::factory($field,$value))
				{
					for ($i=0;$i<count($this->objects);$i++)
					{
						if ($this->objects[$i]->$active)
							$this->permissions[$this->objects[$i]->$permission_id] = $this->objects[$i]->$mode;
					}
				}
			}
			
			// Check if permission is active
			function permission($permission)
			{
				print_("ASKED FOR '$permission' IS '".$this->permissions[$permission]."'","AUTH_WIDE");
				if ($this->permissions[$permission])
					return $this->permissions[$permission];
				return false;
			}			
			
			/*
			 * Define table to work on
			 */
			function table()
			{
		        return array(
		            LYBRA_ROLE_PERMISSION_ROLE_ID		=>	DB_DATAOBJECT_INT,
		            LYBRA_ROLE_PERMISSION_PERMISSION_ID	=>	DB_DATAOBJECT_INT,
		            LYBRA_ROLE_PERMISSION_MODE			=>	DB_DATAOBJECT_INT,
		            LYBRA_ROLE_PERMISSION_ACTIVE		=>	DB_DATAOBJECT_INT
		        );
			}
			
			// Override default key
			function keys() 
	    	{
	        	return array(
	        		LYBRA_ROLE_PERMISSION_ROLE_ID	=>	DB_DATAOBJECT_INT,
	        		LYBRA_ROLE_PERMISSION_PERMISSION_ID	=>	DB_DATAOBJECT_INT
	        	);
	    	}
	    	
	    	// No real sequenceKey present
	    	function sequence_key()
	    	{
	    		return array(false,false);
	    	}
		}

		define("LYBRA_GROUP_TABLE","lybra_auth_groups");
		define("LYBRA_GROUP_GROUP_ID","group_id");
		define("LYBRA_GROUP_DESCRIPTION","group_description");

		class group extends Lybra_DB_DataObject 
		{
			var $__table = LYBRA_GROUP_TABLE;

			function group($field="",$value="")
			{
				$this->common_init($field,$value);
			}
			
			function factory($field="",$value="")
			{
				if (Lybra_DB_DataObject::factory($field,$value))
				{
					for ($i=0;$i<count($this->objects);$i++)
					{
						// For each retrieved record do special tasks
						//$this->objects[$i]->wide_permission = new group_wide_permission(LYBRA_GROUP_GROUP_ID,$this->objects[$i]->group_id);									
						//$this->objects[$i]->permission_on_object = new group_object_permission(LYBRA_GROUP_GROUP_ID,$this->objects[$i]->group_id);
					}
				}
			}
			
			function wide_permission($permission,$i=0)
			{
				return $this->objects[$i]->group_wide_permission($permission);
			}

			/*
			 * Define table to work on
			 */
			function table()
			{
		        return array(
		            LYBRA_GROUP_GROUP_ID	=> DB_DATAOBJECT_INT,
		            LYBRA_GROUP_DESCRIPTION	=> DB_DATAOBJECT_STR
		        );
			}

			// Override default key
			function keys() 
	    	{
	        	return array(LYBRA_GROUP_GROUP_ID	=>	DB_DATAOBJECT_INT);
			}
		}
		
		define("LYBRA_GROUP_PERMISSION_ON_OBJECT","lybra_auth_group_permission_on_object");
		define("LYBRA_GROUP_PERMISSION_ON_OBJECT_GROUP_ID","group_id");
		define("LYBRA_GROUP_PERMISSION_ON_OBJECT_PERMISSION_ID","permission_id");
		define("LYBRA_GROUP_PERMISSION_ON_OBJECT_CATEGORY","object_category");
		define("LYBRA_GROUP_PERMISSION_ON_OBJECT_TYPE","object_type");
		define("LYBRA_GROUP_PERMISSION_ON_OBJECT_MODE","mode");
		
		class group_object_permission extends Lybra_DB_DataObject
		{
			var $__table = LYBRA_GROUP_PERMISSION_ON_OBJECT;
			
			function group_object_permission($field="",$value="")
			{
				$this->common_init($field,$value);
			}
			
			function factory($field,$value)
			{
				if (Lybra_DB_DataObject::factory($field,$value))
				{
					// Retrieve all permissions
				}
			}
			
			/*
			 * Define table to work on
			 */
			function table()
			{
		        return array(
		            LYBRA_GROUP_PERMISSION_ON_OBJECT_GROUP_ID	=> DB_DATAOBJECT_INT,
		            LYBRA_GROUP_PERMISSION_ON_OBJECT_PERMISSION_ID	=> DB_DATAOBJECT_INT,
		            LYBRA_GROUP_PERMISSION_ON_OBJECT_CATEGORY	=> DB_DATAOBJECT_INT,
		            LYBRA_GROUP_PERMISSION_ON_OBJECT_TYPE	=> DB_DATAOBJECT_INT,
		            LYBRA_GROUP_PERMISSION_ON_OBJECT_MODE	=> DB_DATAOBJECT_INT
		        );
			}

			// Override default key
			function keys()
	    	{
	        	return array(
	        			LYBRA_GROUP_PERMISSION_ON_OBJECT_GROUP_ID	=> DB_DATAOBJECT_INT,
	        			LYBRA_GROUP_PERMISSION_ON_OBJECT_PERMISSION_ID => DB_DATAOBJECT_INT,
	        			LYBRA_GROUP_PERMISSION_ON_OBJECT_CATEGORY => DB_DATAOBJECT_INT);
			}
			
	    	// No real sequenceKey present
	    	function sequence_key()
	    	{
	    		return array(false,false);
	    	}
			
		}
		
		define("LYBRA_AUTH_GROUP_PERMISSION_TABLE","lybra_auth_group_permission");
		define("LYBRA_AUTH_GROUP_PERMISSION_GROUP_ID","group_id");
		define("LYBRA_AUTH_GROUP_PERMISSION_PERMISSION_ID","permission_id");
		define("LYBRA_AUTH_GROUP_PERMISSION_MODE","mode");
		
		class group_wide_permission extends Lybra_DB_DataObject 
		{
			var $__table = LYBRA_AUTH_GROUP_PERMISSION_TABLE;
			
			// Permissions by id
			var $permissions = array();

			function group_wide_permission($field="",$value="")
			{
				$this->common_init($field,$value);
			}
			
			function factory($field,$value)
			{
				$permission_id = LYBRA_AUTH_GROUP_PERMISSION_PERMISSION_ID;
				$mode = LYBRA_AUTH_GROUP_PERMISSION_MODE;
				
				if (Lybra_DB_DataObject::factory($field,$value))
				{
					// Store all permissions
					for ($i=0;$i<count($this->objects);$i++)
					{
						$this->permissions[$this->objects[$i]->$permission_id] = $this->objects[$i]->$mode;
						print_("'$i' COUNT_GWP '".$this->objects[$i]->$permission_id."' '".(($this->permissions[$i]->$permission_id)?"TRUE":"FALSE")."' is TRUE ","GROUP_WIDE_PERMISSION");
					}
				}
			}
			// Check if permission is active
			function permission($permission)
			{
				print_("ASKED FOR '$permission' IS '".$this->permissions[$permission]."'","AUTH_WIDE");
				if ($this->permissions[$permission])
					return $this->permissions[$permission];
				return false;
			}
			
			/*
			 * Define table to work on
			 */
			function table()
			{
		        return array(
		            LYBRA_AUTH_GROUP_PERMISSION_GROUP_ID => DB_DATAOBJECT_INT,
		            LYBRA_AUTH_GROUP_PERMISSION_PERMISSION_ID => DB_DATAOBJECT_INT,
		            LYBRA_AUTH_GROUP_PERMISSION_MODE => DB_DATAOBJECT_INT
		        );
			}

			// Override default key
			function keys() 
	    	{
	        	return array(
	        			LYBRA_GROUP_USER_GROUP_ID	=>	DB_DATAOBJECT_INT,
	        			LYBRA_AUTH_GROUP_PERMISSION_PERMISSION_ID => DB_DATAOBJECT_INT
	        	);
			}
			
	    	// No real sequenceKey present
	    	function sequence_key()
	    	{
	    		return array(false,false);
	    	}
		}

		define("LYBRA_ROLE_TABLE","lybra_auth_role");
		define("LYBRA_ROLE_ROLE_ID","role_id");
		define("LYBRA_ROLE_DESCRIPTION","role_description");

		class role extends Lybra_DB_DataObject 
		{
			var $__table=LYBRA_ROLE_TABLE;

			function role($field="",$value="")
			{
				$this->common_init($field,$value);
			}

			/*
			 * Define table to work on
			 */
			function table()
			{
		        return array(
		            LYBRA_ROLE_ROLE_ID		=>	DB_DATAOBJECT_INT,
		            LYBRA_ROLE_DESCRIPTION	=>	DB_DATAOBJECT_STR
		        );
			}

			// Override default key
			function keys() 
	    	{
	        	return array(LYBRA_ROLE_ROLE_ID		=>	DB_DATAOBJECT_INT);
			}
		}
?>