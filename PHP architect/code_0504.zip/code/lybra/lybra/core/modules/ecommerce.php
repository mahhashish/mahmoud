<?
 /**********************************************************************************************
 		Lybra: A general purpose framework for fast web development
		Copyright (C) 2002-2004 Simone Grassi, Andrea Giorgini

	    ecommerce.php
	    -------------
		begin:  	6/2003 Simone Grassi (Ci S.B.i.C. snc)
		copyright:	(C) 2003, Simone Grassi,  Andrea Giorgini
					viale Marconi 438, 47023 Cesena (FC), Italy.
		email:		lybra@cisbic.com

	    This program is free software; you can redistribute it and/or modify
	    it under the terms of the GNU General Public License as published by
	    the Free Software Foundation; either version 2 of the License, or
	    (at your option) any later version.

	    This program is distributed in the hope that it will be useful,
	    but WITHOUT ANY WARRANTY; without even the implied warranty of
	    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	    GNU General Public License for more details.

	    You should have received a copy of the GNU General Public License
	    along with this program; if not, write to the Free Software
	    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************************************/
	class user extends not_core_user
	{
  
		/**
		 * Crea un nuovo utente visitatore
		 *
		 **/
		function user($user_id="")
		{
			// New user
			$this->user_id = (strcmp($user_id,"")?$user_id:$this->create_new_random_user_id());
			$this->cart_id = new cart();
		}
	
		/**
		 * Set a parametric field value
		 **/
		function set_field($name,$value)
		{
		    $this->$name = $value;
		}
	
		/**
		 * Register user as a not_core_user
		 **/
		function register_user()
		{
		}

		/**
		 * Guest user_id generator
		 **/
		function create_new_random_user_id()
		{
			// Change with a db_sequence query
			return rand(1,2147483647);
		}
  }

   /**
   * Not Core database user manager
   *
   *
   **/
  class not_core_user
  {
	function not_core_user($not_core_user_id)
	{
	    $this->table->retrieve("SELECT * FROM ".USER_TABLE." WHERE ".USER_ITEM_ID."='$item_id' ");
	}
	function get_not_core_id($core_id)
	{
	    // Now core_id and not_core_id are the same
	    return $core_id;
	}
	function get_core_id($not_core_id)
	{
	    // Now core_id and not_core_id are the same
	    return $not_core_id;
	}
  }

	/**
	* Il carrello viene creato e salvato nella sessione
	* la sua creazione � quindi unica in tutto l'arco di durata della sessione
	*
	**/
	class cart
	{
		/**
		 * Just create an associative array that (the cart itself)
		 **/
		function cart()
		{
			// Just a new empty hash array
			$this->items = array();
		}
		
		function add_item($item_id)
		{
		    // Store item istance into hash
		    $this->items[$item_id] = new item($item_id);
		}
		
		function remove_item($item_id)
		{
		    // Destroy istance
		    $this->items[$item_id]->destroy();
		    // Unset the hash entry
		    unset($this->items[$item_id]);
		}
	}

	define("CORE_ITEM_ID","core_item_id");
	define("NOT_CORE_ITEM_ID","not_core_item_id");
	/**
	* Core item manager
	**/ 
	class item extends not_core_item
	{
		/**
		 * Istanzia l'elemento
		 * a stringa vuota
		 **/
		function item($item_id)
		{
		    $this->item_id = $item_id;
		    // Costruct the correct not_core_item
		    return $this->not_core_item($this->get_not_core_id($item_id));
		}	
		
		/**
		 * Associa questa istanza all'id di un item
		 * non parte del database core di lybra
		 **/
		function link_to_not_core_db($non_core_id)
		{
		    $this->not_core_id = $not_core_id;
		    $this->table->retrieve();
		}
	}
  
	/**
	* Not Core database item manager
	**/
	class not_core_item
	{
		function not_core_item($not_core_item_id)
		{
		    $this->table->retrieve("SELECT * FROM ".ITEM_TABLE." WHERE ".CORE_ITEM_ID."='$item_id' ");
		}
		function get_not_core_id($core_id)
		{
		    // Now core_id and not_core_id are the same
		    return $core_id;
		}
		function get_core_id($not_core_id)
		{
		    // Now core_id and not_core_id are the same
		    return $not_core_id;
		}
		function destroy()
		{
		    // Destructor tasks
		    //	- product booking etc...
		    // Loop over registered fields for destroy method
		}	
	}
?>