<?php
// Defines Moved to lybra with amother prefix!

require_once("phplayersmenu/lib/layersmenu.inc.php");
require_once("phplayersmenu/lib/template.inc.php");


Class LayersMenuComplete extends LayersMenu{
	var $css_menu;
	var $menu_js_header;
	var $language;
	
	function LayersMenuComplete($dsn,$parameters="")
	{
		parent::LayersMenu();

		$this->dsn = $dsn;
		##############################
		#   LAYER MENU PARAMETERS    #
		#############################
		$this->js_load = false;
		$this->js_layer = false;
		$this->js_tree = false;
		
		$this->setImgdir($parameters->dir_images);
		$this->setImgwww($parameters->www_dir_images);
		$this->setTpldir($parameters->dir_template);
		$this->setLibjswww($parameters->libjswww);		
		$this->setLibjsdir($parameters->libjsdir);
		
		$this->menu_jscript[0] = $this->libjswww.$parameters->menu_jscript_0;
		$this->menu_jscript[1] = $this->libjswww.$parameters->menu_jscript_1;
		$this->menu_jscript[2] = $this->libjswww.$parameters->menu_jscript_2;
		//To use only with tree menu
		$this->menu_jscript[3] = $this->libjswww.$parameters->menu_jscript_3;
		
		//Parameters DB
		$this->db_table_name = "lybra_phplayersmenu";
		$this->db_table_fields = array(
			"Name"		=> "Name",
			"id"		=> "id",
			"parent_id"	=> "parent_id",
			"text"		=> "text",
			"link"		=> "link",
			"title"		=> "title",
			"icon"		=> "icon",
			"target"	=> "target",
			"orderfield"	=> "orderfield",
			"expanded"	=> "expanded"
		);

		$this->db_table_i18n = "lybra_phplayersmenu_i18n";
		$this->db_table_i18n_fields = array(
			"language"	=> "language",
			"Name"		=> "Name",
			"id"		=> "id",
			"text"		=> "text",
			"title"		=> "title"
		);
		//DB Parameters
		$this->dsn = $dsn;
		$this->tableName = $this->db_table_name;
		$this->tableFields = $this->db_table_fields;
		$this->tableName_i18n = $this->db_table_i18n;
		$this->tableFields_i18n = $this->db_table_i18n_fields;
		// END COMMON PATAMETERS
	}

	// Store some parameters relative to phplayermenu module
	function layersMenu_add_istance_parameters($menu_name,$css,$arrows_down,$arrows_forward,$layer_position,$template,$sub_template,$visibility,$abscissa_step)
	{
		//Css file for menu style
		$this->css[$menu_name] =  $css;
		
		//Position of SubMenu from Menu
		$this->layer_position[$menu_name] = $layer_position;
		
		//Template Configuration
		$this->template[$menu_name] = $template;
		$this->sub_template[$menu_name] = $sub_template;
		
		// FIXME: uno ogni menu!
		$this->visibility[$menu_name] = $visibility;
		$this->abscissaStep[$menu_name] = $abscissa_step;

		//Some PhpLayersMenu Settings
		$this->setDownArrowImg($arrows_down,$menu_name);
		$this->setForwardArrowImg($arrows_forward,$menu_name);
		
		//Tag Template for Menu
		//$this->menu_array_tags[$menu_name][TEMPLATE] = array("parent_id","text","link","title","icon","target","expanded","speriod","schairman","speaker","day","cut_text");
		$this->menu_array_tags[$menu_name][PHPLAYERSMENU_TEMPLATE] = array("parent_id","text","link","title","icon","target","expanded","field0","field1","field2","field3","field4");
		$this->menu_array_tags[$menu_name][PHPLAYERSMENU_SUBTEMPLATE] = array("parent_id","text","link","title","icon","target","expanded","field0","field1","field2","field3","field4");
	}
	
	function set_template_menu_array_tags($menu_name,$array_tag)
	{
			$this->menu_array_tags[$menu_name][PHPLAYERSMENU_TEMPLATE] = &$array_tag;
	}
	
	function set_sub_template_menu_array_tags($menu_name,$array_tag)
	{
			$this->menu_array_tags[$menu_name][PHPLAYERSMENU_SUBTEMPLATE] = &$array_tag;
	}
	
	/**
	* The method to set the value of abscissaStep
	* @access public
	* @return void
	*/
	function setAbscissaStep($abscissaStep,$name) {
		$this->abscissaStep[$name] = $abscissaStep;
	}
	
	/**
	* A method to set forwardArrow
	* @access public
	* @param string $forwardArrow the forward arrow HTML code
	* @return void
	*/
	function setForwardArrow($forwardArrow,$menu_name) {
		$this->forwardArrow[$menu_name] = $forwardArrow;
	}
	
	
	/**
	* The method to set an image to be used for the forward arrow
	* @access public
	* @param string $forwardArrowImg the forward arrow image filename
	* @return boolean
	*/
	function setForwardArrowImg($forwardArrowImg,$menu_name) {
		if (!file_exists($this->imgdir . $forwardArrowImg)) {
			$this->error("setForwardArrowImg: file " . $this->imgdir . $forwardArrowImg . " does not exist.");
			return false;
		}
		print_("FILE EXISTS '".$this->imgdir.$forwardArrowImg."'");
		$foobar = getimagesize($this->imgdir . $forwardArrowImg);
		$this->forwardArrow[$menu_name] = " <img src=\"" . $this->imgwww . $forwardArrowImg . "\" width=\"" . $foobar[0] . "\" height=\"" . $foobar[1] . "\" border=\"0\" alt=\" >>\" />";
		return true;
	}
	
	/**
	* A method to set downArrow
	* @access public
	* @param string $downArrow the down arrow HTML code
	* @return void
	*/
	function setDownArrow($downArrow,$menu_name) {
		$this->downArrow[$menu_name] = $downArrow;
	}
	
	/**
	* The method to set an image to be used for the down arrow
	* @access public
	* @param string $downArrowImg the down arrow image filename
	* @return boolean
	*/
	function setDownArrowImg($downArrowImg,$menu_name) {
		if (!file_exists($this->imgdir . $downArrowImg)) {
			$this->error("setDownArrowImg: file " . $this->imgdir . $downArrowImg . " does not exist.");
			return false;
		}
		$foobar = getimagesize($this->imgdir . $downArrowImg);
		$this->downArrow[$menu_name] = " <img src=\"" . $this->imgwww . $downArrowImg . "\" width=\"" . $foobar[0] . "\" height=\"" . $foobar[1] . "\" border=\"0\" alt=\" >>\" />";
		return true;
	}
	
	function setHorizontal($name){
		//$this->forwardArrow[$name] = " --&gt;";
		//$this->downArrow[$name] = " --&gt;";
		
		//$this->setForwardArrowImg($this->arrow[$name][FORWARD],$name);
		//$this->setDownArrowImg($this->arrow[$name][DOWN],$name);
		
		$this->setHorizontalMenuTpl($name,$this->template[$name]);
		$this->setSubMenuTpl($this->sub_template[$name]);
		$this->newHorizontalMenu($name, $this->layer_position[$name]);
	}
	
	function setVertical($name){
		//$this->forwardArrow[$name] = " --&gt;";
		//$this->downArrow[$name] = " --&gt;";
		
		//$this->setForwardArrowImg($this->arrow[$name][FORWARD],$name);
		//$this->setDownArrowImg($this->arrow[$name][DOWN],$name);
		
		$this->setVerticalMenuTpl($name,$this->template[$name]);
		$this->setSubMenuTpl($this->sub_template[$name]);
		$this->newVerticalMenu($name, $this->layer_position[$name]);
	}
	
	function setTree($name){
		$this->newTreeMenu($name);
	}
	
	function setDB($name){
		$this->setDBConnParms($this->dsn);
		$this->setTableName($this->tableName);
		$this->setTableFields($this->tableFields);
		
		$this->setTableName_i18n($this->tableName_i18n);
		$this->setTableFields_i18n($this->tableFields_i18n);
		$this->scanTableForMenu($name,$this->language);
	}
	
	
	function setFile(&$resource,$name){
		$this->setMenuStructureFile($resource,$name);
		$this->parseStructureForMenu($name);
	}
	
	function setType($name,$type){
		$this->type[$name] = $type;
	}
	
	function getType($name){
		return $this->type[$name];
	}
	
	//Load Browser Detection javascript
	function loadBrowserDtJs(){
		return "<script language=\"JavaScript1.2\" type=\"text/javascript\" src=\"".$this->menu_jscript[0]."\"></script>\n";
	}
	
	function loadLayersJs(){
		return "<script language=\"JavaScript1.2\" type=\"text/javascript\" src=\"".$this->menu_jscript[1]."\"></script>".
			   "<script language=\"JavaScript1.2\" type=\"text/javascript\" src=\"".$this->menu_jscript[2]."\"></script>\n";
	}
	
	function loadTreeJs(){
		return "<script language=\"JavaScript1.2\" type=\"text/javascript\" src=\"".$this->menu_jscript[3]."\"></script>\n";
	}
	
	function loadCss($name){
		return "<link rel=\"stylesheet\" href=\"".$this->css[$name]."\">\n";
	}
	
	
	function scanTableForMenu(
	$menu_name = "", // non consistent default...
	$language = ""
	) {
		$this->_maxLevel[$menu_name] = 0;
		$this->_firstLevelCnt[$menu_name] = 0;
		unset($this->tree[$this->_nodesCount+1]);
		$this->_firstItem[$menu_name] = $this->_nodesCount + 1;
		/* BEGIN BENCHMARK CODE
		$time_start = $this->_getmicrotime();
		/* END BENCHMARK CODE */
		$db = DB::connect($this->dsn, $this->persistent);
		if (DB::isError($db)) {
			$this->error("scanTableForMenu: " . $db->getMessage());
		}
		
		$query = "
		SELECT " .
		$this->tableFields["Name"] . " AS Name, " .
		$this->tableFields["id"] . " AS id, " .
		$this->tableFields["parent_id"] . " AS parent_id, " .
		$this->tableFields["text"] . " AS text, " .
		$this->tableFields["link"] . " AS link, " .
		$this->tableFields["title"] . " AS title, " .
		$this->tableFields["icon"] . " AS icon, " .
		$this->tableFields["target"] . " AS target, " .
		$this->tableFields["expanded"] . " AS expanded
		FROM " . $this->tableName . "
		WHERE " . $this->tableFields["id"] . " <> 1 and  Name = '$menu_name' ";
	
		if($this->label[$menu_name] != ""){
			$i = 0;
			$at_least_one = false;
			while(isset($this->label[$menu_name][$i])){
				$at_least_one = true;
				if($i == 0){
					$query .= "and ( label = '".$this->label[$menu_name][$i]."' ";
				}else{
					$query .= "or label = '".$this->label[$menu_name][$i]."' ";
				}
				$i++;
			}
			if ($at_least_one)
				$query .= ") ";
		}

		$query .= "ORDER BY " . $this->tableFields["orderfield"] . ", " . $this->tableFields["text"] . " ASC ";

		$dbresult = $db->query($query);
		print_("QUERYMENU '$query'");
		if(DB::isError($dbresult)){
			print($query);
		}
		
		$this->_tmpArray = array();
		while ($dbresult->fetchInto($row, DB_FETCHMODE_ASSOC)) {
			$this->_tmpArray[$row["id"]]["parent_id"] = $row["parent_id"];
			$this->_tmpArray[$row["id"]]["text"] = $row["text"];
			$this->_tmpArray[$row["id"]]["link"] = $row["link"];
			$this->_tmpArray[$row["id"]]["title"] = $row["title"];
			$this->_tmpArray[$row["id"]]["icon"] = $row["icon"];
			$this->_tmpArray[$row["id"]]["target"] = $row["target"];
			$this->_tmpArray[$row["id"]]["expanded"] = $row["expanded"];
		}
		if ($language != "") {
			$dbresult = $db->query("
			SELECT " .
			$this->tableFields_i18n["id"] . " AS id, " .
			$this->tableFields_i18n["text"] . " AS text, " .
			$this->tableFields_i18n["title"] . " AS title
			FROM " . $this->tableName_i18n . "
			WHERE " . $this->tableFields_i18n["id"] . " <> 1 and Name = $menu_name
			AND " . $this->tableFields_i18n["language"] . " = '$language'
		");
			while ($dbresult->fetchInto($row, DB_FETCHMODE_ASSOC)) {
				$this->_tmpArray[$row["id"]]["text"] = $row["text"];
				$this->_tmpArray[$row["id"]]["title"] = $row["title"];
			}
		}
		unset($dbresult);
		unset($row);
		$this->_depthFirstSearch($this->_tmpArray, $menu_name, 1, 1);
		//BEGIN BENCHMARK CODE
		//$time_end = $this->_getmicrotime();
		//$time = $time_end - $time_start;
		//print "TIME ELAPSED = " . $time . "\n<br>";
		//END BENCHMARK CODE */
		$this->_lastItem[$menu_name] = count($this->tree);
		$this->_nodesCount = $this->_lastItem[$menu_name];
		$this->tree[$this->_lastItem[$menu_name]+1]["level"] = 0;
		$this->_postParse($menu_name);
	}
	
	function _depthFirstSearch($tmpArray, $menu_name, $parent_id = 1, $level) {
		reset ($tmpArray);
		foreach ($tmpArray as $id => $foobar) {
			if ($foobar["parent_id"] == $parent_id) {
				unset($tmpArray[$id]);
				unset($this->_tmpArray[$id]);
				$cnt = count($this->tree) + 1;
				$this->tree[$cnt]["level"] = $level;
				
				foreach($foobar as $key => $value){
					$this->tree[$cnt][$key] = $foobar[$key];
				}

				unset($foobar);
				if ($id != $parent_id) {
					$this->_depthFirstSearch($this->_tmpArray, $menu_name, $id, $level+1);
				}
			}
		}
	}
	
	/**
	* Method to preparare a vertical menu.
	*
	* This method processes items of a menu to prepare the corresponding
	* vertical menu code updating many variables; it returns the code
	* of the corresponding _firstLevelMenu
	*
	* @access public
	* @param string $menu_name the name of the menu whose items have to be processed
	* @param integer $ordinateMargin margin (in pixels) to set the position
	*   of a layer a bit above the ordinate of the "father" link
	* @return string
	*/
	function newVerticalMenu(
	$menu_name = "",	// non consistent default...
	$ordinateMargin = 12
	) {
		//global $menu_array;
		
		if (!isset($this->_firstItem[$menu_name]) || !isset($this->_lastItem[$menu_name])) {
			$this->error("newVerticalMenu: the first/last item of the menu '$menu_name' is not defined; please check if you have parsed its menu data.");
			return 0;
		}
		
		$this->parseCommon($menu_name);
		
		$t = new TemplateMenu();
		$t->setFile("tplfile", $this->verticalMenuTpl[$menu_name]);
		$t->setBlock("tplfile", "template", "template_blck");
		$t->setBlock("template", "vertical_menu_table", "vertical_menu_table_blck");
		$t->setVar("vertical_menu_table_blck", "");
		$t->setBlock("vertical_menu_table", "vertical_menu_cell", "vertical_menu_cell_blck");
		$t->setVar("vertical_menu_cell_blck", "");
		$t->setVar("abscissaStep", $this->abscissaStep[$menu_name]);
		
		$t_sub = new TemplateMenu();
		$t_sub->setFile("tplfile", $this->subMenuTpl);
		$t_sub->setBlock("tplfile", "sub_menu_cell", "sub_menu_cell_blck");
		$t_sub->setVar("abscissaStep", $this->abscissaStep[$menu_name]);
		
		$this->_firstLevelMenu[$menu_name] = "";
		
		$this->moveLayers .= "\tvar " . $menu_name . "TOP = getOffsetTop('" . $menu_name . "');\n";
		$this->moveLayers .= "\tvar " . $menu_name . "LEFT = getOffsetLeft('" . $menu_name . "');\n";
		$this->moveLayers .= "\tvar " . $menu_name . "WIDTH = getOffsetWidth('" . $menu_name . "');\n";
		
		for ($cnt=$this->_firstItem[$menu_name]; $cnt<=$this->_lastItem[$menu_name]; $cnt++) {	// this counter scans all nodes of the new menu
		
		if ($this->tree[$cnt]["not_a_leaf"]) {
			// geometrical parameters are assigned to the new layer, related to the above mentioned children
			if ($this->tree[$cnt]["child_of_root_node"]) {
				$this->moveLayers .= "\tsetLeft('" . $this->tree[$cnt]["layer_label"] . "', " . $menu_name . "LEFT + " . $menu_name . "WIDTH);\n";
			}
			$this->tree[$cnt]["arrow"] = $this->forwardArrow[$menu_name];
			$this->moveLayers .= "\tif (IE4) setWidth('" . $this->tree[$cnt]["layer_label"] . "'," . $this->abscissaStep[$menu_name] . ");\n";
		} else {
			$this->tree[$cnt]["arrow"] = "";
		}
		$foobar = "";
		
		$t->setVar(array(
		"cellwidth"		=> $this->abscissaStep[$menu_name],
		"cell_link_blck"	=> $foobar
		));
		
		if ($this->tree[$cnt]["child_of_root_node"]) {
			if ($this->tree[$cnt]["not_a_leaf"]) {
				$this->tree[$cnt]["onmouseover"] = " onmouseover=\"moveLayerY('" . $this->tree[$cnt]["layer_label"] . "', " . $ordinateMargin . ") ; moveLayerX('" . $this->tree[$cnt]["layer_label"] . "') ; LMPopUp('" . $this->tree[$cnt]["layer_label"] . "', false);\"";
			} else {
				$this->tree[$cnt]["onmouseover"] = " onmouseover=\"shutdown();\"";
			}
			
			$template_array = array();
			
			foreach ($this->menu_array_tags[$menu_name][PHPLAYERSMENU_TEMPLATE] as $key){
					
					if($this->tree[$cnt]["parsed_".$key])
						$template_array[$key] = $this->tree[$cnt]["parsed_".$key];
					else
						$template_array[$key] = $this->tree[$cnt][$key];
			}	
			
			
			
			$t->setVar(array(
			"ordinateStep"	=> $this->ordinateStep,
			"icontag"	=> $this->tree[$cnt]["icontag"],
			"refid"		=> " id=\"ref" . $this->tree[$cnt]["layer_label"] . "\"",
			"onmouseover"	=> $this->tree[$cnt]["onmouseover"],
			"arrow"		=> $this->tree[$cnt]["arrow"]
			));
			
			$t->setVar($template_array);
			$this->_firstLevelMenu[$menu_name] .= $t->parse("vertical_menu_cell_blck", "vertical_menu_cell");
		} else {
			if ($this->tree[$cnt]["not_a_leaf"]) {
				$this->tree[$cnt]["onmouseover"] = " onmouseover=\"moveLayerY('" . $this->tree[$cnt]["layer_label"] . "', " . $ordinateMargin . ") ; moveLayerX('" . $this->tree[$cnt]["layer_label"] . "') ; LMPopUp('" . $this->tree[$cnt]["layer_label"] . "', false);\"";
			} else {
				$this->tree[$cnt]["onmouseover"] = " onmouseover=\"LMPopUp('" . $this->tree[$this->tree[$cnt]["father_node"]]["layer_label"] . "', true);\"";
			}
			
			foreach ($this->menu_array_tags[$menu_name][PHPLAYERSMENU_SUBTEMPLATE] as $key){
					
					if($this->tree[$cnt]["parsed_".$key])
						$template_array[$key] = $this->tree[$cnt]["parsed_".$key];
					else
						$template_array[$key] = $this->tree[$cnt][$key];
						
			}	
			
			$t_sub->setVar(array(
			"cellwidth"	=> $this->abscissaStep[$menu_name],
			"ordinateStep"	=> $this->ordinateStep,
			"icontag"	=> $this->tree[$cnt]["icontag"],
			"refid"		=> " id=\"ref" . $this->tree[$cnt]["layer_label"] . "\"",
			"onmouseover"	=> $this->tree[$cnt]["onmouseover"],
			"arrow"		=> $this->tree[$cnt]["arrow"]
			));
			
			$t_sub->setVar($template_array);
			
			$this->tree[$this->tree[$cnt]["father_node"]]["layer_content"] .= $t_sub->parse("sub_menu_cell_blck", "sub_menu_cell");
		}
		}	// end of the "for" cycle scanning all nodes
		
		$t->setVar("vertical_menu_cell_blck", $this->_firstLevelMenu[$menu_name]);
		$this->_firstLevelMenu[$menu_name] = $t->parse("vertical_menu_table_blck", "vertical_menu_table");
		
		if($this->visibility[$menu_name] == OFF)
			$visibility = "visibility: hidden";
		else
			$visibility = "visibility: inherit";
		
		$this->_firstLevelMenu[$menu_name] =
		"<div  id=\"$menu_name\" style=\"$visibility;\" onmouseover=\"clearLMTO();\" onmouseout=\"setLMTO();\">\n" .
		"<script language=\"JavaScript\" type=\"text/javascript\">\n" .
		"<!--\n" .
		"if (IE) fixieflm(\"" . $menu_name . "\");\n" .
		"// -->\n" .
		"</script>" .
		$this->_firstLevelMenu[$menu_name] . "\n" .
		"</div>";
		$t->setVar(array(
		"layer_label"			=> $menu_name,
		//"abscissaStep"	=> $this->abscissaStep[$menu_name],
		"vertical_menu_table_blck"	=> $this->_firstLevelMenu[$menu_name],
		"visibility"			=> $visibility
		));
		
		$this->_firstLevelMenu[$menu_name] = $t->parse("template_blck", "template");
		
		$this->_updateFooter($menu_name);
		
		return $this->_firstLevelMenu[$menu_name];
	}
	
	/**
	* Method to preparare a horizontal menu.
	*
	* This method processes items of a menu to prepare the corresponding
	* horizontal menu code updating many variables; it returns the code
	* of the corresponding _firstLevelMenu
	*
	* @access public
	* @param string $menu_name the name of the menu whose items have to be processed
	* @param integer $ordinateMargin margin (in pixels) to set the position
	*   of a layer a bit above the ordinate of the "father" link
	* @return string
	*/
	function newHorizontalMenu(
	$menu_name = "",	// non consistent default...
	$ordinateMargin = 12
	) {
	
	//global $menu_array;
	
	
	
	if (!isset($this->_firstItem[$menu_name]) || !isset($this->_lastItem[$menu_name])) {
		$this->error("newHorizontalMenu: the first/last item of the menu '$menu_name' is not defined; please check if you have parsed its menu data.");
		return 0;
	}

	$this->parseCommon($menu_name);

	$t = new TemplateMenu();

	$t->setFile("tplfile", $this->horizontalMenuTpl[$menu_name]);
	$t->setBlock("tplfile", "template", "template_blck");
	$t->setBlock("template", "horizontal_menu_cell", "horizontal_menu_cell_blck");
	$t->setVar("horizontal_menu_cell_blck", "");
	$t->setBlock("horizontal_menu_cell", "cell_link", "cell_link_blck");
	$t->setVar("cell_link_blck", "");
	$t->setVar("abscissaStep", $this->abscissaStep[$menu_name]);
	
	$t_sub = new TemplateMenu();
	$t_sub->setFile("tplfile", $this->subMenuTpl);
	$t_sub->setBlock("tplfile", "sub_menu_cell", "sub_menu_cell_blck");
	$t_sub->setVar("abscissaStep", $this->abscissaStep[$menu_name]);

	$this->_firstLevelMenu[$menu_name] = "";

	$foobar = $this->_firstItem[$menu_name];
	$this->moveLayers .= "\tvar " . $menu_name . "TOP = getOffsetTop('" . $menu_name . "L" . $foobar . "');\n";
	$this->moveLayers .= "\tvar " . $menu_name . "HEIGHT = getOffsetHeight('" . $menu_name . "L" . $foobar . "');\n";
	
	for ($cnt=$this->_firstItem[$menu_name]; $cnt<=$this->_lastItem[$menu_name]; $cnt++) {	// this counter scans all nodes of the new menu
		if ($this->tree[$cnt]["not_a_leaf"]) {
			// geometrical parameters are assigned to the new layer, related to the above mentioned children
			if ($this->tree[$cnt]["child_of_root_node"]) {
				$this->moveLayers .= "\tsetLeft('" . $this->tree[$cnt]["layer_label"] . "', getOffsetLeft('" . $menu_name . $this->tree[$cnt]["layer_label"] . "'));\n";
				$this->tree[$cnt]["arrow"] = $this->downArrow[$menu_name];
			} else {
				$this->tree[$cnt]["arrow"] = $this->forwardArrow[$menu_name];
			}
			if ($this->tree[$cnt]["child_of_root_node"]) {
				$this->moveLayers .= "\tsetTop('" . $this->tree[$cnt]["layer_label"] . "', "  . $menu_name . "TOP + " . $menu_name . "HEIGHT);\n";
			}
			$this->moveLayers .= "\tif (IE4) setWidth('" . $this->tree[$cnt]["layer_label"] . "'," . $this->abscissaStep[$menu_name] . ");\n";
		} else {
			$this->tree[$cnt]["arrow"] = "";
		}

		if ($this->tree[$cnt]["child_of_root_node"]) {
			if ($this->tree[$cnt]["not_a_leaf"]) {
				$this->tree[$cnt]["onmouseover"] = " onmouseover=\"LMPopUp('" . $this->tree[$cnt]["layer_label"] . "', false);\"";
			} else {
				$this->tree[$cnt]["onmouseover"] = " onmouseover=\"shutdown();\"";
			}
			print_("MENUNAME '$menu_name'");
			foreach ($this->menu_array_tags[$menu_name][PHPLAYERSMENU_TEMPLATE] as $key){
					if(isset($this->tree[$cnt][$key]))
					{
						if($this->tree[$cnt]["parsed_".$key])
							$template_array[$key] = $this->tree[$cnt]["parsed_".$key];
						else
							$template_array[$key] = $this->tree[$cnt][$key];
						
					}
						
			}	
			
			$t->setVar(array(
				"icontag"	=> $this->tree[$cnt]["icontag"],
				"onmouseover"	=> $this->tree[$cnt]["onmouseover"],
				"arrow"		=> $this->tree[$cnt]["arrow"]
			));
			
			$t->setVar($template_array);
			
			$foobar = $t->parse("cell_link_blck", "cell_link");
			
			if($this->visibility[$menu_name] == OFF)
				$visibility = "visibility: hidden";
			else
				$visibility = "visibility: inherit";
			
			$foobar =
			"<div id=\"" . $menu_name . $this->tree[$cnt]["layer_label"] . "\" style=\"position: relative; $visibility;\" onmouseover=\"clearLMTO();\" onmouseout=\"setLMTO();\">\n" .
			"<script language=\"JavaScript\" type=\"text/javascript\">\n" .
			"<!--\n" .
			"if (IE) fixieflm(\"" . $menu_name . $this->tree[$cnt]["layer_label"] . "\");\n" .
			"// -->\n" .
			"</script>" .
			$foobar . "\n" .
			"</div>";
			
			$t->setVar(array(
				//"abscissaStep" => $this->abscissaStep[$menu_name],
				"cellwidth"		=> $this->abscissaStep[$menu_name],
				"cell_link_blck"	=> $foobar
			));
			
			$t->parse("horizontal_menu_cell_blck", "horizontal_menu_cell", true);
		} else {
			if ($this->tree[$cnt]["not_a_leaf"]) {
				$this->tree[$cnt]["onmouseover"] = " onmouseover=\"moveLayerY('" . $this->tree[$cnt]["layer_label"] . "', " . $ordinateMargin . ") ; moveLayerX('" . $this->tree[$cnt]["layer_label"] . "') ; LMPopUp('" . $this->tree[$cnt]["layer_label"] . "', false);\"";
			} else {
				$this->tree[$cnt]["onmouseover"] = " onmouseover=\"LMPopUp('" . $this->tree[$this->tree[$cnt]["father_node"]]["layer_label"] . "', true);\"";
			}
			
			foreach ($this->menu_array_tags[$menu_name][PHPLAYERSMENU_SUBTEMPLATE] as $key){
					
					if($this->tree[$cnt]["parsed_".$key])
						$template_array[$key] = $this->tree[$cnt]["parsed_".$key];
					else
						$template_array[$key] = $this->tree[$cnt][$key];
						
			}	
			
			$t_sub->setVar(array(
				"ordinateStep"	=> $this->ordinateStep,
				"icontag"	=> $this->tree[$cnt]["icontag"],
				"refid"		=> " id=\"ref" . $this->tree[$cnt]["layer_label"] . "\"",
				"onmouseover"	=> $this->tree[$cnt]["onmouseover"],
				"arrow"		=> $this->tree[$cnt]["arrow"]
			));
			
			$t_sub->setVar($template_array);
			$this->tree[$this->tree[$cnt]["father_node"]]["layer_content"] .= $t_sub->parse("sub_menu_cell_blck", "sub_menu_cell");
		}
	}	// end of the "for" cycle scanning all nodes

	$foobar = $this->_firstLevelCnt[$menu_name] * $this->abscissaStep[$menu_name];
	$t->setVar("menuwidth", $foobar);
	$t->setVar(array(
		"layer_label"	=> $menu_name,
		//"abscissaStep" => $this->abscissaStep[$menu_name],
		"menubody"	=> $this->_firstLevelMenu[$menu_name]
	));

	$this->_firstLevelMenu[$menu_name] = $t->parse("template_blck", "template");

	$this->_updateFooter($menu_name);

	return $this->_firstLevelMenu[$menu_name];
}



	/**
	* @return void
	* @param String $menu_name
	* @param Array $arrayTemplate
	* @desc Method to add tag to template
	*/
	function addTagTemplate($menu_name,$array_template,$template){
		
		for ($cnt=$this->_firstItem[$menu_name]; $cnt<=$this->_lastItem[$menu_name]; $cnt++) {
			for ($i = 0; $i > count($array_template[PHPLAYERSMENU_TEMPLATE]); $i++)
			{
				$template->set_var($array_template[PHPLAYERSMENU_TEMPLATE][$i],$this->tree[$cnt]["parsed_target"]);
			}
		}
		
		
	}

/**
*
*Array(ID,PARENT_ID,TEXT,LINK,TITLE,ICON,TARGET,ORDERFIELDS,EXPANDS)
*
*/
function setMenuFromArray($menu_array,$menu_name){
	$this->_maxLevel[$menu_name] = 0;
	$this->_firstLevelCnt[$menu_name] = 0;
	unset($this->tree[$this->_nodesCount+1]);
	$this->_firstItem[$menu_name] = $this->_nodesCount + 1;
	$this->_tmpArray = $menu_array;
	$this->_depthFirstSearch($this->_tmpArray,$menu_name,1,1);
	//BEGIN BENCHMARK CODE
	//$time_end = $this->_getmicrotime();
	//$time = $time_end - $time_start;
	//print "TIME ELAPSED = " . $time . "\n<br>";
	//END BENCHMARK CODE */
	$this->_lastItem[$menu_name] = count($this->tree);
	$this->_nodesCount = $this->_lastItem[$menu_name];
	$this->tree[$this->_lastItem[$menu_name]+1]["level"] = 0;
	$this->_postParse($menu_name);
}

function setLabel($name,$label){
	$this->label[$name] = $label;
}

function setRepository($menu_name,$repository,&$resource){
	print_($repository,"MENU REPOSITORY");
	switch ($repository)
	{
		case  LYBRA_PHPLAYERMENU_TYPE_DB:
			$this->setDB($menu_name);
			break;
		case LYBRA_PHPLAYERMENU_TYPE_ARRAY:
			$this->setMenuFromArray($resource,$menu_name);
			break;
		case LYBRA_PHPLAYERMENU_TYPE_ARRAY_QUERY:
			$this->setMenuFromArray($resource,$menu_name);
			break;
		default: 
			$this->setFile($resource,$menu_name);
			break;
	}
}

function populateArray($menu_array, $menu_struct){
	
	foreach ($menu_array as $key){
		$tmpArray[$key] = $menu_struct[$key];
	}
	
	return $tmpArray;
	
	
}



		/***************************************************
		   ADDED BY Ci S.B.i.C snc
		   viale Marconi 438 47023 Cesena(FC) Italy
		   Francesco Trucchia, Simone Grassi
		   http://www.cisbic.com
		 ***************************************************/
		function make_menu()
		{
			$this->js_load = false;
			$this->js_layer = false;
			$this->js_tree = false;
			// $this->menu = new LayersMenuComplete($this->table->dsn);
		}

		//Method to make Horizontal menu
		function make_horizontal_menu($name,$repository = FILE, $menu_array = "",$label = "")
		{
			$this->setLabel($name,$label);
			$this->load_css($name);
			$this->setType($name,"Layer");
			$this->load_javascript($name);
			$this->setRepository($name,$repository,$menu_array);
			$this->setHorizontal($name);
		}

		//Method to make Vertical menu
		function make_vertical_menu($name,$repository = FILE, $menu_array = "", $label = "")
		{
			$this->setLabel($name,$label);
			$this->load_css($name);
			$this->setType($name,"Layer");
			$this->load_javascript($name);
			$this->setRepository($name,$repository,$menu_array);
			$this->setVertical($name);
		}

		//Method to make Vertical menu
		function make_tree_menu($name,$repository = FILE, $menu_array = "", $label = "")
		{
			$this->setLabel($name,$label);
			$this->load_css($name);
			$this->setType($name,"Tree");
			$this->load_javascript($name);
			$this->setRepository($name,$repository,$menu_array);
			$this->setTree($name);
		}
		
		function get_header()
		{
			return $this->css_menu.$this->menu_js_header.$this->makeHeader();
		}
		
		function get_css($name)
		{
			return $this->css[$name];
		}

		function get_menu($name)
		{
			return $this->getMenu($name);
		}

		function get_tree_Menu($name)
		{
			return $this->getTreeMenu($name);
		}

		function get_footer()
		{
			return $this->makeFooter();
		}

		function load_css($name)
		{
			$this->css_menu .= $this->loadCss($name);
		}
				
		function load_javascript($name)
		{

			if(!$this->js_load){
				$this->menu_js_header .= $this->loadBrowserDtJs();
				$this->js_load = true;
			}

			switch ($this->getType($name))
			{
				case "Layer":
					if(!$this->js_layer)
					{
						$this->menu_js_header .= $this->loadLayersJs();
						$this->js_layer = true;
					}
					break;
				case "Tree":
					if(!$this->js_tree)
					{
						$this->menu_js_header .= $this->loadTreeJs();
						$this->js_tree = true;
					}
					break;
			}
		}
		
		/**
		* The method to read the menu structure from a file
		* @access public
		* @param string $tree_file the menu structure file
		* @return boolean
		*/
		function setMenuStructureFile($tree_file,$menu_name) {
			if (!($fd = fopen($tree_file, "r"))) {
				$this->error("setMenuStructureFile: unable to open file $tree_file.");
				return false;
			}
			$this->menuStructure[$menu_name] = "";
			while ($buffer = fgets($fd, 4096)) {
				$buffer = ereg_replace(chr(13), "", $buffer);	// Microsoft Stupidity Suppression
				$this->menuStructure[$menu_name] .= $buffer;
			}
			fclose($fd);
			if ($this->menuStructure[$menu_name] == "") {
				$this->error("setMenuStructureFile: $tree_file is empty.");
				return false;
			}
			return true;
		}
		
		/**
		* The method to set the menu structure passing it through a string
		* @access public
		* @param string $tree_string the menu structure string
		* @return boolean
		*/
		function setMenuStructureString($tree_string,$menu_name) {
			$this->menuStructure[$menu_name] = ereg_replace(chr(13), "", $tree_string);	// Microsoft Stupidity Suppression
			if ($this->menuStructure[$menu_name] == "") {
				$this->error("setMenuStructureString: empty string.");
				return false;
			}
			return true;
		}
		
		/**
		* The method to parse the current menu structure and correspondingly update related variables
		* @access public
		* @param string $menu_name the name to be attributed to the menu
		*   whose structure has to be parsed
		* @return void
		*/
		function parseStructureForMenu(
		$menu_name = ""	// non consistent default...
		) {
			$this->_maxLevel[$menu_name] = 0;
			$this->_firstLevelCnt[$menu_name] = 0;
			$this->_firstItem[$menu_name] = $this->_nodesCount + 1;
			$cnt = $this->_firstItem[$menu_name];
			$menuStructure = $this->menuStructure[$menu_name];
			
			/* *********************************************** */
			/* Partially based on a piece of code taken from   */
			/* TreeMenu 1.1 - Bjorge Dijkstra (bjorge@gmx.net) */
			/* *********************************************** */
			
			while ($menuStructure != "") {
				$before_cr = strcspn($menuStructure, "\n");
				$buffer = substr($menuStructure, 0, $before_cr);
				$menuStructure = substr($menuStructure, $before_cr+1);
				if (substr($buffer, 0, 1) != "#") {	// non commented item line...
				$tmp = rtrim($buffer);
				$node = explode($this->separator, $tmp);
				for ($i=count($node); $i<=6; $i++) {
					$node[$i] = "";
				}
				$this->tree[$cnt]["level"] = strlen($node[0]);
				$this->tree[$cnt]["text"] = $node[1];
				$this->tree[$cnt]["link"] = $node[2];
				$this->tree[$cnt]["title"] = $node[3];
				$this->tree[$cnt]["icon"] = $node[4];
				$this->tree[$cnt]["target"] = $node[5];
				$this->tree[$cnt]["expanded"] = $node[6];
				$cnt++;
				}
			}
			
			/* *********************************************** */
			
			$this->_lastItem[$menu_name] = count($this->tree);
			$this->_nodesCount = $this->_lastItem[$menu_name];
			$this->tree[$this->_lastItem[$menu_name]+1]["level"] = 0;
			$this->_postParse($menu_name);
		}
		
		/**
		* The method to set horizontalMenuTpl
		* @access public
		* @return boolean
		*/
		function setHorizontalMenuTpl($menu_name,$horizontalMenuTpl) {
			if (str_replace("/", "", $horizontalMenuTpl) == $horizontalMenuTpl) {
				$horizontalMenuTpl = $this->tpldir . $horizontalMenuTpl;
			}
			if (!file_exists($horizontalMenuTpl)) {
				$this->error("setHorizontalMenuTpl: file $horizontalMenuTpl does not exist.");
				return false;
			}
			$this->horizontalMenuTpl[$menu_name] = $horizontalMenuTpl;
			return true;
		}
		
		/**
		* The method to set verticalMenuTpl
		* @access public
		* @return boolean
		*/
		function setVerticalMenuTpl($menu_name,$verticalMenuTpl) {
			if (str_replace("/", "", $verticalMenuTpl) == $verticalMenuTpl) {
				$verticalMenuTpl = $this->tpldir . $verticalMenuTpl;
			}
			if (!file_exists($verticalMenuTpl)) {
				$this->error("setVerticalMenuTpl: file $verticalMenuTpl does not exist.");
				return false;
			}
			$this->verticalMenuTpl[$menu_name] = $verticalMenuTpl;
			return true;
		}
		/********************************
			END CISBIC CODE
		 ********************************/
}
?>