<?
 /**********************************************************************************************
 		Lybra: A general purpose framework for fast web development
		Copyright (C) 2002-2004 Simone Grassi, Andrea Giorgini

	    html.php
	    --------
		begin:  	3/2003 Simone Grassi (Ci S.B.i.C. snc)
		copyright:	(C) 2003, Simone Grassi,  Andrea Giorgini
					viale Marconi 438, 47023 Cesena (FC), Italy.
		email:		lybra@cisbic.com

	    This program is free software; you can redistribute it and/or modify
	    it under the terms of the GNU General Public License as published by
	    the Free Software Foundation; either version 2 of the License, or
	    (at your option) any later version.

	    This program is distributed in the hope that it will be useful,
	    but WITHOUT ANY WARRANTY; without even the implied warranty of
	    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	    GNU General Public License for more details.

	    You should have received a copy of the GNU General Public License
	    along with this program; if not, write to the Free Software
	    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************************************/

    /**
     * Simple method collector. Collect method to construct HTML objects
     **/
    class html
    {
		function html($new_line="\n")
		{
		    $this->new_line = $new_line;
		    $this->get_start_string = "?";
		    $this->get_parameters_separator = "&";
		    
		    $this->active_methods = array("anchors"=>1);
		    return true;
		}

		// Accept the border, a matrix with data, fields is optional and usually specify
		// witch column to use, here not needed cause we use all rows
		function generic_table_builder($border,$data,$fields="")
		{
			$out_html = "<table border=$border>";
			for ($i=0;$i<count($data);$i++)
			{
				$out_html .= "<TR>";
				for ($j=0;$j<count($data);$j++)
				{
					$out_html .= "<TD>".$data[$i][$j]."</TD>";
				}
				$out_html .= "</TR>";
			}
			$out_html .= "</table>";
			return $out_html;
		}
    }
?>
