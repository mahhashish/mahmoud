<?
define("OFF",0);
define("ON",1);

define("HEADER", 0);
define("MESSAGE", 1);
define("OBJECT", 2);
define("HTML",3);
define("FROM",4);
define("REPLY_TO",5);
define("X_MAILER",6);
define("CC",7);
define("BCC",8);
define("RECEIVER",9);

require_once("log.class.php");

class log_mail extends abstract_log{
	var $header_mail;
	var $receiver;
	var $message;
	var $object;

	
	//Constructor
	function log_mail($mail_param, $log_implicit_fields, $log_timestamp_format = DEFAULT_DATE_FORMAT){
		parent::abstract_log($log_implicit_fields, $log_timestamp_format);
		
		$this->mail_param_list = array(HTML => "MIME-Version: 1.0\r\nContent-type: text/html;         charset=iso-8859-1", 
									   FROM => "From: ", 
									   REPLY_TO => "Reply-To: ", 
									   X_MAILER => "X-Mailer: PHP/".phpversion(), 
									   CC => "Cc: ", 
									   BCC => "Bcc: ");
		
		$this->mail_param = $mail_param;
		$this->receiver = $this->mail_param["log_receiver"];
		
	}
	
	function get_header(){
		$fields = array_keys($this->mail_param);

		$i = 0;
		while(isset($fields[$i])){
			if(isset($this->mail_param_list[$fields[$i]]) || $this->mail_param_list[$fields[$i]] != OFF){
				if($this->mail_param_list[$fields[$i]] == ON) $this->mail_param_list[$fields[$i]] = "";
				$this->header_mail .= $this->mail_param_list[$fields[$i]].$this->mail_param[$fields[$i]].$this->formatting["return"].$this->formatting["newline"];
			}
			$i++;
		}
	}
	
	//Param TYPE_LOG, ESPLICIT FIELD
	//Public method to make log string to mem in log file
	function log(){
		//Elements passed at method
		$args_value = func_get_args();
		$i = 0;
		while(isset($args_value[$i])){
			if($i == 0)
				$this->message .= $this->log_name_field_list[$this->passed_args_list[$i]].": ".$this->log_type[$args_value[$i]].$this->formatting["newline"];
			else
				$this->message .= $this->log_name_field_list[$this->passed_args_list[$i]].": ".$args_value[$i].$this->formatting["newline"];
			$i++;
		}
		$i = 0;
		while(isset($this->log_implicit_fields[$i])){
			$this->message .= $this->log_name_field_list[$this->log_id_field_list[$this->log_implicit_fields[$i]]].": ".$this->get_field($this->log_id_field_list[$this->log_implicit_fields[$i]]).$this->formatting["newline"];
			$i++;
		}

		$this->get_header();

		$this->object = "[".$this->log_type[$args_value[0]]."] Log from host: ".$_SERVER["HTTP_HOST"];
		echo $this->header_mail."<BR>";
		echo $this->receiver."<BR>";
		echo $this->object."<BR>";
		echo $this->message."<BR>";

		if(!mail($this->receiver, $this->object, $this->message,  $this->header_mail))
			echo "<b>Error:</B> Impossibile Inviare l'E-mail";


		
	}
}
?>