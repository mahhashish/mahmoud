<?php
require_once("classes/logXml.class.php");
require_once("classes/logTxt.class.php");
require_once("classes/logCsv.class.php");

$log_path_set= array("PAR_LOG_PATH" => "c:/Programmi/Apache/htdocs/modulo_lybra/log",
	  				 "PAR_LOG_FILE" => "log",
	  				 "PAR_LOG_TYPE_PATH" => "PATH/NAME_TYPE_DATE.EXTENSION");
	  				 
$log_implicit_fields = "TIMESTAMP BROWSER_TYPE IP_ADDRESS SELF";

$logXml = new log_xml($log_path_set, $log_implicit_fields);
$logTxt = new log_txt($log_path_set, $log_implicit_fields);
$logCsv = new log_csv($log_path_set, $log_implicit_fields);

$logXml->log(DEBUG,12,"Error Code: impossibile arara");
$logTxt->log(ERROR);
$logCsv->log(ACCESS);

/*
LYBRA_LOG
ID, PATH, NAME_FILE, TYPE_PATH, ARG_LIST, EXTENSION_FILE, REPOSITORY

LYBRA_LOG_ISTANCE
ID, TYPE
*/
?>