<?
require_once("log.class.php");

class log_xml extends log_on{
	
	
	//Constructor
	function log_xml(&$log_parameters, $log_implicit_fields, $log_timestamp_format = DEFAULT_DATE_FORMAT){
		parent::log_on($log_parameters, $log_implicit_fields, $log_timestamp_format);
		//Set log file extension
		$this->log_path_type_list[EXTENSION] = $log_parameters["log_extension"];
		//Set log path type
		$this->log_path_type = $log_parameters["log_type_path"];
		$this->log_path = $this->log_path_type;
	}
	
	
	
	//Param TYPE_LOG, ESPLICIT FIELD
	//Public method to make log string to mem in log file
	function log(){
		//Elements passed at method
		$args_value = func_get_args();
		//Set the log type
		$this->log_path_type_list[TYPE] = $this->log_type[$args_value[0]];
		//Get the right path where mem log file
		$this->get_path();
		
		if(!$this->exist_dir()){
			$str .= "<LOG>".$this->formatting["newline"];
		}

		$str .= "  <".$this->log_type[$args_value[0]].">".$this->formatting["newline"];
		$i = 1;
		while(isset($args_value[$i])){
			$str .= "     <".$this->log_name_tag_field_list[$this->passed_args_list[$i]].">";
			$str .= $args_value[$i];
			$str .= "</".$this->log_name_tag_field_list[$this->passed_args_list[$i]].">";
			$str .= $this->formatting["newline"];
			$i++;
		}
		$i = 0;
		while(isset($this->log_implicit_fields[$i])){
			$str .= "     <".$this->log_name_tag_field_list[$this->log_id_field_list[$this->log_implicit_fields[$i]]].">";
			$str .= $this->get_field($this->log_id_field_list[$this->log_implicit_fields[$i]]);
			$str .= "</".$this->log_name_tag_field_list[$this->log_id_field_list[$this->log_implicit_fields[$i]]].">";
			$str .= $this->formatting["newline"];
			$i++;
		}

		$str .= "  </".$this->log_type[$args_value[0]].">".$this->formatting["newline"];
		$str .= "</LOG>".$this->formatting["newline"];
		
		if(is_file($this->log_path)){
			$file = new execFileSystem($this->log_path,"r",0);
			$file->_buffer = str_replace("</LOG>", $str, $file->_buffer);
			//FyleSystem object from phenomenon
			new execFileSystem($this->log_path,"w",0,$file->_buffer);
		}else{
			//FyleSystem object from phenomenon
			new execFileSystem($this->log_path,"w",0,$str);
		}
		//Reset log path
		$this->log_path = $this->log_path_type;
		
	}
}
?>