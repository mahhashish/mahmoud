<?php
//LOG INDEX

//Type
define("SYSTEM",1); //System log (ex. server action, etc.)
define("ERROR",2);  //Error log (ex. invalid application action, etc.)
define("DEBUG",3);	//Debug log to find error in the application (TO DEVELOPPE)
define("EXEC",4);	//?????????????????? Chiedere a Simone
define("ACCESS",5); //Access log (ex. access web, etc.)

//Repository
//define("FILE",0);
define("DATABASE",1);

//Repository File
define("CSV_FILE",0);
define("XML_FILE",0);
define("TXT_FILE",0);

//Repositary Settings
define("USE_DB",1);
define("USE_FILE",2);

//Repositary File Extensions
define("TXT",1);
define("LOG",2);
define("XML",3);
define("CSV",4);

//Repositary DB table
define("MONO_TABLE",0);
define("MULTI_TABLE",1);

//Actor Type
define("ACTOR_USER",1);
define("ACTOR_KNOW_USER",1);
define("ACTOR_GUEST",2);
define("ACTOR_VISITOR",2);
define("ACTOR_COMMON_USER",2);
define("ACTOR_ADMINISTRATOR",3);
define("ACTOR_AMMINISTRATORE",3);
define("ACTOR_SPIDER",4); //Motor Search Spider
define("ACTOR_SEARCHER",4);

//Actor action
define("DOWNLOAD",1); //Download something
define("UPLOAD",2); //Upload something
define("MODIFY",3); //Modify something
define("AUTHENTICATION",4); //Auth to web
define("VIEW",5); //View Web Page

//Data Field
define("SCRIPT",1); //Script name
define("LINE",2); //Line of script to log
define("MESSAGE",3); //Message to pass to the log (maybe ERROR MESSAGE,DEBUG MESSAGE)

//Data Implicit Field
define("PID",4); //Process ID
define("TIME",5); //Time
define("DATE",6); //Date
define("TIMESTAMP",7); //Date and Time
define("IP_ADDRESS",8); //IP ADDRESS of remote host
define("BROWSER_TYPE",9);//Browser type
define("ACTOR_ACTION_TYPE",10); //Action of Actor
define("ACTOR_TYPE",11); //Type of Actor to log
define("ACTOR",12); //Actor Implicit to log
define("SELF",13); //The self script
define("SESSION_COUNT",14); //Sessioni counter

//Settings of file mem
define("PATH",15);
define("NAME",16);
define("TYPE",17);
define("YEAR",18);
define("MONTH",19);
define("EXTENSION",20);
define("PATH_TYPE",21);

//Standard DateTime
define ("DEFAULT_DATE_FORMAT","Y-m-d/H:i:s");

//require_once("c:/Programmi/Apache/phenomenon/classes/fileSystem.class.php");

class abstract_log{
	var $log_type; //List of log type (ERROR, ACCESS, DEBUG, SYSTEM, EXEC)
 	
	var $log_name_field_list; //List of all elements can be mem in log file

	var $log_name_tag_field_list; //List Tag of all elemts can be mem in log file
 	
	var $log_id_field_list; //ID list of all element can be mem in log file
 	
	var $log_implicit_fields; /*Implicit element passed at costructor method
	(Valid element: PID TIME DATE TIMESTAMP IPADDRESS BROWSER_TYPE ACTOR ACTOR_TYPE ACTOR_ACTION_TYPE SELF SESSION_COUNT). All this element must be pass to costructor method whit a string type*/

 	var $log_timestamp_format; //Timestamp format (default Y-m-d/H:i:s)
	
	var $log_path_type_list; //Settings list of path log mode

	var $passed_args_list; //Default list passed at virtual method log
	
	//Constructor
	function abstract_log($log_implicit_fields, $log_timestamp_format){
		//Formatting array
		$this->formatting = array("newline" => "\n", "tab" => "\t", "space" => "\s", "return" => "\r");
										  
		//List of log type 
		$this->log_type = array(SYSTEM => "SYSTEM", ERROR => "ERROR", DEBUG => "DEBUG", EXEC => "EXEC", ACCESS => "ACCESS");
		
		//ID list of all element can be mem in log file
		$this->log_id_field_list = array("SCRIPT" => 1, "LINE" => 2, "MESSAGE" => 3, "PID" => 4, "TIME" => 5, "DATE" => 6, "TIMESTAMP" => 7,
										 "IP_ADDRESS" => 8, "BROWSER_TYPE" => 9, "ACTOR_ACTION_TYPE" => 10, "ACTOR_TYPE" =>11, "ACTOR" => 12, "SELF" =>13, "SESSION_COUNT" => 14, "TYPE" => 17);
										 
		//List of all elements can be mem in log file							 
		$this->log_name_tag_field_list = array(SCRIPT => "SCRIPTNAME", LINE => "SCRIPTLINE", MESSAGE => "CODEMESSAGE", PID => "PROCESSID", TIME => "TIME", DATE => "DATA", TIMESTAMP => "TIMESTAMP",
             							   IP_ADDRESS => "IPADDRESS", BROWSER_TYPE => "BROWSERTYPE", ACTOR_ACTION_TYPE => "USERACTIONTYPE", ACTOR_TYPE => "USERTYPE", ACTOR => "USER", SELF => "HTTPSELFVALUE" ,SESSION_COUNT => "SESSIONCOUNT", TYPE => "TYPELOG");

		$this->log_name_field_list = array(SCRIPT => "Script Name", LINE => "Script Line", MESSAGE => "Code Message", PID => "Process ID", TIME => "Time", DATE => "Date", TIMESTAMP => "Timestamp",
             							   IP_ADDRESS => "IP Address", BROWSER_TYPE => "Browser Type", ACTOR_ACTION_TYPE => "USERACTIONTYPE", ACTOR_TYPE => "User Type", ACTOR => "User", SELF => "Http Self Value" ,SESSION_COUNT => "Session Count", TYPE => "Log Type");
		
		//Default list passed at virtual method log
		$this->passed_args_list = array( 0 => TYPE, 1 => LINE, 2 => MESSAGE );
		
		//Explode of implicit element passed at costructor method
		$this->log_implicit_fields = explode(" ",$log_implicit_fields);					
		
		//Timestamp format
		$this->dateFormat = $log_timestamp_format;
		
	}
	
	//Private method who return implicit field to mem in log repositary
	function get_field($field){
	
		switch ($field)
		{
			case TIME:return date($this->dateFormat,time());break;
			case DATE:return date($this->dateFormat,time());break;
			case TIMESTAMP:return date($this->dateFormat,time());break;
			case BROWSER_TYPE:return $_SERVER["HTTP_USER_AGENT"] = str_replace(";",",",$_SERVER["HTTP_USER_AGENT"]);break; //Replace ";" with "," to create CSV log file
			case IP_ADDRESS:return $_SERVER["REMOTE_ADDR"].":".$_SERVER["REMOTE_PORT"];break;
			case PID:return "PID";break;
			case ACTOR_ACTION_TYPE:return $_SERVER["REQUEST_URI"];break;
			case ACTOR_TYPE:return $this->get_actor_type();break;
			case ACTOR:return $this->get_actor();break; //To developpe with AUTH MODULE
			case SELF:return $_SERVER["PHP_SELF"];break;
			case SESSION_COUNT:return $_SESSION["session_count"];break;
			default:return "";break;
		}
	}
	
	//Private method who return actor logged 
	function get_actor(){ return "not yet implemented"; }
	
	//Private method who return actor type logged
	function get_actor_type(){ return "not yet implemented"; }
	
	//Virtual public method
	function log(){}
}

//Class to make log on file
class log_on extends abstract_log{
	
	var $log_path;//Path to log file
	
	function log_on(&$log_parameters, $log_implicit_fields, $log_timestamp_format)
	{
		if($log_parameters["repository"] == DB)
		{
			$this->log_on_db($log_parameters, $log_implicit_fields, $log_timestamp_format);
		}
		else
		{
			$this->log_on_file($log_parameters, $log_implicit_fields, $log_timestamp_format);
		}
	}
	
	//Constructor
	function log_on_file(&$log_path_set, $log_implicit_fields, $log_timestamp_format){
		//Parent constructor
		parent::abstract_log($log_implicit_fields, $log_timestamp_format);

		//Settings list of path log mode
		$this->log_path_type_list = array(PATH => $log_path_set["log_path"],
	  									  NAME => $log_path_set["log_name_file"],
	  									  TYPE => 0, //set this later;
	  									  DATE => date("Y-m-d", time()),
	  									  YEAR => date("Y",time()),
	  									  MONTH => date("n",time()),
										  EXTENSION => 0 /*set this later*/);
	}
	
	function log_on_db(&$log_path_set, $log_implicit_fields, $log_timestamp_format)
	{
		
	}
	
	//Public method to make right path
	function get_path(){
		
		$this->log_path = str_replace("PATH",$this->log_path_type_list[PATH],$this->log_path);
		$this->log_path = str_replace("YEAR",$this->log_path_type_list[YEAR],$this->log_path);
		$this->log_path = str_replace("MONTH",$this->log_path_type_list[MONTH],$this->log_path);
		$this->log_path = str_replace("NAME",$this->log_path_type_list[NAME],$this->log_path);
		$this->log_path = str_replace("DATE",$this->log_path_type_list[DATE],$this->log_path);
		$this->log_path = str_replace("EXTENSION",$this->log_path_type_list[EXTENSION],$this->log_path);
		$this->log_path = str_replace("TYPE",$this->log_path_type_list[TYPE],$this->log_path);
	}
	
	//Public method to create directory for right path
	function exist_dir(){

		$dir = explode("/",$this->log_path);
		$verify = true;
		
		for($i = 0; $i < count($dir)-1; $i++){
			$directory .= $dir[$i]."/";
			if(!is_dir($directory)){
				mkdir($directory, 777);
				$verify = false;
			}
		}

		$directory .= $dir[$i];
		if(!is_file($directory))$verify = false;
		
		return $verify;
	}
}

class multi_log
{
	function multi_log($parameters)
	{
	}
	
	function get_mode()
	{
		
	}
}
?>