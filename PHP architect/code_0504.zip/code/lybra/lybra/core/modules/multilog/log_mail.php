<?php
require_once("classes/logMail.class.php");

$mail_param = array(HTML => ON, BCC => "ciccio1979@email.it", X_MAILER => ON, FROM => "trucchia@csr.unibo.it", RECEIVER => "trucchia@csr.unibo.it", OBJECT => "TYPE log - TIMESTAMP");

//$log_implicit_fields = "TIMESTAMP BROWSER_TYPE IP_ADDRESS SELF";
$log_implicit_fields = "TIMESTAMP BROWSER_TYPE SELF";

$logMail = new log_mail($mail_param, $log_implicit_fields);

$logMail->log(ACCESS);

?>