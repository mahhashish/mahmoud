<?
require_once("log.class.php");

class log_csv extends log_on{
	
	
	//Constructor
	function log_csv(&$log_parameters, $log_implicit_fields, $log_timestamp_format = DEFAULT_DATE_FORMAT){
		parent::log_on($log_path_set, $log_implicit_fields, $log_timestamp_format);
		//Set log file extension
		$this->log_path_type_list[EXTENSION] = $log_parameters["log_extension"];
		//Set log path type
		$this->log_path_type = $log_parameters["log_type_path"];
		$this->log_path = $this->log_path_type;
	}
	
	
	
	//Param TYPE_LOG, ESPLICIT FIELD
	//Public method to make log string to mem in log file
	function log(){
		//Elements passed at method
		$args_value = func_get_args();
		//Set the log type
		$this->log_path_type_list[TYPE] = $this->log_type[$args_value[0]];
		//Get the right path where mem log file
		$this->get_path();
		
		if(!$this->exist_dir()){
			$i = 0;
			while(isset($args_value[$i])){
				$str .= $this->log_name_tag_field_list[$this->passed_args_list[$i]].";";
				$i++;
			}
			$i = 0;
			while(isset($this->log_implicit_fields[$i])){
				$str .= $this->log_name_tag_field_list[$this->log_id_field_list[$this->log_implicit_fields[$i]]].";";
				$i++;
			}
			$str .= $this->formatting["newline"];
		}
		$i = 0;
		while(isset($args_value[$i])){
			if($i == 0)
				$str .= "(".$this->log_type[$args_value[$i]].")".";";
			else
				$str .= $args_value[$i].";";
			$i++;
		}
		$i = 0;
		while(isset($this->log_implicit_fields[$i])){
			$str .= $this->get_field($this->log_id_field_list[$this->log_implicit_fields[$i]]).";";
			$i++;
		}
		$str .= $this->formatting["newline"];
		//FyleSystem object from phenomenon
		new execFileSystem($this->log_path,"a+",0,$str);
		//Reset log path
		$this->log_path = $this->log_path_type;
		
	}
}

?>