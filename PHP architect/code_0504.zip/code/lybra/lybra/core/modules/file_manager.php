<?
 /**********************************************************************************************
 		Lybra: A general purpose framework for fast web development
		Copyright (C) 2002-2004 Simone Grassi, Andrea Giorgini

	    file_manager.php
	    ----------------
		begin:  	12/2003 Simone Grassi (Ci S.B.i.C. snc)
		copyright:	(C) 2003, Simone Grassi,  Andrea Giorgini
					viale Marconi 438, 47023 Cesena (FC), Italy.
		email:		lybra@cisbic.com

	    This program is free software; you can redistribute it and/or modify
	    it under the terms of the GNU General Public License as published by
	    the Free Software Foundation; either version 2 of the License, or
	    (at your option) any later version.

	    This program is distributed in the hope that it will be useful,
	    but WITHOUT ANY WARRANTY; without even the implied warranty of
	    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	    GNU General Public License for more details.

	    You should have received a copy of the GNU General Public License
	    along with this program; if not, write to the Free Software
	    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************************************/

	// Errors and return values 7xx reserved to file_manager module
	define("LYBRA_FILE_ID_NOT_INT","-701");
	define("LYBRA_FILES_FOUND_MORE_IDS","-703");
	define("LYBRA_FILE_ID_NOT_FOUND","702");

	// Define relative to tables
	// to use the same library for different project with different table and/or field names,
	// comment below defines and import them into all project scripts

	define("LYBRA_FILES_TABLE","lybra_files");
	define("LYBRA_FILES_FILE_ID_FIELD","file_id");
	define("LYBRA_FILES_DOCUMENT_ID_FIELD","document_id");
	define("LYBRA_FILES_FILENAME_FIELD","filename");
	define("LYBRA_FILES_PATH_FIELD","path");
	define("LYBRA_FILES_DESCRIPTION_FIELD","description");

	class file_manager extends Lybra_DB_DataObject 
	{
			var $__table = LYBRA_FILES_TABLE;
			
			function file_manager($field="",$value="")
			{
				$this->common_init($field,$value);
			}

			function factory($field,$value)
			{
				$this->objects = Lybra_DB_DataObject::Lybra_DB_DataObject($field,$value);	
			}

			/* Static get */
			function staticGet($k,$v=NULL) { return DB_DataObject::staticGet('file_manager',$k,$v); }
			
			function table()
			{
		        return array(
		            LYBRA_FILES_FILE_ID_FIELD		=> DB_DATAOBJECT_INT,
		            LYBRA_FILES_DOCUMENT_ID_FIELD	=> DB_DATAOBJECT_INT,
		            LYBRA_FILES_FILENAME_FIELD		=> DB_DATAOBJECT_STR,
		            LYBRA_FILES_PATH_FIELD			=> DB_DATAOBJECT_STR,
		            LYBRA_FILES_DESCRIPTION_FIELD	=> DB_DATAOBJECT_STR
		        );
			}
			
			// Override default key
			function keys() 
	    	{
	        	return array(LYBRA_FILES_FILE_ID_FIELD);
	    	}
	}
?>