<?
 /**********************************************************************************************
 		Lybra: A general purpose framework for fast web development
		Copyright (C) 2002-2004 Simone Grassi, Andrea Giorgini

	    workflow.php
	    ------------
		begin:  	12/2003 Simone Grassi (Ci S.B.i.C. snc)
		copyright:	(C) 2003, Simone Grassi,  Andrea Giorgini
					viale Marconi 438, 47023 Cesena (FC), Italy.
		email:		lybra@cisbic.com

	    This program is free software; you can redistribute it and/or modify
	    it under the terms of the GNU General Public License as published by
	    the Free Software Foundation; either version 2 of the License, or
	    (at your option) any later version.

	    This program is distributed in the hope that it will be useful,
	    but WITHOUT ANY WARRANTY; without even the implied warranty of
	    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	    GNU General Public License for more details.

	    You should have received a copy of the GNU General Public License
	    along with this program; if not, write to the Free Software
	    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************************************/
	require_once("lybra/core/modules/file_manager.php");

	define("LYBRA_WORKFLOW_TABLE","lybra_workflow");
	define("LYBRA_WORKFLOW_ISTANCE_ID_FIELD"."lybra_workflow_istance_id");
	define("LYBRA_WORKFLOW_STATIC_ID_FIELD"."lybra_workflow_static_id");
	define("LYBRA_WORKFLOW_DESCRIPTION","lybra_workflow_description");

	class workflow_manager
	{
		function workflow_manager()
		{
			
		}

		function get_workflow_by_id($workflow_id)
		{
			if (!is_int($file_id))
				return LYBRA_FILE_ID_NOT_INT;
			$select = "SELECT ".LYBRA_FILES_FILE_ID_FIELD.",".
								LYBRA_FILES_FILENAME_FIELD.",".
								LYBRA_FILES_DESCRIPTION_FIELD.
								" FROM ".LYBRA_FILES_TABLE." WHERE ".LYBRA_FILES_FILE_ID_FIELD."='$file_id'";
			$this->retrieve($select);
			print_("GET FILE BY ID '$select'","FILE_MANAGER");
			if (!$this->empty_result)
			{
			}
		}
	}
?>