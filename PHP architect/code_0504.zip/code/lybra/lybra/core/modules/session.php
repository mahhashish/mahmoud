<?
 /**********************************************************************************************
 		Lybra: A general purpose framework for fast web development
		Copyright (C) 2002-2004 Simone Grassi, Andrea Giorgini

	    session.php
	    -----------
		begin:  	10/2002 Simone Grassi (Ci S.B.i.C. snc)
		copyright:	(C) 2002, Simone Grassi,  Andrea Giorgini
					viale Marconi 438, 47023 Cesena (FC), Italy.
		email:		lybra@cisbic.com

	    This program is free software; you can redistribute it and/or modify
	    it under the terms of the GNU General Public License as published by
	    the Free Software Foundation; either version 2 of the License, or
	    (at your option) any later version.

	    This program is distributed in the hope that it will be useful,
	    but WITHOUT ANY WARRANTY; without even the implied warranty of
	    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	    GNU General Public License for more details.

	    You should have received a copy of the GNU General Public License
	    along with this program; if not, write to the Free Software
	    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************************************/

    define("LYBRA_SESSION_VARIABLE_NOT_PRESENT",-1);
    define("LYBRA_SESSION_ID_ENTRY","sessionID");
    
    /**
     * General session management
     **/
    class session
    {    
		// Session ID
		var $id;
		// Associate object to SESSION hash
		// session_start executed at script level
		/**
		 * Costructor, simply save session ID inside istance variable
		 *
		 * retval none
		 **/
		function session()
		{
		    $this->id = (isset($_SESSION[LYBRA_SESSION_ID_ENTRY])?$_SESSION[LYBRA_SESSION_ID_ENTRY]:"");
		}
		
		/**
		 * register alias
		 **/
		function put($var_name,$var_value)
		{
		    $_SESSION[$varName] = $var_value;
		}
		
		/**
		 * Register variable with name $var_name with value $var_value
		 *
		 * param $var_name name of the variable to register into session
		 * param $var_value value of the variable to register into session
		 *
		 * retval none
		 **/
		function register($var_name,$var_value)
		{
		    $_SESSION[$var_name]=$var_value;
		}
		
		/**
		 * Retrieve a variable value from the session
		 *
		 * param $var_name name of the variable to retrieve from session
		 *
		 * retval value of the retrieved variable
		 **/
		function session_get($var_name)
		{
		    return $_SESSION[$var_name];
		}
		
		/**
		 * session_get alias
		 **/
		function get($var_name)
		{
		    return (isset($_SESSION[$var_name])?$_SESSION[$var_name]:"");
		}
		
		/**
		 * Return the id of the current session
		 **/
		function session_id()
		{
		    return $this->id;
		}
			
		/**
		 * Unregister a variable from session
		 *
		 * param $var_name name of the variable to unregister from session
		 *
		 * retval return value of the unregistered variable
		 **/
		function remove($var_name)
		{
		    $ret = $this->session_get($var_name);
		    unset($_SESSION[$var_name]);
		    return $ret;
		}
	
		/**
		 * Test if $var_name is set into session variables
		 *
		 * param $var_name name of the variable
		 *
		 * retval true if var_name is registered, false otherwise
		 **/	
		function is_set($var_name)
		{
		    if (isset($_SESSION[$var_name]))
			return true;
		    return false;
		}
		
		function session_update($var_name,$new_value)
		{
		    $_SESSION[$var_name] = $new_value;
		}
    }
?>