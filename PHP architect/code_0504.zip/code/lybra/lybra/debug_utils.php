<?
	function print_($arg,$title="",$color="blue")
	{
		 if (DEBUG_ON)
			print "<br><b><font color=red>[</font>LYBRA_DEBUG</b>:".($title!=""?"<b><font color=$color>(".htmlentities($title).")</font></b>":"")."(".htmlentities($arg).")<font color=red><b>]</b></font><br>";
	}
	
	function get_language($varname)
	{
		return $_SESSION[$varname];
	}
?>