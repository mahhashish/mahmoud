<?php
require_once("db_functions/sql_query.inc");
require_once('phpOpenTracker.php');

class AccessAnalyzer {

  var $startYear;
  var $startMonth;
  var $startDay;
  var $endYear;
  var $endMonth;
  var $endDay;
  var $dataType;
  var $pageType;

  function AccessAnalyzer() {
    $this->pageType = isset($_GET['pageType']) ? $_GET['pageType'] : 'TOP';
    $this->dataType = isset($_GET['dataType']) ? $_GET['dataType'] : 'ALL';
    $this->setStartTime();
    $this->setEndTime();
  }
  function setStartTime() {
    $this->startYear  = isset($_GET['startYear'])  ? $_GET['startYear']  : 0 
;
    $this->startMonth = isset($_GET['startMonth']) ? $_GET['startMonth'] : 
0;
    $this->startDay   = isset($_GET['startDay'])   ? $_GET['startDay']   : 
0;
  }
  function setEndTime() {
    $this->endYear  = isset($_GET['endYear'])  ? $_GET['endYear']  : 0 ;
    $this->endMonth = isset($_GET['endMonth']) ? $_GET['endMonth'] : 0;
    $this->endDay   = isset($_GET['endDay'])   ? $_GET['endDay']   : 0;
  }
  function parseTemplate() {
    $mainTpl = file_get_contents('./accessAnalyzer.html');
    $mainTpl = $this->_addCriteriaSelectors($mainTpl);
    $mainTpl = $this->_addCriteriaSelectors($mainTpl);
    $mainTpl = $this->_addResults($mainTpl);
    return $mainTpl;
  }
  function getEndDateString() {
    return $this->endYear . "/" . $this->endMonth . "/" . $this->endDay;
  }
  function getStartDateString() {
    return $this->startYear . "/" . $this->startMonth . "/" . 
$this->startDay;
  }
  function _addResults($tpl) {
    switch ($this->dataType) {
      case 'ALL' :
        $results = $this->getAllResults();
        break;
      case 'DATE' :
        $results = $this->getDailyResults();
        break;
      case 'TIME' :
        $results = $this->getTimeResults();
        break;
      case 'REFERERS' :
        $results = $this->getReferersResults();
        break;
      case 'KEYWORDS' :
        $results = $this->getSearchKeywordsResults();
        break;
      case 'PAGE_VIEW' :
        $results = $this->getPageViewResults();
        break;
      case 'SEARCH_ENGINES' :
        $results = $this->getSearchEngineResults();
        break;
      case 'HOSTS' :
        $results = $this->getHostResults();
        break;
      case 'OS' :
        $results = $this->getOsResults();
        break;
      case 'BROWSERS' :
        $results = $this->getBrowsersResults();
        break;
      case 'EXIT_PAGE' :
        $results = $this->getExitPageResults();
        break;
      case 'EXIT_TARGET' :
        $results = $this->getExitTargetResults();
        break;
      case 'CLICKPATH' :
        /*
         in this case we will be printing an image to the screen
         so we cannot output anything else. So after making the
         graph object and printing it out we exit
        */
        $graph = $this->getClickPathResults();
        $graph->image('png');
        exit;
        break;
      default:
        $results = "";
    }

    /*
     If page type is TOP this means that we should display the main menu
     and no results
    */

    if ($this->pageType == 'TOP') {
      $helloMessage1 = file_get_contents('./welcomeMessage1.html');
      $tpl = str_replace("<!--RESULTS-->", $helloMessage1, $tpl);
      return $tpl;
    }

    $startDate = $this->getStartDateString();
    $endDate   = $this->getEndDateString();
    $criteria = $startDate . " -> " . $endDate;

    $tpl = str_replace("<!--SEARCH_CRITERIA_MESSAGE-->", $criteria, $tpl);

    $tpl = str_replace("<!--RESULTS-->", $results, $tpl);
    return $tpl;
  }
  function getClickPathResults() {
    $start  = $this->makeStartTime();
    $end    = $this->makeEndTime();

    return
      phpOpenTracker::get(
       array(
        'api_call'      => 'all_paths',
        'result_format' => 'graphviz_object'
       )
      );
  }
  function getAllResults() {
    $results  = $this->getDailyResults();
    $results .= $this->getTimeResults();
    $results .= $this->getReferersResults();
    $results .= $this->getSearchKeywordsResults();
    $results .= $this->getPageViewResults();
    $results .= $this->getSearchEngineResults();
    $results .= $this->getHostResults();
    $results .= $this->getOsResults();
    $results .= $this->getBrowserResults();
    $results .= $this->getExitPageResults();
    $results .= $this->getExitTargetResults();
    return $results;
  }
  function makeStartTime() {
    return mktime(0,0,0, $this->startMonth, $this->startDay, 
$this->startYear);
  }
  function makeEndTime() {
    return mktime(23,59,59, $this->endMonth, $this->endDay, $this->endYear);
  }
  function getExitTargetResults() {
    $tableTpl = file_get_contents('./exitTargetTable.html');
    $rowTpl   = file_get_contents('./exitTargetRow.html');

    $aI = $this->getTop("", "", 'exit_target', 10);
    $aI = $this->generalParse($rowTpl, $aI);

    $results = $aI['rowTpl'];
    $total   = $aI['total'];

    $tableTpl = str_replace('<!--ROW-->',   $results, $tableTpl);
    $tableTpl = str_replace('<!--TOTAL-->', $total,   $tableTpl);
    return $tableTpl;
  }
  function getExitPageResults() {
    $tableTpl = file_get_contents('./exitPageTable.html');
    $rowTpl   = file_get_contents('./exitPageRow.html');

    $aI = $this->getTop("", "", 'exit_document', 10);
    $aI = $this->generalParse($rowTpl, $aI);

    $results = $aI['rowTpl'];
    $total   = $aI['total'];

    $tableTpl = str_replace('<!--ROW-->',   $results, $tableTpl);
    $tableTpl = str_replace('<!--TOTAL-->', $total,   $tableTpl);
    return $tableTpl;
  }
  function getSearchEngineResults() {
    $tableTpl = file_get_contents('./searchEngineTable.html');
    $rowTpl   = file_get_contents('./searchEngineRow.html');

    $aI = $this->getSearchEngineTop("", "", 'top_search_engines', 10);
    $aI = $this->generalParse($rowTpl, $aI);

    $results = $aI['rowTpl'];
    $total   = $aI['total'];

    $tableTpl = str_replace('<!--ROW-->',   $results, $tableTpl);
    $tableTpl = str_replace('<!--TOTAL-->', $total,   $tableTpl);
    return $tableTpl;
  }
  function getBrowserResults() {
    $tableTpl = file_get_contents('./browserTable.html');
    $rowTpl   = file_get_contents('./browserRow.html');

    $aI = $this->getTop("", "", 'user_agent', 10);
    $aI = $this->generalParse($rowTpl, $aI);

    $results = $aI['rowTpl'];
    $total   = $aI['total'];

    $tableTpl = str_replace('<!--ROW-->',   $results, $tableTpl);
    $tableTpl = str_replace('<!--TOTAL-->', $total,   $tableTpl);
    return $tableTpl;
  }
  function getOsResults() {
    $tableTpl = file_get_contents('./osTable.html');
    $rowTpl   = file_get_contents('./osRow.html');

    $aI = $this->getTop("", "", 'operating_system', 10);
    $aI = $this->generalParse($rowTpl, $aI);

    $results = $aI['rowTpl'];
    $total   = $aI['total'];

    $tableTpl = str_replace('<!--ROW-->',   $results, $tableTpl);
    $tableTpl = str_replace('<!--TOTAL-->', $total,   $tableTpl);
    return $tableTpl;
  }
  function getHostResults() {
    $tableTpl = file_get_contents('./hostTable.html');
    $rowTpl   = file_get_contents('./hostRow.html');

    $aI = $this->getTop("", "", 'host', 10);
    $aI = $this->generalParse($rowTpl, $aI);

    $results = $aI['rowTpl'];
    $total   = $aI['total'];

    $tableTpl = str_replace('<!--ROW-->',   $results, $tableTpl);
    $tableTpl = str_replace('<!--TOTAL-->', $total,   $tableTpl);
    return $tableTpl;
  }
  function getPageViewResults() {
    $tableTpl = file_get_contents('./pageViewTable.html');
    $rowTpl   = file_get_contents('./pageViewRow.html');

    $aI = $this->getTop("", "", 'document', 10);
    $aI = $this->generalParse($rowTpl, $aI);

    $results = $aI['rowTpl'];
    $total   = $aI['total'];

    $tableTpl = str_replace('<!--ROW-->',   $results, $tableTpl);
    $tableTpl = str_replace('<!--TOTAL-->', $total,   $tableTpl);
    return $tableTpl;
  }
  function getSearchKeywordsResults() {
    $tableTpl = file_get_contents('./searchKeywordsTable.html');
    $rowTpl   = file_get_contents('./searchKeywordsRow.html');

    $aI = $this->getSearchEngineTop("", "", 'top_search_keywords', 10);
    $aI = $this->generalParse($rowTpl, $aI);

    $results = $aI['rowTpl'];
    $total   = $aI['total'];

    $tableTpl = str_replace('<!--ROW-->',   $results, $tableTpl);
    $tableTpl = str_replace('<!--TOTAL-->', $total,   $tableTpl);
    return $tableTpl;
  }
  function generalParse($rowTpl, $aI) {
    $results = "";
    $total   = 0;
    foreach($aI['top_items'] as $aData) {
      $tmp     = $rowTpl;
      $count   = $aData['count'];
      $percent = $aData['percent'];
      $string  = $aData['string'];
      $total  += $count;
      $tmp = str_replace('<!--STRING-->',            $string,  $tmp);
      $tmp = str_replace('<!--PERCENTAGE-->',        $percent, $tmp);
      $tmp = str_replace('<!--COUNT-->',             $count,   $tmp);
      $tmp = str_replace('<!--BAR_GRAPH_PERCENT-->', round($percent, 0),  
$tmp);
      $results .= $tmp;
    }
    return array('rowTpl' => $results,
                 'total'  => $total);
  }
  function getSearchEngineTop($start, $end, $what, $limit) {

    if ($start == "") $start  = $this->makeStartTime();
    if ($end   == "") $end    = $this->makeEndTime();

    return
     phpOpenTracker::get(
      array(
        'api_call' => 'search_engines',
        'start'    => $start,
        'end'      => $end,
        'what'     => $what,
        'limit'    => $limit
      )
     );
  }
  function getReferersResults() {
    $tableTpl = file_get_contents('./referersTable.html');
    $rowTpl   = file_get_contents('./referersRow.html');
    $results = "";

    $aI = $this->getTop("", "", 'referer', 10);
    $aI = $this->generalParse($rowTpl, $aI);

    $results = $aI['rowTpl'];
    $total   = $aI['total'];

    $tableTpl = str_replace('<!--ROW-->',   $results, $tableTpl);
    $tableTpl = str_replace('<!--TOTAL-->', $total,   $tableTpl);
    return $tableTpl;
  }
  function getTop($start, $end, $what, $limit) {

    if ($start == "") $start  = $this->makeStartTime();
    if ($end   == "") $end    = $this->makeEndTime();

    return
     phpOpenTracker::get(
      array(
        'api_call' => 'top',
        'start'    => $start,
        'end'      => $end,
        'what'     => $what,
        'limit'    => $limit
      )
     );
  }
  function getTimeResults() {
    $tableTpl = file_get_contents('./timeTable.html');
    $rowTpl   = file_get_contents('./timeRow.html');
    $results = "";

    $start  = $this->makeStartTime();
    $end    = $this->makeEndTime();

    $totalImpressions = $this->getPageImpressions($start, $end);
    $totalVisitors    = $this->getVisitors($start, $end);

    $aImpressions = $this->getHourlyImpressions($start, $end);
    $aVisitors    = $this->getHourlyVisitors($start, $end);

    for ($hour = 0; $hour < 24; $hour++) {
      $tmp = $rowTpl;
      $impressionPercent = ($totalImpressions == 0) ? 0 : 
$aImpressions[$hour] / $totalImpressions * 100;
      $visitorPercent    = ($totalVisitors == 0)    ? 0 : $aVisitors[$hour] 
/ $totalVisitors * 100;
      $pages    = $aImpressions[$hour];
      $visitors = $aVisitors[$hour];
      $tmp = str_replace('<!--START_HOUR-->', $hour,      $tmp);
      $tmp = str_replace('<!--END_HOUR-->',   $hour + 1,  $tmp);
      $tmp = str_replace('<!--PAGES-->',      $pages,     $tmp);
      $tmp = str_replace('<!--VISITORS-->',   $visitors,  $tmp);
      $tmp = str_replace('<!--PAGE_PERCENTAGE-->',           
round($impressionPercent, 2), $tmp);
      $tmp = str_replace('<!--VISITOR_PERCENTAGE-->',        
round($visitorPercent, 2),    $tmp);
      $tmp = str_replace('<!--PAGE_GRAPH_BAR_PERCENT-->',    
$impressionPercent, $tmp);
      $tmp = str_replace('<!--VISITOR_GRAPH_BAR_PERCENT-->', $visitorPercent 
   , $tmp);
      $results .= $tmp;
    }

    $tableTpl = str_replace('<!--ROW-->',           $results,          
$tableTpl);
    $tableTpl = str_replace('<!--PAGE_TOTAL-->',    $totalImpressions, 
$tableTpl);
    $tableTpl = str_replace('<!--VISITOR_TOTAL-->', $totalVisitors,    
$tableTpl);
    return $tableTpl;
  }
  function getDailyResults() {
    $tableTpl = file_get_contents('./dailyTable.html');
    $rowTpl   = file_get_contents('./dailyRow.html');
    $results = "";

    $offset = 1;
    $start  = $this->makeStartTime();
    $end    = $this->makeEndTime();

    $totalImpressions = $this->getPageImpressions($start, $end);
    $totalVisitors    = $this->getVisitors($start, $end);

    while ($start <= $end) {
      $tmp = $rowTpl;
      $timeStr = strftime('%Y/%m/%d', $start);
      $nextDay = mktime(0,0,0, $this->startMonth, $this->startDay + $offset, 
$this->startYear);
      $impressions = $this->getPageImpressions($start, $nextDay);
      $visitors =    $this->getVisitors($start, $nextDay);
      $tmp = str_replace('<!--DATE-->',     $timeStr,     $tmp);
      $tmp = str_replace('<!--PAGES-->',    $impressions, $tmp);
      $tmp = str_replace('<!--VISITORS-->', $visitors,    $tmp);
      $results .= $tmp;
      $start = $nextDay;
      $offset++;
    }

    $tableTpl = str_replace('<!--ROW-->', $results, $tableTpl);
    $tableTpl = str_replace('<!--PAGE_TOTAL-->',    $totalImpressions, 
$tableTpl);
    $tableTpl = str_replace('<!--VISITOR_TOTAL-->', $totalVisitors,    
$tableTpl);
    return $tableTpl;
  }
  function getHourlyVisitors($start, $end, $document = "") {
    /* interval is in seconds */
    $apiParams =
      array(
        'api_call' => 'visitors',
        'start'    => $start,
        'end'      => $end,
        'interval' => 3600
      );

    if ($document != "") {
      $constraint = array('document' => $document);
      $apiParams['constraints'] = $constraint;
    }

    $aI = phpOpenTracker::get($apiParams);

    /*
     initialize the array to 0. Needed since I have error
     reporting set to E_ALL :)
    */

    for ($i = 0; $i < 24; $i++) {
      $aR[$i] = 0;
    }

    /* go through in blocks of 24 and pick up the hourly counts */

    $hour = 0;

    foreach ($aI as $aD) {
      $count = $aD['value'];
      $aR[$hour % 24] += $count;
      $hour++;
    }

    return $aR;
  }
  function getHourlyImpressions($start, $end, $document = "") {
    /* interval is in seconds */
    $apiParams =
      array(
        'api_call' => 'page_impressions',
        'start'    => $start,
        'end'      => $end,
        'interval' => 3600
      );

    if ($document != "") {
      $constraint = array('document' => $document);
      $apiParams['constraints'] = $constraint;
    }

    $aI = phpOpenTracker::get($apiParams);

    /*
     initialize the array to 0. Needed since I have error
     reporting set to E_ALL :)
    */

    for ($i = 0; $i < 24; $i++) {
      $aR[$i] = 0;
    }

    /* go through in blocks of 24 and pick up the hourly counts */

    $hour = 0;

    foreach ($aI as $aD) {
      $count = $aD['value'];
      $aR[$hour % 24] += $count;
      $hour++;
    }

    return $aR;
  }
  function getVisitors($start, $end, $document = "") {
    /*
     If a document name is passed in then only visitors
     to that document will be calculated, else the total
     number of visitors for the time period start to end
     is returned
    */
    $apiParams =
      array(
        'api_call' => 'visitors',
        'start'    => $start,
        'end'      => $end
      );

    if ($document != "") {
      $constraint = array('document' => $document);
      $apiParams['constraints'] = $constraint;
    }

    return phpOpenTracker::get($apiParams);
  }
  function getPageImpressions($start, $end, $document = "") {
    /*
     If a document name is passed in then only page impressions
     for that document will be calculated, else the total number
     of impressions for the time period start to end is returned
    */
    $apiParams =
      array(
        'api_call' => 'page_impressions',
        'start'    => $start,
        'end'      => $end
      );

    if ($document != "") {
      $constraint = array('document' => $document);
      $apiParams['constraints'] = $constraint;
    }

    return phpOpenTracker::get($apiParams);
  }
  function _addCriteriaSelectors($tpl) {
    $criteriaTpl = file_get_contents('./searchCriteria.html');
    $tpl = str_replace("<!--SEARCH_CRITERIA_SELECTORS-->", $criteriaTpl, 
$tpl);
    return $tpl;
  }
}
?>

