<?php
get_formdata('POST',array('txt1','txt2');
echo "Box One: $txt1, Box Two: $txt2";
?>
