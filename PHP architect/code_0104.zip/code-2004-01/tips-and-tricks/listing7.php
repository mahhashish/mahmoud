<?

function get_formdata($type,$vars)
{

  $return_vals=array();

  #setup common reference to SuperGlobals depending which array is needed
  if ($type=="GET") { $SG_Array=& $_GET; }
  if ($type=="POST") { $SG_Array=& $_POST; }

  # loop through SuperGlobal data array and grab out data for allowed fields if found
  foreach($SG_Array as $key=>$value)
  {
    if (in_array($key,$vars)) { $data[$key]=$value; }
  }

  # loop through $vars array and declare blank references for all fields that were not found
  foreach($vars as $value)
  {
    if (!isset($data[$value])) { $data[$value]=""; }
  }

  # loop through final data and define all the variables using the $GLOBALS array
  foreach ($data as $key=>$value)
  {
    $GLOBALS[$key]=$value;
  }
 }
?>