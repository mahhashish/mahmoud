
for(i=0;i<document.myform.rad.length;i++)
{
    if(document.myform.rad[i].value == '1')
    {
        document.myform.rad[i].checked = true;
    }
}

for(i=0;i<document.myform.sel.length;i++)
{
    if(document.myform.sel[i].value == 'a')
    {
        document.myform.sel[i].selected = true;
    }
}

