<?php

error_reporting(E_ALL ^ E_NOTICE);

function validate($data)
{
    //perform validation routine here...
    return $data;
}

function Fill_Form($formname,$type,$data)
{
    $retval = '';

    switch($type)
    {
        case 'text':
            $attrib = 'value';
            $quote = '\'';
        break;

        case 'checkbox':
        case 'radio':
            $attrib = 'checked';
            $default_value = 'true';
            $quote = '';
        break;

        case 'select':
            $attrib = 'selected';
        break;
    }

    switch($type)
    {
        case 'text':
        case 'checkbox';
            foreach($data as $key=>$value)
            {
                if(strlen($value)>0)
                {
                    if(isset($default_value))
                    { $value = $default_value; }

                    $retval .= "document.{$formname}['{$key}'].{$attrib} = {$quote}{$value}{$quote};\n";
                }
            }
        break;

        case 'radio':
        case 'select':
            foreach($data as $key=>$value)
            {
                if(strlen($value)>0)
                {
                    $retval .= "
                                for(i=0;i<document.{$formname}.{$key}.length;i++)
                                {
                                    if(document.{$formname}.{$key}[i].value == '{$value}')
                                    {
                                        document.{$formname}.{$key}[i].{$attrib} = true;
                                    }
                                }
                    ";
                }
            }
        break;
    }

    return $retval;
}
?>
<form method="POST" action="test.php" name="myform">
  <input type="text" name="foo1" value="">
  <input type="text" name="foo2" value="">
  <br />
  <input type="checkbox" name="chk1" value="1">
  <input type="checkbox" name="chk2" value="2">
  <input type="checkbox" name="chk3" value="3">
  <br />
  <input type="radio" name="rad" value="1">
  <input type="radio" name="rad" value="2">
  <input type="radio" name="rad" value="3">
  <br />
  <select name="sel" size="3">
    <option value="a">a</option>
    <option value="b">b</option>
    <option value="c">c</option>
  </select>
  <br />
  <input type="submit" name="submit" value="Go">
</form>

<?php
if(!empty($_POST))
{
    $text['foo1'] = validate($_POST['foo1']);
    $text['foo2'] = validate($_POST['foo2']);

    $chk['chk1'] = validate($_POST['chk1']);
    $chk['chk2'] = validate($_POST['chk2']);
    $chk['chk3'] = validate($_POST['chk3']);

    $rad['rad'] = validate($_POST['rad']);

    $sel['sel'] = validate($_POST['sel']);

    echo "<script language=\"JavaScript\">\n";
    echo Fill_Form('myform','text',$text);
    echo Fill_Form('myform','checkbox',$chk);
    echo Fill_Form('myform','radio',$rad);
    echo Fill_Form('myform','select',$sel);
    echo "</script>\n";
}
?>
