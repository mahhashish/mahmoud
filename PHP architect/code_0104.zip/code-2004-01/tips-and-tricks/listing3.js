
document.myform['foo1'].value = 'asdf';
document.myform['foo2'].value = 'asdf';
document.myform['chk1'].checked = true;
document.myform['chk2'].checked = true;

