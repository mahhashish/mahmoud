<?


foreach($data as $key=>$value)
{
    if(strlen($value)>0)
    {
        if(isset($default_value))
        { $value = $default_value; }

        $retval .= "document.{$formname}['{$key}'].{$attrib} = 
                    {$quote}{$value}{$quote};\n";
    }
}


?>