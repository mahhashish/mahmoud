<?

switch($type)
{
    case 'text':
        $attrib = 'value';
        $quote = '\'';
    break;

    case 'checkbox':
    case 'radio':
        $attrib = 'checked';
        $default_value = 'true';
        $quote = '';
    break;

    case 'select':
        $attrib = 'selected';
    break;
}

?>
