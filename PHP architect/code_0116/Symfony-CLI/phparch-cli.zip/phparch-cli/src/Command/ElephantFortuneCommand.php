<?php
// src/Command/ElephantFortuneCommand.php
namespace PHPArch\Command;

use PHPArch\FileLoader;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\ArrayInput;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Logger\ConsoleLogger;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Yaml\Yaml;

class ElephantFortuneCommand extends Command
{

    protected function configure()
    {
        $this->setName('elephant:fortune')
            ->setDescription('Make the Elephant say a fortune.')
            ->setHelp(<<<EOF
The <info>%command.name%</info> will make the elephant say a fortune.
  <info>php %command.full_name%</info>
EOF
            );
    }

    public function execute(InputInterface $input, OutputInterface $output)
    {
        $fortuneCommand = $this->getApplication()->find('fortune');
        $arrayInput = new ArrayInput([
            'command' => 'fortunes',
        ]);
        $fortuneCommand->run($arrayInput, $output);

        $logger = new ConsoleLogger($output);
        $loader = new FileLoader($logger);

        $yamlFile = $loader->load('config/configuration.yml');
        $config = Yaml::parse($yamlFile);

        $elephant = $loader->load($config['elephant_file']);
        $output->writeln($elephant);

        if ($output->isVerbose()) {
            $value = $loader->load('v_elephant');
            $output->writeln($value);
        }
        if ($output->isVeryVerbose()) {
            $value = $loader->load('vv_elephant');
            $output->writeln($value);
        }
        if ($output->isDebug()) {
            $value = $loader->load('vvv_elephant');
            $output->writeln($value);
        }
    }
}
