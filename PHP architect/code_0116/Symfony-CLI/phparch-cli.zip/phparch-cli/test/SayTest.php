<?php
/*
 * This file is part of the Onema {phparch-cli} Package. 
 * For the full copyright and license information, 
 * please view the LICENSE file that was distributed 
 * with this source code.
 */

namespace PHPArch\Test;

use PHPArch\Command\SayCommand;
use Symfony\Component\Console\Application;
use Symfony\Component\Console\Tester\CommandTester;

/**
 * SayTest - Description.
 *
 * @author Juan Manuel Torres <kinojman@gmail.com>
 * @copyright (c) 2015, onema.io
 */
class SayTest extends \PHPUnit_Framework_TestCase
{
    public function testSayNothing()
    {
        $application = new Application();
        $application->add(new SayCommand());

        $command = $application->find('say');
        $tester = new CommandTester($command);
        $tester->execute(['command' => $command->getName()]);
        $this->assertRegExp('/I don\'t have anything to say/', $tester->getDisplay());
    }
}
