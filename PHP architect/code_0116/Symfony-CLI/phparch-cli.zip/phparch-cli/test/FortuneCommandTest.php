<?php
/*
 * This file is part of the Onema {phparch-cli} Package. 
 * For the full copyright and license information, 
 * please view the LICENSE file that was distributed 
 * with this source code.
 */

namespace PHPArch\Test;

use PHPArch\Command\FortuneCommand;
use PHPArch\Command\SayCommand;
use Symfony\Component\Console\Application;
use Symfony\Component\Console\Tester\CommandTester;

/**
 * FortuneCommandTest - Description.
 *
 * @author Juan Manuel Torres <kinojman@gmail.com>
 * @copyright (c) 2015, onema.io
 */
class FortuneCommandTest extends \PHPUnit_Framework_TestCase
{
    public function testSmallFortune()
    {
        $application = new Application();
        $application->add(new FortuneCommand());
        $application->add(new SayCommand());

        $command = $application->find('fortune');
        $tester = new CommandTester($command);
        $tester->execute([
            'command' => $command->getName(),
            '--path-to-fortunes' => __DIR__.'/small_fortune'
        ]);

        // small_fortunes contains quotes by Anonymous quotes only
        $this->assertRegExp('/Anonymous/', $tester->getDisplay());
    }
}
