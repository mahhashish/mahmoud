<?php

namespace PHPArch\test;

use PHPArch\FileLoader;
use Psr\Log\NullLogger;

class FileLoaderTest extends \PHPUnit_Framework_TestCase
{
    public function testLoadFile()
    {
        $loader = new FileLoader(new NullLogger());
        $yamlString = $loader->load('config/configuration.yml');
        $this->assertRegExp('/(elephant_file)/', $yamlString, 'Did not load the expected file');
    }

    public function testLoadInvalidFile()
    {
        $loader = new FileLoader(new NullLogger());
        $file = $loader->load('foo');
        $this->assertFalse($file, 'Invalid files should return false');
    }

    public function testUseLogger()
    {
        $loggerMock = $this->getMockBuilder('\Psr\Log\NullLogger')
            ->disableOriginalConstructor()
            ->setMethods(['info', 'error'])
            ->getMock();
        $loggerMock->expects($this->once())
            ->method('info')
            ->with($this->equalTo('About to load file: foo'));
        $loggerMock->expects($this->once())
            ->method($this->equalTo('error'))
            ->with('Invalid foo');

        $loader = new FileLoader($loggerMock);
        $loader->load('foo');

    }
}
